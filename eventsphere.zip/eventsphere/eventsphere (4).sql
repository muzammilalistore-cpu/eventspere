-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2026 at 03:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventsphere`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`admin_id`, `name`, `email`, `password_hash`, `status`, `created_at`) VALUES
(1, 'System Administrator', 'admin@eventsphere.local', '$2y$12$mdlbnVV8/TzSVPx/XM3sDOo5qRxd3tuXKf/vbxpu5i2XWvU1lb/U.', 'active', '2026-08-27 12:11:39');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int(10) UNSIGNED NOT NULL,
  `organizer_id` int(10) UNSIGNED NOT NULL,
  `event_id` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `organizer_id`, `event_id`, `title`, `message`, `created_at`) VALUES
(1, 0, NULL, 'Welcome to EventSphere', 'Explore upcoming campus events and register for the events you are interested in.', '2026-08-26 18:42:11'),
(2, 0, NULL, 'Event Registration Open', 'New campus events are now available. Check the Browse Events section for details.', '2026-08-26 18:42:11'),
(3, 12, NULL, 'hello', 'f', '2026-08-26 20:41:33');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` bigint(20) UNSIGNED NOT NULL,
  `registration_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `attendance_status` enum('present','absent','late') NOT NULL DEFAULT 'absent',
  `check_in_time` datetime DEFAULT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `marked_by` bigint(20) UNSIGNED DEFAULT NULL,
  `marked_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `registration_id`, `event_id`, `student_id`, `attendance_status`, `check_in_time`, `check_out_time`, `marked_by`, `marked_at`) VALUES
(1, 1, 1, 5, 'present', '2026-09-15 09:48:00', NULL, 1, '2026-08-27 12:18:01');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `audit_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(80) NOT NULL,
  `entity_id` bigint(20) UNSIGNED DEFAULT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_value`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`audit_id`, `user_id`, `action`, `entity_type`, `entity_id`, `old_value`, `new_value`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'toggle', 'user', 8, NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:17:32'),
(2, 1, 'status_update', 'event', 3, NULL, '{\"status\":\"published\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:20:17'),
(3, 1, 'status_update', 'event', 4, NULL, '{\"status\":\"published\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:20:20'),
(4, 1, 'create', 'event', 12, NULL, '{\"title\":\"JAWA\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:21:36'),
(5, 1, 'status_update', 'event', 4, NULL, '{\"status\":\"published\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:22:21'),
(6, 1, 'status_update', 'event', 3, NULL, '{\"status\":\"published\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:22:22'),
(7, 1, 'create', 'event', 14, NULL, '{\"title\":\"C # WorShop\"}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', '2026-08-27 12:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_sync`
--

CREATE TABLE `calendar_sync` (
  `sync_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `calendar_type` enum('google','outlook','apple','ics') NOT NULL,
  `calendar_event_id` varchar(255) DEFAULT NULL,
  `calendar_url` varchar(500) DEFAULT NULL,
  `synced_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calendar_sync`
--

INSERT INTO `calendar_sync` (`sync_id`, `user_id`, `event_id`, `calendar_type`, `calendar_event_id`, `calendar_url`, `synced_at`) VALUES
(1, 5, 1, 'ics', 'EVENTSPHERE-1', NULL, '2026-08-25 19:49:19');

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `certificate_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `registration_id` bigint(20) UNSIGNED NOT NULL,
  `certificate_number` varchar(80) NOT NULL,
  `certificate_type` enum('participation','winner','runner_up','achievement') NOT NULL DEFAULT 'participation',
  `certificate_url` varchar(500) DEFAULT NULL,
  `issued_at` datetime NOT NULL DEFAULT current_timestamp(),
  `certificate_fee` decimal(10,2) NOT NULL DEFAULT 500.00,
  `payment_status` enum('unpaid','paid') NOT NULL DEFAULT 'unpaid',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_reference` varchar(100) DEFAULT NULL,
  `payment_submitted_at` datetime DEFAULT NULL,
  `payment_approved_at` datetime DEFAULT NULL,
  `payment_rejection_reason` text DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `certificates`
--

INSERT INTO `certificates` (`certificate_id`, `event_id`, `student_id`, `registration_id`, `certificate_number`, `certificate_type`, `certificate_url`, `issued_at`, `certificate_fee`, `payment_status`, `payment_method`, `payment_reference`, `payment_submitted_at`, `payment_approved_at`, `payment_rejection_reason`, `paid_at`) VALUES
(1, 1, 5, 1, 'CERT-2026-00001-00005', 'participation', 'uploads/certificates/codesprint-certificate.pdf', '2026-08-25 19:49:18', 500.00, 'unpaid', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 4, 11, 8, 'ES-20260827-6EEF8A', 'winner', NULL, '2026-08-27 12:54:41', 500.00, 'unpaid', NULL, NULL, NULL, NULL, NULL, NULL),
(4, 3, 4, 5, 'ES-20260827-6C7773', 'achievement', NULL, '2026-08-27 15:03:42', 500.00, 'unpaid', NULL, NULL, NULL, NULL, NULL, NULL),
(5, 1, 11, 7, 'ES-20260827-545178', 'participation', NULL, '2026-08-27 15:59:49', 500.00, 'unpaid', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 9, 11, 9, 'ES-20260827-9EE797', 'participation', NULL, '2026-08-27 16:01:03', 500.00, 'unpaid', NULL, NULL, NULL, NULL, NULL, NULL),
(7, 9, 15, 10, 'ES-20260827-458F43', 'participation', NULL, '2026-08-27 16:14:39', 500.00, 'unpaid', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `certificate_fees`
--

CREATE TABLE `certificate_fees` (
  `fee_id` bigint(20) UNSIGNED NOT NULL,
  `certificate_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'PKR',
  `payment_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `payment_reference` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `certificate_fees`
--

INSERT INTO `certificate_fees` (`fee_id`, `certificate_id`, `student_id`, `amount`, `currency`, `payment_status`, `payment_reference`, `payment_method`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 300.00, 'PKR', 'pending', NULL, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_payments`
--

CREATE TABLE `certificate_payments` (
  `payment_id` bigint(20) UNSIGNED NOT NULL,
  `certificate_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'PKR',
  `payment_method` varchar(30) DEFAULT NULL,
  `transaction_reference` varchar(100) DEFAULT NULL,
  `status` enum('initiated','processing','paid','failed','cancelled') NOT NULL DEFAULT 'initiated',
  `gateway_name` varchar(50) DEFAULT NULL,
  `gateway_transaction_id` varchar(150) DEFAULT NULL,
  `failure_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `paid_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `message_id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied','closed') NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` bigint(20) UNSIGNED NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `department_code` varchar(30) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `department_code`, `description`, `status`, `created_at`) VALUES
(6, 'Computer Science', 'CS', 'Technology and software development department', 'active', '2026-08-25 19:45:21'),
(7, 'Business Administration', 'BBA', 'Business and management department', 'active', '2026-08-25 19:45:21'),
(8, 'Media Sciences', 'MEDIA', 'Media and creative studies department', 'active', '2026-08-25 19:45:21'),
(9, 'Electrical Engineering', 'EE', 'Engineering and technology department', 'active', '2026-08-25 19:45:21'),
(10, 'Sports Department', 'SPORTS', 'Sports and physical activities department', 'active', '2026-08-25 19:45:21');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(180) NOT NULL,
  `slug` varchar(220) NOT NULL,
  `short_description` varchar(300) DEFAULT NULL,
  `description` text NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `department_id` bigint(20) UNSIGNED NOT NULL,
  `organizer_id` bigint(20) UNSIGNED NOT NULL,
  `venue_id` bigint(20) UNSIGNED NOT NULL,
  `event_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `registration_open` datetime NOT NULL,
  `registration_close` datetime NOT NULL,
  `event_status` enum('draft','pending_approval','approved','published','cancelled','completed') NOT NULL DEFAULT 'draft',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `featured_image` varchar(500) DEFAULT NULL,
  `max_capacity` int(10) UNSIGNED NOT NULL,
  `waitlist_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `title`, `slug`, `short_description`, `description`, `category_id`, `department_id`, `organizer_id`, `venue_id`, `event_date`, `start_time`, `end_time`, `registration_open`, `registration_close`, `event_status`, `approved_by`, `approved_at`, `rejection_reason`, `cancelled_at`, `cancellation_reason`, `featured_image`, `max_capacity`, `waitlist_enabled`, `created_at`, `updated_at`) VALUES
(1, 'CodeSprint 2026', 'codesprint-2026', 'A practical programming competition for students.', 'CodeSprint 2026 is a programming competition focused on problem solving, web development and software engineering.', 1, 6, 9, 1, '2026-09-15', '10:00:00', '15:00:00', '2026-08-25 09:00:00', '2026-09-13 23:59:59', 'published', NULL, NULL, NULL, NULL, NULL, 'uploads/codesprint.jpg', 120, 1, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(2, 'Annual Cultural Evening', 'annual-cultural-evening', 'An evening of music, theatre, art and cultural performances.', 'Annual Cultural Evening brings together students for a celebration of music, theatre, art and cultural performances.', 2, 8, 10, 2, '2026-09-25', '17:00:00', '21:00:00', '2026-08-25 09:00:00', '2026-09-23 23:59:59', 'published', NULL, NULL, NULL, NULL, NULL, 'uploads/cultural-evening.jpg', 300, 1, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(3, 'Inter Department Cricket Cup', 'inter-department-cricket-cup', 'A competitive cricket tournament between college departments.', 'Students from different departments compete in a friendly and competitive cricket tournament.', 3, 10, 9, 3, '2026-10-05', '09:00:00', '16:00:00', '2026-08-25 09:00:00', '2026-10-02 23:59:59', 'published', NULL, NULL, NULL, NULL, NULL, 'uploads/cricket-cup.jpg', 180, 1, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(4, 'Future of Artificial Intelligence', 'future-of-artificial-intelligence', 'An educational seminar about AI and its future applications.', 'This seminar explores practical artificial intelligence applications, opportunities, challenges and responsible use of AI.', 5, 6, 9, 4, '2026-10-12', '11:00:00', '14:00:00', '2026-08-25 09:00:00', '2026-10-10 23:59:59', 'published', NULL, NULL, NULL, NULL, NULL, 'uploads/ai-seminar.jpg', 150, 1, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(9, 'Wordpress', 'wordpress', 'hello students !!', 'ggggggggggggggggg', 1, 8, 12, 5, '2026-08-26', '21:06:00', '22:07:00', '2026-08-26 22:08:00', '2026-08-26 23:09:00', 'published', NULL, NULL, NULL, NULL, NULL, NULL, 100, 1, '2026-08-26 20:06:12', '2026-08-27 01:34:04'),
(12, 'JavaScript', 'jawa-1787815296', 'hello', 'hi guys', 5, 6, 12, 4, '2026-08-27', '14:23:00', '16:24:00', '2026-08-27 13:04:00', '2026-08-27 13:18:00', 'published', NULL, NULL, NULL, NULL, NULL, NULL, 444, 1, '2026-08-27 12:21:36', '2026-08-27 12:26:43'),
(14, 'C # WorShop', 'c-worshop-1787815918', 'hello student', 'hsgshsnsns', 6, 6, 12, 2, '2026-08-28', '14:33:00', '17:36:00', '2026-08-28 12:31:00', '2026-08-28 18:37:00', 'published', NULL, NULL, NULL, NULL, NULL, NULL, 100, 1, '2026-08-27 12:31:58', '2026-08-27 12:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `event_announcements`
--

CREATE TABLE `event_announcements` (
  `announcement_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `priority` enum('normal','important','urgent') NOT NULL DEFAULT 'normal',
  `published_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `status` enum('draft','published','expired') NOT NULL DEFAULT 'draft',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_announcements`
--

INSERT INTO `event_announcements` (`announcement_id`, `event_id`, `created_by`, `title`, `message`, `priority`, `published_at`, `expires_at`, `status`, `created_at`) VALUES
(1, 1, 9, 'CodeSprint Registration Open', 'Registration is now open. Students are encouraged to register early because seats are limited.', 'important', '2026-08-25 19:49:18', NULL, 'published', '2026-08-25 19:49:18'),
(2, 2, 10, 'Cultural Evening Update', 'Participants should arrive at least 30 minutes before the program begins.', 'normal', '2026-08-25 19:49:18', NULL, 'published', '2026-08-25 19:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `event_capacity_changes`
--

CREATE TABLE `event_capacity_changes` (
  `change_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `requested_by` bigint(20) UNSIGNED NOT NULL,
  `old_capacity` int(10) UNSIGNED NOT NULL,
  `requested_capacity` int(10) UNSIGNED NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `status` enum('requested','approved','rejected','applied') NOT NULL DEFAULT 'requested',
  `requested_at` datetime NOT NULL DEFAULT current_timestamp(),
  `processed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `event_categories`
--

CREATE TABLE `event_categories` (
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(80) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_categories`
--

INSERT INTO `event_categories` (`category_id`, `category_name`, `description`, `icon`, `status`, `created_at`) VALUES
(1, 'Technical', 'Programming, technology and innovation events', 'fa-code', 'active', '2026-08-25 19:49:18'),
(2, 'Cultural', 'Cultural, artistic and creative activities', 'fa-masks-theater', 'inactive', '2026-08-25 19:49:18'),
(3, 'Sports', 'Sports and physical activities', 'fa-futbol', 'active', '2026-08-25 19:49:18'),
(4, 'Workshops', 'Practical workshops and training sessions', 'fa-chalkboard-user', 'active', '2026-08-25 19:49:18'),
(5, 'Seminars', 'Educational seminars and expert sessions', 'fa-microphone', 'active', '2026-08-25 19:49:18'),
(6, 'Competitions', 'Academic and intercollegiate competitions', 'fa-trophy', 'active', '2026-08-25 19:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `event_feedback`
--

CREATE TABLE `event_feedback` (
  `feedback_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `registration_id` bigint(20) UNSIGNED NOT NULL,
  `overall_rating` tinyint(3) UNSIGNED NOT NULL,
  `experience_rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `content_rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `organization_rating` tinyint(3) UNSIGNED DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `is_anonymous` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('visible','hidden') NOT NULL DEFAULT 'visible',
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_feedback`
--

INSERT INTO `event_feedback` (`feedback_id`, `event_id`, `rating`, `student_id`, `registration_id`, `overall_rating`, `experience_rating`, `content_rating`, `organization_rating`, `comments`, `is_anonymous`, `status`, `submitted_at`, `updated_at`) VALUES
(1, 2, NULL, 5, 3, 5, 5, 5, 5, 'The event was well organized and the overall experience was excellent.', 0, 'hidden', '2026-08-25 19:49:18', '2026-08-27 12:16:47');

-- --------------------------------------------------------

--
-- Table structure for table `event_organizers`
--

CREATE TABLE `event_organizers` (
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `organizer_role` enum('lead','coordinator','volunteer') NOT NULL DEFAULT 'coordinator',
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_organizers`
--

INSERT INTO `event_organizers` (`event_id`, `user_id`, `organizer_role`, `assigned_at`) VALUES
(1, 9, 'lead', '2026-08-25 19:49:18'),
(2, 10, 'lead', '2026-08-25 19:49:18'),
(9, 12, 'lead', '2026-08-26 20:06:12');

-- --------------------------------------------------------

--
-- Table structure for table `event_registrations`
--

CREATE TABLE `event_registrations` (
  `registration_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `registration_code` varchar(40) NOT NULL,
  `registered_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('confirmed','cancelled','attended','no_show') NOT NULL DEFAULT 'confirmed',
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_registrations`
--

INSERT INTO `event_registrations` (`registration_id`, `event_id`, `student_id`, `registration_code`, `registered_at`, `status`, `cancelled_at`, `cancellation_reason`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 'EVT-9BF31C7FF0', '2026-08-25 19:49:18', 'attended', NULL, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:19'),
(2, 1, 7, 'EVT-70EFDF2EC9', '2026-08-25 19:49:18', 'confirmed', NULL, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(3, 2, 5, 'EVT-8E296A067A', '2026-08-25 19:49:18', 'confirmed', NULL, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(4, 4, 6, 'EVT-D9D4F495E8', '2026-08-25 19:49:18', 'confirmed', NULL, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(5, 3, 4, 'EVS-1F7F222184', '2026-08-25 19:49:36', 'confirmed', NULL, NULL, '2026-08-25 19:49:36', '2026-08-25 19:49:36'),
(6, 3, 11, 'EVS-9EEA2A17F7', '2026-08-25 20:26:29', 'confirmed', NULL, NULL, '2026-08-25 20:26:29', '2026-08-25 20:26:29'),
(7, 1, 11, 'EVS-90936B7FBB', '2026-08-27 11:05:07', 'confirmed', NULL, NULL, '2026-08-27 11:05:07', '2026-08-27 11:05:07'),
(8, 4, 11, 'EVS-EFD7E12EFF', '2026-08-27 12:23:56', 'confirmed', NULL, NULL, '2026-08-27 12:23:56', '2026-08-27 12:23:56'),
(9, 9, 11, 'EVS-649DBD3DF2', '2026-08-27 12:24:37', 'attended', NULL, NULL, '2026-08-27 12:24:37', '2026-08-27 12:50:11'),
(10, 9, 15, 'EVS-924D6A6E01', '2026-08-27 16:07:41', 'confirmed', NULL, NULL, '2026-08-27 16:07:41', '2026-08-27 16:07:41');

-- --------------------------------------------------------

--
-- Table structure for table `event_share_logs`
--

CREATE TABLE `event_share_logs` (
  `share_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `platform` enum('facebook','whatsapp','twitter','linkedin','instagram','email') NOT NULL,
  `share_message` text DEFAULT NULL,
  `shared_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_share_logs`
--

INSERT INTO `event_share_logs` (`share_id`, `event_id`, `user_id`, `platform`, `share_message`, `shared_at`) VALUES
(1, 1, 5, 'whatsapp', 'Check out CodeSprint 2026 on EventSphere!', '2026-08-25 19:49:19');

-- --------------------------------------------------------

--
-- Table structure for table `event_tags`
--

CREATE TABLE `event_tags` (
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `tag_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_tags`
--

INSERT INTO `event_tags` (`tag_id`, `tag_name`) VALUES
(8, 'artificial-intelligence'),
(10, 'competition'),
(7, 'cricket'),
(4, 'culture'),
(5, 'music'),
(2, 'programming'),
(9, 'seminar'),
(6, 'sports'),
(3, 'students'),
(1, 'technology');

-- --------------------------------------------------------

--
-- Table structure for table `event_tag_map`
--

CREATE TABLE `event_tag_map` (
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `tag_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_tag_map`
--

INSERT INTO `event_tag_map` (`event_id`, `tag_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 3),
(2, 4),
(2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `event_waitlist`
--

CREATE TABLE `event_waitlist` (
  `waitlist_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `queue_position` int(10) UNSIGNED NOT NULL,
  `joined_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('waiting','promoted','cancelled','expired') NOT NULL DEFAULT 'waiting',
  `promoted_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_waitlist`
--

INSERT INTO `event_waitlist` (`waitlist_id`, `event_id`, `student_id`, `queue_position`, `joined_at`, `status`, `promoted_at`, `expires_at`) VALUES
(1, 1, 8, 1, '2026-08-25 19:49:18', 'waiting', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `feedback_ratings`
--

CREATE TABLE `feedback_ratings` (
  `rating_id` bigint(20) UNSIGNED NOT NULL,
  `feedback_id` bigint(20) UNSIGNED NOT NULL,
  `component` enum('venue','coordination','technical_arrangements','hospitality','content','time_management') NOT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback_ratings`
--

INSERT INTO `feedback_ratings` (`rating_id`, `feedback_id`, `component`, `rating`) VALUES
(1, 1, 'venue', 5),
(2, 1, 'coordination', 5),
(3, 1, 'hospitality', 4);

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `attempt_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`attempt_id`, `user_id`, `email`, `ip_address`, `success`, `attempted_at`) VALUES
(1, 1, 'admin@example.com', '::1', 0, '2026-08-25 19:22:27'),
(2, NULL, 'mm4979351@gmail.com', '::1', 0, '2026-08-25 19:45:44'),
(3, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:46:52'),
(4, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:38'),
(5, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:38'),
(6, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:39'),
(7, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:40'),
(8, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:41'),
(9, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:53'),
(10, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:54'),
(11, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:56'),
(12, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:57'),
(13, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:54:58'),
(14, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:55:09'),
(15, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 19:55:16'),
(16, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 20:18:08'),
(17, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:18:53'),
(18, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:19:02'),
(19, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:19:08'),
(20, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:19:09'),
(21, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:40:29'),
(22, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:40:40'),
(23, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:48:09'),
(24, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:48:10'),
(25, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:48:11'),
(26, 11, 'bilal@gmail.com', '::1', 1, '2026-08-25 20:50:11'),
(27, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-25 21:48:04'),
(28, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 13:11:43'),
(29, 11, 'bilal@gmail.com', '::1', 1, '2026-08-26 13:12:15'),
(30, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 13:12:34'),
(31, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 15:58:21'),
(32, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 17:36:02'),
(33, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 18:10:33'),
(34, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 18:10:35'),
(35, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 18:10:36'),
(36, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 18:10:36'),
(37, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 18:10:38'),
(38, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:11:36'),
(39, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:11:37'),
(40, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:12:11'),
(41, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:15:53'),
(42, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:15:54'),
(43, 11, 'bilal@gmail.com', '::1', 1, '2026-08-26 18:43:00'),
(44, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:43:01'),
(45, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:43:02'),
(46, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:43:12'),
(47, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:43:12'),
(48, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:51:29'),
(49, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:51:30'),
(50, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:52:42'),
(51, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:52:43'),
(52, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:52:52'),
(53, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:54:15'),
(54, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:57:29'),
(55, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:57:30'),
(56, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 18:59:30'),
(57, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:32:10'),
(58, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:33:12'),
(59, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:36:17'),
(60, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:42:19'),
(61, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:42:21'),
(62, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:42:23'),
(63, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:42:28'),
(64, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 19:42:33'),
(65, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 19:48:41'),
(66, 11, 'bilal@gmail.com', '::1', 1, '2026-08-26 19:48:51'),
(67, 13, 'muzammil@gmail.com', '::1', 1, '2026-08-26 19:48:57'),
(68, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 19:48:59'),
(69, 11, 'bilal@gmail.com', '::1', 1, '2026-08-26 20:29:20'),
(70, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 20:35:52'),
(71, 4, 'mm4979351@gmail.com', '::1', 1, '2026-08-26 20:39:28'),
(72, 12, 'fabiha.orginzer@yahoo.com', '::1', 1, '2026-08-26 20:50:00'),
(73, 11, 'bilal@gmail.com', '::1', 1, '2026-08-26 20:50:13');

-- --------------------------------------------------------

--
-- Table structure for table `media_favorites`
--

CREATE TABLE `media_favorites` (
  `favorite_id` bigint(20) UNSIGNED NOT NULL,
  `media_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `saved_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `media_gallery`
--

CREATE TABLE `media_gallery` (
  `media_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `uploaded_by` bigint(20) UNSIGNED NOT NULL,
  `media_type` enum('image','video') NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `visibility` enum('public','private') NOT NULL DEFAULT 'public',
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `media_gallery`
--

INSERT INTO `media_gallery` (`media_id`, `event_id`, `uploaded_by`, `media_type`, `file_url`, `thumbnail_url`, `title`, `caption`, `display_order`, `visibility`, `uploaded_at`) VALUES
(1, 1, 9, 'image', 'uploads/gallery/codesprint-1.jpg', 'uploads/gallery/codesprint-1.jpg', 'CodeSprint Participants', 'Students participating in the programming competition.', 1, 'public', '2026-08-25 19:49:18'),
(2, 2, 10, 'image', 'uploads/gallery/cultural-evening-1.jpg', 'uploads/gallery/cultural-evening-1.jpg', 'Cultural Evening', 'Students performing during the annual cultural evening.', 1, 'public', '2026-08-25 19:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `notification_type` enum('event','registration','reminder','deadline','certificate','announcement','system') NOT NULL,
  `event_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `title`, `message`, `notification_type`, `event_id`, `created_by`, `created_at`) VALUES
(1, 'CodeSprint Registration Confirmed', 'Your registration for CodeSprint 2026 has been confirmed.', 'registration', 1, 9, '2026-08-25 19:49:18'),
(2, 'Upcoming Event Reminder', 'CodeSprint 2026 is approaching. Please review your event details.', 'reminder', 1, 9, '2026-08-25 19:49:18'),
(3, 'hello', 'and', 'registration', 4, 1, '2026-08-27 12:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `registration_status_history`
--

CREATE TABLE `registration_status_history` (
  `history_id` bigint(20) UNSIGNED NOT NULL,
  `registration_id` bigint(20) UNSIGNED NOT NULL,
  `old_status` varchar(30) DEFAULT NULL,
  `new_status` varchar(30) NOT NULL,
  `changed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `changed_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration_status_history`
--

INSERT INTO `registration_status_history` (`history_id`, `registration_id`, `old_status`, `new_status`, `changed_by`, `reason`, `changed_at`) VALUES
(1, 1, 'confirmed', 'attended', 9, 'Attendance recorded during the event.', '2026-08-25 19:49:19'),
(2, 7, 'confirmed', 'confirmed', 1, 'Admin status update', '2026-08-27 12:16:28'),
(3, 6, 'confirmed', 'confirmed', 1, 'Admin status update', '2026-08-27 12:16:30'),
(4, 9, 'cancelled', 'confirmed', 1, 'Admin status update', '2026-08-27 12:28:10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('student','organizer') NOT NULL DEFAULT 'student',
  `account_status` enum('active','inactive','blocked') NOT NULL DEFAULT 'active',
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password_hash`, `role`, `account_status`, `email_verified`, `last_login_at`, `created_at`, `updated_at`) VALUES
(1, 'admin@example.com', '$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '', 'active', 1, NULL, '2026-08-25 18:58:36', '2026-08-25 18:58:36'),
(4, 'mm4979351@gmail.com', '$2y$10$L0.f6xbcD9d34t2M5RV8pey3VOa4627d1SLwLSkFC22Df00N6fCPK', 'student', 'active', 1, '2026-08-26 20:39:28', '2026-08-25 19:46:48', '2026-08-26 20:39:28'),
(5, 'student@eventsphere.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5aN9bJ8JQ5Zr3K1mK', 'student', 'active', 1, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(6, 'sara@eventsphere.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5aN9bJ8JQ5Zr3K1mK', 'student', 'active', 1, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(7, 'hamza@eventsphere.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5aN9bJ8JQ5Zr3K1mK', 'student', 'active', 1, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(8, 'ayesha@eventsphere.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5aN9bJ8JQ5Zr3K1mK', 'student', 'blocked', 1, NULL, '2026-08-25 19:49:18', '2026-08-27 12:17:32'),
(9, 'organizer@eventsphere.test', 'YAHAN_GENERATED_HASH', 'organizer', 'active', 1, NULL, '2026-08-25 19:49:18', '2026-08-26 18:51:08'),
(10, 'organizer2@eventsphere.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5aN9bJ8JQ5Zr3K1mK', 'organizer', 'active', 1, NULL, '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(11, 'bilal@gmail.com', '$2y$10$40cheGMsGJ1HqxlJFt8GL.q7Rio0XGJ1lao.aa5jjK./fuY2TWCiq', 'student', 'active', 1, '2026-08-26 20:50:13', '2026-08-25 20:18:44', '2026-08-26 20:50:13'),
(12, 'fabiha.orginzer@yahoo.com', '$2y$10$fNcYAIzv3ZTmJKMYqIAwd.PgG.g35qLdOsdnJPiSBhQSh0v9gUsHK', 'organizer', 'active', 0, '2026-08-26 20:50:00', '2026-08-25 23:06:27', '2026-08-26 20:50:00'),
(13, 'muzammil@gmail.com', '$2y$10$eWqQNtDfV1de10dxnI1CruZ1JQzBq1yDRmQnk2qwdp3xNDY7dlRKm', 'student', 'active', 1, '2026-08-26 19:48:57', '2026-08-26 18:11:19', '2026-08-26 19:48:57'),
(14, 'ali@gmail.com', '$2y$10$bj5FULxY0Q03pwpt0.W26O5R.zl9fV65hdb5rcgwq/i1rP5V5UmFu', 'student', 'active', 1, NULL, '2026-08-27 16:02:21', '2026-08-27 16:02:21'),
(15, 'alikhan@gmail.com', '$2y$10$CbsSR97fIEpSiIl.pStxRubpqxxoOMWn1plWrrSja7TZwQpOYxuLu', 'student', 'active', 1, NULL, '2026-08-27 16:06:38', '2026-08-27 16:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `user_notification_id` bigint(20) UNSIGNED NOT NULL,
  `notification_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`user_notification_id`, `notification_id`, `user_id`, `is_read`, `read_at`, `created_at`) VALUES
(1, 1, 7, 0, NULL, '2026-08-25 19:49:18'),
(2, 1, 5, 0, NULL, '2026-08-25 19:49:18'),
(3, 3, 1, 0, NULL, '2026-08-27 12:15:35'),
(4, 3, 4, 0, NULL, '2026-08-27 12:15:35'),
(5, 3, 5, 0, NULL, '2026-08-27 12:15:35'),
(6, 3, 6, 0, NULL, '2026-08-27 12:15:35'),
(7, 3, 7, 0, NULL, '2026-08-27 12:15:35'),
(8, 3, 8, 0, NULL, '2026-08-27 12:15:35'),
(9, 3, 9, 0, NULL, '2026-08-27 12:15:35'),
(10, 3, 10, 0, NULL, '2026-08-27 12:15:35'),
(11, 3, 11, 0, NULL, '2026-08-27 12:15:35'),
(12, 3, 12, 0, NULL, '2026-08-27 12:15:35'),
(13, 3, 13, 0, NULL, '2026-08-27 12:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `preference_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `event_reminders` tinyint(1) NOT NULL DEFAULT 1,
  `event_updates` tinyint(1) NOT NULL DEFAULT 1,
  `certificate_alerts` tinyint(1) NOT NULL DEFAULT 1,
  `preferred_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_preferences`
--

INSERT INTO `user_preferences` (`preference_id`, `user_id`, `email_notifications`, `event_reminders`, `event_updates`, `certificate_alerts`, `preferred_category_id`, `updated_at`) VALUES
(1, 1, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(2, 4, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(3, 5, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(4, 6, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(5, 7, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(6, 8, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(7, 9, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18'),
(8, 10, 1, 1, 1, 1, NULL, '2026-08-25 19:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `profile_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `profile_image` varchar(500) DEFAULT NULL,
  `department_id` bigint(20) UNSIGNED DEFAULT NULL,
  `enrollment_no` varchar(50) DEFAULT NULL,
  `semester` varchar(30) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`profile_id`, `user_id`, `full_name`, `phone`, `gender`, `date_of_birth`, `profile_image`, `department_id`, `enrollment_no`, `semester`, `bio`, `created_at`, `updated_at`) VALUES
(4, 4, 'Muhammad Muzammil', '03192945306', NULL, NULL, NULL, 6, '12345', NULL, 'hello', '2026-08-25 19:46:48', '2026-08-25 21:58:56'),
(5, 5, 'Ali Raza', '03001234567', 'Male', '2005-04-15', NULL, 6, 'CS-2026-001', '4th Semester', 'Computer Science student interested in programming and technology.', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(6, 6, 'Sara Ahmed', '03011234567', 'Female', '2005-08-20', NULL, 7, 'BBA-2026-014', '4th Semester', 'Business administration student interested in events and entrepreneurship.', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(7, 7, 'Hamza Khan', '03121234567', 'Male', '2004-12-10', NULL, 6, 'CS-2026-027', '5th Semester', 'Student interested in web development and software engineering.', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(8, 8, 'Ayesha Malik', '03211234567', 'Female', '2005-02-18', NULL, 8, 'MEDIA-2026-008', '3rd Semester', 'Media sciences student interested in photography and creative activities.', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(9, 9, 'Usman Ahmed', '03331234567', NULL, NULL, NULL, 6, NULL, NULL, 'College staff member responsible for technical events.', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(10, 10, 'Maham Sheikh', '03451234567', NULL, NULL, NULL, 8, NULL, NULL, 'College staff member responsible for cultural and media events.', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(11, 11, 'bilal ali', '', NULL, NULL, NULL, 7, '5543434', NULL, '', '2026-08-25 20:18:44', '2026-08-27 11:07:06'),
(12, 13, 'Muhammad Muzammil', NULL, NULL, NULL, NULL, 10, '335555', NULL, NULL, '2026-08-26 18:11:19', '2026-08-26 18:11:19'),
(13, 14, 'Ali', NULL, NULL, NULL, NULL, 6, '09876661', NULL, NULL, '2026-08-27 16:02:21', '2026-08-27 16:02:21'),
(14, 15, 'Ali khan', NULL, NULL, NULL, NULL, 8, '098766613', NULL, NULL, '2026-08-27 16:06:38', '2026-08-27 16:06:38');

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE `venues` (
  `venue_id` bigint(20) UNSIGNED NOT NULL,
  `venue_name` varchar(120) NOT NULL,
  `building_name` varchar(120) DEFAULT NULL,
  `floor_no` varchar(30) DEFAULT NULL,
  `location_description` varchar(255) DEFAULT NULL,
  `default_capacity` int(10) UNSIGNED NOT NULL,
  `status` enum('available','unavailable') NOT NULL DEFAULT 'available',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venues`
--

INSERT INTO `venues` (`venue_id`, `venue_name`, `building_name`, `floor_no`, `location_description`, `default_capacity`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Main Computer Lab', 'Technology Block', 'Ground Floor', 'Computer laboratory near the main entrance', 120, 'unavailable', '2026-08-25 19:49:18', '2026-08-27 12:19:06'),
(2, 'College Auditorium', 'Main Academic Block', 'Ground Floor', 'Main auditorium for large college events', 300, 'available', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(3, 'Sports Ground', 'Sports Complex', 'Ground', 'College outdoor sports ground', 250, 'available', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(4, 'Seminar Hall', 'Academic Block', 'First Floor', 'Large seminar and workshop hall', 150, 'available', '2026-08-25 19:49:18', '2026-08-25 19:49:18'),
(5, 'Innovation Lab', 'Technology Block', 'First Floor', 'Innovation and project development laboratory', 100, 'available', '2026-08-25 19:49:18', '2026-08-25 19:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `venue_capacity_history`
--

CREATE TABLE `venue_capacity_history` (
  `history_id` bigint(20) UNSIGNED NOT NULL,
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `old_capacity` int(10) UNSIGNED NOT NULL,
  `new_capacity` int(10) UNSIGNED NOT NULL,
  `changed_by` bigint(20) UNSIGNED NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `changed_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue_capacity_history`
--

INSERT INTO `venue_capacity_history` (`history_id`, `event_id`, `old_capacity`, `new_capacity`, `changed_by`, `reason`, `changed_at`) VALUES
(1, 1, 100, 120, 9, 'Venue capacity adjusted according to expected participation.', '2026-08-25 19:49:19');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_student_activity`
-- (See below for the actual view)
--
CREATE TABLE `vw_student_activity` (
`user_id` bigint(20) unsigned
,`full_name` varchar(120)
,`total_registrations` bigint(21)
,`attended_events` bigint(21)
,`certificates_received` bigint(21)
,`reviews_submitted` bigint(21)
);

-- --------------------------------------------------------

--
-- Structure for view `vw_student_activity`
--
DROP TABLE IF EXISTS `vw_student_activity`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_student_activity`  AS SELECT `u`.`user_id` AS `user_id`, `up`.`full_name` AS `full_name`, count(distinct `r`.`registration_id`) AS `total_registrations`, count(distinct case when `r`.`status` = 'attended' then `r`.`registration_id` end) AS `attended_events`, count(distinct `c`.`certificate_id`) AS `certificates_received`, count(distinct `f`.`feedback_id`) AS `reviews_submitted` FROM ((((`users` `u` left join `user_profiles` `up` on(`u`.`user_id` = `up`.`user_id`)) left join `event_registrations` `r` on(`u`.`user_id` = `r`.`student_id`)) left join `certificates` `c` on(`u`.`user_id` = `c`.`student_id`)) left join `event_feedback` `f` on(`u`.`user_id` = `f`.`student_id`)) WHERE `u`.`role` = 'student' GROUP BY `u`.`user_id`, `up`.`full_name` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`),
  ADD KEY `idx_announcements_created_at` (`created_at`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `registration_id` (`registration_id`),
  ADD KEY `fk_attendance_marker` (`marked_by`),
  ADD KEY `idx_attendance_event` (`event_id`),
  ADD KEY `idx_attendance_student` (`student_id`),
  ADD KEY `idx_attendance_status` (`attendance_status`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`audit_id`),
  ADD KEY `idx_audit_user` (`user_id`),
  ADD KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_audit_date` (`created_at`);

--
-- Indexes for table `calendar_sync`
--
ALTER TABLE `calendar_sync`
  ADD PRIMARY KEY (`sync_id`),
  ADD UNIQUE KEY `uq_calendar_sync` (`user_id`,`event_id`,`calendar_type`),
  ADD KEY `fk_calendar_event` (`event_id`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`certificate_id`),
  ADD UNIQUE KEY `certificate_number` (`certificate_number`),
  ADD UNIQUE KEY `uq_certificate_event_student` (`event_id`,`student_id`),
  ADD KEY `fk_certificate_student` (`student_id`),
  ADD KEY `fk_certificate_registration` (`registration_id`);

--
-- Indexes for table `certificate_fees`
--
ALTER TABLE `certificate_fees`
  ADD PRIMARY KEY (`fee_id`),
  ADD UNIQUE KEY `uq_certificate_student` (`certificate_id`,`student_id`),
  ADD KEY `fk_fee_certificate` (`certificate_id`),
  ADD KEY `fk_fee_student` (`student_id`),
  ADD KEY `idx_fee_status` (`payment_status`);

--
-- Indexes for table `certificate_payments`
--
ALTER TABLE `certificate_payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `uq_transaction_reference` (`transaction_reference`),
  ADD KEY `idx_certificate_payment` (`certificate_id`),
  ADD KEY `idx_student_payment` (`student_id`),
  ADD KEY `idx_payment_status` (`status`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `idx_contact_email` (`email`),
  ADD KEY `idx_contact_status` (`status`),
  ADD KEY `idx_contact_created` (`created_at`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`),
  ADD UNIQUE KEY `department_name` (`department_name`),
  ADD UNIQUE KEY `department_code` (`department_code`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx_events_date` (`event_date`),
  ADD KEY `idx_events_category` (`category_id`),
  ADD KEY `idx_events_department` (`department_id`),
  ADD KEY `idx_events_organizer` (`organizer_id`),
  ADD KEY `idx_events_venue` (`venue_id`),
  ADD KEY `idx_events_status` (`event_status`),
  ADD KEY `idx_events_search` (`title`,`event_date`);

--
-- Indexes for table `event_announcements`
--
ALTER TABLE `event_announcements`
  ADD PRIMARY KEY (`announcement_id`),
  ADD KEY `fk_announcement_creator` (`created_by`),
  ADD KEY `idx_announcement_event` (`event_id`),
  ADD KEY `idx_announcement_status` (`status`);

--
-- Indexes for table `event_capacity_changes`
--
ALTER TABLE `event_capacity_changes`
  ADD PRIMARY KEY (`change_id`),
  ADD KEY `fk_capacity_change_event` (`event_id`),
  ADD KEY `fk_capacity_change_user` (`requested_by`);

--
-- Indexes for table `event_categories`
--
ALTER TABLE `event_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `event_feedback`
--
ALTER TABLE `event_feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD UNIQUE KEY `uq_feedback_event_student` (`event_id`,`student_id`),
  ADD KEY `fk_feedback_registration` (`registration_id`),
  ADD KEY `idx_feedback_event` (`event_id`),
  ADD KEY `idx_feedback_student` (`student_id`);

--
-- Indexes for table `event_organizers`
--
ALTER TABLE `event_organizers`
  ADD PRIMARY KEY (`event_id`,`user_id`),
  ADD KEY `fk_event_org_user` (`user_id`);

--
-- Indexes for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD PRIMARY KEY (`registration_id`),
  ADD UNIQUE KEY `registration_code` (`registration_code`),
  ADD UNIQUE KEY `uq_event_student` (`event_id`,`student_id`),
  ADD KEY `idx_registration_event` (`event_id`),
  ADD KEY `idx_registration_student` (`student_id`),
  ADD KEY `idx_registration_status` (`status`),
  ADD KEY `idx_registration_date` (`registered_at`);

--
-- Indexes for table `event_share_logs`
--
ALTER TABLE `event_share_logs`
  ADD PRIMARY KEY (`share_id`),
  ADD KEY `fk_share_user` (`user_id`),
  ADD KEY `idx_share_event` (`event_id`),
  ADD KEY `idx_share_platform` (`platform`);

--
-- Indexes for table `event_tags`
--
ALTER TABLE `event_tags`
  ADD PRIMARY KEY (`tag_id`),
  ADD UNIQUE KEY `tag_name` (`tag_name`);

--
-- Indexes for table `event_tag_map`
--
ALTER TABLE `event_tag_map`
  ADD PRIMARY KEY (`event_id`,`tag_id`),
  ADD KEY `fk_event_tag_tag` (`tag_id`);

--
-- Indexes for table `event_waitlist`
--
ALTER TABLE `event_waitlist`
  ADD PRIMARY KEY (`waitlist_id`),
  ADD UNIQUE KEY `uq_waitlist_event_student` (`event_id`,`student_id`),
  ADD KEY `fk_waitlist_student` (`student_id`),
  ADD KEY `idx_waitlist_queue` (`event_id`,`status`,`queue_position`);

--
-- Indexes for table `feedback_ratings`
--
ALTER TABLE `feedback_ratings`
  ADD PRIMARY KEY (`rating_id`),
  ADD UNIQUE KEY `uq_feedback_component` (`feedback_id`,`component`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`attempt_id`),
  ADD KEY `fk_login_user` (`user_id`),
  ADD KEY `idx_login_email` (`email`),
  ADD KEY `idx_login_ip` (`ip_address`),
  ADD KEY `idx_login_date` (`attempted_at`);

--
-- Indexes for table `media_favorites`
--
ALTER TABLE `media_favorites`
  ADD PRIMARY KEY (`favorite_id`),
  ADD UNIQUE KEY `uq_media_user` (`media_id`,`user_id`),
  ADD KEY `fk_favorite_user` (`user_id`);

--
-- Indexes for table `media_gallery`
--
ALTER TABLE `media_gallery`
  ADD PRIMARY KEY (`media_id`),
  ADD KEY `fk_media_uploader` (`uploaded_by`),
  ADD KEY `idx_media_event` (`event_id`),
  ADD KEY `idx_media_type` (`media_type`),
  ADD KEY `idx_media_visibility` (`visibility`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `fk_notification_creator` (`created_by`),
  ADD KEY `idx_notification_type` (`notification_type`),
  ADD KEY `idx_notification_event` (`event_id`);

--
-- Indexes for table `registration_status_history`
--
ALTER TABLE `registration_status_history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `fk_reg_history_registration` (`registration_id`),
  ADD KEY `fk_reg_history_user` (`changed_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`account_status`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`user_notification_id`),
  ADD UNIQUE KEY `uq_user_notification` (`notification_id`,`user_id`),
  ADD KEY `idx_user_notifications` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`preference_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `enrollment_no` (`enrollment_no`),
  ADD KEY `idx_profile_department` (`department_id`),
  ADD KEY `idx_profile_name` (`full_name`);

--
-- Indexes for table `venues`
--
ALTER TABLE `venues`
  ADD PRIMARY KEY (`venue_id`),
  ADD KEY `idx_venue_status` (`status`);

--
-- Indexes for table `venue_capacity_history`
--
ALTER TABLE `venue_capacity_history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `fk_capacity_event` (`event_id`),
  ADD KEY `fk_capacity_user` (`changed_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `admin_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `audit_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `calendar_sync`
--
ALTER TABLE `calendar_sync`
  MODIFY `sync_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
  MODIFY `certificate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `certificate_fees`
--
ALTER TABLE `certificate_fees`
  MODIFY `fee_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `certificate_payments`
--
ALTER TABLE `certificate_payments`
  MODIFY `payment_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `message_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `event_announcements`
--
ALTER TABLE `event_announcements`
  MODIFY `announcement_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `event_capacity_changes`
--
ALTER TABLE `event_capacity_changes`
  MODIFY `change_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_categories`
--
ALTER TABLE `event_categories`
  MODIFY `category_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `event_feedback`
--
ALTER TABLE `event_feedback`
  MODIFY `feedback_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `event_registrations`
--
ALTER TABLE `event_registrations`
  MODIFY `registration_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `event_share_logs`
--
ALTER TABLE `event_share_logs`
  MODIFY `share_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `event_tags`
--
ALTER TABLE `event_tags`
  MODIFY `tag_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `event_waitlist`
--
ALTER TABLE `event_waitlist`
  MODIFY `waitlist_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback_ratings`
--
ALTER TABLE `feedback_ratings`
  MODIFY `rating_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `attempt_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `media_favorites`
--
ALTER TABLE `media_favorites`
  MODIFY `favorite_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `media_gallery`
--
ALTER TABLE `media_gallery`
  MODIFY `media_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration_status_history`
--
ALTER TABLE `registration_status_history`
  MODIFY `history_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `user_notification_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_preferences`
--
ALTER TABLE `user_preferences`
  MODIFY `preference_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `profile_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `venues`
--
ALTER TABLE `venues`
  MODIFY `venue_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `venue_capacity_history`
--
ALTER TABLE `venue_capacity_history`
  MODIFY `history_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `fk_attendance_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_attendance_marker` FOREIGN KEY (`marked_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_attendance_registration` FOREIGN KEY (`registration_id`) REFERENCES `event_registrations` (`registration_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `calendar_sync`
--
ALTER TABLE `calendar_sync`
  ADD CONSTRAINT `fk_calendar_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_calendar_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `certificates`
--
ALTER TABLE `certificates`
  ADD CONSTRAINT `fk_certificate_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_certificate_registration` FOREIGN KEY (`registration_id`) REFERENCES `event_registrations` (`registration_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_certificate_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `certificate_fees`
--
ALTER TABLE `certificate_fees`
  ADD CONSTRAINT `fk_fee_certificate` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`certificate_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fee_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `certificate_payments`
--
ALTER TABLE `certificate_payments`
  ADD CONSTRAINT `fk_certificate_payment_certificate` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`certificate_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_certificate_payment_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `fk_event_category` FOREIGN KEY (`category_id`) REFERENCES `event_categories` (`category_id`),
  ADD CONSTRAINT `fk_event_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`),
  ADD CONSTRAINT `fk_event_organizer` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_event_venue` FOREIGN KEY (`venue_id`) REFERENCES `venues` (`venue_id`);

--
-- Constraints for table `event_announcements`
--
ALTER TABLE `event_announcements`
  ADD CONSTRAINT `fk_announcement_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_announcement_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_capacity_changes`
--
ALTER TABLE `event_capacity_changes`
  ADD CONSTRAINT `fk_capacity_change_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_capacity_change_user` FOREIGN KEY (`requested_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `event_feedback`
--
ALTER TABLE `event_feedback`
  ADD CONSTRAINT `fk_feedback_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_feedback_registration` FOREIGN KEY (`registration_id`) REFERENCES `event_registrations` (`registration_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_feedback_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_organizers`
--
ALTER TABLE `event_organizers`
  ADD CONSTRAINT `fk_event_org_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_event_org_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_registrations`
--
ALTER TABLE `event_registrations`
  ADD CONSTRAINT `fk_registration_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_registration_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_share_logs`
--
ALTER TABLE `event_share_logs`
  ADD CONSTRAINT `fk_share_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_share_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_tag_map`
--
ALTER TABLE `event_tag_map`
  ADD CONSTRAINT `fk_event_tag_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_event_tag_tag` FOREIGN KEY (`tag_id`) REFERENCES `event_tags` (`tag_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_waitlist`
--
ALTER TABLE `event_waitlist`
  ADD CONSTRAINT `fk_waitlist_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_waitlist_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `feedback_ratings`
--
ALTER TABLE `feedback_ratings`
  ADD CONSTRAINT `fk_rating_feedback` FOREIGN KEY (`feedback_id`) REFERENCES `event_feedback` (`feedback_id`) ON DELETE CASCADE;

--
-- Constraints for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD CONSTRAINT `fk_login_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `media_favorites`
--
ALTER TABLE `media_favorites`
  ADD CONSTRAINT `fk_favorite_media` FOREIGN KEY (`media_id`) REFERENCES `media_gallery` (`media_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_favorite_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `media_gallery`
--
ALTER TABLE `media_gallery`
  ADD CONSTRAINT `fk_media_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_media_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notification_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_notification_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE;

--
-- Constraints for table `registration_status_history`
--
ALTER TABLE `registration_status_history`
  ADD CONSTRAINT `fk_reg_history_registration` FOREIGN KEY (`registration_id`) REFERENCES `event_registrations` (`registration_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_reg_history_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `fk_notification_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user_notification` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`notification_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD CONSTRAINT `fk_preferences_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `fk_profile_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_profile_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `venue_capacity_history`
--
ALTER TABLE `venue_capacity_history`
  ADD CONSTRAINT `fk_capacity_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_capacity_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
