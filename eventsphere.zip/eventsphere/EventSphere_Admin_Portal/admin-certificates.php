<?php

require 'db.php';
require 'functions.php';

$pageTitle = 'Certificates & Fees';

/*
|--------------------------------------------------------------------------
| ISSUE CERTIFICATE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $registration_id = (int) post('registration_id');
    $certificate_type = post('certificate_type', 'participation');

    $allowedTypes = [
        'participation',
        'winner',
        'runner_up',
        'achievement'
    ];

    if (!in_array($certificate_type, $allowedTypes, true)) {
        $certificate_type = 'participation';
    }

    if ($registration_id <= 0) {

        flash('error', 'Please select a valid registration.');
        header('Location: admin-certificates.php');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | GET REGISTRATION DETAILS
    |--------------------------------------------------------------------------
    */

    $check = $conn->prepare("
        SELECT
            r.registration_id,
            r.event_id,
            r.student_id,
            r.status,
            e.title AS event_title,
            u.email,
            COALESCE(up.full_name, u.email) AS student_name
        FROM event_registrations r
        INNER JOIN events e
            ON e.event_id = r.event_id
        INNER JOIN users u
            ON u.user_id = r.student_id
        LEFT JOIN user_profiles up
            ON up.user_id = u.user_id
        WHERE r.registration_id = ?
        LIMIT 1
    ");

    $check->bind_param('i', $registration_id);
    $check->execute();

    $registrationResult = $check->get_result();

    if ($registrationResult->num_rows === 0) {

        flash('error', 'Selected registration does not exist.');
        header('Location: admin-certificates.php');
        exit;
    }

    $registration = $registrationResult->fetch_assoc();

    $event_id = (int) $registration['event_id'];
    $student_id = (int) $registration['student_id'];

    /*
    |--------------------------------------------------------------------------
    | CHECK REGISTRATION STATUS
    |--------------------------------------------------------------------------
    */

    if (!in_array($registration['status'], ['confirmed', 'attended'], true)) {

        flash(
            'error',
            'Certificate can only be issued to confirmed or attended registrations.'
        );

        header('Location: admin-certificates.php');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | CHECK ATTENDANCE
    |--------------------------------------------------------------------------
    |
    | If attendance table exists and student has an attendance record,
    | require present/late.
    |
    */

    $attendanceStatus = null;

    $attendanceCheck = $conn->prepare("
        SELECT attendance_status
        FROM attendance
        WHERE registration_id = ?
        LIMIT 1
    ");

    if ($attendanceCheck) {

        $attendanceCheck->bind_param('i', $registration_id);
        $attendanceCheck->execute();

        $attendanceResult = $attendanceCheck->get_result();

        if ($attendanceResult->num_rows > 0) {

            $attendanceRow = $attendanceResult->fetch_assoc();
            $attendanceStatus = $attendanceRow['attendance_status'];

            if (!in_array(
                $attendanceStatus,
                ['present', 'late'],
                true
            )) {

                flash(
                    'error',
                    'Certificate cannot be issued because the student is not marked present.'
                );

                header('Location: admin-certificates.php');
                exit;
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | PREVENT DUPLICATE CERTIFICATE
    |--------------------------------------------------------------------------
    */

    $duplicate = $conn->prepare("
        SELECT certificate_id
        FROM certificates
        WHERE registration_id = ?
        LIMIT 1
    ");

    $duplicate->bind_param('i', $registration_id);
    $duplicate->execute();

    $duplicateResult = $duplicate->get_result();

    if ($duplicateResult->num_rows > 0) {

        flash(
            'error',
            'A certificate has already been issued for this registration.'
        );

        header('Location: admin-certificates.php');
        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | GENERATE CERTIFICATE NUMBER
    |--------------------------------------------------------------------------
    */

    $certificateNumber =
        'ES-' .
        date('Ymd') .
        '-' .
        strtoupper(bin2hex(random_bytes(3)));

    /*
    |--------------------------------------------------------------------------
    | INSERT CERTIFICATE
    |--------------------------------------------------------------------------
    */

    $insert = $conn->prepare("
        INSERT INTO certificates
        (
            event_id,
            student_id,
            registration_id,
            certificate_number,
            certificate_type
        )
        VALUES (?, ?, ?, ?, ?)
    ");

    $insert->bind_param(
        'iiiss',
        $event_id,
        $student_id,
        $registration_id,
        $certificateNumber,
        $certificate_type
    );

    if ($insert->execute()) {

        flash(
            'success',
            'Certificate issued successfully: ' . $certificateNumber
        );

    } else {

        flash(
            'error',
            'Unable to issue certificate.'
        );
    }

    header('Location: admin-certificates.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| REGISTRATION LIST
|--------------------------------------------------------------------------
|
| Instead of separately selecting event + student + registration ID,
| we use one registration dropdown.
|
*/

$registrations = $conn->query("
    SELECT
        r.registration_id,
        r.event_id,
        r.student_id,
        r.registration_code,
        r.status,

        e.title AS event_title,
        e.event_date,

        u.email,

        COALESCE(up.full_name, u.email) AS student_name

    FROM event_registrations r

    INNER JOIN events e
        ON e.event_id = r.event_id

    INNER JOIN users u
        ON u.user_id = r.student_id

    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id

    WHERE r.status IN ('confirmed', 'attended')

    ORDER BY
        e.event_date DESC,
        student_name ASC
");


/*
|--------------------------------------------------------------------------
| ISSUED CERTIFICATES
|--------------------------------------------------------------------------
*/

$rows = $conn->query("
    SELECT
        c.certificate_id,
        c.certificate_number,
        c.certificate_type,
        c.issued_at,

        e.title,

        u.email,

        COALESCE(up.full_name, u.email) AS student,

        r.registration_code

    FROM certificates c

    INNER JOIN events e
        ON e.event_id = c.event_id

    INNER JOIN users u
        ON u.user_id = c.student_id

    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id

    LEFT JOIN event_registrations r
        ON r.registration_id = c.registration_id

    ORDER BY c.issued_at DESC
");


require 'admin-header.php';

?>

<div class="row g-3">

    <!-- =========================================================
         ISSUE CERTIFICATE
    ========================================================== -->

    <div class="col-lg-4">

        <div class="cardx">

            <h5>Issue Certificate</h5>

            <p class="text-muted small mb-3">
                Select a registered participant. Event and student
                information will be taken automatically from the
                registration.
            </p>

            <form method="post">

                <label class="form-label">
                    Participant Registration
                </label>

                <select
                    name="registration_id"
                    class="form-select mb-3"
                    required
                >

                    <option value="">
                        Select Registration
                    </option>

                    <?php if ($registrations && $registrations->num_rows > 0): ?>

                        <?php while ($x = $registrations->fetch_assoc()): ?>

                            <option
                                value="<?= (int)$x['registration_id'] ?>"
                            >

                                <?= h($x['student_name']) ?>

                                —
                                <?= h($x['event_title']) ?>

                                <?php if (!empty($x['registration_code'])): ?>

                                    —
                                    <?= h($x['registration_code']) ?>

                                <?php endif; ?>

                                [<?= h($x['status']) ?>]

                            </option>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <option value="" disabled>
                            No eligible registrations found
                        </option>

                    <?php endif; ?>

                </select>


                <label class="form-label">
                    Certificate Type
                </label>

                <select
                    name="certificate_type"
                    class="form-select mb-3"
                    required
                >

                    <option value="participation">
                        Participation
                    </option>

                    <option value="winner">
                        Winner
                    </option>

                    <option value="runner_up">
                        Runner Up
                    </option>

                    <option value="achievement">
                        Achievement
                    </option>

                </select>


                <button
                    type="submit"
                    class="btn btn-primary w-100"
                >

                    Issue Certificate

                </button>

            </form>

        </div>

    </div>


    <!-- =========================================================
         ISSUED CERTIFICATES
    ========================================================== -->

    <div class="col-lg-8">

        <div class="cardx">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <h5 class="mb-1">
                        Issued Certificates
                    </h5>

                    <small class="text-muted">
                        Certificate history
                    </small>

                </div>

                <span class="badge bg-primary">

                    <?= $rows ? $rows->num_rows : 0 ?>

                    Certificates

                </span>

            </div>


            <div class="table-responsive mt-3">

                <table class="table align-middle">

                    <thead>

                        <tr>

                            <th>Certificate No.</th>

                            <th>Student</th>

                            <th>Event</th>

                            <th>Registration</th>

                            <th>Type</th>

                            <th>Issued</th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php if ($rows && $rows->num_rows > 0): ?>

                        <?php while ($r = $rows->fetch_assoc()): ?>

                            <tr>

                                <td>

                                    <strong>
                                        <?= h($r['certificate_number']) ?>
                                    </strong>

                                </td>


                                <td>

                                    <?= h($r['student']) ?>

                                    <div class="small text-muted">

                                        <?= h($r['email']) ?>

                                    </div>

                                </td>


                                <td>

                                    <?= h($r['title']) ?>

                                </td>


                                <td>

                                    <?php if (!empty($r['registration_code'])): ?>

                                        <span class="badge bg-light text-dark">

                                            <?= h($r['registration_code']) ?>

                                        </span>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            —
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php
                                    $badgeClass = 'bg-primary';

                                    if ($r['certificate_type'] === 'winner') {
                                        $badgeClass = 'bg-success';
                                    } elseif ($r['certificate_type'] === 'runner_up') {
                                        $badgeClass = 'bg-warning text-dark';
                                    } elseif ($r['certificate_type'] === 'achievement') {
                                        $badgeClass = 'bg-info text-dark';
                                    }
                                    ?>

                                    <span class="badge <?= $badgeClass ?>">

                                        <?= h(
                                            ucwords(
                                                str_replace(
                                                    '_',
                                                    ' ',
                                                    $r['certificate_type']
                                                )
                                            )
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <?= h($r['issued_at']) ?>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="6"
                                class="text-center text-muted py-4"
                            >

                                No certificates issued yet.

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>


<?php

require 'admin-footer.php';

?>