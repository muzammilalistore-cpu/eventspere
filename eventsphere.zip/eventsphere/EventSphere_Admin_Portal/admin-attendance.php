<?php

declare(strict_types=1);

require 'db.php';
require 'functions.php';

$pageTitle = 'Attendance Management';

/*
|--------------------------------------------------------------------------
| ADMIN CHECK
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$adminId = (int) $_SESSION['admin_id'];

$message = '';
$messageType = 'success';


/*
|--------------------------------------------------------------------------
| GENERATE ATTENDANCE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | GENERATE FOR EVENT
    |--------------------------------------------------------------------------
    */

    if ($action === 'generate') {

        $eventId = (int)($_POST['event_id'] ?? 0);

        if ($eventId <= 0) {

            $message = 'Please select a valid event.';
            $messageType = 'danger';

        } else {

            /*
            | Get confirmed registrations
            */

            $sql = "
                SELECT
                    r.registration_id,
                    r.event_id,
                    r.student_id
                FROM event_registrations r
                WHERE r.event_id = ?
                AND LOWER(COALESCE(r.status, '')) = 'confirmed'
            ";

            $stmt = mysqli_prepare($conn, $sql);

            if (!$stmt) {

                $message = mysqli_error($conn);
                $messageType = 'danger';

            } else {

                mysqli_stmt_bind_param(
                    $stmt,
                    'i',
                    $eventId
                );

                mysqli_stmt_execute($stmt);

                $result = mysqli_stmt_get_result($stmt);

                $inserted = 0;

                while ($registration = mysqli_fetch_assoc($result)) {

                    $registrationId = (int)$registration['registration_id'];
                    $studentId = (int)$registration['student_id'];

                    /*
                    | Check if attendance already exists
                    */

                    $check = mysqli_prepare(
                        $conn,
                        "
                        SELECT attendance_id
                        FROM attendance
                        WHERE registration_id = ?
                        LIMIT 1
                        "
                    );

                    mysqli_stmt_bind_param(
                        $check,
                        'i',
                        $registrationId
                    );

                    mysqli_stmt_execute($check);

                    mysqli_stmt_store_result($check);

                    $exists = mysqli_stmt_num_rows($check) > 0;

                    mysqli_stmt_close($check);


                    /*
                    | Create attendance record
                    */

                    if (!$exists) {

                        $insert = mysqli_prepare(
                            $conn,
                            "
                            INSERT INTO attendance
                            (
                                event_id,
                                student_id,
                                registration_id,
                                attendance_status,
                                marked_by,
                                marked_at
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                'absent',
                                ?,
                                NOW()
                            )
                            "
                        );

                        if ($insert) {

                            mysqli_stmt_bind_param(
                                $insert,
                                'iiii',
                                $eventId,
                                $studentId,
                                $registrationId,
                                $adminId
                            );

                            if (mysqli_stmt_execute($insert)) {
                                $inserted++;
                            }

                            mysqli_stmt_close($insert);
                        }
                    }
                }

                mysqli_stmt_close($stmt);

                $message =
                    $inserted .
                    ' attendance record(s) generated successfully.';

                $messageType = 'success';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE ATTENDANCE
    |--------------------------------------------------------------------------
    */

    if ($action === 'update') {

        $attendanceId =
            (int)($_POST['attendance_id'] ?? 0);

        $status =
            strtolower(
                trim(
                    (string)(
                        $_POST['attendance_status']
                        ?? ''
                    )
                )
            );

        $allowedStatuses = [
            'present',
            'absent',
            'late'
        ];

        if (
            $attendanceId <= 0 ||
            !in_array(
                $status,
                $allowedStatuses,
                true
            )
        ) {

            $message = 'Invalid attendance update.';
            $messageType = 'danger';

        } else {

            /*
            | Present / Late gets check-in time
            | Absent clears check-in time
            */

            if (
                $status === 'present' ||
                $status === 'late'
            ) {

                $sql = "
                    UPDATE attendance
                    SET
                        attendance_status = ?,
                        marked_by = ?,
                        marked_at = NOW(),
                        check_in_time = COALESCE(
                            check_in_time,
                            NOW()
                        )
                    WHERE attendance_id = ?
                ";

            } else {

                $sql = "
                    UPDATE attendance
                    SET
                        attendance_status = ?,
                        marked_by = ?,
                        marked_at = NOW(),
                        check_in_time = NULL
                    WHERE attendance_id = ?
                ";
            }

            $stmt = mysqli_prepare(
                $conn,
                $sql
            );

            if ($stmt) {

                mysqli_stmt_bind_param(
                    $stmt,
                    'sii',
                    $status,
                    $adminId,
                    $attendanceId
                );

                mysqli_stmt_execute($stmt);

                mysqli_stmt_close($stmt);

                $message =
                    'Attendance updated successfully.';

            } else {

                $message =
                    'Unable to update attendance.';

                $messageType = 'danger';
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| EVENTS
|--------------------------------------------------------------------------
*/

$events = mysqli_query(
    $conn,
    "
    SELECT
        event_id,
        title,
        event_date
    FROM events
    ORDER BY event_date DESC, event_id DESC
    "
);


/*
|--------------------------------------------------------------------------
| FILTER
|--------------------------------------------------------------------------
*/

$selectedEvent =
    (int)(
        $_GET['event_id']
        ?? 0
    );

$search =
    trim(
        (string)(
            $_GET['search']
            ?? ''
        )
    );


/*
|--------------------------------------------------------------------------
| ATTENDANCE QUERY
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        a.attendance_id,
        a.event_id,
        a.student_id,
        a.registration_id,
        a.attendance_status,
        a.check_in_time,
        a.marked_at,

        e.title AS event_title,
        e.event_date,

        u.email,

        COALESCE(
            up.full_name,
            u.email
        ) AS student_name,

        r.registration_code

    FROM attendance a

    INNER JOIN events e
        ON e.event_id = a.event_id

    INNER JOIN users u
        ON u.user_id = a.student_id

    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id

    INNER JOIN event_registrations r
        ON r.registration_id = a.registration_id

    WHERE 1 = 1
";


$params = [];
$types = '';


if ($selectedEvent > 0) {

    $sql .= "
        AND a.event_id = ?
    ";

    $params[] = $selectedEvent;
    $types .= 'i';
}


if ($search !== '') {

    $sql .= "
        AND (
            up.full_name LIKE ?
            OR u.email LIKE ?
            OR r.registration_code LIKE ?
        )
    ";

    $searchValue =
        '%' . $search . '%';

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;

    $types .= 'sss';
}


$sql .= "
    ORDER BY
        e.event_date DESC,
        student_name ASC
";


$stmt = mysqli_prepare(
    $conn,
    $sql
);


if ($stmt && !empty($params)) {

    mysqli_stmt_bind_param(
        $stmt,
        $types,
        ...$params
    );
}


$rows = [];

if ($stmt) {

    mysqli_stmt_execute($stmt);

    $result =
        mysqli_stmt_get_result($stmt);

    while (
        $row =
        mysqli_fetch_assoc($result)
    ) {

        $rows[] = $row;
    }

    mysqli_stmt_close($stmt);
}


/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$totalRecords = count($rows);

$presentCount = 0;
$lateCount = 0;
$absentCount = 0;

foreach ($rows as $row) {

    $status =
        strtolower(
            (string)(
                $row['attendance_status']
                ?? ''
            )
        );

    if ($status === 'present') {
        $presentCount++;
    }

    if ($status === 'late') {
        $lateCount++;
    }

    if ($status === 'absent') {
        $absentCount++;
    }
}


/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

require 'admin-header.php';

?>

<style>

.attendance-page {
    padding: 25px 0 60px;
}

.attendance-card {
    background: #fff;
    border: 1px solid #e7ebf0;
    border-radius: 18px;
    padding: 24px;
    box-shadow: 0 8px 30px rgba(15,23,42,.05);
}

.attendance-header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    margin-bottom:22px;
}

.attendance-header h4 {
    margin:0;
    font-weight:800;
    color:#172033;
}

.attendance-header p {
    margin:5px 0 0;
    color:#94a3b8;
    font-size:12px;
}

.attendance-stat {
    padding:20px;
    border:1px solid #e7ebf0;
    border-radius:16px;
    background:#fff;
    height:100%;
}

.attendance-stat small {
    color:#94a3b8;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.5px;
}

.attendance-stat h3 {
    margin:7px 0 0;
    font-weight:850;
}

.attendance-tools {
    background:#f8fafc;
    border:1px solid #e8edf3;
    padding:18px;
    border-radius:15px;
    margin-bottom:20px;
}

.status-badge {
    display:inline-flex;
    padding:6px 10px;
    border-radius:999px;
    font-size:10px;
    font-weight:800;
    text-transform:uppercase;
}

.status-present {
    background:#dcfce7;
    color:#166534;
}

.status-late {
    background:#fef3c7;
    color:#92400e;
}

.status-absent {
    background:#fee2e2;
    color:#991b1b;
}

.student-name {
    font-weight:750;
    color:#172033;
}

.student-email {
    display:block;
    color:#94a3b8;
    font-size:11px;
    margin-top:2px;
}

.attendance-actions {
    white-space:nowrap;
}

@media(max-width:767px){

    .attendance-header {
        align-items:flex-start;
        flex-direction:column;
    }

    .attendance-card {
        padding:17px;
    }

}

</style>


<div class="container attendance-page">

    <?php if ($message !== ''): ?>

        <div class="alert alert-<?= h($messageType) ?> alert-dismissible fade show">
            <?= h($message) ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
            ></button>
        </div>

    <?php endif; ?>


    <!-- HEADER -->

    <div class="attendance-card mb-4">

        <div class="attendance-header">

            <div>

                <h4>
                    Attendance Management
                </h4>

                <p>
                    Generate and manage attendance for registered participants.
                </p>

            </div>

        </div>


        <!-- GENERATE -->

        <form
            method="POST"
            class="row g-3"
        >

            <input
                type="hidden"
                name="action"
                value="generate"
            >

            <div class="col-md-8">

                <label class="form-label fw-bold">
                    Select Event
                </label>

                <select
                    name="event_id"
                    class="form-select"
                    required
                >

                    <option value="">
                        Select event
                    </option>

                    <?php while ($event = mysqli_fetch_assoc($events)): ?>

                        <option
                            value="<?= (int)$event['event_id'] ?>"
                        >

                            <?= h($event['title']) ?>

                            —
                            <?= h($event['event_date']) ?>

                        </option>

                    <?php endwhile; ?>

                </select>

            </div>


            <div class="col-md-4 d-flex align-items-end">

                <button
                    type="submit"
                    class="btn btn-primary w-100"
                >

                    Generate Attendance

                </button>

            </div>

        </form>

    </div>


    <!-- STATS -->

    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-3">

            <div class="attendance-stat">

                <small>
                    Total
                </small>

                <h3>
                    <?= $totalRecords ?>
                </h3>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="attendance-stat">

                <small>
                    Present
                </small>

                <h3>
                    <?= $presentCount ?>
                </h3>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="attendance-stat">

                <small>
                    Late
                </small>

                <h3>
                    <?= $lateCount ?>
                </h3>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="attendance-stat">

                <small>
                    Absent
                </small>

                <h3>
                    <?= $absentCount ?>
                </h3>

            </div>

        </div>

    </div>


    <!-- RECORDS -->

    <div class="attendance-card">

        <div class="attendance-header">

            <div>

                <h4>
                    Attendance Records
                </h4>

                <p>
                    Update participant attendance status.
                </p>

            </div>

        </div>


        <!-- FILTER -->

        <div class="attendance-tools">

            <form
                method="GET"
                class="row g-3"
            >

                <div class="col-md-5">

                    <label class="form-label fw-bold">
                        Event
                    </label>

                    <select
                        name="event_id"
                        class="form-select"
                    >

                        <option value="0">
                            All Events
                        </option>

                        <?php

                        /*
                        | Re-query events because previous result
                        | was consumed by mysqli_fetch_assoc().
                        */

                        $filterEvents = mysqli_query(
                            $conn,
                            "
                            SELECT
                                event_id,
                                title,
                                event_date
                            FROM events
                            ORDER BY event_date DESC
                            "
                        );

                        while (
                            $event =
                            mysqli_fetch_assoc(
                                $filterEvents
                            )
                        ):

                        ?>

                            <option
                                value="<?= (int)$event['event_id'] ?>"
                                <?= $selectedEvent === (int)$event['event_id'] ? 'selected' : '' ?>
                            >

                                <?= h($event['title']) ?>

                                —
                                <?= h($event['event_date']) ?>

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>


                <div class="col-md-5">

                    <label class="form-label fw-bold">
                        Search
                    </label>

                    <input
                        type="search"
                        name="search"
                        class="form-control"
                        value="<?= h($search) ?>"
                        placeholder="Student name, email or registration code..."
                    >

                </div>


                <div class="col-md-2 d-flex align-items-end">

                    <button
                        type="submit"
                        class="btn btn-dark w-100"
                    >
                        Search
                    </button>

                </div>

            </form>

        </div>


        <?php if (!empty($rows)): ?>

            <div class="table-responsive">

                <table class="table align-middle">

                    <thead>

                        <tr>

                            <th>
                                Student
                            </th>

                            <th>
                                Event
                            </th>

                            <th>
                                Registration
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Check-in
                            </th>

                            <th>
                                Update
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php foreach ($rows as $row): ?>

                            <?php

                            $status =
                                strtolower(
                                    (string)(
                                        $row[
                                            'attendance_status'
                                        ] ?? 'absent'
                                    )
                                );

                            ?>

                            <tr>

                                <td>

                                    <span class="student-name">

                                        <?= h(
                                            $row[
                                                'student_name'
                                            ]
                                        ) ?>

                                    </span>

                                    <span class="student-email">

                                        <?= h(
                                            $row[
                                                'email'
                                            ]
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <strong>

                                        <?= h(
                                            $row[
                                                'event_title'
                                            ]
                                        ) ?>

                                    </strong>

                                    <small class="d-block text-muted">

                                        <?= h(
                                            $row[
                                                'event_date'
                                            ]
                                        ) ?>

                                    </small>

                                </td>


                                <td>

                                    <?= h(
                                        $row[
                                            'registration_code'
                                        ]
                                    ) ?>

                                </td>


                                <td>

                                    <span
                                        class="status-badge status-<?= h($status) ?>"
                                    >

                                        <?= h($status) ?>

                                    </span>

                                </td>


                                <td>

                                    <?= !empty(
                                        $row[
                                            'check_in_time'
                                        ]
                                    )
                                        ? h(
                                            date(
                                                'd M Y, h:i A',
                                                strtotime(
                                                    $row[
                                                        'check_in_time'
                                                    ]
                                                )
                                            )
                                        )
                                        : '—'
                                    ?>

                                </td>


                                <td class="attendance-actions">

                                    <!-- PRESENT -->

                                    <form
                                        method="POST"
                                        class="d-inline"
                                    >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="update"
                                        >

                                        <input
                                            type="hidden"
                                            name="attendance_id"
                                            value="<?= (int)$row['attendance_id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="attendance_status"
                                            value="present"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-outline-success"
                                        >
                                            Present
                                        </button>

                                    </form>


                                    <!-- LATE -->

                                    <form
                                        method="POST"
                                        class="d-inline"
                                    >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="update"
                                        >

                                        <input
                                            type="hidden"
                                            name="attendance_id"
                                            value="<?= (int)$row['attendance_id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="attendance_status"
                                            value="late"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-outline-warning"
                                        >
                                            Late
                                        </button>

                                    </form>


                                    <!-- ABSENT -->

                                    <form
                                        method="POST"
                                        class="d-inline"
                                    >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="update"
                                        >

                                        <input
                                            type="hidden"
                                            name="attendance_id"
                                            value="<?= (int)$row['attendance_id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="attendance_status"
                                            value="absent"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-outline-danger"
                                        >
                                            Absent
                                        </button>

                                    </form>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="text-center py-5">

                <div style="font-size:40px;">
                    📋
                </div>

                <h5 class="mt-3">
                    No attendance records found
                </h5>

                <p class="text-muted">
                    Select an event and generate attendance records first.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>


<?php require 'admin-footer.php'; ?>