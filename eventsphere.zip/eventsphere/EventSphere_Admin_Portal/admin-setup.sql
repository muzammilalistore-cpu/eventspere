USE eventsphere;
CREATE TABLE IF NOT EXISTS admin_accounts (
 admin_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO admin_accounts(name,email,password_hash,status) VALUES
('System Administrator','admin@eventsphere.local','$2y$12$mdlbnVV8/TzSVPx/XM3sDOo5qRxd3tuXKf/vbxpu5i2XWvU1lb/U.','active')
ON DUPLICATE KEY UPDATE name=VALUES(name),status='active';
