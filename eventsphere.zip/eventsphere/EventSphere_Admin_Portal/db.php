<?php
declare(strict_types=1);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$host='127.0.0.1'; $user='root'; $pass=''; $db='eventsphere';
try { $conn=new mysqli($host,$user,$pass,$db); $conn->set_charset('utf8mb4'); }
catch(Throwable $e){ die('Database connection failed: '.htmlspecialchars($e->getMessage())); }
