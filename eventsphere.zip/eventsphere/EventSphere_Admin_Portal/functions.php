<?php
declare(strict_types=1);
if(session_status()!==PHP_SESSION_ACTIVE) session_start();
function h(mixed $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function admin_required():void{if(empty($_SESSION['admin_id'])){header('Location: admin-login.php');exit;}}
function flash(?string $type=null,?string $msg=null):?array{if($msg!==null){$_SESSION['flash']=[$type,$msg];return null;} $x=$_SESSION['flash']??null;unset($_SESSION['flash']);return $x;}
function audit(mysqli $c,int $uid,string $action,string $type,?int $id=null,?string $old=null,?string $new=null):void{try{$ip=$_SERVER['REMOTE_ADDR']??null;$ua=$_SERVER['HTTP_USER_AGENT']??null;$s=$c->prepare('INSERT INTO audit_logs(user_id,action,entity_type,entity_id,old_value,new_value,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?)');$s->bind_param('ississss',$uid,$action,$type,$id,$old,$new,$ip,$ua);$s->execute();}catch(Throwable $e){}}
function post(string $k,string $d=''):string{return trim($_POST[$k]??$d);}
