EVENTSPHERE ADMIN PORTAL
========================

Technology: Procedural PHP 8.2+, MySQL/MariaDB, Bootstrap 5.

FILES
-----
admin-login.php          Secure admin login
admin-dashboard.php     Dashboard and statistics
admin-users.php         Users / status management
admin-events.php        Events and publishing
admin-event-form.php    Create events
admin-registrations.php Registration management
admin-categories.php    Category management
admin-departments.php   Department management
admin-venues.php        Venue/capacity management
admin-media.php         Media gallery management
admin-reviews.php       Reviews moderation
admin-attendance.php    Attendance management
admin-certificates.php  Certificate management
admin-notifications.php Notifications
admin-reports.php       Reports
admin-logs.php          Audit logs
admin-setup.sql         Creates admin_accounts and default admin

db.php / functions.php / admin-header.php / admin-footer.php / admin.css / admin.js are shared files.

INSTALL
-------
1. Put all files in C:\xampp\htdocs\eventsphere\ (same root as the existing EventSphere PHP files).
2. Import your existing eventsphere.sql first.
3. Import admin-setup.sql in phpMyAdmin.
4. Edit db.php if your MySQL username/password/database differs.
5. Open /eventsphere/admin-login.php.

DEFAULT ADMIN
-------------
Email: admin@eventsphere.local
Password: Admin@123

IMPORTANT
---------
The portal uses the actual EventSphere schema: users, user_profiles, events, event_registrations,
media_gallery, event_feedback, attendance, certificates, certificate_fees, notifications,
user_notifications, departments, event_categories, venues, event_waitlist and audit_logs.
Admin authentication is kept in a separate admin_accounts table because the supplied users.role
enum contains student and organizer only.

Media file_url accepts a path/URL; upload handling can be connected to your existing upload convention.
Actual online certificate payment is intentionally not implemented because the SRS places payment
processing outside project scope.
