<?php

require "db.php";
require_once "functions.php";

require_auth();

$user = $_SESSION["user"];

if (($user["role"] ?? "") !== "student") {
    flash("Only students can register for events.", "danger");
    go("events.php");
}

$event_id = (int)($_GET["id"] ?? $_POST["event_id"] ?? 0);

if ($event_id <= 0) {
    flash("Invalid event selected.", "danger");
    go("events.php");
}

$event_sql = "
    SELECT
        e.event_id,
        e.title,
        e.description,
        e.short_description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.max_capacity,
        e.waitlist_enabled,
        c.category_name,
        d.department_name,
        v.venue_name,
        v.location_description
    FROM events e
    INNER JOIN event_categories c
        ON c.category_id = e.category_id
    INNER JOIN departments d
        ON d.department_id = e.department_id
    INNER JOIN venues v
        ON v.venue_id = e.venue_id
    WHERE e.event_id = ?
    AND e.event_status = 'published'
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $event_sql);
mysqli_stmt_bind_param($stmt, "i", $event_id);
mysqli_stmt_execute($stmt);
$event_result = mysqli_stmt_get_result($stmt);
$event = mysqli_fetch_assoc($event_result);

if (!$event) {
    flash("Event not found.", "danger");
    go("events.php");
}

$profile_sql = "
    SELECT
        up.full_name,
        up.enrollment_no,
        up.department_id,
        d.department_name
    FROM user_profiles up
    LEFT JOIN departments d
        ON d.department_id = up.department_id
    WHERE up.user_id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $profile_sql);
mysqli_stmt_bind_param($stmt, "i", $user["user_id"]);
mysqli_stmt_execute($stmt);
$profile_result = mysqli_stmt_get_result($stmt);
$profile = mysqli_fetch_assoc($profile_result);

$registered = false;
$registration_code = "";

$check_sql = "
    SELECT registration_id, registration_code, status
    FROM event_registrations
    WHERE event_id = ?
    AND student_id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $check_sql);
mysqli_stmt_bind_param(
    $stmt,
    "ii",
    $event_id,
    $user["user_id"]
);
mysqli_stmt_execute($stmt);
$check_result = mysqli_stmt_get_result($stmt);
$existing = mysqli_fetch_assoc($check_result);

if ($existing && in_array(
    $existing["status"],
    ["confirmed", "attended"],
    true
)) {
    $registered = true;
    $registration_code = $existing["registration_code"];
}

$count_sql = "
    SELECT COUNT(*) AS total
    FROM event_registrations
    WHERE event_id = ?
    AND status IN ('confirmed', 'attended')
";

$stmt = mysqli_prepare($conn, $count_sql);
mysqli_stmt_bind_param($stmt, "i", $event_id);
mysqli_stmt_execute($stmt);
$count_result = mysqli_stmt_get_result($stmt);
$count_row = mysqli_fetch_assoc($count_result);

$registered_count = (int)($count_row["total"] ?? 0);
$available_seats = max(
    0,
    (int)$event["max_capacity"] - $registered_count
);

$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST" && !$registered) {

    $phone = trim($_POST["phone"] ?? "");
    $semester = trim($_POST["semester"] ?? "");
    $message = trim($_POST["message"] ?? "");
    $terms = isset($_POST["terms"]) ? 1 : 0;

    if ($phone === "") {
        $errors[] = "Please enter your phone number.";
    } elseif (!preg_match("/^[0-9+\-\s()]{7,20}$/", $phone)) {
        $errors[] = "Please enter a valid phone number.";
    }

    if ($semester === "") {
        $errors[] = "Please select your semester.";
    }

    if (!$terms) {
        $errors[] = "Please confirm the registration terms.";
    }

    if ($existing) {
        if (in_array(
            $existing["status"],
            ["confirmed", "attended"],
            true
        )) {
            $errors[] = "You are already registered for this event.";
        }
    }

    if (!$errors && $available_seats <= 0) {

        if ((int)$event["waitlist_enabled"] === 1) {

            $wait_sql = "
                SELECT queue_position
                FROM event_waitlist
                WHERE event_id = ?
                AND student_id = ?
                AND status = 'waiting'
                LIMIT 1
            ";

            $stmt = mysqli_prepare($conn, $wait_sql);
            mysqli_stmt_bind_param(
                $stmt,
                "ii",
                $event_id,
                $user["user_id"]
            );
            mysqli_stmt_execute($stmt);
            $wait_result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($wait_result) > 0) {
                $errors[] = "You are already on the event waitlist.";
            } else {

                $position_sql = "
                    SELECT COALESCE(MAX(queue_position), 0) + 1 AS position
                    FROM event_waitlist
                    WHERE event_id = ?
                    AND status = 'waiting'
                ";

                $stmt = mysqli_prepare($conn, $position_sql);
                mysqli_stmt_bind_param(
                    $stmt,
                    "i",
                    $event_id
                );
                mysqli_stmt_execute($stmt);
                $position_result = mysqli_stmt_get_result($stmt);
                $position_row = mysqli_fetch_assoc($position_result);

                $position = (int)$position_row["position"];

                $insert_wait_sql = "
                    INSERT INTO event_waitlist
                    (
                        event_id,
                        student_id,
                        queue_position,
                        status
                    )
                    VALUES (?, ?, ?, 'waiting')
                ";

                $stmt = mysqli_prepare(
                    $conn,
                    $insert_wait_sql
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    "iii",
                    $event_id,
                    $user["user_id"],
                    $position
                );

                if (mysqli_stmt_execute($stmt)) {
                    flash(
                        "The event is currently full. You have been added to the waitlist.",
                        "warning"
                    );

                    go(
                        "event-details.php?id=" .
                        $event_id
                    );
                }

                $errors[] = "Unable to join the waitlist right now.";
            }

        } else {
            $errors[] = "This event is currently full.";
        }
    }

    if (!$errors && $available_seats > 0) {

        $registration_code =
            "EVS-" .
            strtoupper(
                bin2hex(random_bytes(5))
            );

        $insert_sql = "
            INSERT INTO event_registrations
            (
                event_id,
                student_id,
                registration_code,
                status
            )
            VALUES (?, ?, ?, 'confirmed')
        ";

        $stmt = mysqli_prepare(
            $conn,
            $insert_sql
        );

        mysqli_stmt_bind_param(
            $stmt,
            "iis",
            $event_id,
            $user["user_id"],
            $registration_code
        );

        if (mysqli_stmt_execute($stmt)) {

            flash(
                "Registration confirmed successfully. Your registration code is " .
                $registration_code .
                ".",
                "success"
            );

            go(
                "event-details.php?id=" .
                $event_id
            );
        }

        if (mysqli_errno($conn) == 1062) {
            $errors[] =
                "You are already registered for this event.";
        } else {
            $errors[] =
                "Registration could not be completed. Please try again.";
        }
    }
}

$title = "Register | " . $event["title"];

require "header.php";
?>

<style>

.registration-page {
    padding: 20px 0 65px;
}

.registration-wrap {
    max-width: 1080px;
    margin: 0 auto;
}

.registration-hero {
    position: relative;
    overflow: hidden;
    padding: 38px;
    margin-bottom: 24px;
    border-radius: 26px;
    color: #fff;
    background:
        radial-gradient(
            circle at 85% 15%,
            rgba(99,102,241,.34),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #1e1b4b
        );
    box-shadow: 0 25px 60px rgba(15,23,42,.16);
}

.registration-hero::before {
    content: "";
    position: absolute;
    width: 280px;
    height: 280px;
    right: -90px;
    top: -110px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 50%;
    animation: rotateCircle 18s linear infinite;
}

.registration-hero-content {
    position: relative;
    z-index: 2;
}

.registration-kicker {
    display: inline-flex;
    padding: 7px 11px;
    border-radius: 9px;
    background: rgba(255,255,255,.1);
    color: #c7d2fe;
    font-size: .72rem;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.registration-hero h1 {
    max-width: 760px;
    margin: 15px 0 10px;
    font-size: clamp(2rem, 5vw, 3.6rem);
    line-height: 1.03;
    font-weight: 850;
    letter-spacing: -.05em;
}

.registration-hero p {
    max-width: 700px;
    margin: 0;
    color: #cbd5e1;
    line-height: 1.7;
}

.event-summary {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 22px;
}

.summary-chip {
    padding: 8px 11px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 10px;
    background: rgba(255,255,255,.07);
    color: #e2e8f0;
    font-size: .78rem;
}

.registration-card {
    border: 1px solid #e5e7eb;
    border-radius: 24px;
    background: #fff;
    box-shadow: 0 15px 45px rgba(15,23,42,.07);
}

.form-section {
    padding: 30px;
}

.form-section + .form-section {
    border-top: 1px solid #eef2f7;
}

.form-title {
    margin-bottom: 22px;
}

.form-title h2 {
    margin: 0;
    color: #0f172a;
    font-size: 1.2rem;
    font-weight: 800;
}

.form-title p {
    margin: 5px 0 0;
    color: #64748b;
    font-size: .86rem;
}

.field-label {
    display: block;
    margin-bottom: 7px;
    color: #334155;
    font-size: .82rem;
    font-weight: 750;
}

.modern-input,
.modern-select,
.modern-textarea {
    width: 100%;
    border: 1px solid #dbe2ea;
    border-radius: 12px;
    padding: 12px 14px;
    color: #0f172a;
    background: #fff;
    outline: none;
    transition: .25s ease;
}

.modern-input:focus,
.modern-select:focus,
.modern-textarea:focus {
    border-color: #6366f1;
    box-shadow: 0 0 0 4px rgba(99,102,241,.1);
}

.modern-input[readonly] {
    background: #f8fafc;
    color: #64748b;
}

.modern-textarea {
    min-height: 120px;
    resize: vertical;
}

.info-box {
    padding: 20px;
    border-radius: 16px;
    background: #f8fafc;
    border: 1px solid #eef2f7;
}

.info-box strong {
    display: block;
    margin-bottom: 4px;
    color: #0f172a;
}

.info-box span {
    color: #64748b;
    font-size: .82rem;
}

.seat-status {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 18px;
    border-radius: 16px;
    background: #ecfdf5;
    border: 1px solid #bbf7d0;
}

.seat-status.full {
    background: #fff7ed;
    border-color: #fed7aa;
}

.seat-number {
    color: #047857;
    font-size: 1.5rem;
    font-weight: 850;
}

.seat-status.full .seat-number {
    color: #c2410c;
}

.terms-box {
    display: flex;
    gap: 10px;
    align-items: flex-start;
    margin-top: 22px;
}

.terms-box input {
    width: 18px;
    height: 18px;
    margin-top: 2px;
    accent-color: #4f46e5;
}

.terms-box label {
    color: #64748b;
    font-size: .82rem;
    line-height: 1.55;
}

.submit-btn {
    width: 100%;
    border: 0;
    border-radius: 13px;
    padding: 14px 20px;
    color: #fff;
    background: linear-gradient(
        135deg,
        #6366f1,
        #4f46e5
    );
    font-weight: 750;
    box-shadow: 0 12px 28px rgba(79,70,229,.25);
    transition: .3s ease;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 17px 35px rgba(79,70,229,.34);
}

.error-box {
    margin-bottom: 22px;
    padding: 15px 17px;
    border: 1px solid #fecaca;
    border-radius: 14px;
    background: #fef2f2;
    color: #991b1b;
}

.error-box ul {
    margin: 0;
    padding-left: 20px;
}

.side-card {
    padding: 24px;
    border: 1px solid #e5e7eb;
    border-radius: 20px;
    background: #fff;
    box-shadow: 0 10px 35px rgba(15,23,42,.05);
}

.side-card h3 {
    margin-bottom: 18px;
    color: #0f172a;
    font-size: 1rem;
    font-weight: 800;
}

.event-detail {
    display: flex;
    gap: 12px;
    padding: 13px 0;
    border-bottom: 1px solid #eef2f7;
}

.event-detail:last-child {
    border-bottom: 0;
}

.detail-label {
    color: #94a3b8;
    font-size: .75rem;
}

.detail-value {
    margin-top: 2px;
    color: #334155;
    font-size: .86rem;
    font-weight: 650;
}

@keyframes rotateCircle {

    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(360deg);
    }

}

@media (max-width: 767px) {

    .registration-hero {
        padding: 27px 22px;
    }

    .form-section {
        padding: 22px;
    }

}

</style>

<div class="registration-page">

    <div class="registration-wrap">

        <section class="registration-hero">

            <div class="registration-hero-content">

                <span class="registration-kicker">
                    Event Registration
                </span>

                <h1>
                    <?= e($event["title"]) ?>
                </h1>

                <p>
                    Complete your details below to reserve your place
                    at this college event.
                </p>

                <div class="event-summary">

                    <span class="summary-chip">
                        <?= e($event["category_name"]) ?>
                    </span>

                    <span class="summary-chip">
                        <?= e($event["event_date"]) ?>
                    </span>

                    <span class="summary-chip">
                        <?= e($event["start_time"]) ?>
                    </span>

                    <span class="summary-chip">
                        <?= e($event["venue_name"]) ?>
                    </span>

                </div>

            </div>

        </section>

        <div class="row g-4 align-items-start">

            <div class="col-lg-8">

                <div class="registration-card">

                    <form method="post">

                        <input
                            type="hidden"
                            name="event_id"
                            value="<?= $event_id ?>"
                        >

                        <?php if ($errors): ?>

                            <div class="form-section">

                                <div class="error-box">

                                    <ul>

                                        <?php foreach ($errors as $error): ?>

                                            <li>
                                                <?= e($error) ?>
                                            </li>

                                        <?php endforeach; ?>

                                    </ul>

                                </div>

                            </div>

                        <?php endif; ?>

                        <div class="form-section">

                            <div class="form-title">

                                <h2>
                                    Student Information
                                </h2>

                                <p>
                                    Your registered account information
                                    is shown automatically.
                                </p>

                            </div>

                            <div class="row g-3">

                                <div class="col-md-6">

                                    <label class="field-label">
                                        Full Name
                                    </label>

                                    <input
                                        class="modern-input"
                                        type="text"
                                        value="<?= e($profile["full_name"] ?? $user["email"]) ?>"
                                        readonly
                                    >

                                </div>

                                <div class="col-md-6">

                                    <label class="field-label">
                                        Enrollment Number
                                    </label>

                                    <input
                                        class="modern-input"
                                        type="text"
                                        value="<?= e($profile["enrollment_no"] ?? "Not available") ?>"
                                        readonly
                                    >

                                </div>

                                <div class="col-md-6">

                                    <label class="field-label">
                                        Email
                                    </label>

                                    <input
                                        class="modern-input"
                                        type="email"
                                        value="<?= e($user["email"]) ?>"
                                        readonly
                                    >

                                </div>

                                <div class="col-md-6">

                                    <label class="field-label">
                                        Department
                                    </label>

                                    <input
                                        class="modern-input"
                                        type="text"
                                        value="<?= e($profile["department_name"] ?? "Not assigned") ?>"
                                        readonly
                                    >

                                </div>

                            </div>

                        </div>

                        <div class="form-section">

                            <div class="form-title">

                                <h2>
                                    Registration Details
                                </h2>

                                <p>
                                    Add the information required for
                                    your event registration.
                                </p>

                            </div>

                            <div class="row g-3">

                                <div class="col-md-6">

                                    <label class="field-label">
                                        Phone Number
                                    </label>

                                    <input
                                        class="modern-input"
                                        type="tel"
                                        name="phone"
                                        value="<?= e($_POST["phone"] ?? "") ?>"
                                        placeholder="+92 300 1234567"
                                        required
                                    >

                                </div>

                                <div class="col-md-6">

                                    <label class="field-label">
                                        Semester
                                    </label>

                                    <select
                                        class="modern-select"
                                        name="semester"
                                        required
                                    >

                                        <option value="">
                                            Select Semester
                                        </option>

                                        <?php

                                        $semesters = [
                                            "1st Semester",
                                            "2nd Semester",
                                            "3rd Semester",
                                            "4th Semester",
                                            "5th Semester",
                                            "6th Semester",
                                            "7th Semester",
                                            "8th Semester"
                                        ];

                                        foreach ($semesters as $semester):
                                        ?>

                                            <option
                                                value="<?= e($semester) ?>"
                                                <?= ($_POST["semester"] ?? "") === $semester ? "selected" : "" ?>
                                            >
                                                <?= e($semester) ?>
                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                </div>

                                <div class="col-12">

                                    <label class="field-label">
                                        Message
                                    </label>

                                    <textarea
                                        class="modern-textarea"
                                        name="message"
                                        maxlength="500"
                                        placeholder="Anything you would like the organizer to know?"><?= e($_POST["message"] ?? "") ?></textarea>

                                </div>

                            </div>

                            <div class="seat-status <?= $available_seats <= 0 ? "full" : "" ?> mt-4">

                                <div>

                                    <strong>
                                        <?= $available_seats > 0 ? "Seats Available" : "Event Full" ?>
                                    </strong>

                                    <div class="text-muted small">
                                        <?= $available_seats > 0
                                            ? "You can confirm your registration now."
                                            : (
                                                (int)$event["waitlist_enabled"] === 1
                                                    ? "You can join the waitlist."
                                                    : "Registration is currently unavailable."
                                            )
                                        ?>
                                    </div>

                                </div>

                                <div class="seat-number">
                                    <?= $available_seats > 0
                                        ? $available_seats
                                        : "Full"
                                    ?>
                                </div>

                            </div>

                            <?php if ($available_seats > 0 || (int)$event["waitlist_enabled"] === 1): ?>

                                <div class="terms-box">

                                    <input
                                        type="checkbox"
                                        id="terms"
                                        name="terms"
                                        value="1"
                                        <?= isset($_POST["terms"]) ? "checked" : "" ?>
                                        required
                                    >

                                    <label for="terms">
                                        I confirm that the information provided
                                        is correct and I understand that my
                                        registration will be recorded for this event.
                                    </label>

                                </div>

                                <button
                                    type="submit"
                                    class="submit-btn mt-4"
                                >
                                    <?= $available_seats > 0
                                        ? "Confirm Registration"
                                        : "Join Event Waitlist"
                                    ?>
                                </button>

                            <?php endif; ?>

                        </div>

                    </form>

                </div>

            </div>

            <div class="col-lg-4">

                <div class="side-card">

                    <h3>
                        Event Information
                    </h3>

                    <div class="event-detail">

                        <div>
                            <div class="detail-label">
                                Date
                            </div>

                            <div class="detail-value">
                                <?= e($event["event_date"]) ?>
                            </div>
                        </div>

                    </div>

                    <div class="event-detail">

                        <div>
                            <div class="detail-label">
                                Time
                            </div>

                            <div class="detail-value">
                                <?= e($event["start_time"]) ?>
                                -
                                <?= e($event["end_time"]) ?>
                            </div>
                        </div>

                    </div>

                    <div class="event-detail">

                        <div>
                            <div class="detail-label">
                                Department
                            </div>

                            <div class="detail-value">
                                <?= e($event["department_name"]) ?>
                            </div>
                        </div>

                    </div>

                    <div class="event-detail">

                        <div>
                            <div class="detail-label">
                                Venue
                            </div>

                            <div class="detail-value">
                                <?= e($event["venue_name"]) ?>
                            </div>
                        </div>

                    </div>

                    <div class="event-detail">

                        <div>
                            <div class="detail-label">
                                Available Seats
                            </div>

                            <div class="detail-value">
                                <?= $available_seats ?>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="side-card mt-4">

                    <h3>
                        Registration Process
                    </h3>

                    <div class="info-box mb-2">
                        <strong>01. Complete Details</strong>
                        <span>
                            Provide your contact and semester information.
                        </span>
                    </div>

                    <div class="info-box mb-2">
                        <strong>02. Confirm</strong>
                        <span>
                            Submit your registration while seats are available.
                        </span>
                    </div>

                    <div class="info-box">
                        <strong>03. Attend</strong>
                        <span>
                            Keep your registration confirmation for the event.
                        </span>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php require "footer.php"; ?>