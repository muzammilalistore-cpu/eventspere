<?php

require "db.php";
require_once "functions.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_auth();

if (!isset($_SESSION["user"]["user_id"])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION["user"];
$userId = (int)$user["user_id"];

$title = "Profile | EventSphere";

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$errors = [];
$success = "";

$profile = [
    "full_name" => "",
    "phone" => "",
    "bio" => ""
];

$stmt = mysqli_prepare(
    $conn,
    "SELECT full_name, phone, bio
     FROM user_profiles
     WHERE user_id = ?
     LIMIT 1"
);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $userId);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);

    if ($data) {
        $profile = array_merge($profile, $data);
    }

    mysqli_stmt_close($stmt);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $fullName = trim($_POST["full_name"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $bio = trim($_POST["bio"] ?? "");

    if ($fullName === "") {
        $errors[] = "Full name is required.";
    }

    if (mb_strlen($fullName) > 150) {
        $errors[] = "Full name cannot exceed 150 characters.";
    }

    if (mb_strlen($phone) > 30) {
        $errors[] = "Phone number cannot exceed 30 characters.";
    }

    if (mb_strlen($bio) > 1000) {
        $errors[] = "Bio cannot exceed 1000 characters.";
    }

    if (empty($errors)) {

        $checkStmt = mysqli_prepare(
            $conn,
            "SELECT user_id
             FROM user_profiles
             WHERE user_id = ?
             LIMIT 1"
        );

        $profileExists = false;

        if ($checkStmt) {
            mysqli_stmt_bind_param($checkStmt, "i", $userId);
            mysqli_stmt_execute($checkStmt);

            $checkResult = mysqli_stmt_get_result($checkStmt);
            $profileExists = mysqli_num_rows($checkResult) > 0;

            mysqli_stmt_close($checkStmt);
        }

        if ($profileExists) {

            $updateStmt = mysqli_prepare(
                $conn,
                "UPDATE user_profiles
                 SET full_name = ?,
                     phone = ?,
                     bio = ?
                 WHERE user_id = ?"
            );

            if ($updateStmt) {

                mysqli_stmt_bind_param(
                    $updateStmt,
                    "sssi",
                    $fullName,
                    $phone,
                    $bio,
                    $userId
                );

                if (mysqli_stmt_execute($updateStmt)) {
                    $success = "Profile updated successfully.";

                    $profile["full_name"] = $fullName;
                    $profile["phone"] = $phone;
                    $profile["bio"] = $bio;
                } else {
                    $errors[] = "Unable to update your profile.";
                }

                mysqli_stmt_close($updateStmt);

            } else {
                $errors[] = "Unable to process your profile.";
            }

        } else {

            $insertStmt = mysqli_prepare(
                $conn,
                "INSERT INTO user_profiles
                (user_id, full_name, phone, bio)
                VALUES (?, ?, ?, ?)"
            );

            if ($insertStmt) {

                mysqli_stmt_bind_param(
                    $insertStmt,
                    "isss",
                    $userId,
                    $fullName,
                    $phone,
                    $bio
                );

                if (mysqli_stmt_execute($insertStmt)) {
                    $success = "Profile created successfully.";

                    $profile["full_name"] = $fullName;
                    $profile["phone"] = $phone;
                    $profile["bio"] = $bio;
                } else {
                    $errors[] = "Unable to create your profile.";
                }

                mysqli_stmt_close($insertStmt);

            } else {
                $errors[] = "Unable to process your profile.";
            }
        }
    }
}

$email = $user["email"] ?? "";

$displayName = !empty($profile["full_name"])
    ? $profile["full_name"]
    : $email;

$avatarLetter = strtoupper(
    substr(trim($displayName), 0, 1)
);

require "header.php";
?>

<style>
.profile-page {
    padding: 42px 0 80px;
}

.profile-hero {
    position: relative;
    overflow: hidden;
    padding: 40px;
    border-radius: 28px;
    color: #fff;
    background:
        radial-gradient(circle at 88% 10%, rgba(99,102,241,.35), transparent 30%),
        radial-gradient(circle at 8% 92%, rgba(34,211,238,.14), transparent 28%),
        linear-gradient(135deg, #0f172a, #1e293b 55%, #312e81);
    box-shadow: 0 28px 70px rgba(15,23,42,.16);
}

.profile-hero-content {
    display: flex;
    align-items: center;
    gap: 20px;
}

.profile-avatar {
    width: 76px;
    height: 76px;
    flex: 0 0 76px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 22px;
    background: rgba(255,255,255,.13);
    border: 1px solid rgba(255,255,255,.18);
    font-size: 28px;
    font-weight: 850;
}

.profile-eyebrow {
    color: #a5b4fc;
    font-size: 11px;
    font-weight: 850;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.profile-hero h1 {
    margin: 7px 0 5px;
    font-size: 34px;
    font-weight: 850;
    letter-spacing: -.04em;
}

.profile-hero p {
    margin: 0;
    color: #cbd5e1;
    font-size: 13px;
}

.profile-card {
    margin-top: 30px;
    padding: 30px;
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 22px;
    box-shadow: 0 10px 34px rgba(15,23,42,.045);
}

.profile-card h2 {
    margin: 0 0 6px;
    color: #0f172a;
    font-size: 21px;
    font-weight: 850;
}

.profile-card-description {
    margin: 0 0 25px;
    color: #94a3b8;
    font-size: 12px;
    line-height: 1.6;
}

.profile-form-group {
    margin-bottom: 20px;
}

.profile-label {
    display: block;
    margin-bottom: 8px;
    color: #1e293b;
    font-size: 12px;
    font-weight: 800;
}

.profile-control {
    width: 100%;
    min-height: 49px;
    padding: 0 14px;
    border: 1px solid #dfe5ec;
    border-radius: 12px;
    outline: none;
    background: #f8fafc;
    color: #172033;
    font-size: 13px;
    transition: .2s ease;
}

.profile-control:focus {
    border-color: #6366f1;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(99,102,241,.09);
}

textarea.profile-control {
    min-height: 125px;
    padding: 13px 14px;
    resize: vertical;
}

.profile-email {
    background: #f1f5f9;
    color: #64748b;
    cursor: not-allowed;
}

.profile-submit {
    width: 100%;
    min-height: 52px;
    border: 0;
    border-radius: 13px;
    color: #fff;
    background: linear-gradient(135deg, #6366f1, #4f46e5);
    font-size: 13px;
    font-weight: 850;
    box-shadow: 0 12px 27px rgba(79,70,229,.22);
    transition: .25s ease;
}

.profile-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 17px 35px rgba(79,70,229,.3);
}

.profile-alert {
    margin-bottom: 20px;
    padding: 14px 16px;
    border-radius: 13px;
    font-size: 12px;
    line-height: 1.6;
}

.profile-error {
    border: 1px solid #fecaca;
    background: #fef2f2;
    color: #b91c1c;
}

.profile-success {
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
    color: #15803d;
}

.profile-info {
    margin-top: 30px;
    padding: 25px;
    border: 1px solid #e8edf3;
    border-radius: 18px;
    background: #fafbfc;
}

.profile-info-title {
    margin-bottom: 18px;
    color: #172033;
    font-size: 15px;
    font-weight: 850;
}

.profile-info-row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 0;
    border-bottom: 1px solid #edf0f4;
}

.profile-info-row:last-child {
    border-bottom: 0;
}

.profile-info-label {
    color: #94a3b8;
    font-size: 11px;
}

.profile-info-value {
    color: #334155;
    font-size: 12px;
    font-weight: 750;
    text-align: right;
}

@media (max-width: 767px) {
    .profile-page {
        padding: 25px 0 55px;
    }

    .profile-hero {
        padding: 27px 22px;
        border-radius: 21px;
    }

    .profile-hero-content {
        align-items: flex-start;
        flex-direction: column;
    }

    .profile-hero h1 {
        font-size: 29px;
    }

    .profile-card {
        padding: 21px;
    }

    .profile-info-row {
        flex-direction: column;
        gap: 4px;
    }

    .profile-info-value {
        text-align: left;
    }
}
</style>

<div class="container profile-page">

    <section class="profile-hero">

        <div class="profile-hero-content">

            <div class="profile-avatar">
                <?= h($avatarLetter) ?>
            </div>

            <div>

                <span class="profile-eyebrow">
                    EventSphere Student Portal
                </span>

                <h1>
                    <?= h($displayName) ?>
                </h1>

                <p>
                    Manage your personal profile information.
                </p>

            </div>

        </div>

    </section>

    <div class="profile-card">

        <h2>
            Personal Information
        </h2>

        <p class="profile-card-description">
            Keep your profile information up to date.
        </p>

        <?php if (!empty($errors)): ?>

            <div class="profile-alert profile-error">

                <?php foreach ($errors as $error): ?>

                    <div>
                        <?= h($error) ?>
                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

        <?php if ($success !== ""): ?>

            <div class="profile-alert profile-success">
                <?= h($success) ?>
            </div>

        <?php endif; ?>

        <form method="post" action="profile.php">

            <div class="row g-4">

                <div class="col-md-6">

                    <div class="profile-form-group">

                        <label class="profile-label" for="full_name">
                            Full Name
                        </label>

                        <input
                            type="text"
                            class="profile-control"
                            id="full_name"
                            name="full_name"
                            maxlength="150"
                            value="<?= h($profile["full_name"]) ?>"
                            required
                        >

                    </div>

                </div>

                <div class="col-md-6">

                    <div class="profile-form-group">

                        <label class="profile-label" for="email">
                            Email Address
                        </label>

                        <input
                            type="email"
                            class="profile-control profile-email"
                            id="email"
                            value="<?= h($email) ?>"
                            readonly
                        >

                    </div>

                </div>

                <div class="col-md-6">

                    <div class="profile-form-group">

                        <label class="profile-label" for="phone">
                            Phone Number
                        </label>

                        <input
                            type="text"
                            class="profile-control"
                            id="phone"
                            name="phone"
                            maxlength="30"
                            value="<?= h($profile["phone"]) ?>"
                            placeholder="Enter your phone number"
                        >

                    </div>

                </div>

                <div class="col-12">

                    <div class="profile-form-group">

                        <label class="profile-label" for="bio">
                            About Me
                        </label>

                        <textarea
                            class="profile-control"
                            id="bio"
                            name="bio"
                            maxlength="1000"
                            placeholder="Write something about yourself..."
                        ><?= h($profile["bio"]) ?></textarea>

                    </div>

                </div>

                <div class="col-12">

                    <button
                        type="submit"
                        class="profile-submit"
                    >
                        Save Profile
                    </button>

                </div>

            </div>

        </form>

        <div class="profile-info">

            <div class="profile-info-title">
                Account Information
            </div>

            <div class="profile-info-row">

                <span class="profile-info-label">
                    Account ID
                </span>

                <span class="profile-info-value">
                    #<?= $userId ?>
                </span>

            </div>

            <div class="profile-info-row">

                <span class="profile-info-label">
                    Email
                </span>

                <span class="profile-info-value">
                    <?= h($email) ?>
                </span>

            </div>

            <div class="profile-info-row">

                <span class="profile-info-label">
                    Account Type
                </span>

                <span class="profile-info-value">
                    <?= h(ucfirst($user["role"] ?? "Student")) ?>
                </span>

            </div>

        </div>

    </div>

</div>

<?php require "footer.php"; ?>