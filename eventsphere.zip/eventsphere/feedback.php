<?php

require "db.php";
require_once "functions.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_auth();

if (!isset($_SESSION["user"]["user_id"])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION["user"];
$userId = (int)$user["user_id"];

if (($user["role"] ?? "") !== "student") {
    header("Location: index.php");
    exit;
}

$title = "Event Feedback | EventSphere";

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$errors = [];
$success = "";

$studentName = $user["email"] ?? "Student";

$profileStmt = mysqli_prepare(
    $conn,
    "SELECT full_name
     FROM user_profiles
     WHERE user_id = ?
     LIMIT 1"
);

if ($profileStmt) {
    mysqli_stmt_bind_param($profileStmt, "i", $userId);
    mysqli_stmt_execute($profileStmt);

    $profileResult = mysqli_stmt_get_result($profileStmt);
    $profile = mysqli_fetch_assoc($profileResult);

    if (!empty($profile["full_name"])) {
        $studentName = $profile["full_name"];
    }

    mysqli_stmt_close($profileStmt);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $registrationId = filter_input(
        INPUT_POST,
        "registration_id",
        FILTER_VALIDATE_INT
    );

    $overallRating = filter_input(
        INPUT_POST,
        "overall_rating",
        FILTER_VALIDATE_INT
    );

    $experienceRating = filter_input(
        INPUT_POST,
        "experience_rating",
        FILTER_VALIDATE_INT
    );

    $contentRating = filter_input(
        INPUT_POST,
        "content_rating",
        FILTER_VALIDATE_INT
    );

    $organizationRating = filter_input(
        INPUT_POST,
        "organization_rating",
        FILTER_VALIDATE_INT
    );

    $comments = trim($_POST["comments"] ?? "");
    $isAnonymous = isset($_POST["is_anonymous"]) ? 1 : 0;

    if (!$registrationId || $registrationId < 1) {
        $errors[] = "Please select an event.";
    }

    $ratings = [
        "Overall rating" => $overallRating,
        "Experience rating" => $experienceRating,
        "Content rating" => $contentRating,
        "Organization rating" => $organizationRating
    ];

    foreach ($ratings as $label => $rating) {
        if ($rating === false || $rating === null || $rating < 1 || $rating > 5) {
            $errors[] = $label . " must be between 1 and 5.";
        }
    }

    if ($comments !== "") {
        if (mb_strlen($comments) < 10) {
            $errors[] = "Comments must contain at least 10 characters.";
        }

        if (mb_strlen($comments) > 1000) {
            $errors[] = "Comments cannot exceed 1000 characters.";
        }
    }

    $verifiedEvent = null;

    if (empty($errors)) {

        $verifyStmt = mysqli_prepare(
            $conn,
            "SELECT
                r.registration_id,
                r.event_id,
                e.title,
                e.event_date,
                e.start_time,
                c.category_name
             FROM event_registrations r
             INNER JOIN events e
                ON e.event_id = r.event_id
             LEFT JOIN attendance a
                ON a.event_id = r.event_id
                AND a.student_id = r.student_id
             LEFT JOIN event_categories c
                ON c.category_id = e.category_id
             WHERE r.registration_id = ?
             AND r.student_id = ?
             AND r.status IN ('confirmed', 'attended')
             AND (
                    r.status = 'attended'
                    OR a.attendance_status = 'present'
                 )
             AND e.event_date < CURDATE()
             LIMIT 1"
        );

        if ($verifyStmt) {

            mysqli_stmt_bind_param(
                $verifyStmt,
                "ii",
                $registrationId,
                $userId
            );

            mysqli_stmt_execute($verifyStmt);

            $verifyResult = mysqli_stmt_get_result($verifyStmt);
            $verifiedEvent = mysqli_fetch_assoc($verifyResult);

            mysqli_stmt_close($verifyStmt);

            if (!$verifiedEvent) {
                $errors[] = "Feedback is available only for events you have attended.";
            }

        } else {
            $errors[] = "Unable to verify the selected event.";
        }
    }

    if (empty($errors)) {

        $duplicateStmt = mysqli_prepare(
            $conn,
            "SELECT feedback_id
             FROM event_feedback
             WHERE registration_id = ?
             LIMIT 1"
        );

        if ($duplicateStmt) {

            mysqli_stmt_bind_param(
                $duplicateStmt,
                "i",
                $registrationId
            );

            mysqli_stmt_execute($duplicateStmt);

            $duplicateResult = mysqli_stmt_get_result($duplicateStmt);
            $existingFeedback = mysqli_fetch_assoc($duplicateResult);

            mysqli_stmt_close($duplicateStmt);

            if ($existingFeedback) {
                $errors[] = "You have already submitted feedback for this event.";
            }

        } else {
            $errors[] = "Unable to check your previous feedback.";
        }
    }

    if (empty($errors)) {

        $eventId = (int)$verifiedEvent["event_id"];
        $status = "visible";

        $insertStmt = mysqli_prepare(
            $conn,
            "INSERT INTO event_feedback
            (
                event_id,
                student_id,
                registration_id,
                overall_rating,
                experience_rating,
                content_rating,
                organization_rating,
                comments,
                is_anonymous,
                status,
                submitted_at,
                updated_at
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())"
        );

        if ($insertStmt) {

            mysqli_stmt_bind_param(
                $insertStmt,
                "iiiiiiisis",
                $eventId,
                $userId,
                $registrationId,
                $overallRating,
                $experienceRating,
                $contentRating,
                $organizationRating,
                $comments,
                $isAnonymous,
                $status
            );

            if (mysqli_stmt_execute($insertStmt)) {
                $success = "Your feedback has been submitted successfully.";
                $_POST = [];
            } else {
                $errors[] = "Your feedback could not be submitted. Please try again.";
            }

            mysqli_stmt_close($insertStmt);

        } else {
            $errors[] = "Unable to process your feedback.";
        }
    }
}

$eligibleEvents = [];

$eventsStmt = mysqli_prepare(
    $conn,
    "SELECT
        r.registration_id,
        e.event_id,
        e.title,
        e.event_date,
        e.start_time,
        c.category_name,
        ef.feedback_id,
        ef.overall_rating,
        ef.experience_rating,
        ef.content_rating,
        ef.organization_rating,
        ef.comments,
        ef.is_anonymous,
        ef.status,
        ef.submitted_at
     FROM event_registrations r
     INNER JOIN events e
        ON e.event_id = r.event_id
     LEFT JOIN attendance a
        ON a.event_id = r.event_id
        AND a.student_id = r.student_id
     LEFT JOIN event_categories c
        ON c.category_id = e.category_id
     LEFT JOIN event_feedback ef
        ON ef.registration_id = r.registration_id
     WHERE r.student_id = ?
     AND r.status IN ('confirmed', 'attended')
     AND (
            r.status = 'attended'
            OR a.attendance_status = 'present'
         )
     AND e.event_date < CURDATE()
     ORDER BY e.event_date DESC, e.start_time DESC"
);

if ($eventsStmt) {

    mysqli_stmt_bind_param(
        $eventsStmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($eventsStmt);

    $eventsResult = mysqli_stmt_get_result($eventsStmt);

    while ($row = mysqli_fetch_assoc($eventsResult)) {
        $eligibleEvents[] = $row;
    }

    mysqli_stmt_close($eventsStmt);
}

$feedbackCount = 0;
$pendingEvents = [];
$submittedEvents = [];

foreach ($eligibleEvents as $event) {

    if (!empty($event["feedback_id"])) {
        $feedbackCount++;
        $submittedEvents[] = $event;
    } else {
        $pendingEvents[] = $event;
    }
}

$pendingCount = count($pendingEvents);

require "header.php";
?>

<style>

.feedback-page {
    padding: 42px 0 80px;
}

.feedback-hero {
    position: relative;
    overflow: hidden;
    padding: 44px;
    border-radius: 28px;
    color: #fff;
    background:
        radial-gradient(circle at 88% 10%, rgba(99,102,241,.35), transparent 30%),
        radial-gradient(circle at 8% 92%, rgba(34,211,238,.14), transparent 28%),
        linear-gradient(135deg, #0f172a, #1e293b 55%, #312e81);
    box-shadow: 0 28px 70px rgba(15,23,42,.16);
}

.feedback-eyebrow {
    color: #a5b4fc;
    font-size: 11px;
    font-weight: 850;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.feedback-hero h1 {
    margin: 9px 0 10px;
    font-size: 40px;
    font-weight: 850;
    letter-spacing: -.045em;
}

.feedback-hero p {
    max-width: 700px;
    margin: 0;
    color: #cbd5e1;
    line-height: 1.75;
}

.feedback-user {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 25px;
}

.feedback-avatar {
    width: 46px;
    height: 46px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: rgba(255,255,255,.13);
    border: 1px solid rgba(255,255,255,.18);
    font-weight: 850;
}

.feedback-user small {
    color: #94a3b8;
}

.feedback-stats {
    margin-top: 24px;
}

.feedback-stat {
    height: 100%;
    padding: 23px;
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 20px;
    box-shadow: 0 9px 30px rgba(15,23,42,.05);
    transition: .25s ease;
}

.feedback-stat:hover {
    transform: translateY(-4px);
    box-shadow: 0 17px 40px rgba(15,23,42,.08);
}

.feedback-stat strong {
    display: block;
    color: #0f172a;
    font-size: 30px;
    font-weight: 850;
}

.feedback-stat span {
    color: #64748b;
    font-size: 12px;
}

.feedback-content {
    margin-top: 32px;
}

.feedback-card {
    height: 100%;
    padding: 28px;
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 22px;
    box-shadow: 0 10px 34px rgba(15,23,42,.045);
}

.feedback-card h2 {
    margin: 0 0 6px;
    color: #0f172a;
    font-size: 21px;
    font-weight: 850;
}

.feedback-card > p {
    margin: 0 0 23px;
    color: #94a3b8;
    font-size: 12px;
    line-height: 1.6;
}

.alert-box {
    margin-bottom: 20px;
    padding: 14px 16px;
    border-radius: 13px;
    font-size: 12px;
    line-height: 1.6;
}

.alert-error {
    border: 1px solid #fecaca;
    background: #fef2f2;
    color: #b91c1c;
}

.alert-success {
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
    color: #15803d;
}

.form-group {
    margin-bottom: 19px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: #1e293b;
    font-size: 12px;
    font-weight: 800;
}

.form-control,
.form-select {
    width: 100%;
    min-height: 49px;
    padding: 0 14px;
    border: 1px solid #dfe5ec;
    border-radius: 12px;
    outline: none;
    background: #f8fafc;
    color: #172033;
    font-size: 13px;
    transition: .2s ease;
}

.form-control:focus,
.form-select:focus {
    border-color: #6366f1;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(99,102,241,.09);
}

textarea.form-control {
    min-height: 135px;
    padding: 13px 14px;
    resize: vertical;
}

.rating-group {
    display: grid;
    gap: 10px;
}

.rating-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 14px;
    border: 1px solid #e8edf3;
    border-radius: 12px;
    background: #fafbfc;
}

.rating-title {
    color: #334155;
    font-size: 12px;
    font-weight: 750;
}

.stars {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-end;
    gap: 2px;
}

.stars input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}

.stars label {
    cursor: pointer;
    color: #cbd5e1;
    font-size: 22px;
    line-height: 1;
    transition: .15s ease;
}

.stars label:hover,
.stars label:hover ~ label,
.stars input:checked ~ label {
    color: #f59e0b;
}

.anonymous-box {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 13px 14px;
    border: 1px solid #e8edf3;
    border-radius: 12px;
    background: #fafbfc;
}

.anonymous-box input {
    margin-top: 3px;
}

.anonymous-box strong {
    display: block;
    color: #334155;
    font-size: 12px;
}

.anonymous-box span {
    display: block;
    margin-top: 3px;
    color: #94a3b8;
    font-size: 10px;
    line-height: 1.5;
}

.submit-feedback {
    width: 100%;
    min-height: 52px;
    border: 0;
    border-radius: 13px;
    color: #fff;
    background: linear-gradient(135deg, #6366f1, #4f46e5);
    font-size: 13px;
    font-weight: 850;
    box-shadow: 0 12px 27px rgba(79,70,229,.22);
    transition: .25s ease;
}

.submit-feedback:hover {
    transform: translateY(-2px);
    box-shadow: 0 17px 35px rgba(79,70,229,.3);
}

.event-review {
    padding: 18px;
    border: 1px solid #e8edf3;
    border-radius: 15px;
    background: #fafbfc;
}

.event-review + .event-review {
    margin-top: 12px;
}

.review-title {
    color: #172033;
    font-size: 13px;
    font-weight: 800;
}

.review-meta {
    margin-top: 4px;
    color: #94a3b8;
    font-size: 10px;
}

.review-status {
    display: inline-flex;
    margin-top: 11px;
    padding: 6px 10px;
    border-radius: 999px;
    background: #ecfdf5;
    color: #15803d;
    font-size: 9px;
    font-weight: 850;
}

.review-rating {
    margin-top: 11px;
    color: #f59e0b;
    font-size: 14px;
    letter-spacing: 1px;
}

.review-details {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-top: 13px;
}

.review-detail {
    padding: 9px;
    border-radius: 9px;
    background: #fff;
    border: 1px solid #edf0f4;
}

.review-detail strong {
    display: block;
    color: #334155;
    font-size: 10px;
}

.review-detail span {
    color: #f59e0b;
    font-size: 11px;
}

.review-text {
    margin-top: 12px;
    color: #64748b;
    font-size: 11px;
    line-height: 1.65;
}

.empty-feedback {
    padding: 45px 20px;
    text-align: center;
}

.empty-feedback-icon {
    width: 58px;
    height: 58px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    border-radius: 17px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 22px;
    font-weight: 850;
}

.empty-feedback h3 {
    margin: 0 0 7px;
    color: #1e293b;
    font-size: 17px;
    font-weight: 850;
}

.empty-feedback p {
    max-width: 430px;
    margin: auto;
    color: #94a3b8;
    font-size: 12px;
    line-height: 1.7;
}

@media (max-width: 767px) {

    .feedback-page {
        padding: 25px 0 55px;
    }

    .feedback-hero {
        padding: 29px 22px;
        border-radius: 21px;
    }

    .feedback-hero h1 {
        font-size: 30px;
    }

    .feedback-card {
        padding: 21px;
    }

    .rating-row {
        align-items: flex-start;
        flex-direction: column;
    }

    .review-details {
        grid-template-columns: 1fr;
    }
}

</style>

<div class="container feedback-page">

    <section class="feedback-hero">

        <span class="feedback-eyebrow">
            EventSphere Student Portal
        </span>

        <h1>
            Event Feedback
        </h1>

        <p>
            Share your experience from events you have attended.
            Your feedback helps us improve future EventSphere activities.
        </p>

        <div class="feedback-user">

            <div class="feedback-avatar">
                <?= h(strtoupper(substr($studentName, 0, 1))) ?>
            </div>

            <div>
                <strong><?= h($studentName) ?></strong>
                <br>
                <small>Student Account</small>
            </div>

        </div>

    </section>

    <div class="row g-4 feedback-stats">

        <div class="col-md-4">
            <div class="feedback-stat">
                <strong><?= count($eligibleEvents) ?></strong>
                <span>Completed Events</span>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feedback-stat">
                <strong><?= $feedbackCount ?></strong>
                <span>Feedback Submitted</span>
            </div>
        </div>

        <div class="col-md-4">
            <div class="feedback-stat">
                <strong><?= $pendingCount ?></strong>
                <span>Feedback Pending</span>
            </div>
        </div>

    </div>

    <div class="row g-4 feedback-content">

        <div class="col-lg-6">

            <div class="feedback-card">

                <h2>Share Your Experience</h2>

                <p>
                    Select an event you attended and tell us about your experience.
                </p>

                <?php if (!empty($errors)): ?>

                    <div class="alert-box alert-error">
                        <?php foreach ($errors as $error): ?>
                            <div><?= h($error) ?></div>
                        <?php endforeach; ?>
                    </div>

                <?php endif; ?>

                <?php if ($success !== ""): ?>

                    <div class="alert-box alert-success">
                        <?= h($success) ?>
                    </div>

                <?php endif; ?>

                <?php if (empty($pendingEvents)): ?>

                    <div class="empty-feedback">

                        <div class="empty-feedback-icon">
                            ✓
                        </div>

                        <h3>
                            You're all caught up
                        </h3>

                        <p>
                            There are currently no completed events waiting for your feedback.
                        </p>

                    </div>

                <?php else: ?>

                    <form
                        method="post"
                        action="feedback.php"
                        id="feedbackForm"
                        novalidate
                    >

                        <div class="form-group">

                            <label
                                class="form-label"
                                for="registration_id"
                            >
                                Select Completed Event
                            </label>

                            <select
                                class="form-select"
                                id="registration_id"
                                name="registration_id"
                                required
                            >

                                <option value="">
                                    Choose an event
                                </option>

                                <?php foreach ($pendingEvents as $event): ?>

                                    <option
                                        value="<?= (int)$event["registration_id"] ?>"
                                        <?= (
                                            (int)($_POST["registration_id"] ?? 0)
                                            ===
                                            (int)$event["registration_id"]
                                        ) ? "selected" : "" ?>
                                    >

                                        <?= h($event["title"]) ?>
                                        —
                                        <?= date("d M Y", strtotime($event["event_date"])) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="form-group">

                            <label class="form-label">
                                Event Ratings
                            </label>

                            <div class="rating-group">

                                <div class="rating-row">

                                    <span class="rating-title">
                                        Overall Experience
                                    </span>

                                    <div class="stars">

                                        <?php for ($i = 5; $i >= 1; $i--): ?>

                                            <input
                                                type="radio"
                                                id="overall<?= $i ?>"
                                                name="overall_rating"
                                                value="<?= $i ?>"
                                                <?= (
                                                    (int)($_POST["overall_rating"] ?? 0)
                                                    === $i
                                                ) ? "checked" : "" ?>
                                                required
                                            >

                                            <label for="overall<?= $i ?>">
                                                ★
                                            </label>

                                        <?php endfor; ?>

                                    </div>

                                </div>

                                <div class="rating-row">

                                    <span class="rating-title">
                                        Event Experience
                                    </span>

                                    <div class="stars">

                                        <?php for ($i = 5; $i >= 1; $i--): ?>

                                            <input
                                                type="radio"
                                                id="experience<?= $i ?>"
                                                name="experience_rating"
                                                value="<?= $i ?>"
                                                <?= (
                                                    (int)($_POST["experience_rating"] ?? 0)
                                                    === $i
                                                ) ? "checked" : "" ?>
                                                required
                                            >

                                            <label for="experience<?= $i ?>">
                                                ★
                                            </label>

                                        <?php endfor; ?>

                                    </div>

                                </div>

                                <div class="rating-row">

                                    <span class="rating-title">
                                        Content & Activities
                                    </span>

                                    <div class="stars">

                                        <?php for ($i = 5; $i >= 1; $i--): ?>

                                            <input
                                                type="radio"
                                                id="content<?= $i ?>"
                                                name="content_rating"
                                                value="<?= $i ?>"
                                                <?= (
                                                    (int)($_POST["content_rating"] ?? 0)
                                                    === $i
                                                ) ? "checked" : "" ?>
                                                required
                                            >

                                            <label for="content<?= $i ?>">
                                                ★
                                            </label>

                                        <?php endfor; ?>

                                    </div>

                                </div>

                                <div class="rating-row">

                                    <span class="rating-title">
                                        Organization
                                    </span>

                                    <div class="stars">

                                        <?php for ($i = 5; $i >= 1; $i--): ?>

                                            <input
                                                type="radio"
                                                id="organization<?= $i ?>"
                                                name="organization_rating"
                                                value="<?= $i ?>"
                                                <?= (
                                                    (int)($_POST["organization_rating"] ?? 0)
                                                    === $i
                                                ) ? "checked" : "" ?>
                                                required
                                            >

                                            <label for="organization<?= $i ?>">
                                                ★
                                            </label>

                                        <?php endfor; ?>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="form-group">

                            <label
                                class="form-label"
                                for="comments"
                            >
                                Additional Comments
                            </label>

                            <textarea
                                class="form-control"
                                id="comments"
                                name="comments"
                                maxlength="1000"
                                placeholder="Tell us what you liked or what could be improved..."
                            ><?= h($_POST["comments"] ?? "") ?></textarea>

                        </div>

                        <div class="form-group">

                            <label class="anonymous-box">

                                <input
                                    type="checkbox"
                                    name="is_anonymous"
                                    value="1"
                                    <?= isset($_POST["is_anonymous"]) ? "checked" : "" ?>
                                >

                                <span>

                                    <strong>
                                        Submit anonymously
                                    </strong>

                                    <span>
                                        Your name will not be displayed with the feedback.
                                    </span>

                                </span>

                            </label>

                        </div>

                        <button
                            type="submit"
                            class="submit-feedback"
                        >
                            Submit Event Feedback
                        </button>

                    </form>

                <?php endif; ?>

            </div>

        </div>

        <div class="col-lg-6">

            <div class="feedback-card">

                <h2>
                    Your Submitted Feedback
                </h2>

                <p>
                    Here you can review feedback you have already submitted.
                </p>

                <?php if (empty($submittedEvents)): ?>

                    <div class="empty-feedback">

                        <div class="empty-feedback-icon">
                            —
                        </div>

                        <h3>
                            No feedback submitted
                        </h3>

                        <p>
                            Your submitted feedback will appear here.
                        </p>

                    </div>

                <?php else: ?>

                    <?php foreach ($submittedEvents as $event): ?>

                        <div class="event-review">

                            <div class="review-title">
                                <?= h($event["title"]) ?>
                            </div>

                            <div class="review-meta">

                                <?= h($event["category_name"] ?: "General Event") ?>

                                ·

                                <?= date(
                                    "d M Y",
                                    strtotime($event["event_date"])
                                ) ?>

                            </div>

                            <span class="review-status">
                                <?= h(ucfirst($event["status"] ?: "Submitted")) ?>
                            </span>

                            <div class="review-rating">

                                <?= str_repeat(
                                    "★",
                                    (int)$event["overall_rating"]
                                ) ?>

                                <?= str_repeat(
                                    "☆",
                                    5 - (int)$event["overall_rating"]
                                ) ?>

                            </div>

                            <div class="review-details">

                                <div class="review-detail">

                                    <strong>
                                        Experience
                                    </strong>

                                    <span>
                                        <?= str_repeat(
                                            "★",
                                            (int)$event["experience_rating"]
                                        ) ?>
                                    </span>

                                </div>

                                <div class="review-detail">

                                    <strong>
                                        Content
                                    </strong>

                                    <span>
                                        <?= str_repeat(
                                            "★",
                                            (int)$event["content_rating"]
                                        ) ?>
                                    </span>

                                </div>

                                <div class="review-detail">

                                    <strong>
                                        Organization
                                    </strong>

                                    <span>
                                        <?= str_repeat(
                                            "★",
                                            (int)$event["organization_rating"]
                                        ) ?>
                                    </span>

                                </div>

                            </div>

                            <?php if (!empty($event["comments"])): ?>

                                <div class="review-text">
                                    <?= h($event["comments"]) ?>
                                </div>

                            <?php endif; ?>

                        </div>

                    <?php endforeach; ?>

                <?php endif; ?>

            </div>

        </div>

    </div>

</div>

<script>

document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("feedbackForm");

    if (!form) {
        return;
    }

    form.addEventListener("submit", function (event) {

        const registration = document.getElementById("registration_id");
        const comments = document.getElementById("comments");

        const ratingNames = [
            "overall_rating",
            "experience_rating",
            "content_rating",
            "organization_rating"
        ];

        if (!registration.value) {
            event.preventDefault();
            registration.focus();
            return;
        }

        for (const name of ratingNames) {

            const selected = document.querySelector(
                'input[name="' + name + '"]:checked'
            );

            if (!selected) {
                event.preventDefault();
                return;
            }
        }

        const text = comments.value.trim();

        if (text.length > 1000) {
            event.preventDefault();
            comments.focus();
        }

    });

});

</script>

<?php
require "footer.php";
?>