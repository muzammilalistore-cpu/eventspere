<?php

$host = "localhost";
$username = "root";
$password = "";
$database = "eventsphere";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die(
        "Database connection failed. Please make sure MySQL is running in XAMPP."
    );
}

mysqli_set_charset($conn, "utf8mb4");