<?php

require "db.php";
require_once "functions.php";

require_auth();

$title = "Reports";

$total_events = 0;
$total_registrations = 0;
$total_students = 0;
$total_attended = 0;

$result = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM events
     WHERE event_status = 'published'"
);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $total_events = (int)$row["total"];
}

$result = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM event_registrations"
);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $total_registrations = (int)$row["total"];
}

$result = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE role = 'student'"
);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $total_students = (int)$row["total"];
}

$result = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM event_registrations
     WHERE status = 'attended'"
);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $total_attended = (int)$row["total"];
}

$attendance_rate = 0;

if ($total_registrations > 0) {
    $attendance_rate = round(
        ($total_attended / $total_registrations) * 100
    );
}

$event_report = mysqli_query(
    $conn,
    "SELECT
        e.event_id,
        e.title,
        e.event_date,
        e.max_capacity,
        c.category_name,
        d.department_name,
        v.venue_name,
        COUNT(er.registration_id) AS registrations,
        SUM(
            CASE
                WHEN er.status = 'attended' THEN 1
                ELSE 0
            END
        ) AS attended
     FROM events e
     INNER JOIN event_categories c
        ON c.category_id = e.category_id
     INNER JOIN departments d
        ON d.department_id = e.department_id
     INNER JOIN venues v
        ON v.venue_id = e.venue_id
     LEFT JOIN event_registrations er
        ON er.event_id = e.event_id
     GROUP BY
        e.event_id,
        e.title,
        e.event_date,
        e.max_capacity,
        c.category_name,
        d.department_name,
        v.venue_name
     ORDER BY e.event_date DESC
     LIMIT 10"
);

require "header.php";
?>

<style>

.reports-page {
    padding: 15px 0 50px;
}

.report-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 20px;
    margin-bottom: 32px;
}

.report-header h1 {
    margin: 0;
    font-size: clamp(2rem, 4vw, 3rem);
    font-weight: 800;
    letter-spacing: -0.04em;
    color: #0f172a;
}

.report-header p {
    margin: 8px 0 0;
    color: #64748b;
}

.report-date {
    padding: 10px 15px;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    background: #fff;
    color: #475569;
    font-size: .85rem;
    white-space: nowrap;
}

.report-stat {
    position: relative;
    overflow: hidden;
    height: 100%;
    padding: 25px;
    border: 1px solid #e5e7eb;
    border-radius: 20px;
    background: #fff;
    box-shadow: 0 8px 30px rgba(15,23,42,.05);
    transition: .3s ease;
}

.report-stat:hover {
    transform: translateY(-5px);
    box-shadow: 0 18px 40px rgba(15,23,42,.09);
}

.report-stat::after {
    content: "";
    position: absolute;
    width: 100px;
    height: 100px;
    right: -35px;
    top: -35px;
    border-radius: 50%;
    background: rgba(79,70,229,.07);
}

.report-label {
    color: #64748b;
    font-size: .82rem;
    font-weight: 600;
}

.report-number {
    margin-top: 8px;
    color: #0f172a;
    font-size: 2.15rem;
    line-height: 1;
    font-weight: 800;
    letter-spacing: -.04em;
}

.report-icon {
    display: grid;
    place-items: center;
    width: 44px;
    height: 44px;
    margin-bottom: 20px;
    border-radius: 13px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: .8rem;
    font-weight: 800;
}

.report-panel {
    margin-top: 32px;
    overflow: hidden;
    border: 1px solid #e5e7eb;
    border-radius: 22px;
    background: #fff;
    box-shadow: 0 8px 30px rgba(15,23,42,.05);
}

.report-panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 24px 26px;
    border-bottom: 1px solid #eef2f7;
}

.report-panel-header h2 {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 800;
    color: #0f172a;
}

.report-panel-header span {
    color: #94a3b8;
    font-size: .82rem;
}

.report-table {
    margin: 0;
}

.report-table th {
    padding: 15px 20px;
    border-bottom: 1px solid #e5e7eb;
    color: #64748b;
    background: #f8fafc;
    font-size: .75rem;
    font-weight: 750;
    text-transform: uppercase;
    letter-spacing: .05em;
}

.report-table td {
    padding: 17px 20px;
    vertical-align: middle;
    color: #475569;
    border-bottom: 1px solid #f1f5f9;
    font-size: .88rem;
}

.report-table tbody tr {
    transition: .2s ease;
}

.report-table tbody tr:hover {
    background: #f8fafc;
}

.event-name {
    color: #0f172a;
    font-weight: 750;
}

.category-pill {
    display: inline-flex;
    padding: 6px 9px;
    border-radius: 8px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: .72rem;
    font-weight: 750;
}

.attendance-pill {
    display: inline-flex;
    padding: 6px 9px;
    border-radius: 8px;
    background: #ecfdf5;
    color: #047857;
    font-size: .72rem;
    font-weight: 750;
}

.empty-report {
    padding: 60px 20px;
    text-align: center;
    color: #64748b;
}

@media (max-width: 767px) {

    .report-header {
        display: block;
    }

    .report-date {
        display: inline-block;
        margin-top: 15px;
    }

    .report-panel {
        overflow-x: auto;
    }

    .report-table {
        min-width: 850px;
    }

}

</style>

<div class="reports-page">

    <div class="report-header">

        <div>
            <h1>Reports & Analytics</h1>
            <p>Overview of events, registrations and student participation.</p>
        </div>

        <div class="report-date">
            <?= date("d M Y") ?>
        </div>

    </div>

    <div class="row g-4">

        <div class="col-6 col-lg-3">
            <div class="report-stat">
                <div class="report-icon">EV</div>
                <div class="report-label">Published Events</div>
                <div class="report-number">
                    <?= $total_events ?>
                </div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="report-stat">
                <div class="report-icon">RG</div>
                <div class="report-label">Registrations</div>
                <div class="report-number">
                    <?= $total_registrations ?>
                </div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="report-stat">
                <div class="report-icon">ST</div>
                <div class="report-label">Students</div>
                <div class="report-number">
                    <?= $total_students ?>
                </div>
            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="report-stat">
                <div class="report-icon">AT</div>
                <div class="report-label">Attendance Rate</div>
                <div class="report-number">
                    <?= $attendance_rate ?>%
                </div>
            </div>
        </div>

    </div>

    <div class="report-panel">

        <div class="report-panel-header">

            <div>
                <h2>Event Performance</h2>
                <span>Latest event activity</span>
            </div>

        </div>

        <?php if ($event_report && mysqli_num_rows($event_report) > 0): ?>

            <div class="table-responsive">

                <table class="table report-table">

                    <thead>

                        <tr>
                            <th>Event</th>
                            <th>Category</th>
                            <th>Department</th>
                            <th>Date</th>
                            <th>Registrations</th>
                            <th>Attended</th>
                            <th>Capacity</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php while ($event = mysqli_fetch_assoc($event_report)): ?>

                            <tr>

                                <td>
                                    <div class="event-name">
                                        <?= e($event["title"]) ?>
                                    </div>
                                    <small class="text-muted">
                                        <?= e($event["venue_name"]) ?>
                                    </small>
                                </td>

                                <td>
                                    <span class="category-pill">
                                        <?= e($event["category_name"]) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= e($event["department_name"]) ?>
                                </td>

                                <td>
                                    <?= e($event["event_date"]) ?>
                                </td>

                                <td>
                                    <?= (int)$event["registrations"] ?>
                                </td>

                                <td>
                                    <span class="attendance-pill">
                                        <?= (int)$event["attended"] ?>
                                    </span>
                                </td>

                                <td>
                                    <?= (int)$event["max_capacity"] ?>
                                </td>

                            </tr>

                        <?php endwhile; ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="empty-report">
                <h5>No event data available</h5>
                <p class="mb-0">
                    Published events and their activity will appear here.
                </p>
            </div>

        <?php endif; ?>

    </div>

</div>

<?php require "footer.php"; ?>