<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

/*
|--------------------------------------------------------------------------
| EventSphere - Student Dashboard
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/db.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection failed. Please check db.php');
}

$conn->set_charset('utf8mb4');

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function e(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function firstLetter(string $name): string
{
    $name = trim($name);

    if ($name === '') {
        return 'S';
    }

    if (function_exists('mb_substr')) {
        return strtoupper(
            mb_substr($name, 0, 1, 'UTF-8')
        );
    }

    return strtoupper(substr($name, 0, 1));
}

function formatDate(?string $date): string
{
    if (!$date) {
        return '—';
    }

    $timestamp = strtotime($date);

    return $timestamp !== false
        ? date('d M Y', $timestamp)
        : '—';
}

function formatTime(?string $time): string
{
    if (!$time) {
        return '';
    }

    $timestamp = strtotime($time);

    return $timestamp !== false
        ? date('h:i A', $timestamp)
        : $time;
}

function statusLabel(string $status): string
{
    return ucwords(
        str_replace(
            '_',
            ' ',
            strtolower(trim($status))
        )
    );
}

/*
|--------------------------------------------------------------------------
| PREPARED SELECT
|--------------------------------------------------------------------------
*/

function selectQuery(
    mysqli $conn,
    string $sql,
    string $types = '',
    array $params = []
): mysqli_result|false {

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return false;
    }

    if ($types !== '' && !empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        $stmt->close();
        return false;
    }

    $result = $stmt->get_result();

    $stmt->close();

    return $result ?: false;
}

/*
|--------------------------------------------------------------------------
| CURRENT STUDENT ID
|--------------------------------------------------------------------------
*/

$student_id = 0;

if (
    isset($_SESSION['user']['user_id']) &&
    is_numeric($_SESSION['user']['user_id'])
) {
    $student_id = (int) $_SESSION['user']['user_id'];
}

if (
    $student_id <= 0 &&
    isset($_SESSION['user_id']) &&
    is_numeric($_SESSION['user_id'])
) {
    $student_id = (int) $_SESSION['user_id'];
}

/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

if ($student_id <= 0) {
    redirect('login.php?error=unauthorized');
}

/*
|--------------------------------------------------------------------------
| VERIFY STUDENT
|--------------------------------------------------------------------------
*/

$user_sql = "
    SELECT
        u.user_id,
        u.email,
        u.role,
        u.account_status,
        COALESCE(up.full_name, '') AS full_name
    FROM users u
    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id
    WHERE u.user_id = ?
      AND u.role = 'student'
      AND u.account_status = 'active'
    LIMIT 1
";

$user_result = selectQuery(
    $conn,
    $user_sql,
    'i',
    [$student_id]
);

$student = $user_result
    ? $user_result->fetch_assoc()
    : null;

if (!$student) {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    redirect('login.php?error=unauthorized');
}

/*
|--------------------------------------------------------------------------
| STUDENT DATA
|--------------------------------------------------------------------------
*/

$student_name = trim(
    (string) ($student['full_name'] ?? '')
);

if ($student_name === '') {
    $student_name = 'Student';
}

$student_email = trim(
    (string) ($student['email'] ?? '')
);

$student_initial = firstLetter($student_name);

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (
    empty($_SESSION['student_csrf_token']) ||
    !is_string($_SESSION['student_csrf_token'])
) {
    $_SESSION['student_csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

$csrf_token = $_SESSION['student_csrf_token'];

/*
|--------------------------------------------------------------------------
| CANCEL REGISTRATION
|--------------------------------------------------------------------------
*/

$cancel_success = '';
$cancel_error = '';

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['cancel_registration'])
) {

    $posted_token = (string) (
        $_POST['csrf_token'] ?? ''
    );

    if (
        !hash_equals(
            $csrf_token,
            $posted_token
        )
    ) {

        $cancel_error =
            'Invalid security token. Please refresh the page.';

    } else {

        $registration_id =
            isset($_POST['registration_id']) &&
            is_numeric($_POST['registration_id'])
                ? (int) $_POST['registration_id']
                : 0;

        if ($registration_id <= 0) {

            $cancel_error =
                'Invalid registration selected.';

        } else {

            $cancel_sql = "
                UPDATE event_registrations er
                INNER JOIN events e
                    ON e.event_id = er.event_id
                SET er.status = 'cancelled'
                WHERE er.registration_id = ?
                  AND er.student_id = ?
                  AND er.status <> 'cancelled'
                  AND e.event_date >= CURDATE()
            ";

            $stmt = $conn->prepare($cancel_sql);

            if (!$stmt) {

                $cancel_error =
                    'Unable to process cancellation.';

            } else {

                $stmt->bind_param(
                    'ii',
                    $registration_id,
                    $student_id
                );

                if ($stmt->execute()) {

                    if ($stmt->affected_rows > 0) {

                        $cancel_success =
                            'Registration cancelled successfully.';

                    } else {

                        $cancel_error =
                            'This registration cannot be cancelled.';
                    }

                } else {

                    $cancel_error =
                        'Unable to cancel registration. Please try again.';
                }

                $stmt->close();
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| DEFAULT STATISTICS
|--------------------------------------------------------------------------
*/

$total_registrations = 0;
$upcoming_registrations = 0;
$attended_events = 0;
$certificates_count = 0;
$feedback_count = 0;
$available_events = 0;

$upcoming_events_data = [];
$registration_data = [];
$announcement_data = [];

/*
|--------------------------------------------------------------------------
| REGISTRATION STATISTICS
|--------------------------------------------------------------------------
*/

$stats_sql = "
    SELECT
        COUNT(*) AS total_registrations,

        COALESCE(
            SUM(
                CASE
                    WHEN er.status <> 'cancelled'
                    AND e.event_date >= CURDATE()
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS upcoming_registrations,

        COALESCE(
            SUM(
                CASE
                    WHEN er.status = 'attended'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS attended_events

    FROM event_registrations er

    INNER JOIN events e
        ON e.event_id = er.event_id

    WHERE er.student_id = ?
";

$stats_result = selectQuery(
    $conn,
    $stats_sql,
    'i',
    [$student_id]
);

if ($stats_result) {

    $stats = $stats_result->fetch_assoc();

    if ($stats) {

        $total_registrations =
            (int) ($stats['total_registrations'] ?? 0);

        $upcoming_registrations =
            (int) ($stats['upcoming_registrations'] ?? 0);

        $attended_events =
            (int) ($stats['attended_events'] ?? 0);
    }
}

/*
|--------------------------------------------------------------------------
| AVAILABLE EVENTS
|--------------------------------------------------------------------------
*/

$available_sql = "
    SELECT COUNT(*) AS total
    FROM events
    WHERE event_status IN ('approved', 'published')
      AND event_date >= CURDATE()
";

$available_result = selectQuery(
    $conn,
    $available_sql
);

if ($available_result) {

    $row = $available_result->fetch_assoc();

    $available_events =
        (int) ($row['total'] ?? 0);
}

/*
|--------------------------------------------------------------------------
| FEEDBACK COUNT
|--------------------------------------------------------------------------
*/

$feedback_sql = "
    SELECT COUNT(*) AS total
    FROM event_feedback
    WHERE student_id = ?
";

$feedback_result = selectQuery(
    $conn,
    $feedback_sql,
    'i',
    [$student_id]
);

if ($feedback_result) {

    $row = $feedback_result->fetch_assoc();

    $feedback_count =
        (int) ($row['total'] ?? 0);
}

/*
|--------------------------------------------------------------------------
| CERTIFICATE COUNT
|--------------------------------------------------------------------------
*/

$certificate_sql = "
    SELECT COUNT(*) AS total
    FROM certificates
    WHERE student_id = ?
";

$certificate_result = selectQuery(
    $conn,
    $certificate_sql,
    'i',
    [$student_id]
);

if ($certificate_result) {

    $row = $certificate_result->fetch_assoc();

    $certificates_count =
        (int) ($row['total'] ?? 0);
}

/*
|--------------------------------------------------------------------------
| UPCOMING REGISTERED EVENTS
|--------------------------------------------------------------------------
*/

$upcoming_sql = "
    SELECT
        e.event_id,
        e.title,
        e.slug,
        e.event_date,
        e.start_time,
        e.end_time,
        e.event_status,
        e.featured_image,

        ec.category_name,

        v.venue_name,
        v.building_name,

        er.registration_id,
        er.registration_code,
        er.status AS registration_status

    FROM event_registrations er

    INNER JOIN events e
        ON e.event_id = er.event_id

    LEFT JOIN event_categories ec
        ON ec.category_id = e.category_id

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    WHERE er.student_id = ?
      AND er.status <> 'cancelled'
      AND e.event_date >= CURDATE()
      AND e.event_status NOT IN ('cancelled', 'completed')

    ORDER BY
        e.event_date ASC,
        e.start_time ASC

    LIMIT 6
";

$upcoming_result = selectQuery(
    $conn,
    $upcoming_sql,
    'i',
    [$student_id]
);

if ($upcoming_result) {

    while ($row = $upcoming_result->fetch_assoc()) {
        $upcoming_events_data[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| RECENT REGISTRATIONS
|--------------------------------------------------------------------------
*/

$registration_sql = "
    SELECT
        er.registration_id,
        er.registration_code,
        er.registered_at,
        er.status,

        e.title AS event_title,
        e.event_date

    FROM event_registrations er

    INNER JOIN events e
        ON e.event_id = er.event_id

    WHERE er.student_id = ?

    ORDER BY er.registered_at DESC

    LIMIT 6
";

$registration_result = selectQuery(
    $conn,
    $registration_sql,
    'i',
    [$student_id]
);

if ($registration_result) {

    while ($row = $registration_result->fetch_assoc()) {
        $registration_data[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| ANNOUNCEMENTS
|--------------------------------------------------------------------------
*/

$announcement_sql = "
    SELECT
        announcement_id,
        title,
        message,
        created_at
    FROM announcements
    ORDER BY created_at DESC
    LIMIT 5
";

$announcement_result = selectQuery(
    $conn,
    $announcement_sql
);

if ($announcement_result) {

    while ($row = $announcement_result->fetch_assoc()) {
        $announcement_data[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<meta
    name="theme-color"
    content="#111827"
>

<title>Student Dashboard | EventSphere</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {

    --primary: #4f46e5;
    --primary-dark: #3730a3;
    --primary-light: #eef2ff;

    --dark: #111827;
    --text: #172033;
    --muted: #64748b;
    --light: #f8fafc;
    --border: #e8edf3;

    --success: #16a34a;
    --warning: #d97706;
    --danger: #dc2626;

    --radius: 18px;
}

html {
    scroll-behavior: smooth;
}

body {

    font-family:
        Inter,
        ui-sans-serif,
        system-ui,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        sans-serif;

    background: #f4f6fa;
    color: var(--text);

    line-height: 1.5;
}

button,
a {
    font: inherit;
}

a {
    color: inherit;
    text-decoration: none;
}

.dashboard {
    min-height: 100vh;
}

/*
|--------------------------------------------------------------------------
| SIDEBAR
|--------------------------------------------------------------------------
*/

.sidebar {

    width: 265px;

    position: fixed;

    left: 0;
    top: 0;
    bottom: 0;

    background:
        linear-gradient(
            180deg,
            #111827 0%,
            #0f172a 100%
        );

    color: #fff;

    padding: 22px 15px;

    overflow-y: auto;

    z-index: 1000;

    transition: transform .3s ease;
}

.main {

    margin-left: 265px;

    min-height: 100vh;
}

/*
|--------------------------------------------------------------------------
| BRAND
|--------------------------------------------------------------------------
*/

.brand {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 7px 10px 25px;
}

.brand-icon {

    width: 44px;
    height: 44px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #8b5cf6
        );

    font-size: 17px;
    font-weight: 900;

    box-shadow:
        0 8px 22px rgba(99,102,241,.3);
}

.brand-text strong {

    display: block;

    font-size: 17px;
}

.brand-text span {

    display: block;

    color: #94a3b8;

    font-size: 10px;

    margin-top: 2px;
}

/*
|--------------------------------------------------------------------------
| NAVIGATION
|--------------------------------------------------------------------------
*/

.nav-title {

    color: #64748b;

    text-transform: uppercase;

    letter-spacing: .1em;

    font-size: 9px;

    font-weight: 800;

    padding: 18px 12px 8px;
}

.nav-link {

    display: flex;

    align-items: center;

    gap: 12px;

    color: #cbd5e1;

    padding: 11px 12px;

    border-radius: 11px;

    margin-bottom: 3px;

    font-size: 13px;

    font-weight: 500;

    transition: .2s ease;
}

.nav-link:hover {

    background: #1e293b;

    color: #fff;

    transform: translateX(2px);
}

.nav-link.active {

    background:
        linear-gradient(
            135deg,
            #4f46e5,
            #6366f1
        );

    color: #fff;

    box-shadow:
        0 8px 20px rgba(79,70,229,.22);
}

.nav-icon {

    width: 21px;

    text-align: center;

    font-size: 15px;
}

.logout {

    border-top: 1px solid #263244;

    margin-top: 24px;

    padding-top: 16px;
}

.logout .nav-link {
    color: #fca5a5;
}

/*
|--------------------------------------------------------------------------
| TOPBAR
|--------------------------------------------------------------------------
*/

.topbar {

    height: 76px;

    position: sticky;

    top: 0;

    z-index: 500;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;

    background: rgba(255,255,255,.94);

    backdrop-filter: blur(14px);

    border-bottom: 1px solid var(--border);
}

.page-heading {

    display: flex;

    align-items: center;

    gap: 13px;
}

.mobile-toggle {

    display: none;

    width: 38px;
    height: 38px;

    border: 0;

    border-radius: 10px;

    background: #f1f5f9;

    cursor: pointer;

    font-size: 18px;
}

.page-title h1 {

    font-size: 20px;

    font-weight: 800;
}

.page-title p {

    color: var(--muted);

    font-size: 12px;

    margin-top: 2px;
}

.profile {

    display: flex;

    align-items: center;

    gap: 10px;
}

.profile-avatar {

    width: 40px;
    height: 40px;

    border-radius: 50%;

    display: flex;

    align-items: center;
    justify-content: center;

    color: #fff;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #8b5cf6
        );

    font-weight: 800;
}

.profile-info strong {

    display: block;

    font-size: 12px;
}

.profile-info span {

    display: block;

    color: #94a3b8;

    font-size: 10px;
}

/*
|--------------------------------------------------------------------------
| CONTENT
|--------------------------------------------------------------------------
*/

.content {

    padding: 28px;

    max-width: 1700px;

    margin: auto;
}

/*
|--------------------------------------------------------------------------
| WELCOME
|--------------------------------------------------------------------------
*/

.welcome {

    position: relative;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

    overflow: hidden;

    color: #fff;

    padding: 28px 30px;

    margin-bottom: 23px;

    border-radius: 20px;

    background:
        radial-gradient(
            circle at 85% 20%,
            rgba(129,140,248,.28),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #111827,
            #312e81
        );

    box-shadow:
        0 16px 40px rgba(30,27,75,.15);
}

.welcome h2 {

    font-size: 24px;

    font-weight: 800;
}

.welcome p {

    color: #c7d2fe;

    font-size: 13px;

    margin-top: 5px;
}

.browse-btn {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    background: #fff;

    color: #4338ca;

    padding: 11px 17px;

    border-radius: 11px;

    font-size: 12px;

    font-weight: 800;

    white-space: nowrap;

    transition: .2s ease;
}

.browse-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 10px 25px rgba(0,0,0,.2);
}

/*
|--------------------------------------------------------------------------
| ALERTS
|--------------------------------------------------------------------------
*/

.alert {

    padding: 12px 16px;

    border-radius: 12px;

    margin-bottom: 18px;

    font-size: 12px;

    font-weight: 700;
}

.alert-success {

    background: #dcfce7;

    color: #166534;

    border: 1px solid #bbf7d0;
}

.alert-error {

    background: #fee2e2;

    color: #991b1b;

    border: 1px solid #fecaca;
}

/*
|--------------------------------------------------------------------------
| STATS
|--------------------------------------------------------------------------
*/

.stats-grid {

    display: grid;

    grid-template-columns:
        repeat(5, minmax(0,1fr));

    gap: 14px;

    margin-bottom: 22px;
}

.stat-card {

    background: #fff;

    border: 1px solid var(--border);

    border-radius: 16px;

    padding: 18px;

    box-shadow:
        0 4px 16px rgba(15,23,42,.025);

    transition: .25s ease;
}

.stat-card:hover {

    transform: translateY(-4px);

    box-shadow:
        0 15px 35px rgba(15,23,42,.08);
}

.stat-top {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 14px;
}

.stat-label {

    color: #64748b;

    font-size: 11px;

    font-weight: 700;
}

.stat-icon {

    width: 36px;
    height: 36px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: #eef2ff;

    color: var(--primary);

    font-size: 15px;
}

.stat-value {

    font-size: 25px;

    font-weight: 850;

    line-height: 1;
}

.stat-small {

    color: #94a3b8;

    font-size: 10px;

    margin-top: 8px;
}

/*
|--------------------------------------------------------------------------
| PANELS
|--------------------------------------------------------------------------
*/

.two-column {

    display: grid;

    grid-template-columns:
        1.65fr 1fr;

    gap: 20px;

    margin-bottom: 20px;
}

.panel {

    background: #fff;

    border: 1px solid var(--border);

    border-radius: 17px;

    overflow: hidden;

    box-shadow:
        0 4px 16px rgba(15,23,42,.025);
}

.panel-header {

    min-height: 62px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 16px 20px;

    border-bottom: 1px solid #eef1f5;
}

.panel-header h3 {

    font-size: 14px;

    font-weight: 800;
}

.view-all {

    color: var(--primary);

    font-size: 11px;

    font-weight: 800;
}

/*
|--------------------------------------------------------------------------
| EVENTS
|--------------------------------------------------------------------------
*/

.event-list {
    padding: 5px 0;
}

.event-item {

    display: flex;

    align-items: center;

    gap: 13px;

    padding: 14px 20px;

    border-bottom: 1px solid #f1f3f6;

    transition: background .2s ease;
}

.event-item:hover {
    background: #fafbff;
}

.event-item:last-child {
    border-bottom: 0;
}

.event-date {

    width: 48px;
    height: 51px;

    flex-shrink: 0;

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    border-radius: 11px;

    background: #eef2ff;

    color: #4338ca;
}

.event-date strong {

    font-size: 17px;

    line-height: 1;
}

.event-date span {

    font-size: 9px;

    font-weight: 800;

    text-transform: uppercase;

    margin-top: 4px;
}

.event-info {

    flex: 1;

    min-width: 0;
}

.event-info h4 {

    font-size: 12px;

    font-weight: 750;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;
}

.event-info p {

    color: #64748b;

    font-size: 10px;

    margin-top: 4px;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;
}

.event-time {

    color: #94a3b8;

    font-size: 9px;

    margin-top: 3px;
}

.event-meta {

    min-width: 100px;

    text-align: right;
}

/*
|--------------------------------------------------------------------------
| BADGES
|--------------------------------------------------------------------------
*/

.badge,
.reg-status {

    display: inline-flex;

    align-items: center;

    padding: 4px 8px;

    border-radius: 999px;

    font-size: 8px;

    font-weight: 800;

    text-transform: capitalize;
}

.badge-confirmed {

    color: #166534;

    background: #dcfce7;
}

.badge-attended {

    color: #3730a3;

    background: #e0e7ff;
}

.badge-no_show {

    color: #92400e;

    background: #fef3c7;
}

.badge-cancelled {

    color: #991b1b;

    background: #fee2e2;
}

.badge-pending {

    color: #92400e;

    background: #fef3c7;
}

/*
|--------------------------------------------------------------------------
| REGISTRATIONS
|--------------------------------------------------------------------------
*/

.registration-list {
    padding: 5px 0;
}

.registration-item {

    display: flex;

    align-items: center;

    gap: 10px;

    padding: 13px 20px;

    border-bottom: 1px solid #f1f3f6;
}

.registration-item:last-child {
    border-bottom: 0;
}

.registration-icon {

    width: 36px;
    height: 36px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #eef2ff,
            #e0e7ff
        );

    color: #4338ca;

    font-size: 14px;
}

.registration-info {

    flex: 1;

    min-width: 0;
}

.registration-info strong {

    display: block;

    font-size: 11px;

    font-weight: 750;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;
}

.registration-info span {

    display: block;

    color: #94a3b8;

    font-size: 9px;

    margin-top: 2px;
}

/*
|--------------------------------------------------------------------------
| ANNOUNCEMENTS
|--------------------------------------------------------------------------
*/

.announcement-list {

    padding: 5px 20px 12px;
}

.announcement-item {

    padding: 13px 0;

    border-bottom: 1px solid #f1f3f6;
}

.announcement-item:last-child {
    border-bottom: 0;
}

.announcement-top {

    display: flex;

    align-items: center;

    gap: 10px;
}

.announcement-icon {

    width: 34px;
    height: 34px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: #eef2ff;

    color: #4f46e5;

    font-size: 14px;
}

.announcement-info {
    min-width: 0;
}

.announcement-info strong {

    display: block;

    font-size: 11px;

    font-weight: 800;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;
}

.announcement-info span {

    display: block;

    color: #94a3b8;

    font-size: 9px;

    margin-top: 2px;
}

.announcement-message {

    color: #64748b;

    font-size: 10px;

    line-height: 1.55;

    margin-top: 7px;

    padding-left: 44px;
}

/*
|--------------------------------------------------------------------------
| ACTIVITY
|--------------------------------------------------------------------------
*/

.activity-box {

    padding: 22px 20px;
}

.activity-grid {

    display: grid;

    grid-template-columns:
        repeat(2,1fr);

    gap: 13px;
}

.activity-card {

    background: #f8fafc;

    border: 1px solid #edf1f5;

    border-radius: 13px;

    padding: 18px;
}

.activity-card span {

    display: block;

    color: #64748b;

    font-size: 10px;

    font-weight: 600;

    margin-bottom: 7px;
}

.activity-card strong {

    display: block;

    font-size: 26px;

    font-weight: 850;
}

.activity-note {

    margin-top: 20px;

    padding: 16px;

    background: #eef2ff;

    border-radius: 13px;
}

.activity-note strong {

    color: #3730a3;

    font-size: 11px;

    display: block;

    margin-bottom: 4px;
}

.activity-note p {

    color: #64748b;

    font-size: 10px;

    line-height: 1.6;
}

/*
|--------------------------------------------------------------------------
| QUICK ACTIONS
|--------------------------------------------------------------------------
*/

.quick-actions {

    display: grid;

    grid-template-columns:
        repeat(4,1fr);

    gap: 12px;

    padding: 18px 20px 20px;
}

.quick-action {

    display: block;

    border: 1px solid var(--border);

    border-radius: 13px;

    padding: 15px;

    transition: .2s ease;
}

.quick-action:hover {

    border-color: #c7d2fe;

    background: #fafaff;

    transform: translateY(-3px);

    box-shadow:
        0 8px 20px rgba(79,70,229,.06);
}

.quick-action-icon {

    width: 34px;
    height: 34px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: #eef2ff;

    color: #4f46e5;

    margin-bottom: 9px;
}

.quick-action strong {

    display: block;

    font-size: 11px;

    font-weight: 800;
}

.quick-action span {

    display: block;

    color: #94a3b8;

    font-size: 9px;

    margin-top: 3px;
}

/*
|--------------------------------------------------------------------------
| EMPTY
|--------------------------------------------------------------------------
*/

.empty {

    padding: 35px 20px;

    text-align: center;

    color: #94a3b8;
}

.empty-icon {

    width: 42px;
    height: 42px;

    display: flex;

    align-items: center;
    justify-content: center;

    margin: 0 auto 9px;

    border-radius: 12px;

    background: #f8fafc;

    font-size: 18px;
}

.empty p {
    font-size: 11px;
}

/*
|--------------------------------------------------------------------------
| MOBILE
|--------------------------------------------------------------------------
*/

.sidebar-overlay {

    display: none;

    position: fixed;

    inset: 0;

    background:
        rgba(15,23,42,.45);

    z-index: 900;
}

@media (max-width: 1350px) {

    .stats-grid {

        grid-template-columns:
            repeat(3,1fr);
    }
}

@media (max-width: 1050px) {

    .sidebar {
        width: 235px;
    }

    .main {
        margin-left: 235px;
    }

    .two-column {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 800px) {

    .sidebar {

        transform: translateX(-100%);
    }

    .sidebar.open {
        transform: translateX(0);
    }

    .sidebar-overlay.show {
        display: block;
    }

    .main {
        margin-left: 0;
    }

    .mobile-toggle {

        display: flex;

        align-items: center;
        justify-content: center;
    }

    .topbar {
        padding: 0 18px;
    }

    .content {
        padding: 18px;
    }

    .stats-grid {

        grid-template-columns:
            repeat(2,1fr);
    }

    .quick-actions {

        grid-template-columns:
            repeat(2,1fr);
    }

    .welcome {

        align-items: flex-start;

        flex-direction: column;
    }
}

@media (max-width: 520px) {

    .profile-info {
        display: none;
    }

    .page-title h1 {
        font-size: 16px;
    }

    .page-title p {
        display: none;
    }

    .stats-grid {
        grid-template-columns: 1fr;
    }

    .quick-actions {
        grid-template-columns: 1fr;
    }

    .event-item {
        align-items: flex-start;
    }

    .event-meta {
        display: none;
    }

    .welcome {
        padding: 22px;
    }

    .welcome h2 {
        font-size: 20px;
    }

    .browse-btn {

        width: 100%;

        justify-content: center;
    }

    .activity-grid {
        grid-template-columns: 1fr;
    }
}

</style>

</head>

<body>

<div class="dashboard">

<!-- SIDEBAR -->

<aside
    class="sidebar"
    id="sidebar"
>

    <div class="brand">

        <div class="brand-icon">
            ES
        </div>

        <div class="brand-text">

            <strong>
                EventSphere
            </strong>

            <span>
                Student Portal
            </span>

        </div>

    </div>

    <div class="nav-title">
        Main
    </div>

    <a
        href="student-dashboard.php"
        class="nav-link active"
    >

        <span class="nav-icon">⌂</span>

        <span>
            Dashboard
        </span>

    </a>

    <a
        href="student-events.php"
        class="nav-link"
    >

        <span class="nav-icon">◈</span>

        <span>
            Browse Events
        </span>

    </a>

    <a
        href="my-registrations.php"
        class="nav-link"
    >

        <span class="nav-icon">♙</span>

        <span>
            My Registrations
        </span>

    </a>

    <div class="nav-title">
        My Activity
    </div>

    <a
        href="my-attendance.php"
        class="nav-link"
    >

        <span class="nav-icon">✓</span>

        <span>
            My Attendance
        </span>

    </a>

    <a
        href="certificates.php"
        class="nav-link"
    >

        <span class="nav-icon">▣</span>

        <span>
            Certificates
        </span>

    </a>

    <a
        href="my-feedback.php"
        class="nav-link"
    >

        <span class="nav-icon">★</span>

        <span>
            My Feedback
        </span>

    </a>

    <div class="nav-title">
        Community
    </div>

    <a
        href="announcements.php"
        class="nav-link"
    >

        <span class="nav-icon">◉</span>

        <span>
            Announcements
        </span>

    </a>

    <a
        href="gallery.php"
        class="nav-link"
    >

        <span class="nav-icon">▧</span>

        <span>
            Event Gallery
        </span>

    </a>

    <div class="nav-title">
        Account
    </div>

    <a
        href="profile.php"
        class="nav-link"
    >

        <span class="nav-icon">●</span>

        <span>
            My Profile
        </span>

    </a>

    <div class="logout">

        <a
            href="logout.php"
            class="nav-link"
        >

            <span class="nav-icon">↪</span>

            <span>
                Logout
            </span>

        </a>

    </div>

</aside>

<div
    class="sidebar-overlay"
    id="sidebarOverlay"
></div>

<!-- MAIN -->

<main class="main">

<header class="topbar">

    <div class="page-heading">

        <button
            type="button"
            class="mobile-toggle"
            id="mobileToggle"
            aria-label="Open menu"
        >
            ☰
        </button>

        <div class="page-title">

            <h1>
                Student Dashboard
            </h1>

            <p>
                Discover events, manage registrations and track your activity
            </p>

        </div>

    </div>

    <div class="profile">

        <div class="profile-avatar">
            <?= e($student_initial) ?>
        </div>

        <div class="profile-info">

            <strong>
                <?= e($student_name) ?>
            </strong>

            <span>
                <?= e(
                    $student_email !== ''
                        ? $student_email
                        : 'Student Account'
                ) ?>
            </span>

        </div>

    </div>

</header>

<section class="content">

<?php if ($cancel_success !== ''): ?>

    <div class="alert alert-success">
        <?= e($cancel_success) ?>
    </div>

<?php endif; ?>

<?php if ($cancel_error !== ''): ?>

    <div class="alert alert-error">
        <?= e($cancel_error) ?>
    </div>

<?php endif; ?>

<!-- WELCOME -->

<div class="welcome">

    <div>

        <h2>
            Welcome back,
            <?= e($student_name) ?>!
        </h2>

        <p>
            Explore upcoming campus events and keep track of your participation.
        </p>

    </div>

    <a
        href="student-events.php"
        class="browse-btn"
    >
        ◈
        Browse Events
    </a>

</div>

<!-- STATS -->

<div class="stats-grid">

    <div class="stat-card">

        <div class="stat-top">

            <span class="stat-label">
                My Registrations
            </span>

            <div class="stat-icon">
                ♙
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($total_registrations) ?>
        </div>

        <div class="stat-small">
            Total event registrations
        </div>

    </div>

    <div class="stat-card">

        <div class="stat-top">

            <span class="stat-label">
                Upcoming
            </span>

            <div class="stat-icon">
                ◷
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($upcoming_registrations) ?>
        </div>

        <div class="stat-small">
            Events you are registered for
        </div>

    </div>

    <div class="stat-card">

        <div class="stat-top">

            <span class="stat-label">
                Attended
            </span>

            <div class="stat-icon">
                ✓
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($attended_events) ?>
        </div>

        <div class="stat-small">
            Events attended
        </div>

    </div>

    <div class="stat-card">

        <div class="stat-top">

            <span class="stat-label">
                Certificates
            </span>

            <div class="stat-icon">
                ▣
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($certificates_count) ?>
        </div>

        <div class="stat-small">
            Certificates earned
        </div>

    </div>

    <div class="stat-card">

        <div class="stat-top">

            <span class="stat-label">
                Available Events
            </span>

            <div class="stat-icon">
                ◈
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($available_events) ?>
        </div>

        <div class="stat-small">
            Upcoming published events
        </div>

    </div>

</div>

<!-- UPCOMING + REGISTRATIONS -->

<div class="two-column">

<!-- UPCOMING EVENTS -->

<div class="panel">

    <div class="panel-header">

        <h3>
            My Upcoming Events
        </h3>

        <a
            href="my-registrations.php"
            class="view-all"
        >
            View all →
        </a>

    </div>

    <div class="event-list">

        <?php if (!empty($upcoming_events_data)): ?>

            <?php foreach ($upcoming_events_data as $event): ?>

                <?php

                $timestamp =
                    !empty($event['event_date'])
                        ? strtotime((string) $event['event_date'])
                        : false;

                $event_day =
                    $timestamp !== false
                        ? date('d', $timestamp)
                        : '--';

                $event_month =
                    $timestamp !== false
                        ? date('M', $timestamp)
                        : '---';

                $venue = trim(
                    (string) ($event['venue_name'] ?? '')
                );

                $building = trim(
                    (string) ($event['building_name'] ?? '')
                );

                $location =
                    $venue !== ''
                        ? $venue
                        : 'Venue not assigned';

                if ($building !== '') {
                    $location .= ' · ' . $building;
                }

                $registration_status =
                    strtolower(
                        trim(
                            (string) (
                                $event['registration_status']
                                ?? 'confirmed'
                            )
                        )
                    );

                ?>

                <div class="event-item">

                    <div class="event-date">

                        <strong>
                            <?= e($event_day) ?>
                        </strong>

                        <span>
                            <?= e($event_month) ?>
                        </span>

                    </div>

                    <div class="event-info">

                        <h4>
                            <?= e(
                                $event['title']
                                ?? 'Untitled Event'
                            ) ?>
                        </h4>

                        <p>
                            <?= e($location) ?>
                        </p>

                        <?php if (!empty($event['start_time'])): ?>

                            <div class="event-time">

                                <?= e(
                                    formatTime(
                                        (string) $event['start_time']
                                    )
                                ) ?>

                                <?php if (!empty($event['end_time'])): ?>

                                    —
                                    <?= e(
                                        formatTime(
                                            (string) $event['end_time']
                                        )
                                    ) ?>

                                <?php endif; ?>

                            </div>

                        <?php endif; ?>

                    </div>

                    <div class="event-meta">

                        <span
                            class="badge badge-<?= e(
                                $registration_status
                            ) ?>"
                        >

                            <?= e(
                                statusLabel(
                                    $registration_status
                                )
                            ) ?>

                        </span>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ◈
                </div>

                <p>
                    You have no upcoming registered events.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

<!-- RECENT REGISTRATIONS -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Recent Registrations
        </h3>

        <a
            href="my-registrations.php"
            class="view-all"
        >
            View all →
        </a>

    </div>

    <div class="registration-list">

        <?php if (!empty($registration_data)): ?>

            <?php foreach ($registration_data as $registration): ?>

                <?php

                $registration_status =
                    strtolower(
                        trim(
                            (string) (
                                $registration['status']
                                ?? 'confirmed'
                            )
                        )
                    );

                ?>

                <div class="registration-item">

                    <div class="registration-icon">
                        ◈
                    </div>

                    <div class="registration-info">

                        <strong>
                            <?= e(
                                $registration['event_title']
                                ?? 'Event'
                            ) ?>
                        </strong>

                        <span>

                            <?= e(
                                formatDate(
                                    $registration['event_date']
                                    ?? null
                                )
                            ) ?>

                            <?php if (
                                !empty(
                                    $registration['registration_code']
                                )
                            ): ?>

                                ·
                                <?= e(
                                    $registration['registration_code']
                                ) ?>

                            <?php endif; ?>

                        </span>

                    </div>

                    <span
                        class="reg-status badge-<?= e(
                            $registration_status
                        ) ?>"
                    >

                        <?= e(
                            statusLabel(
                                $registration_status
                            )
                        ) ?>

                    </span>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ♙
                </div>

                <p>
                    You have not registered for any events yet.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

</div>

<!-- ANNOUNCEMENTS + ACTIVITY -->

<div class="two-column">

<!-- ANNOUNCEMENTS -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Latest Announcements
        </h3>

        <a
            href="announcements.php"
            class="view-all"
        >
            View all →
        </a>

    </div>

    <div class="announcement-list">

        <?php if (!empty($announcement_data)): ?>

            <?php foreach ($announcement_data as $announcement): ?>

                <div class="announcement-item">

                    <div class="announcement-top">

                        <div class="announcement-icon">
                            ◉
                        </div>

                        <div class="announcement-info">

                            <strong>
                                <?= e(
                                    $announcement['title']
                                    ?? 'Announcement'
                                ) ?>
                            </strong>

                            <span>
                                <?= e(
                                    formatDate(
                                        $announcement['created_at']
                                        ?? null
                                    )
                                ) ?>
                            </span>

                        </div>

                    </div>

                    <?php if (
                        !empty($announcement['message'])
                    ): ?>

                        <div class="announcement-message">

                            <?= e(
                                $announcement['message']
                            ) ?>

                        </div>

                    <?php endif; ?>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ◉
                </div>

                <p>
                    No announcements available.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

<!-- ACTIVITY -->

<div class="panel">

    <div class="panel-header">

        <h3>
            My Activity
        </h3>

        <a
            href="my-attendance.php"
            class="view-all"
        >
            View attendance →
        </a>

    </div>

    <div class="activity-box">

        <div class="activity-grid">

            <div class="activity-card">

                <span>
                    Attended Events
                </span>

                <strong>
                    <?= number_format(
                        $attended_events
                    ) ?>
                </strong>

            </div>

            <div class="activity-card">

                <span>
                    Feedback Given
                </span>

                <strong>
                    <?= number_format(
                        $feedback_count
                    ) ?>
                </strong>

            </div>

        </div>

        <div class="activity-note">

            <strong>
                Keep participating
            </strong>

            <p>
                Attend events, collect certificates and share your feedback to build your EventSphere activity record.
            </p>

        </div>

    </div>

</div>

</div>

<!-- QUICK ACTIONS -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Quick Actions
        </h3>

    </div>

    <div class="quick-actions">

        <a
            href="student-events.php"
            class="quick-action"
        >

            <div class="quick-action-icon">
                ◈
            </div>

            <strong>
                Browse Events
            </strong>

            <span>
                Find upcoming events
            </span>

        </a>

        <a
            href="my-registrations.php"
            class="quick-action"
        >

            <div class="quick-action-icon">
                ♙
            </div>

            <strong>
                My Registrations
            </strong>

            <span>
                Manage your registrations
            </span>

        </a>

        <a
            href="certificates.php"
            class="quick-action"
        >

            <div class="quick-action-icon">
                ▣
            </div>

            <strong>
                Certificates
            </strong>

            <span>
                View your certificates
            </span>

        </a>

        <a
            href="profile.php"
            class="quick-action"
        >

            <div class="quick-action-icon">
                ●
            </div>

            <strong>
                My Profile
            </strong>

            <span>
                Update your information
            </span>

        </a>

    </div>

</div>

</section>

</main>

</div>

<script>

const sidebar =
    document.getElementById('sidebar');

const toggle =
    document.getElementById('mobileToggle');

const overlay =
    document.getElementById('sidebarOverlay');

function openSidebar() {

    if (sidebar) {
        sidebar.classList.add('open');
    }

    if (overlay) {
        overlay.classList.add('show');
    }
}

function closeSidebar() {

    if (sidebar) {
        sidebar.classList.remove('open');
    }

    if (overlay) {
        overlay.classList.remove('show');
    }
}

if (toggle) {

    toggle.addEventListener(
        'click',
        openSidebar
    );
}

if (overlay) {

    overlay.addEventListener(
        'click',
        closeSidebar
    );
}

document.addEventListener(
    'keydown',
    function(event) {

        if (event.key === 'Escape') {
            closeSidebar();
        }

    }
);

document.querySelectorAll(
    '.sidebar .nav-link'
).forEach(
    function(link) {

        link.addEventListener(
            'click',
            closeSidebar
        );

    }
);

/*
|--------------------------------------------------------------------------
| Entrance Animation
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'DOMContentLoaded',
    function() {

        const elements =
            document.querySelectorAll(
                '.stat-card, .panel'
            );

        elements.forEach(
            function(element, index) {

                element.style.opacity = '0';

                element.style.transform =
                    'translateY(12px)';

                setTimeout(
                    function() {

                        element.style.transition =
                            'opacity .45s ease, transform .45s ease';

                        element.style.opacity = '1';

                        element.style.transform =
                            'translateY(0)';

                    },
                    70 + (index * 45)
                );

            }
        );

    }
);

</script>

</body>

</html>