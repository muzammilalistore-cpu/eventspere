<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| EventSphere - Announcements
|--------------------------------------------------------------------------
| Authenticated users can view announcements.
| Global announcements:
|   organizer_id = 0
|
| Organizer announcements:
|   organizer_id = current user's ID
|--------------------------------------------------------------------------
*/

require_auth();

/*
|--------------------------------------------------------------------------
| Current User
|--------------------------------------------------------------------------
*/

$user = $_SESSION['user'] ?? [];

$userId = (int)($user['user_id'] ?? 0);
$role   = strtolower(trim((string)($user['role'] ?? '')));

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
|
| Prevent undefined function h() error.
|
*/

if (!function_exists('h')) {
    function h($value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Page Title
|--------------------------------------------------------------------------
*/

$title = 'Announcements | EventSphere';

/*
|--------------------------------------------------------------------------
| Load Announcements
|--------------------------------------------------------------------------
|
| Show:
|
| 1. Global announcements       -> organizer_id = 0
| 2. Organizer announcements    -> organizer_id = current organizer ID
|
| Students will normally see global announcements.
|
*/

$announcements = [];

if ($role === 'organizer') {

    $sql = "
        SELECT
            a.announcement_id,
            a.organizer_id,
            a.event_id,
            a.title,
            a.message,
            a.created_at,
            e.title AS event_title
        FROM announcements a
        LEFT JOIN events e
            ON e.event_id = a.event_id
        WHERE
            a.organizer_id = 0
            OR a.organizer_id = ?
        ORDER BY
            a.created_at DESC,
            a.announcement_id DESC
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die(
            'Unable to load announcements: ' .
            h(mysqli_error($conn))
        );
    }

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

} else {

    /*
    |--------------------------------------------------------------------------
    | Student / Other authenticated users
    |--------------------------------------------------------------------------
    |
    | Students see global announcements only.
    |
    */

    $sql = "
        SELECT
            a.announcement_id,
            a.organizer_id,
            a.event_id,
            a.title,
            a.message,
            a.created_at,
            e.title AS event_title
        FROM announcements a
        LEFT JOIN events e
            ON e.event_id = a.event_id
        WHERE a.organizer_id = 0
        ORDER BY
            a.created_at DESC,
            a.announcement_id DESC
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die(
            'Unable to load announcements: ' .
            h(mysqli_error($conn))
        );
    }
}

/*
|--------------------------------------------------------------------------
| Execute
|--------------------------------------------------------------------------
*/

if (!mysqli_stmt_execute($stmt)) {
    die(
        'Unable to load announcements: ' .
        h(mysqli_stmt_error($stmt))
    );
}

$result = mysqli_stmt_get_result($stmt);

if ($result) {

    while ($row = mysqli_fetch_assoc($result)) {
        $announcements[] = $row;
    }

    mysqli_free_result($result);
}

mysqli_stmt_close($stmt);

/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/header.php';

?>

<style>

/* =========================================================
   EVENTSPHERE ANNOUNCEMENTS
   ========================================================= */

.announcements-page {
    padding: 45px 0 80px;
}

/* =========================================================
   HERO
   ========================================================= */

.announcements-hero {
    position: relative;
    overflow: hidden;
    padding: 42px;
    border-radius: 28px;
    color: #fff;

    background:
        radial-gradient(
            circle at 88% 10%,
            rgba(99,102,241,.42),
            transparent 30%
        ),
        radial-gradient(
            circle at 8% 92%,
            rgba(34,211,238,.18),
            transparent 32%
        ),
        linear-gradient(
            135deg,
            #0f172a 0%,
            #172554 52%,
            #312e81 100%
        );

    box-shadow:
        0 25px 70px rgba(15,23,42,.18);
}

.announcements-hero-content {
    position: relative;
    z-index: 2;
}

.announcements-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    color: #a5b4fc;

    font-size: 11px;
    font-weight: 850;

    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.announcements-eyebrow::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #818cf8;

    box-shadow:
        0 0 0 5px rgba(129,140,248,.12);
}

.announcements-hero h1 {
    margin: 10px 0 8px;

    font-size: 37px;
    line-height: 1.1;

    font-weight: 850;
    letter-spacing: -.8px;
}

.announcements-hero p {
    max-width: 700px;

    margin: 0;

    color: #cbd5e1;

    font-size: 14px;
    line-height: 1.7;
}

/* =========================================================
   MAIN BOX
   ========================================================= */

.announcements-box {
    margin-top: 28px;

    padding: 30px;

    border: 1px solid #e8edf3;
    border-radius: 22px;

    background: #fff;

    box-shadow:
        0 10px 35px rgba(15,23,42,.045);
}

/* =========================================================
   HEADER
   ========================================================= */

.announcements-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 20px;

    margin-bottom: 25px;
}

.announcements-header h2 {
    margin: 0;

    color: #0f172a;

    font-size: 21px;
    font-weight: 850;
}

.announcements-header p {
    margin: 5px 0 0;

    color: #94a3b8;

    font-size: 12px;
}

/* =========================================================
   CARD
   ========================================================= */

.announcement-card {
    position: relative;

    padding: 23px;

    margin-bottom: 16px;

    border: 1px solid #e8edf3;
    border-radius: 17px;

    background: #fff;

    transition:
        transform .25s ease,
        box-shadow .25s ease,
        border-color .25s ease;
}

.announcement-card:last-child {
    margin-bottom: 0;
}

.announcement-card:hover {
    transform: translateY(-3px);

    border-color: #d9defa;

    box-shadow:
        0 15px 38px rgba(15,23,42,.08);
}

/* =========================================================
   ICON
   ========================================================= */

.announcement-icon {
    width: 48px;
    height: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    flex-shrink: 0;

    border-radius: 14px;

    color: #4f46e5;

    background: #eef2ff;

    font-size: 21px;
}

/* =========================================================
   CONTENT
   ========================================================= */

.announcement-content {
    flex: 1;
}

.announcement-top {
    display: flex;
    align-items: flex-start;

    gap: 15px;
}

.announcement-title {
    margin: 0 0 6px;

    color: #172033;

    font-size: 17px;
    line-height: 1.35;

    font-weight: 850;
}

.announcement-message {
    color: #64748b;

    font-size: 12px;
    line-height: 1.7;

    white-space: pre-line;
}

/* =========================================================
   META
   ========================================================= */

.announcement-meta {
    display: flex;
    flex-wrap: wrap;

    gap: 9px 16px;

    margin-top: 15px;
}

.announcement-meta-item {
    color: #94a3b8;

    font-size: 10px;
}

.announcement-meta-item strong {
    color: #475569;
}

/* =========================================================
   BADGE
   ========================================================= */

.announcement-badge {
    display: inline-flex;

    padding: 6px 9px;

    border-radius: 999px;

    color: #4f46e5;

    background: #eef2ff;

    font-size: 8px;
    font-weight: 850;

    letter-spacing: .5px;

    text-transform: uppercase;
}

/* =========================================================
   EMPTY
   ========================================================= */

.announcements-empty {
    padding: 70px 20px;

    text-align: center;

    border: 1px dashed #dbe2ea;
    border-radius: 17px;

    background: #fafbfc;
}

.announcements-empty-icon {
    width: 66px;
    height: 66px;

    margin: 0 auto 16px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 18px;

    color: #4f46e5;

    background: #eef2ff;

    font-size: 27px;
}

.announcements-empty h3 {
    margin-bottom: 7px;

    color: #172033;

    font-size: 18px;
    font-weight: 850;
}

.announcements-empty p {
    max-width: 500px;

    margin: 0 auto;

    color: #94a3b8;

    font-size: 12px;
    line-height: 1.6;
}

/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 767px) {

    .announcements-page {
        padding: 25px 0 55px;
    }

    .announcements-hero {
        padding: 30px 22px;

        border-radius: 21px;
    }

    .announcements-hero h1 {
        font-size: 28px;
    }

    .announcements-box {
        padding: 20px;
    }

    .announcement-top {
        flex-direction: column;
    }

}

</style>


<div class="container announcements-page">

    <!-- =====================================================
         HERO
    ====================================================== -->

    <section class="announcements-hero">

        <div class="announcements-hero-content">

            <div class="announcements-eyebrow">
                EventSphere Updates
            </div>

            <h1>
                Announcements
            </h1>

            <p>
                Stay updated with the latest event announcements,
                registration updates, important notices, and
                information shared through EventSphere.
            </p>

        </div>

    </section>


    <!-- =====================================================
         ANNOUNCEMENTS
    ====================================================== -->

    <section class="announcements-box">

        <div class="announcements-header">

            <div>

                <h2>
                    Latest Announcements
                </h2>

                <p>
                    Important updates and notices from EventSphere.
                </p>

            </div>

        </div>


        <?php if (!empty($announcements)): ?>

            <?php foreach ($announcements as $announcement): ?>

                <?php

                $announcementTitle =
                    trim(
                        (string)(
                            $announcement['title'] ?? ''
                        )
                    );

                $announcementMessage =
                    trim(
                        (string)(
                            $announcement['message'] ?? ''
                        )
                    );

                $eventTitle =
                    trim(
                        (string)(
                            $announcement['event_title'] ?? ''
                        )
                    );

                $createdAt =
                    $announcement['created_at'] ?? '';

                $isGlobal =
                    (int)(
                        $announcement['organizer_id'] ?? 0
                    ) === 0;

                ?>

                <article class="announcement-card">

                    <div class="announcement-top">

                        <div class="announcement-icon">
                            📢
                        </div>

                        <div class="announcement-content">

                            <div class="d-flex flex-wrap align-items-center gap-2 mb-2">

                                <span class="announcement-badge">

                                    <?= $isGlobal
                                        ? 'General'
                                        : 'Organizer Update'
                                    ?>

                                </span>

                            </div>


                            <h3 class="announcement-title">

                                <?= h(
                                    $announcementTitle !== ''
                                        ? $announcementTitle
                                        : 'Announcement'
                                ) ?>

                            </h3>


                            <div class="announcement-message">

                                <?= h(
                                    $announcementMessage !== ''
                                        ? $announcementMessage
                                        : 'No message available.'
                                ) ?>

                            </div>


                            <div class="announcement-meta">

                                <?php if ($eventTitle !== ''): ?>

                                    <div class="announcement-meta-item">

                                        <strong>
                                            Event:
                                        </strong>

                                        <?= h($eventTitle) ?>

                                    </div>

                                <?php endif; ?>


                                <?php if (!empty($createdAt)): ?>

                                    <div class="announcement-meta-item">

                                        <strong>
                                            Posted:
                                        </strong>

                                        <?= h(
                                            date(
                                                'd M Y, h:i A',
                                                strtotime($createdAt)
                                            )
                                        ) ?>

                                    </div>

                                <?php endif; ?>

                            </div>

                        </div>

                    </div>

                </article>

            <?php endforeach; ?>


        <?php else: ?>


            <!-- =================================================
                 EMPTY STATE
            ================================================== -->

            <div class="announcements-empty">

                <div class="announcements-empty-icon">
                    📢
                </div>

                <h3>
                    No announcements available
                </h3>

                <p>
                    There are no announcements available at the
                    moment. Please check back later for updates.
                </p>

            </div>


        <?php endif; ?>

    </section>

</div>


<?php

require_once __DIR__ . '/footer.php';

?>