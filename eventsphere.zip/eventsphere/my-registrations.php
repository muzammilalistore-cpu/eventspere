
<?php

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/functions.php";

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_auth();

$title = "Registrations | EventSphere";

$user = $_SESSION["user"] ?? [];
$user_id = (int)($user["user_id"] ?? 0);
$role = $user["role"] ?? "";

$registrations = false;
$page_error = "";


/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function registration_status_class(string $status): string
{
    switch (strtolower(trim($status))) {

        case "confirmed":
            return "status-confirmed";

        case "attended":
            return "status-attended";

        case "cancelled":
        case "canceled":
            return "status-cancelled";

        case "pending":
            return "status-pending";

        default:
            return "status-default";
    }
}


/*
|--------------------------------------------------------------------------
| Student Registrations
|--------------------------------------------------------------------------
*/

if ($role === "student") {

    $sql = "
        SELECT
            r.registration_id,
            r.registration_code,
            r.status,
            r.registered_at,

            e.event_id,
            e.title,
            e.short_description,
            e.event_date,
            e.start_time,
            e.end_time,
            e.event_status,

            c.category_name,
            d.department_name,
            v.venue_name

        FROM event_registrations AS r

        INNER JOIN events AS e
            ON e.event_id = r.event_id

        INNER JOIN event_categories AS c
            ON c.category_id = e.category_id

        INNER JOIN departments AS d
            ON d.department_id = e.department_id

        INNER JOIN venues AS v
            ON v.venue_id = e.venue_id

        WHERE r.student_id = ?

        ORDER BY
            e.event_date DESC,
            e.start_time DESC
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {

        $page_error =
            "Unable to prepare registrations query: "
            . mysqli_error($conn);

    } else {

        mysqli_stmt_bind_param(
            $stmt,
            "i",
            $user_id
        );

        if (!mysqli_stmt_execute($stmt)) {

            $page_error =
                "Unable to load registrations: "
                . mysqli_stmt_error($stmt);

        } else {

            $registrations = mysqli_stmt_get_result($stmt);

        }
    }
}


/*
|--------------------------------------------------------------------------
| Organizer Registrations
|--------------------------------------------------------------------------
*/

elseif ($role === "organizer") {

    $sql = "
        SELECT
            r.registration_id,
            r.registration_code,
            r.status,
            r.registered_at,

            e.event_id,
            e.title,
            e.short_description,
            e.event_date,
            e.start_time,
            e.end_time,
            e.event_status,

            c.category_name,
            d.department_name,
            v.venue_name,

            up.full_name,
            u.email

        FROM event_registrations AS r

        INNER JOIN events AS e
            ON e.event_id = r.event_id

        INNER JOIN event_categories AS c
            ON c.category_id = e.category_id

        INNER JOIN departments AS d
            ON d.department_id = e.department_id

        INNER JOIN venues AS v
            ON v.venue_id = e.venue_id

        INNER JOIN users AS u
            ON u.user_id = r.student_id

        LEFT JOIN user_profiles AS up
            ON up.user_id = r.student_id

        WHERE e.organizer_id = ?

        ORDER BY
            e.event_date DESC,
            r.registered_at DESC
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {

        $page_error =
            "Unable to prepare organizer registrations query: "
            . mysqli_error($conn);

    } else {

        mysqli_stmt_bind_param(
            $stmt,
            "i",
            $user_id
        );

        if (!mysqli_stmt_execute($stmt)) {

            $page_error =
                "Unable to load organizer registrations: "
                . mysqli_stmt_error($stmt);

        } else {

            $registrations = mysqli_stmt_get_result($stmt);

        }
    }
}


/*
|--------------------------------------------------------------------------
| Unknown Role
|--------------------------------------------------------------------------
*/

else {

    $page_error = "Your account role is not supported.";

}


require "header.php";

?>

<style>

/* =========================================================
   EVENTSPHERE
   ADVANCED REGISTRATIONS PAGE
   ========================================================= */

.reg-page {
    padding: 35px 0 80px;
}


/* =========================================================
   HEADER
   ========================================================= */

.reg-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    gap: 25px;
    margin-bottom: 30px;
}

.reg-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 10px;
    padding: 7px 12px;
    border-radius: 999px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.reg-header h1 {
    margin: 0;
    color: #0f172a;
    font-size: clamp(2.2rem, 5vw, 3.4rem);
    font-weight: 850;
    letter-spacing: -.055em;
    line-height: 1;
}

.reg-header p {
    max-width: 650px;
    margin: 12px 0 0;
    color: #64748b;
    font-size: .95rem;
    line-height: 1.7;
}


/* =========================================================
   ACTION
   ========================================================= */

.reg-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 18px;
    border-radius: 13px;
    background: #4f46e5;
    color: #ffffff;
    text-decoration: none;
    font-size: .85rem;
    font-weight: 750;
    white-space: nowrap;
    box-shadow: 0 8px 20px rgba(79,70,229,.18);
    transition: .25s ease;
}

.reg-action:hover {
    color: #ffffff;
    background: #4338ca;
    transform: translateY(-2px);
    box-shadow: 0 14px 28px rgba(79,70,229,.25);
}


/* =========================================================
   SUMMARY
   ========================================================= */

.reg-summary {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
    margin-bottom: 28px;
}

.summary-card {
    padding: 18px 20px;
    border: 1px solid #e8edf4;
    border-radius: 17px;
    background: #ffffff;
    box-shadow: 0 6px 24px rgba(15,23,42,.045);
}

.summary-label {
    color: #64748b;
    font-size: .76rem;
    font-weight: 650;
}

.summary-value {
    margin-top: 5px;
    color: #0f172a;
    font-size: 1.55rem;
    font-weight: 850;
}


/* =========================================================
   ERROR
   ========================================================= */

.reg-error {
    margin-bottom: 25px;
    padding: 16px 18px;
    border: 1px solid #fecaca;
    border-radius: 14px;
    background: #fef2f2;
    color: #991b1b;
    font-size: .88rem;
}


/* =========================================================
   REGISTRATION CARD
   ========================================================= */

.registration-card {
    position: relative;
    overflow: hidden;
    margin-bottom: 17px;
    border: 1px solid #e5e7eb;
    border-radius: 21px;
    background: #ffffff;
    box-shadow: 0 8px 30px rgba(15,23,42,.05);
    transition:
        transform .3s ease,
        box-shadow .3s ease,
        border-color .3s ease;
}

.registration-card:hover {
    transform: translateY(-4px);
    border-color: #d9def0;
    box-shadow: 0 18px 48px rgba(15,23,42,.10);
}

.registration-top {
    height: 5px;
    background: linear-gradient(
        90deg,
        #6366f1,
        #06b6d4
    );
}

.registration-body {
    padding: 24px;
}

.registration-main {
    display: flex;
    justify-content: space-between;
    gap: 25px;
}


/* =========================================================
   LEFT CONTENT
   ========================================================= */

.registration-category {
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 8px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: .68rem;
    font-weight: 850;
    letter-spacing: .05em;
    text-transform: uppercase;
}

.registration-title {
    margin: 12px 0 8px;
    color: #111827;
    font-size: 1.3rem;
    font-weight: 820;
    line-height: 1.3;
}

.registration-description {
    max-width: 720px;
    margin: 0 0 15px;
    color: #64748b;
    font-size: .84rem;
    line-height: 1.6;
}


/* =========================================================
   META
   ========================================================= */

.registration-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.meta-item {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 11px;
    border-radius: 10px;
    background: #f8fafc;
    color: #64748b;
    font-size: .78rem;
    font-weight: 600;
}


/* =========================================================
   STUDENT INFO
   ========================================================= */

.student-info {
    display: flex;
    align-items: center;
    gap: 9px;
    margin-top: 15px;
    color: #64748b;
    font-size: .8rem;
}

.student-avatar {
    display: grid;
    place-items: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: #eef2ff;
    color: #4f46e5;
    font-size: .72rem;
    font-weight: 850;
}


/* =========================================================
   RIGHT SIDE
   ========================================================= */

.registration-side {
    min-width: 170px;
    text-align: right;
}

.status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 11px;
    border-radius: 999px;
    font-size: .7rem;
    font-weight: 850;
    text-transform: capitalize;
}

.status::before {
    content: "";
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
}

.status-confirmed {
    background: #dcfce7;
    color: #15803d;
}

.status-attended {
    background: #dbeafe;
    color: #1d4ed8;
}

.status-cancelled {
    background: #fee2e2;
    color: #b91c1c;
}

.status-pending {
    background: #fef3c7;
    color: #b45309;
}

.status-default {
    background: #f1f5f9;
    color: #475569;
}


/* =========================================================
   CODE
   ========================================================= */

.registration-code {
    margin-top: 14px;
    color: #64748b;
    font-size: .75rem;
}

.registration-code strong {
    display: block;
    margin-top: 4px;
    color: #111827;
    font-size: .82rem;
    letter-spacing: .06em;
}


/* =========================================================
   EVENT DETAILS BUTTON
   ========================================================= */

.view-event {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    margin-top: 15px;
    padding: 9px 13px;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    color: #334155;
    background: #ffffff;
    text-decoration: none;
    font-size: .75rem;
    font-weight: 750;
    transition: .25s ease;
}

.view-event:hover {
    color: #4f46e5;
    border-color: #c7d2fe;
    background: #eef2ff;
}


/* =========================================================
   EMPTY STATE
   ========================================================= */

.empty-state {
    padding: 75px 25px;
    border: 1px dashed #cbd5e1;
    border-radius: 23px;
    background:
        linear-gradient(
            145deg,
            #f8fafc,
            #ffffff
        );
    text-align: center;
}

.empty-icon {
    display: grid;
    place-items: center;
    width: 68px;
    height: 68px;
    margin: 0 auto 19px;
    border-radius: 20px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 14px;
    font-weight: 900;
}

.empty-state h3 {
    margin-bottom: 8px;
    color: #111827;
    font-size: 1.25rem;
    font-weight: 820;
}

.empty-state p {
    max-width: 520px;
    margin: 0 auto 23px;
    color: #64748b;
    font-size: .88rem;
    line-height: 1.7;
}


/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 850px) {

    .reg-summary {
        grid-template-columns: 1fr;
    }

    .registration-main {
        flex-direction: column;
    }

    .registration-side {
        min-width: 0;
        text-align: left;
    }

    .registration-code strong {
        display: inline;
        margin-left: 4px;
    }

}


@media (max-width: 600px) {

    .reg-page {
        padding: 25px 0 55px;
    }

    .reg-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .reg-action {
        width: 100%;
    }

    .registration-body {
        padding: 19px;
    }

    .registration-title {
        font-size: 1.15rem;
    }

    .registration-meta {
        flex-direction: column;
        align-items: flex-start;
    }

    .meta-item {
        width: 100%;
    }

}

</style>


<div class="container reg-page">

    <!-- =====================================================
         HEADER
         ===================================================== -->

    <div class="reg-header">

        <div>

            <div class="reg-eyebrow">
                EventSphere
            </div>

            <h1>
                Registrations
            </h1>

            <p>
                <?php if ($role === "student"): ?>

                    Keep track of your upcoming and previous
                    event registrations in one place.

                <?php else: ?>

                    View and monitor students registered
                    for your events.

                <?php endif; ?>
            </p>

        </div>


        <?php if ($role === "student"): ?>

            <a
                href="events.php"
                class="reg-action"
            >
                Explore Events
                <span>→</span>
            </a>

        <?php endif; ?>

    </div>


    <!-- =====================================================
         ERROR
         ===================================================== -->

    <?php if ($page_error !== ""): ?>

        <div class="reg-error">
            <?= e($page_error) ?>
        </div>

    <?php endif; ?>


    <?php

    /*
    |--------------------------------------------------------------------------
    | Summary Counters
    |--------------------------------------------------------------------------
    */

    $totalRegistrations = 0;
    $confirmedRegistrations = 0;
    $attendedRegistrations = 0;

    if ($registrations) {

        $rows = [];

        while ($row = mysqli_fetch_assoc($registrations)) {

            $rows[] = $row;

            $totalRegistrations++;

            $rowStatus = strtolower(
                trim($row["status"] ?? "")
            );

            if ($rowStatus === "confirmed") {
                $confirmedRegistrations++;
            }

            if ($rowStatus === "attended") {
                $attendedRegistrations++;
            }
        }

    } else {

        $rows = [];
    }

    ?>


    <!-- =====================================================
         SUMMARY
         ===================================================== -->

    <div class="reg-summary">

        <div class="summary-card">

            <div class="summary-label">
                Total Registrations
            </div>

            <div class="summary-value">
                <?= $totalRegistrations ?>
            </div>

        </div>


        <div class="summary-card">

            <div class="summary-label">
                Confirmed
            </div>

            <div class="summary-value">
                <?= $confirmedRegistrations ?>
            </div>

        </div>


        <div class="summary-card">

            <div class="summary-label">
                Attended
            </div>

            <div class="summary-value">
                <?= $attendedRegistrations ?>
            </div>

        </div>

    </div>


    <!-- =====================================================
         REGISTRATION LIST
         ===================================================== -->

    <?php if (count($rows) > 0): ?>

        <?php foreach ($rows as $registration): ?>

            <?php

            $status = strtolower(
                trim($registration["status"] ?? "pending")
            );

            $status_class =
                registration_status_class($status);

            $eventTimestamp = strtotime(
                $registration["event_date"]
            );

            $formattedDate =
                $eventTimestamp
                    ? date("D, d M Y", $eventTimestamp)
                    : $registration["event_date"];

            $startTimestamp = strtotime(
                $registration["start_time"]
            );

            $endTimestamp = strtotime(
                $registration["end_time"]
            );

            $formattedStart =
                $startTimestamp
                    ? date("g:i A", $startTimestamp)
                    : $registration["start_time"];

            $formattedEnd =
                $endTimestamp
                    ? date("g:i A", $endTimestamp)
                    : $registration["end_time"];

            ?>


            <article class="registration-card">

                <div class="registration-top"></div>

                <div class="registration-body">

                    <div class="registration-main">


                        <!-- =================================================
                             EVENT INFORMATION
                             ================================================= -->

                        <div class="registration-content">

                            <span class="registration-category">
                                <?= e($registration["category_name"]) ?>
                            </span>


                            <h2 class="registration-title">
                                <?= e($registration["title"]) ?>
                            </h2>


                            <?php if (!empty($registration["short_description"])): ?>

                                <p class="registration-description">
                                    <?= e($registration["short_description"]) ?>
                                </p>

                            <?php endif; ?>


                            <div class="registration-meta">

                                <span class="meta-item">
                                    📅
                                    <?= e($formattedDate) ?>
                                </span>

                                <span class="meta-item">
                                    🕐
                                    <?= e($formattedStart) ?>
                                    -
                                    <?= e($formattedEnd) ?>
                                </span>

                                <span class="meta-item">
                                    📍
                                    <?= e($registration["venue_name"]) ?>
                                </span>

                                <span class="meta-item">
                                    🏢
                                    <?= e($registration["department_name"]) ?>
                                </span>

                            </div>


                            <!-- =============================================
                                 ORGANIZER STUDENT INFORMATION
                                 ============================================= -->

                            <?php if ($role === "organizer"): ?>

                                <?php

                                $studentName =
                                    trim(
                                        $registration["full_name"] ?? ""
                                    );

                                if ($studentName === "") {
                                    $studentName =
                                        $registration["email"] ?? "Student";
                                }

                                $studentInitial =
                                    strtoupper(
                                        substr(
                                            trim($studentName),
                                            0,
                                            1
                                        )
                                    );

                                ?>

                                <div class="student-info">

                                    <span class="student-avatar">
                                        <?= e($studentInitial) ?>
                                    </span>

                                    <span>
                                        Student:
                                        <strong>
                                            <?= e($studentName) ?>
                                        </strong>
                                    </span>

                                </div>

                            <?php endif; ?>


                        </div>


                        <!-- =================================================
                             STATUS / CODE
                             ================================================= -->

                        <div class="registration-side">

                            <span class="status <?= e($status_class) ?>">

                                <?= e(
                                    ucfirst($status)
                                ) ?>

                            </span>


                            <div class="registration-code">

                                Registration Code

                                <strong>
                                    <?= e(
                                        $registration["registration_code"]
                                    ) ?>
                                </strong>

                            </div>


                            <a
                                href="event-details.php?id=<?= (int)$registration["event_id"] ?>"
                                class="view-event"
                            >
                                View Event
                                <span>→</span>
                            </a>

                        </div>


                    </div>

                </div>

            </article>


        <?php endforeach; ?>


    <?php elseif ($page_error === ""): ?>


        <!-- =====================================================
             EMPTY STATE
             ===================================================== -->

        <div class="empty-state">

            <div class="empty-icon">
                REG
            </div>

            <h3>
                No registrations found
            </h3>

            <p>

                <?php if ($role === "student"): ?>

                    You have not registered for any events yet.
                    Explore upcoming events and reserve your place.

                <?php else: ?>

                    No students have registered for your events yet.

                <?php endif; ?>

            </p>


            <?php if ($role === "student"): ?>

                <a
                    href="events.php"
                    class="reg-action"
                >
                    Browse Events
                    <span>→</span>
                </a>

            <?php endif; ?>

        </div>

    <?php endif; ?>

</div>


<?php require "footer.php"; ?>
