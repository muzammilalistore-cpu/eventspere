<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/db.php';

if (!isset($conn) || !($conn instanceof mysqli)) {
    die('Database connection failed. Please check db.php');
}

$conn->set_charset('utf8mb4');

function h(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function go(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];

    unset($_SESSION['flash']);

    return $flash;
}

function post_string(string $key, string $default = ''): string
{
    return isset($_POST[$key])
        ? trim((string)$_POST[$key])
        : $default;
}

function post_int(string $key, int $default = 0): int
{
    return isset($_POST[$key]) && is_numeric($_POST[$key])
        ? (int)$_POST[$key]
        : $default;
}

function dashboard_count(
    mysqli $conn,
    string $sql,
    int $organizer_id
): int {
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return 0;
    }

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $organizer_id
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return 0;
    }

    mysqli_stmt_bind_result(
        $stmt,
        $count
    );

    mysqli_stmt_fetch($stmt);

    mysqli_stmt_close($stmt);

    return (int)($count ?? 0);
}

function table_exists(mysqli $conn, string $table): bool
{
    $sql = "
        SELECT COUNT(*)
        FROM information_schema.tables
        WHERE table_schema = DATABASE()
          AND table_name = ?
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param($stmt, 's', $table);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $count);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    return (int)$count > 0;
}

function column_exists(
    mysqli $conn,
    string $table,
    string $column
): bool {
    $sql = "
        SELECT COUNT(*)
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = ?
          AND column_name = ?
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param(
        $stmt,
        'ss',
        $table,
        $column
    );

    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $count);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    return (int)$count > 0;
}

function column_nullable(
    mysqli $conn,
    string $table,
    string $column
): bool {
    $sql = "
        SELECT IS_NULLABLE
        FROM information_schema.columns
        WHERE table_schema = DATABASE()
          AND table_name = ?
          AND column_name = ?
        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return false;
    }

    mysqli_stmt_bind_param(
        $stmt,
        'ss',
        $table,
        $column
    );

    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $nullable);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    return strtoupper((string)$nullable) === 'YES';
}

$organizer_id = 0;

if (
    isset($_SESSION['user']['user_id']) &&
    is_numeric($_SESSION['user']['user_id'])
) {
    $organizer_id = (int)$_SESSION['user']['user_id'];
}

if (
    $organizer_id <= 0 &&
    isset($_SESSION['user_id']) &&
    is_numeric($_SESSION['user_id'])
) {
    $organizer_id = (int)$_SESSION['user_id'];
}

if ($organizer_id <= 0) {
    go('login.php?error=unauthorized');
}

$user_sql = "
    SELECT
        u.user_id,
        u.email,
        u.role,
        u.account_status,
        COALESCE(up.full_name, '') AS full_name
    FROM users u
    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id
    WHERE u.user_id = ?
      AND u.role = 'organizer'
      AND u.account_status = 'active'
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $user_sql);

if (!$stmt) {
    die('Unable to verify organizer account.');
}

mysqli_stmt_bind_param(
    $stmt,
    'i',
    $organizer_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$organizer = $result
    ? mysqli_fetch_assoc($result)
    : null;

mysqli_stmt_close($stmt);

if (!$organizer) {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    go('login.php?error=unauthorized');
}

$organizer_name = trim(
    (string)($organizer['full_name'] ?? '')
);

if ($organizer_name === '') {
    $organizer_name = 'Organizer';
}

$organizer_email = (string)(
    $organizer['email'] ?? ''
);

$organizer_initial = strtoupper(
    mb_substr(
        $organizer_name,
        0,
        1,
        'UTF-8'
    )
);

$organizer_department_id = 0;

if (
    column_exists(
        $conn,
        'users',
        'department_id'
    )
) {
    $stmt = mysqli_prepare(
        $conn,
        "
        SELECT department_id
        FROM users
        WHERE user_id = ?
        LIMIT 1
        "
    );

    if ($stmt) {
        mysqli_stmt_bind_param(
            $stmt,
            'i',
            $organizer_id
        );

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_bind_result(
                $stmt,
                $user_department_id
            );

            if (mysqli_stmt_fetch($stmt)) {
                $organizer_department_id =
                    (int)($user_department_id ?? 0);
            }
        }

        mysqli_stmt_close($stmt);
    }
}

if (
    $organizer_department_id <= 0 &&
    column_exists(
        $conn,
        'user_profiles',
        'department_id'
    )
) {
    $stmt = mysqli_prepare(
        $conn,
        "
        SELECT department_id
        FROM user_profiles
        WHERE user_id = ?
        LIMIT 1
        "
    );

    if ($stmt) {
        mysqli_stmt_bind_param(
            $stmt,
            'i',
            $organizer_id
        );

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_bind_result(
                $stmt,
                $profile_department_id
            );

            if (mysqli_stmt_fetch($stmt)) {
                $organizer_department_id =
                    (int)($profile_department_id ?? 0);
            }
        }

        mysqli_stmt_close($stmt);
    }
}

$section = isset($_GET['section'])
    ? trim((string)$_GET['section'])
    : 'dashboard';

$allowed_sections = [
    'dashboard',
    'events',
    'create-event',
    'registrations',
    'attendance',
    'feedback',
    'announcements',
    'profile'
];

if (!in_array($section, $allowed_sections, true)) {
    $section = 'dashboard';
}

if (
    !isset($_SESSION['organizer_csrf']) ||
    !is_string($_SESSION['organizer_csrf'])
) {
    $_SESSION['organizer_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf_token =
    $_SESSION['organizer_csrf'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $posted_token =
        isset($_POST['csrf_token'])
            ? (string)$_POST['csrf_token']
            : '';

    if (
        !hash_equals(
            $csrf_token,
            $posted_token
        )
    ) {
        flash(
            'error',
            'Security token expired. Please try again.'
        );

        go('organizer-dashboard.php');
    }

    $action = post_string('action');

    if ($action === 'create_event') {

        $title =
            post_string('title');

        $event_date =
            post_string('event_date');

        $start_time =
            post_string('start_time');

        $max_capacity =
            post_int('max_capacity');

        $category_id =
            post_int('category_id');

        $venue_id =
            post_int('venue_id');

        $department_id =
            post_int('department_id');

        if ($department_id <= 0) {
            $department_id =
                $organizer_department_id;
        }

        if ($title === '') {
            flash(
                'error',
                'Event title is required.'
            );

            go(
                'organizer-dashboard.php?section=create-event'
            );
        }

        if ($event_date === '') {
            flash(
                'error',
                'Event date is required.'
            );

            go(
                'organizer-dashboard.php?section=create-event'
            );
        }

        if ($max_capacity < 1) {
            flash(
                'error',
                'Maximum capacity must be at least 1.'
            );

            go(
                'organizer-dashboard.php?section=create-event'
            );
        }

        $columns = [
            'organizer_id',
            'title',
            'event_date',
            'start_time',
            'max_capacity',
            'event_status'
        ];

        $values = [
            $organizer_id,
            $title,
            $event_date,
            $start_time !== ''
                ? $start_time
                : null,
            $max_capacity,
            'pending_approval'
        ];

        $types = 'isssis';

        if (
            column_exists(
                $conn,
                'events',
                'department_id'
            )
        ) {
            if ($department_id > 0) {

                $department_valid = false;

                if (
                    table_exists(
                        $conn,
                        'departments'
                    ) &&
                    column_exists(
                        $conn,
                        'departments',
                        'department_id'
                    )
                ) {
                    $check_department = mysqli_prepare(
                        $conn,
                        "
                        SELECT department_id
                        FROM departments
                        WHERE department_id = ?
                        LIMIT 1
                        "
                    );

                    if ($check_department) {
                        mysqli_stmt_bind_param(
                            $check_department,
                            'i',
                            $department_id
                        );

                        mysqli_stmt_execute(
                            $check_department
                        );

                        mysqli_stmt_bind_result(
                            $check_department,
                            $valid_department_id
                        );

                        if (
                            mysqli_stmt_fetch(
                                $check_department
                            )
                        ) {
                            $department_valid = true;
                            $department_id =
                                (int)$valid_department_id;
                        }

                        mysqli_stmt_close(
                            $check_department
                        );
                    }
                }

                if (!$department_valid) {
                    flash(
                        'error',
                        'Please select a valid department.'
                    );

                    go(
                        'organizer-dashboard.php?section=create-event'
                    );
                }

                $columns[] =
                    'department_id';

                $values[] =
                    $department_id;

                $types .= 'i';

            } elseif (
                column_nullable(
                    $conn,
                    'events',
                    'department_id'
                )
            ) {

                $columns[] =
                    'department_id';

                $values[] =
                    null;

                $types .= 'i';

            } else {

                flash(
                    'error',
                    'Your organizer account does not have a valid department assigned.'
                );

                go(
                    'organizer-dashboard.php?section=create-event'
                );
            }
        }

        if (
            $category_id > 0 &&
            column_exists(
                $conn,
                'events',
                'category_id'
            )
        ) {
            $columns[] =
                'category_id';

            $values[] =
                $category_id;

            $types .= 'i';
        }

        if (
            $venue_id > 0 &&
            column_exists(
                $conn,
                'events',
                'venue_id'
            )
        ) {
            $columns[] =
                'venue_id';

            $values[] =
                $venue_id;

            $types .= 'i';
        }

        $placeholders = implode(
            ', ',
            array_fill(
                0,
                count($columns),
                '?'
            )
        );

        $sql = "
            INSERT INTO events
            (" . implode(', ', $columns) . ")
            VALUES
            ($placeholders)
        ";

        $stmt = mysqli_prepare(
            $conn,
            $sql
        );

        if (!$stmt) {
            flash(
                'error',
                'Unable to create event: ' .
                mysqli_error($conn)
            );

            go(
                'organizer-dashboard.php?section=create-event'
            );
        }

        mysqli_stmt_bind_param(
            $stmt,
            $types,
            ...$values
        );

        if (mysqli_stmt_execute($stmt)) {

            flash(
                'success',
                'Event created successfully and submitted for approval.'
            );

            mysqli_stmt_close($stmt);

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        $error =
            mysqli_stmt_error($stmt);

        mysqli_stmt_close($stmt);

        flash(
            'error',
            'Event could not be created: ' .
            $error
        );

        go(
            'organizer-dashboard.php?section=create-event'
        );
    }

    if ($action === 'update_event') {

        $event_id =
            post_int('event_id');

        $title =
            post_string('title');

        $event_date =
            post_string('event_date');

        $start_time =
            post_string('start_time');

        $max_capacity =
            post_int('max_capacity');

        $category_id =
            post_int('category_id');

        $venue_id =
            post_int('venue_id');

        $department_id =
            post_int('department_id');

        if ($department_id <= 0) {
            $department_id =
                $organizer_department_id;
        }

        if ($event_id <= 0) {
            flash(
                'error',
                'Invalid event.'
            );

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        if (
            $title === '' ||
            $event_date === ''
        ) {
            flash(
                'error',
                'Event title and date are required.'
            );

            go(
                'organizer-dashboard.php?section=events&edit=' .
                $event_id
            );
        }

        if ($max_capacity < 1) {
            flash(
                'error',
                'Maximum capacity must be at least 1.'
            );

            go(
                'organizer-dashboard.php?section=events&edit=' .
                $event_id
            );
        }

        $check = mysqli_prepare(
            $conn,
            "
            SELECT event_id
            FROM events
            WHERE event_id = ?
              AND organizer_id = ?
            LIMIT 1
            "
        );

        if (!$check) {
            flash(
                'error',
                'Unable to verify event.'
            );

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        mysqli_stmt_bind_param(
            $check,
            'ii',
            $event_id,
            $organizer_id
        );

        mysqli_stmt_execute($check);

        $check_result =
            mysqli_stmt_get_result($check);

        $owned =
            $check_result &&
            mysqli_num_rows($check_result) > 0;

        mysqli_stmt_close($check);

        if (!$owned) {
            flash(
                'error',
                'You are not allowed to edit this event.'
            );

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        $set_parts = [
            'title = ?',
            'event_date = ?',
            'start_time = ?',
            'max_capacity = ?'
        ];

        $values = [
            $title,
            $event_date,
            $start_time,
            $max_capacity
        ];

        $types = 'sssi';

        if (
            column_exists(
                $conn,
                'events',
                'category_id'
            )
        ) {
            $set_parts[] =
                'category_id = NULLIF(?, 0)';

            $values[] =
                $category_id;

            $types .= 'i';
        }

        if (
            column_exists(
                $conn,
                'events',
                'venue_id'
            )
        ) {
            $set_parts[] =
                'venue_id = NULLIF(?, 0)';

            $values[] =
                $venue_id;

            $types .= 'i';
        }

        if (
            column_exists(
                $conn,
                'events',
                'department_id'
            )
        ) {

            if ($department_id > 0) {

                $department_valid = false;

                if (
                    table_exists(
                        $conn,
                        'departments'
                    )
                ) {
                    $check_department = mysqli_prepare(
                        $conn,
                        "
                        SELECT department_id
                        FROM departments
                        WHERE department_id = ?
                        LIMIT 1
                        "
                    );

                    if ($check_department) {

                        mysqli_stmt_bind_param(
                            $check_department,
                            'i',
                            $department_id
                        );

                        mysqli_stmt_execute(
                            $check_department
                        );

                        mysqli_stmt_bind_result(
                            $check_department,
                            $valid_department_id
                        );

                        if (
                            mysqli_stmt_fetch(
                                $check_department
                            )
                        ) {
                            $department_valid = true;
                            $department_id =
                                (int)$valid_department_id;
                        }

                        mysqli_stmt_close(
                            $check_department
                        );
                    }
                }

                if (!$department_valid) {
                    flash(
                        'error',
                        'Please select a valid department.'
                    );

                    go(
                        'organizer-dashboard.php?section=events&edit=' .
                        $event_id
                    );
                }

                $set_parts[] =
                    'department_id = ?';

                $values[] =
                    $department_id;

                $types .= 'i';

            } elseif (
                column_nullable(
                    $conn,
                    'events',
                    'department_id'
                )
            ) {

                $set_parts[] =
                    'department_id = NULL';

            } else {

                flash(
                    'error',
                    'Your organizer account does not have a valid department assigned.'
                );

                go(
                    'organizer-dashboard.php?section=events&edit=' .
                    $event_id
                );
            }
        }

        $values[] =
            $event_id;

        $types .= 'i';

        $values[] =
            $organizer_id;

        $types .= 'i';

        $sql = "
            UPDATE events
            SET
                " . implode(', ', $set_parts) . "
            WHERE event_id = ?
              AND organizer_id = ?
        ";

        $stmt =
            mysqli_prepare(
                $conn,
                $sql
            );

        if (!$stmt) {
            flash(
                'error',
                'Unable to update event: ' .
                mysqli_error($conn)
            );

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        mysqli_stmt_bind_param(
            $stmt,
            $types,
            ...$values
        );

        if (mysqli_stmt_execute($stmt)) {
            flash(
                'success',
                'Event updated successfully.'
            );
        } else {
            flash(
                'error',
                'Unable to update event: ' .
                mysqli_stmt_error($stmt)
            );
        }

        mysqli_stmt_close($stmt);

        go(
            'organizer-dashboard.php?section=events'
        );
    }

    if ($action === 'delete_event') {

        $event_id =
            post_int('event_id');

        if ($event_id <= 0) {
            flash(
                'error',
                'Invalid event.'
            );

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        $stmt = mysqli_prepare(
            $conn,
            "
            DELETE FROM events
            WHERE event_id = ?
              AND organizer_id = ?
            LIMIT 1
            "
        );

        if (!$stmt) {
            flash(
                'error',
                'Unable to delete event.'
            );

            go(
                'organizer-dashboard.php?section=events'
            );
        }

        mysqli_stmt_bind_param(
            $stmt,
            'ii',
            $event_id,
            $organizer_id
        );

        if (mysqli_stmt_execute($stmt)) {

            if (
                mysqli_stmt_affected_rows($stmt) > 0
            ) {
                flash(
                    'success',
                    'Event deleted successfully.'
                );
            } else {
                flash(
                    'error',
                    'Event was not found or does not belong to you.'
                );
            }

        } else {
            flash(
                'error',
                'Event cannot be deleted because it may already have related registrations.'
            );
        }

        mysqli_stmt_close($stmt);

        go(
            'organizer-dashboard.php?section=events'
        );
    }

    if ($action === 'update_registration') {

        $registration_id =
            post_int('registration_id');

        $status =
            post_string('status');

        $allowed_statuses = [
            'confirmed',
            'attended',
            'no_show',
            'cancelled',
            'pending'
        ];

        if (
            $registration_id <= 0 ||
            !in_array(
                $status,
                $allowed_statuses,
                true
            )
        ) {
            flash(
                'error',
                'Invalid registration update.'
            );

            go(
                'organizer-dashboard.php?section=registrations'
            );
        }

        $sql = "
            UPDATE event_registrations er
            INNER JOIN events e
                ON e.event_id = er.event_id
            SET er.status = ?
            WHERE er.registration_id = ?
              AND e.organizer_id = ?
        ";

        $stmt =
            mysqli_prepare(
                $conn,
                $sql
            );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                'sii',
                $status,
                $registration_id,
                $organizer_id
            );

            if (mysqli_stmt_execute($stmt)) {
                flash(
                    'success',
                    'Registration status updated.'
                );
            } else {
                flash(
                    'error',
                    'Unable to update registration.'
                );
            }

            mysqli_stmt_close($stmt);

        } else {
            flash(
                'error',
                'Unable to prepare registration update.'
            );
        }

        go(
            'organizer-dashboard.php?section=registrations'
        );
    }

    if ($action === 'update_profile') {

        $full_name =
            post_string('full_name');

        if ($full_name === '') {
            flash(
                'error',
                'Full name is required.'
            );

            go(
                'organizer-dashboard.php?section=profile'
            );
        }

        $stmt = mysqli_prepare(
            $conn,
            "
            UPDATE user_profiles
            SET full_name = ?
            WHERE user_id = ?
            "
        );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                'si',
                $full_name,
                $organizer_id
            );

            if (mysqli_stmt_execute($stmt)) {
                flash(
                    'success',
                    'Profile updated successfully.'
                );
            } else {
                flash(
                    'error',
                    'Unable to update profile.'
                );
            }

            mysqli_stmt_close($stmt);

        } else {
            flash(
                'error',
                'Unable to prepare profile update.'
            );
        }

        go(
            'organizer-dashboard.php?section=profile'
        );
    }

    if ($action === 'create_announcement') {

        $title =
            post_string('announcement_title');

        $message =
            post_string('announcement_message');

        $event_id =
            post_int('announcement_event_id');

        if (
            $title === '' ||
            $message === ''
        ) {
            flash(
                'error',
                'Announcement title and message are required.'
            );

            go(
                'organizer-dashboard.php?section=announcements'
            );
        }

        $sql = "
            INSERT INTO announcements
            (
                organizer_id,
                event_id,
                title,
                message
            )
            VALUES
            (?, NULLIF(?, 0), ?, ?)
        ";

        $stmt =
            mysqli_prepare(
                $conn,
                $sql
            );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                'iiss',
                $organizer_id,
                $event_id,
                $title,
                $message
            );

            if (mysqli_stmt_execute($stmt)) {
                flash(
                    'success',
                    'Announcement published successfully.'
                );
            } else {
                flash(
                    'error',
                    'Announcement could not be published: ' .
                    mysqli_stmt_error($stmt)
                );
            }

            mysqli_stmt_close($stmt);

        } else {
            flash(
                'error',
                'Announcements table is not configured yet.'
            );
        }

        go(
            'organizer-dashboard.php?section=announcements'
        );
    }
}

$flash =
    get_flash();

$total_events =
    dashboard_count(
        $conn,
        "
        SELECT COUNT(*)
        FROM events
        WHERE organizer_id = ?
        ",
        $organizer_id
    );

$pending_events =
    dashboard_count(
        $conn,
        "
        SELECT COUNT(*)
        FROM events
        WHERE organizer_id = ?
          AND event_status = 'pending_approval'
        ",
        $organizer_id
    );

$upcoming_events =
    dashboard_count(
        $conn,
        "
        SELECT COUNT(*)
        FROM events
        WHERE organizer_id = ?
          AND event_date >= CURDATE()
          AND event_status NOT IN
              ('cancelled', 'completed')
        ",
        $organizer_id
    );

$completed_events =
    dashboard_count(
        $conn,
        "
        SELECT COUNT(*)
        FROM events
        WHERE organizer_id = ?
          AND event_status = 'completed'
        ",
        $organizer_id
    );

$total_registrations =
    dashboard_count(
        $conn,
        "
        SELECT COUNT(*)
        FROM event_registrations er
        INNER JOIN events e
            ON e.event_id = er.event_id
        WHERE e.organizer_id = ?
          AND er.status <> 'cancelled'
        ",
        $organizer_id
    );

$total_attendance =
    dashboard_count(
        $conn,
        "
        SELECT COUNT(*)
        FROM event_registrations er
        INNER JOIN events e
            ON e.event_id = er.event_id
        WHERE e.organizer_id = ?
          AND er.status = 'attended'
        ",
        $organizer_id
    );

$average_rating = 0;
$total_feedback = 0;

$rating_sql = "
    SELECT
        COALESCE(
            AVG(ef.overall_rating),
            0
        ),
        COUNT(ef.feedback_id)
    FROM event_feedback ef
    INNER JOIN events e
        ON e.event_id = ef.event_id
    WHERE e.organizer_id = ?
      AND ef.status = 'visible'
";

$stmt =
    mysqli_prepare(
        $conn,
        $rating_sql
    );

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $organizer_id
    );

    if (mysqli_stmt_execute($stmt)) {

        mysqli_stmt_bind_result(
            $stmt,
            $avg_rating,
            $feedback_count
        );

        if (mysqli_stmt_fetch($stmt)) {

            $average_rating =
                round(
                    (float)$avg_rating,
                    1
                );

            $total_feedback =
                (int)$feedback_count;
        }
    }

    mysqli_stmt_close($stmt);
}

$attendance_rate = 0;

if ($total_registrations > 0) {

    $attendance_rate =
        (int)round(
            (
                $total_attendance /
                $total_registrations
            ) * 100
        );
}

$attendance_rate =
    min(
        100,
        max(
            0,
            $attendance_rate
        )
    );

$events_data = [];

$department_select = '';

if (
    column_exists(
        $conn,
        'events',
        'department_id'
    )
) {
    $department_select =
        'e.department_id,';
}

$sql = "
    SELECT
        e.event_id,
        e.title,
        e.event_date,
        e.start_time,
        e.event_status,
        e.max_capacity,
        e.category_id,
        e.venue_id,
        $department_select

        ec.category_name,

        v.venue_name,
        v.building_name,

        (
            SELECT COUNT(*)
            FROM event_registrations er2
            WHERE er2.event_id = e.event_id
              AND er2.status <> 'cancelled'
        ) AS registration_count

    FROM events e

    LEFT JOIN event_categories ec
        ON ec.category_id = e.category_id

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    WHERE e.organizer_id = ?

    ORDER BY
        e.event_date DESC,
        e.start_time DESC
";

$stmt =
    mysqli_prepare(
        $conn,
        $sql
    );

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $organizer_id
    );

    if (mysqli_stmt_execute($stmt)) {

        $result =
            mysqli_stmt_get_result($stmt);

        if ($result) {

            while (
                $row =
                mysqli_fetch_assoc($result)
            ) {
                $events_data[] = $row;
            }
        }
    }

    mysqli_stmt_close($stmt);
}

$upcoming_data = [];

$sql = "
    SELECT
        e.event_id,
        e.title,
        e.event_date,
        e.start_time,
        e.event_status,
        e.max_capacity,

        v.venue_name,
        v.building_name,

        (
            SELECT COUNT(*)
            FROM event_registrations er2
            WHERE er2.event_id = e.event_id
              AND er2.status <> 'cancelled'
        ) AS registration_count

    FROM events e

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    WHERE e.organizer_id = ?
      AND e.event_date >= CURDATE()
      AND e.event_status NOT IN
          ('cancelled', 'completed')

    ORDER BY
        e.event_date ASC,
        e.start_time ASC

    LIMIT 6
";

$stmt =
    mysqli_prepare(
        $conn,
        $sql
    );

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $organizer_id
    );

    if (mysqli_stmt_execute($stmt)) {

        $result =
            mysqli_stmt_get_result($stmt);

        if ($result) {

            while (
                $row =
                mysqli_fetch_assoc($result)
            ) {
                $upcoming_data[] = $row;
            }
        }
    }

    mysqli_stmt_close($stmt);
}

$registrations = [];

$sql = "
    SELECT
        er.registration_id,
        er.registration_code,
        er.registered_at,
        er.status,

        e.event_id,
        e.title AS event_title,

        COALESCE(
            up.full_name,
            u.email,
            'Participant'
        ) AS student_name

    FROM event_registrations er

    INNER JOIN events e
        ON e.event_id = er.event_id

    INNER JOIN users u
        ON u.user_id = er.student_id

    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id

    WHERE e.organizer_id = ?

    ORDER BY
        er.registered_at DESC

    LIMIT 50
";

$stmt =
    mysqli_prepare(
        $conn,
        $sql
    );

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $organizer_id
    );

    if (mysqli_stmt_execute($stmt)) {

        $result =
            mysqli_stmt_get_result($stmt);

        if ($result) {

            while (
                $row =
                mysqli_fetch_assoc($result)
            ) {
                $registrations[] = $row;
            }
        }
    }

    mysqli_stmt_close($stmt);
}

$feedback = [];

$sql = "
    SELECT
        ef.feedback_id,
        ef.overall_rating,
        ef.comments,
        ef.submitted_at,
        ef.is_anonymous,

        COALESCE(
            up.full_name,
            'Participant'
        ) AS student_name,

        e.title AS event_title

    FROM event_feedback ef

    INNER JOIN events e
        ON e.event_id = ef.event_id

    LEFT JOIN user_profiles up
        ON up.user_id = ef.student_id

    WHERE e.organizer_id = ?
      AND ef.status = 'visible'

    ORDER BY
        ef.submitted_at DESC

    LIMIT 20
";

$stmt =
    mysqli_prepare(
        $conn,
        $sql
    );

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $organizer_id
    );

    if (mysqli_stmt_execute($stmt)) {

        $result =
            mysqli_stmt_get_result($stmt);

        if ($result) {

            while (
                $row =
                mysqli_fetch_assoc($result)
            ) {
                $feedback[] = $row;
            }
        }
    }

    mysqli_stmt_close($stmt);
}

$categories = [];

if (
    table_exists(
        $conn,
        'event_categories'
    )
) {

    $result =
        mysqli_query(
            $conn,
            "
            SELECT
                category_id,
                category_name
            FROM event_categories
            ORDER BY category_name ASC
            "
        );

    if ($result) {

        while (
            $row =
            mysqli_fetch_assoc($result)
        ) {
            $categories[] = $row;
        }
    }
}

$venues = [];

if (
    table_exists(
        $conn,
        'venues'
    )
) {

    $result =
        mysqli_query(
            $conn,
            "
            SELECT
                venue_id,
                venue_name,
                building_name
            FROM venues
            ORDER BY venue_name ASC
            "
        );

    if ($result) {

        while (
            $row =
            mysqli_fetch_assoc($result)
        ) {
            $venues[] = $row;
        }
    }
}

$departments = [];

if (
    table_exists(
        $conn,
        'departments'
    )
) {

    $result =
        mysqli_query(
            $conn,
            "
            SELECT
                department_id,
                department_name
            FROM departments
            ORDER BY department_name ASC
            "
        );

    if ($result) {

        while (
            $row =
            mysqli_fetch_assoc($result)
        ) {
            $departments[] = $row;
        }
    }
}

$edit_event = null;

if (
    $section === 'events' &&
    isset($_GET['edit']) &&
    is_numeric($_GET['edit'])
) {

    $edit_id =
        (int)$_GET['edit'];

    $department_select =
        column_exists(
            $conn,
            'events',
            'department_id'
        )
        ? 'department_id,'
        : '';

    $stmt =
        mysqli_prepare(
            $conn,
            "
            SELECT
                event_id,
                title,
                event_date,
                start_time,
                max_capacity,
                category_id,
                venue_id,
                $department_select
                event_status
            FROM events
            WHERE event_id = ?
              AND organizer_id = ?
            LIMIT 1
            "
        );

    if ($stmt) {

        mysqli_stmt_bind_param(
            $stmt,
            'ii',
            $edit_id,
            $organizer_id
        );

        mysqli_stmt_execute($stmt);

        $result =
            mysqli_stmt_get_result($stmt);

        if ($result) {
            $edit_event =
                mysqli_fetch_assoc($result);
        }

        mysqli_stmt_close($stmt);
    }
}

$announcements = [];

if (
    table_exists(
        $conn,
        'announcements'
    )
) {

    $announcement_sql = "
        SELECT
            announcement_id,
            title,
            message,
            created_at
        FROM announcements
        WHERE organizer_id = ?
        ORDER BY created_at DESC
        LIMIT 20
    ";

    $stmt =
        mysqli_prepare(
            $conn,
            $announcement_sql
        );

    if ($stmt) {

        mysqli_stmt_bind_param(
            $stmt,
            'i',
            $organizer_id
        );

        if (mysqli_stmt_execute($stmt)) {

            $result =
                mysqli_stmt_get_result($stmt);

            if ($result) {

                while (
                    $row =
                    mysqli_fetch_assoc($result)
                ) {
                    $announcements[] = $row;
                }
            }
        }

        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    EventSphere | Organizer Portal
</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

:root{

    --primary:#4f46e5;
    --primary-dark:#3730a3;

    --sidebar:#111827;
    --sidebar-hover:#1f2937;

    --bg:#f5f7fb;
    --card:#ffffff;

    --text:#172033;
    --muted:#718096;

    --border:#e7eaf0;

    --success:#16a34a;
    --warning:#d97706;
    --danger:#dc2626;
}

html{
    scroll-behavior:smooth;
}

body{

    font-family:
        Inter,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        sans-serif;

    background:var(--bg);
    color:var(--text);
}

a{
    text-decoration:none;
    color:inherit;
}

button,
input,
select,
textarea{
    font:inherit;
}

button{
    cursor:pointer;
}

/* SIDEBAR */

.sidebar{

    width:255px;

    position:fixed;

    inset:0 auto 0 0;

    background:
        linear-gradient(
            180deg,
            #111827 0%,
            #0f172a 100%
        );

    color:#fff;

    padding:20px 14px;

    overflow-y:auto;

    z-index:1000;
}

.brand{

    display:flex;
    align-items:center;

    gap:12px;

    padding:
        5px 10px 24px;
}

.brand-logo{

    width:43px;
    height:43px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:13px;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #8b5cf6
        );

    font-size:14px;
    font-weight:900;
}

.brand h2{
    font-size:18px;
}

.brand span{

    display:block;

    margin-top:2px;

    color:#9ca3af;

    font-size:10px;
}

.nav-heading{

    color:#64748b;

    font-size:9px;

    font-weight:800;

    text-transform:uppercase;

    letter-spacing:.1em;

    padding:
        16px 12px 7px;
}

.nav-link{

    display:flex;
    align-items:center;

    gap:11px;

    padding:11px 12px;

    border-radius:10px;

    color:#cbd5e1;

    font-size:12px;

    margin-bottom:3px;

    transition:.2s;
}

.nav-link:hover{

    background:
        var(--sidebar-hover);

    color:#fff;
}

.nav-link.active{

    background:
        linear-gradient(
            135deg,
            #4f46e5,
            #6366f1
        );

    color:#fff;

    box-shadow:
        0 8px 20px
        rgba(79,70,229,.22);
}

.nav-icon{

    width:20px;

    text-align:center;

    font-size:14px;
}

.sidebar-bottom{

    margin-top:20px;

    border-top:
        1px solid #273244;

    padding-top:14px;
}

.logout{
    color:#fca5a5;
}

/* MAIN */

.main{

    margin-left:255px;

    min-height:100vh;
}

/* TOPBAR */

.topbar{

    height:72px;

    background:#fff;

    border-bottom:
        1px solid var(--border);

    display:flex;

    align-items:center;

    justify-content:space-between;

    padding:
        0 28px;

    position:sticky;

    top:0;

    z-index:100;
}

.top-title h1{

    font-size:20px;

    font-weight:800;
}

.top-title p{

    color:var(--muted);

    font-size:11px;

    margin-top:3px;
}

.profile{

    display:flex;

    align-items:center;

    gap:10px;
}

.avatar{

    width:39px;
    height:39px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    color:#fff;

    font-size:13px;
    font-weight:800;

    background:
        linear-gradient(
            135deg,
            #4f46e5,
            #8b5cf6
        );
}

.profile strong{

    display:block;

    font-size:12px;
}

.profile span{

    display:block;

    color:#94a3b8;

    font-size:9px;

    margin-top:2px;
}

/* CONTENT */

.content{
    padding:26px;
}

/* FLASH */

.alert{

    padding:13px 16px;

    border-radius:11px;

    margin-bottom:18px;

    font-size:12px;

    font-weight:700;
}

.alert.success{

    background:#dcfce7;
    color:#166534;

    border:
        1px solid #bbf7d0;
}

.alert.error{

    background:#fee2e2;
    color:#991b1b;

    border:
        1px solid #fecaca;
}

/* WELCOME */

.welcome{

    position:relative;

    overflow:hidden;

    display:flex;

    align-items:center;

    justify-content:space-between;

    gap:20px;

    padding:
        27px 29px;

    margin-bottom:20px;

    border-radius:18px;

    color:#fff;

    background:
        linear-gradient(
            135deg,
            #111827,
            #312e81,
            #4338ca
        );
}

.welcome h2{

    position:relative;

    z-index:1;

    font-size:24px;

    margin-bottom:5px;
}

.welcome p{

    position:relative;

    z-index:1;

    color:#c7d2fe;

    font-size:12px;
}

.create-btn{

    position:relative;

    z-index:2;

    padding:
        11px 17px;

    border-radius:10px;

    background:#fff;

    color:#4338ca;

    font-size:11px;

    font-weight:800;

    white-space:nowrap;
}

.create-btn:hover{
    transform:translateY(-2px);
}

/* STATS */

.stats{

    display:grid;

    grid-template-columns:
        repeat(6,minmax(0,1fr));

    gap:13px;

    margin-bottom:20px;
}

.stat{

    background:#fff;

    border:
        1px solid var(--border);

    border-radius:14px;

    padding:16px;

    transition:.2s;
}

.stat:hover{

    transform:
        translateY(-2px);

    box-shadow:
        0 12px 25px
        rgba(15,23,42,.06);
}

.stat-top{

    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-bottom:12px;
}

.stat-label{

    color:#64748b;

    font-size:10px;

    font-weight:700;
}

.stat-icon{

    width:34px;
    height:34px;

    border-radius:9px;

    display:flex;

    align-items:center;
    justify-content:center;

    background:#eef2ff;

    color:var(--primary);

    font-size:14px;
}

.stat-value{

    font-size:24px;

    font-weight:900;
}

.stat-description{

    color:#9ca3af;

    font-size:9px;

    margin-top:5px;
}

/* GRID */

.grid{

    display:grid;

    grid-template-columns:
        1.55fr 1fr;

    gap:18px;

    margin-bottom:18px;
}

/* PANEL */

.panel{

    background:#fff;

    border:
        1px solid var(--border);

    border-radius:15px;

    overflow:hidden;

    box-shadow:
        0 3px 12px
        rgba(15,23,42,.025);

    margin-bottom:18px;
}

.panel-header{

    display:flex;

    align-items:center;

    justify-content:space-between;

    padding:
        17px 19px;

    border-bottom:
        1px solid #eef1f5;
}

.panel-header h3{

    font-size:13px;

    font-weight:800;
}

.view{

    color:var(--primary);

    font-size:10px;

    font-weight:800;
}

/* EVENT ROW */

.event-row{

    display:flex;

    align-items:center;

    gap:12px;

    padding:
        13px 19px;

    border-bottom:
        1px solid #f0f2f5;
}

.event-row:last-child{
    border-bottom:0;
}

.event-date{

    width:47px;
    height:49px;

    flex-shrink:0;

    display:flex;

    flex-direction:column;

    align-items:center;
    justify-content:center;

    border-radius:10px;

    background:#eef2ff;

    color:#4338ca;
}

.event-date strong{

    font-size:16px;

    line-height:1;
}

.event-date span{

    font-size:8px;

    font-weight:700;

    margin-top:3px;

    text-transform:uppercase;
}

.event-main{

    flex:1;

    min-width:0;
}

.event-main h4{

    font-size:11px;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}

.event-main p{

    color:#94a3b8;

    font-size:9px;

    margin-top:4px;
}

.event-actions{

    display:flex;

    gap:5px;

    margin-top:5px;
}

.small-btn{

    display:inline-block;

    border:0;

    padding:
        4px 7px;

    border-radius:6px;

    font-size:8px;

    font-weight:800;
}

.small-btn.edit{

    background:#eef2ff;

    color:#4338ca;
}

.small-btn.delete{

    background:#fee2e2;

    color:#991b1b;
}

.event-side{

    min-width:90px;

    text-align:right;
}

.badge{

    display:inline-flex;

    padding:
        4px 8px;

    border-radius:999px;

    font-size:7px;

    font-weight:800;

    text-transform:capitalize;
}

.approved,
.published,
.confirmed{

    background:#dcfce7;

    color:#166534;
}

.pending_approval,
.pending{

    background:#fef3c7;

    color:#92400e;
}

.completed,
.attended{

    background:#e0e7ff;

    color:#3730a3;
}

.cancelled{

    background:#fee2e2;

    color:#991b1b;
}

.no_show{

    background:#fef3c7;

    color:#92400e;
}

.registered{

    font-size:9px;

    font-weight:800;

    margin-top:5px;
}

/* REGISTRATION */

.registration{

    display:flex;

    align-items:center;

    gap:10px;

    padding:
        12px 19px;

    border-bottom:
        1px solid #f0f2f5;
}

.registration:last-child{
    border-bottom:0;
}

.reg-avatar{

    width:34px;
    height:34px;

    flex-shrink:0;

    border-radius:50%;

    display:flex;

    align-items:center;
    justify-content:center;

    background:#f1f5f9;

    color:#475569;

    font-size:10px;

    font-weight:900;
}

.reg-info{

    flex:1;

    min-width:0;
}

.reg-info strong{

    display:block;

    font-size:10px;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}

.reg-info span{

    display:block;

    color:#94a3b8;

    font-size:8px;

    margin-top:3px;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}

/* PARTICIPATION */

.participation{
    padding:20px;
}

.part-grid{

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:12px;
}

.part-box{

    padding:16px;

    border-radius:11px;

    background:#f8fafc;
}

.part-box span{

    color:#64748b;

    font-size:9px;
}

.part-box strong{

    display:block;

    font-size:25px;

    margin-top:6px;
}

.progress-area{
    margin-top:18px;
}

.progress-head{

    display:flex;

    justify-content:space-between;

    color:#64748b;

    font-size:9px;

    margin-bottom:6px;
}

.progress-head strong{
    color:var(--primary);
}

.progress{

    height:8px;

    background:#e5e7eb;

    border-radius:20px;

    overflow:hidden;
}

.progress-bar{

    height:100%;

    width:<?= (int)$attendance_rate ?>%;

    background:
        linear-gradient(
            90deg,
            #4f46e5,
            #8b5cf6
        );

    border-radius:20px;
}

/* FEEDBACK */

.feedback{
    padding:
        5px 19px 12px;
}

.feedback-item{

    padding:
        12px 0;

    border-bottom:
        1px solid #f0f2f5;
}

.feedback-item:last-child{
    border-bottom:0;
}

.feedback-head{

    display:flex;

    justify-content:space-between;

    gap:10px;
}

.feedback-name{

    font-size:10px;

    font-weight:800;
}

.stars{

    color:#f59e0b;

    font-size:10px;

    letter-spacing:1px;
}

.feedback-event{

    color:#94a3b8;

    font-size:8px;

    margin-top:3px;
}

.feedback-comment{

    color:#475569;

    font-size:9px;

    line-height:1.5;

    margin-top:5px;
}

/* EMPTY */

.empty{

    padding:
        30px 20px;

    text-align:center;

    color:#94a3b8;
}

.empty-icon{

    font-size:25px;

    margin-bottom:7px;
}

.empty p{
    font-size:10px;
}

/* FORM */

.form-grid{

    display:grid;

    grid-template-columns:
        repeat(2,1fr);

    gap:15px;

    padding:20px;
}

.form-group{
    display:flex;
    flex-direction:column;
    gap:6px;
}

.form-group.full{
    grid-column:
        1 / -1;
}

.form-group label{

    color:#475569;

    font-size:10px;

    font-weight:800;
}

.form-control{

    width:100%;

    padding:
        11px 12px;

    border:
        1px solid #dbe1ea;

    border-radius:9px;

    outline:none;

    background:#fff;

    color:#172033;

    font-size:11px;

    transition:.2s;
}

.form-control:focus{

    border-color:#818cf8;

    box-shadow:
        0 0 0 3px
        rgba(99,102,241,.1);
}

textarea.form-control{

    min-height:110px;

    resize:vertical;
}

.form-actions{

    display:flex;

    gap:10px;

    padding:
        0 20px 20px;
}

.primary-btn{

    border:0;

    padding:
        11px 17px;

    border-radius:9px;

    background:
        linear-gradient(
            135deg,
            #4f46e5,
            #6366f1
        );

    color:#fff;

    font-size:10px;

    font-weight:800;
}

.secondary-btn{

    display:inline-flex;

    align-items:center;

    justify-content:center;

    padding:
        11px 17px;

    border-radius:9px;

    background:#f1f5f9;

    color:#475569;

    font-size:10px;

    font-weight:800;
}

/* TABLE */

.table-wrap{

    width:100%;

    overflow-x:auto;
}

table{

    width:100%;

    border-collapse:collapse;

    min-width:700px;
}

th,
td{

    padding:
        12px 15px;

    border-bottom:
        1px solid #eef1f5;

    text-align:left;

    font-size:10px;
}

th{

    background:#f8fafc;

    color:#64748b;

    font-size:9px;

    text-transform:uppercase;

    letter-spacing:.04em;
}

td strong{
    font-size:10px;
}

.status-form{

    display:flex;

    align-items:center;

    gap:5px;
}

.status-select{

    padding:
        6px 8px;

    border:
        1px solid #dbe1ea;

    border-radius:7px;

    font-size:9px;

    background:#fff;
}

.update-btn{

    border:0;

    padding:
        6px 9px;

    border-radius:7px;

    background:#eef2ff;

    color:#4338ca;

    font-size:8px;

    font-weight:800;
}

/* QUICK */

.quick-actions{

    display:grid;

    grid-template-columns:
        repeat(4,1fr);

    gap:11px;

    padding:
        17px 19px 19px;
}

.action{

    padding:14px;

    border:
        1px solid var(--border);

    border-radius:11px;

    transition:.2s;
}

.action:hover{

    border-color:#c7d2fe;

    background:#fafaff;

    transform:
        translateY(-2px);
}

.action-icon{

    width:33px;
    height:33px;

    display:flex;

    align-items:center;
    justify-content:center;

    border-radius:8px;

    background:#eef2ff;

    color:var(--primary);

    margin-bottom:8px;
}

.action strong{

    display:block;

    font-size:10px;
}

.action span{

    display:block;

    color:#94a3b8;

    font-size:8px;

    margin-top:3px;
}

/* PROFILE */

.profile-card{
    padding:20px;
}

.profile-head{

    display:flex;

    align-items:center;

    gap:15px;

    margin-bottom:20px;
}

.profile-big-avatar{

    width:70px;
    height:70px;

    border-radius:50%;

    display:flex;

    align-items:center;
    justify-content:center;

    color:#fff;

    font-size:24px;

    font-weight:900;

    background:
        linear-gradient(
            135deg,
            #4f46e5,
            #8b5cf6
        );
}

.profile-head h2{
    font-size:18px;
}

.profile-head p{

    color:#94a3b8;

    font-size:10px;

    margin-top:3px;
}

/* ANNOUNCEMENTS */

.announcement{

    padding:
        15px 20px;

    border-bottom:
        1px solid #eef1f5;
}

.announcement:last-child{
    border-bottom:0;
}

.announcement h4{

    font-size:11px;

    margin-bottom:4px;
}

.announcement p{

    color:#64748b;

    font-size:10px;

    line-height:1.6;
}

.announcement small{

    display:block;

    color:#94a3b8;

    margin-top:6px;

    font-size:8px;
}

/* RESPONSIVE */

@media(max-width:1250px){

    .stats{
        grid-template-columns:
            repeat(3,1fr);
    }
}

@media(max-width:1000px){

    .sidebar{
        width:215px;
    }

    .main{
        margin-left:215px;
    }

    .grid{
        grid-template-columns:1fr;
    }
}

@media(max-width:750px){

    .sidebar{

        position:relative;

        width:100%;

        height:auto;
    }

    .main{
        margin-left:0;
    }

    .topbar{
        padding:
            0 17px;
    }

    .content{
        padding:17px;
    }

    .stats{
        grid-template-columns:
            repeat(2,1fr);
    }

    .welcome{

        align-items:flex-start;

        flex-direction:column;
    }

    .quick-actions{

        grid-template-columns:
            repeat(2,1fr);
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    .form-group.full{
        grid-column:auto;
    }
}

@media(max-width:480px){

    .stats{
        grid-template-columns:1fr;
    }

    .profile-info{
        display:none;
    }

    .event-side{
        display:none;
    }

    .quick-actions{
        grid-template-columns:1fr;
    }

    .part-grid{
        grid-template-columns:1fr;
    }
}

</style>

</head>

<body>

<div class="dashboard">

<!-- =========================================================
     SIDEBAR
========================================================= -->

<aside class="sidebar">

    <div class="brand">

        <div class="brand-logo">
            ES
        </div>

        <div>

            <h2>
                EventSphere
            </h2>

            <span>
                Organizer Portal
            </span>

        </div>

    </div>


    <div class="nav-heading">
        Main
    </div>


    <a
        href="organizer-dashboard.php?section=dashboard"
        class="nav-link <?= $section === 'dashboard' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ⌂
        </span>

        Dashboard

    </a>


    <a
        href="organizer-dashboard.php?section=events"
        class="nav-link <?= $section === 'events' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ◈
        </span>

        My Events

    </a>


    <a
        href="organizer-dashboard.php?section=create-event"
        class="nav-link <?= $section === 'create-event' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ＋
        </span>

        Create Event

    </a>


    <div class="nav-heading">
        Event Operations
    </div>


    <a
        href="organizer-dashboard.php?section=registrations"
        class="nav-link <?= $section === 'registrations' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ♙
        </span>

        Registrations

    </a>


    <a
        href="organizer-dashboard.php?section=attendance"
        class="nav-link <?= $section === 'attendance' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ✓
        </span>

        Attendance

    </a>


    <div class="nav-heading">
        Engagement
    </div>


    <a
        href="organizer-dashboard.php?section=feedback"
        class="nav-link <?= $section === 'feedback' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ★
        </span>

        Feedback

    </a>


    <a
        href="organizer-dashboard.php?section=announcements"
        class="nav-link <?= $section === 'announcements' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ◉
        </span>

        Announcements

    </a>


    <div class="nav-heading">
        Account
    </div>


    <a
        href="organizer-dashboard.php?section=profile"
        class="nav-link <?= $section === 'profile' ? 'active' : '' ?>"
    >

        <span class="nav-icon">
            ●
        </span>

        My Profile

    </a>


    <div class="sidebar-bottom">

        <a
            href="logout.php"
            class="nav-link logout"
        >

            <span class="nav-icon">
                ↪
            </span>

            Logout

        </a>

    </div>

</aside>


<!-- =========================================================
     MAIN
========================================================= -->

<main class="main">

<header class="topbar">

    <div class="top-title">

        <h1>
            Organizer Portal
        </h1>

        <p>
            Manage your complete EventSphere account
        </p>

    </div>


    <div class="profile">

        <div class="avatar">
            <?= h($organizer_initial) ?>
        </div>

        <div class="profile-info">

            <strong>
                <?= h($organizer_name) ?>
            </strong>

            <span>
                <?= h($organizer_email) ?>
            </span>

        </div>

    </div>

</header>


<section class="content">


<?php if ($flash): ?>

    <div
        class="alert <?= h($flash['type']) ?>"
    >
        <?= h($flash['message']) ?>
    </div>

<?php endif; ?>


<!-- =========================================================
     DASHBOARD
========================================================= -->

<?php if ($section === 'dashboard'): ?>


<div class="welcome">

    <div>

        <h2>
            Welcome back, <?= h($organizer_name) ?>!
        </h2>

        <p>
            Here's your complete EventSphere organizer overview.
        </p>

    </div>


    <a
        href="organizer-dashboard.php?section=create-event"
        class="create-btn"
    >
        + Create New Event
    </a>

</div>


<div class="stats">


    <div class="stat">

        <div class="stat-top">

            <span class="stat-label">
                Total Events
            </span>

            <div class="stat-icon">
                ◈
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($total_events) ?>
        </div>

        <div class="stat-description">
            Events created
        </div>

    </div>


    <div class="stat">

        <div class="stat-top">

            <span class="stat-label">
                Pending
            </span>

            <div class="stat-icon">
                ◷
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($pending_events) ?>
        </div>

        <div class="stat-description">
            Awaiting approval
        </div>

    </div>


    <div class="stat">

        <div class="stat-top">

            <span class="stat-label">
                Upcoming
            </span>

            <div class="stat-icon">
                ◷
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($upcoming_events) ?>
        </div>

        <div class="stat-description">
            Future events
        </div>

    </div>


    <div class="stat">

        <div class="stat-top">

            <span class="stat-label">
                Completed
            </span>

            <div class="stat-icon">
                ✓
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($completed_events) ?>
        </div>

        <div class="stat-description">
            Finished events
        </div>

    </div>


    <div class="stat">

        <div class="stat-top">

            <span class="stat-label">
                Registrations
            </span>

            <div class="stat-icon">
                ♙
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($total_registrations) ?>
        </div>

        <div class="stat-description">
            Active participants
        </div>

    </div>


    <div class="stat">

        <div class="stat-top">

            <span class="stat-label">
                Rating
            </span>

            <div class="stat-icon">
                ★
            </div>

        </div>

        <div class="stat-value">
            <?= number_format($average_rating, 1) ?>
        </div>

        <div class="stat-description">
            <?= number_format($total_feedback) ?>
            responses
        </div>

    </div>

</div>


<div class="grid">


<!-- UPCOMING -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Upcoming Events
        </h3>

        <a
            href="organizer-dashboard.php?section=events"
            class="view"
        >
            View All
        </a>

    </div>


    <?php if ($upcoming_data): ?>

        <?php foreach ($upcoming_data as $event): ?>

            <?php

            $timestamp =
                !empty($event['event_date'])
                    ? strtotime(
                        (string)$event['event_date']
                    )
                    : false;

            $day =
                $timestamp
                    ? date('d', $timestamp)
                    : '--';

            $month =
                $timestamp
                    ? date('M', $timestamp)
                    : '---';

            $status =
                strtolower(
                    trim(
                        (string)(
                            $event['event_status']
                            ?? 'unknown'
                        )
                    )
                );

            $registered =
                (int)(
                    $event['registration_count']
                    ?? 0
                );

            $capacity =
                (int)(
                    $event['max_capacity']
                    ?? 0
                );

            ?>

            <div class="event-row">

                <div class="event-date">

                    <strong>
                        <?= h($day) ?>
                    </strong>

                    <span>
                        <?= h($month) ?>
                    </span>

                </div>


                <div class="event-main">

                    <h4>
                        <?= h(
                            $event['title']
                            ?? 'Untitled Event'
                        ) ?>
                    </h4>

                    <p>

                        <?= h(
                            $event['venue_name']
                            ?? 'Venue not assigned'
                        ) ?>

                    </p>

                    <div class="event-actions">

                        <a
                            class="small-btn edit"
                            href="organizer-dashboard.php?section=events&edit=<?= (int)$event['event_id'] ?>"
                        >
                            Edit
                        </a>

                    </div>

                </div>


                <div class="event-side">

                    <span
                        class="badge <?= h($status) ?>"
                    >
                        <?= h(
                            str_replace(
                                '_',
                                ' ',
                                $status
                            )
                        ) ?>
                    </span>

                    <div class="registered">

                        <?= number_format($registered) ?>

                        /

                        <?= number_format($capacity) ?>

                    </div>

                </div>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">

            <div class="empty-icon">
                ◈
            </div>

            <p>
                No upcoming events found.
            </p>

        </div>

    <?php endif; ?>

</div>


<!-- REGISTRATIONS -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Recent Registrations
        </h3>

        <a
            href="organizer-dashboard.php?section=registrations"
            class="view"
        >
            View All
        </a>

    </div>


    <?php if ($registrations): ?>

        <?php foreach (
            array_slice(
                $registrations,
                0,
                7
            )
            as $registration
        ): ?>

            <?php

            $student_name =
                trim(
                    (string)(
                        $registration['student_name']
                        ?? 'Participant'
                    )
                );

            $initial =
                strtoupper(
                    mb_substr(
                        $student_name,
                        0,
                        1,
                        'UTF-8'
                    )
                );

            $status =
                strtolower(
                    trim(
                        (string)(
                            $registration['status']
                            ?? 'unknown'
                        )
                    )
                );

            ?>

            <div class="registration">

                <div class="reg-avatar">
                    <?= h($initial) ?>
                </div>

                <div class="reg-info">

                    <strong>
                        <?= h($student_name) ?>
                    </strong>

                    <span>
                        <?= h(
                            $registration['event_title']
                            ?? 'Event'
                        ) ?>
                    </span>

                </div>

                <span
                    class="badge <?= h($status) ?>"
                >
                    <?= h(
                        str_replace(
                            '_',
                            ' ',
                            $status
                        )
                    ) ?>
                </span>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">

            <div class="empty-icon">
                ♙
            </div>

            <p>
                No registrations yet.
            </p>

        </div>

    <?php endif; ?>

</div>

</div>


<div class="grid">


<!-- PARTICIPATION -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Participation Overview
        </h3>

        <a
            href="organizer-dashboard.php?section=attendance"
            class="view"
        >
            Manage
        </a>

    </div>


    <div class="participation">

        <div class="part-grid">

            <div class="part-box">

                <span>
                    Total Registered
                </span>

                <strong>
                    <?= number_format(
                        $total_registrations
                    ) ?>
                </strong>

            </div>


            <div class="part-box">

                <span>
                    Attended
                </span>

                <strong>
                    <?= number_format(
                        $total_attendance
                    ) ?>
                </strong>

            </div>

        </div>


        <div class="progress-area">

            <div class="progress-head">

                <span>
                    Attendance Rate
                </span>

                <strong>
                    <?= $attendance_rate ?>%
                </strong>

            </div>

            <div class="progress">

                <div
                    class="progress-bar"
                ></div>

            </div>

        </div>

    </div>

</div>


<!-- FEEDBACK -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Recent Feedback
        </h3>

        <a
            href="organizer-dashboard.php?section=feedback"
            class="view"
        >
            View All
        </a>

    </div>


    <div class="feedback">

        <?php if ($feedback): ?>

            <?php foreach (
                array_slice(
                    $feedback,
                    0,
                    5
                )
                as $item
            ): ?>

                <?php

                $rating =
                    (int)(
                        $item['overall_rating']
                        ?? 0
                    );

                $rating =
                    max(
                        0,
                        min(
                            5,
                            $rating
                        )
                    );

                ?>

                <div class="feedback-item">

                    <div class="feedback-head">

                        <span class="feedback-name">

                            <?php if (
                                (int)(
                                    $item['is_anonymous']
                                    ?? 0
                                ) === 1
                            ): ?>

                                Anonymous Participant

                            <?php else: ?>

                                <?= h(
                                    $item['student_name']
                                    ?? 'Participant'
                                ) ?>

                            <?php endif; ?>

                        </span>

                        <span class="stars">

                            <?= str_repeat(
                                '★',
                                $rating
                            ) ?>

                            <?= str_repeat(
                                '☆',
                                5 - $rating
                            ) ?>

                        </span>

                    </div>


                    <div class="feedback-event">

                        <?= h(
                            $item['event_title']
                            ?? 'Event'
                        ) ?>

                    </div>


                    <?php if (
                        !empty(
                            $item['comments']
                        )
                    ): ?>

                        <div class="feedback-comment">

                            <?= h(
                                $item['comments']
                            ) ?>

                        </div>

                    <?php endif; ?>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ★
                </div>

                <p>
                    No feedback available yet.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

</div>


<!-- QUICK ACTIONS -->

<div class="panel">

    <div class="panel-header">

        <h3>
            Quick Actions
        </h3>

    </div>


    <div class="quick-actions">


        <a
            href="organizer-dashboard.php?section=create-event"
            class="action"
        >

            <div class="action-icon">
                ＋
            </div>

            <strong>
                Create Event
            </strong>

            <span>
                Submit a new event
            </span>

        </a>


        <a
            href="organizer-dashboard.php?section=registrations"
            class="action"
        >

            <div class="action-icon">
                ♙
            </div>

            <strong>
                Registrations
            </strong>

            <span>
                Manage participants
            </span>

        </a>


        <a
            href="organizer-dashboard.php?section=attendance"
            class="action"
        >

            <div class="action-icon">
                ✓
            </div>

            <strong>
                Attendance
            </strong>

            <span>
                Track participation
            </span>

        </a>


        <a
            href="organizer-dashboard.php?section=announcements"
            class="action"
        >

            <div class="action-icon">
                ◉
            </div>

            <strong>
                Announcements
            </strong>

            <span>
                Notify participants
            </span>

        </a>

    </div>

</div>


<?php endif; ?>


<!-- =========================================================
     CREATE EVENT
========================================================= -->

<?php if ($section === 'create-event'): ?>

<div class="panel">

    <div class="panel-header">

        <div>

            <h3>
                Create New Event
            </h3>

        </div>

        <a
            href="organizer-dashboard.php?section=events"
            class="view"
        >
            My Events
        </a>

    </div>


    <form
        method="POST"
        action="organizer-dashboard.php?section=create-event"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h($csrf_token) ?>"
        >

        <input
            type="hidden"
            name="action"
            value="create_event"
        >


        <div class="form-grid">


            <div class="form-group full">

                <label>
                    Event Title
                </label>

                <input
                    type="text"
                    name="title"
                    class="form-control"
                    placeholder="Enter event title"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Event Date
                </label>

                <input
                    type="date"
                    name="event_date"
                    class="form-control"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Start Time
                </label>

                <input
                    type="time"
                    name="start_time"
                    class="form-control"
                >

            </div>


            <div class="form-group">

                <label>
                    Maximum Capacity
                </label>

                <input
                    type="number"
                    name="max_capacity"
                    class="form-control"
                    min="1"
                    placeholder="100"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Category
                </label>

                <select
                    name="category_id"
                    class="form-control"
                >

                    <option value="0">
                        Select Category
                    </option>

                    <?php foreach ($categories as $category): ?>

                        <option
                            value="<?= (int)$category['category_id'] ?>"
                        >
                            <?= h(
                                $category['category_name']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="form-group full">

                <label>
                    Venue
                </label>

                <select
                    name="venue_id"
                    class="form-control"
                >

                    <option value="0">
                        Select Venue
                    </option>

                    <?php foreach ($venues as $venue): ?>

                        <option
                            value="<?= (int)$venue['venue_id'] ?>"
                        >

                            <?= h(
                                $venue['venue_name']
                            ) ?>

                            <?php if (
                                !empty(
                                    $venue['building_name']
                                )
                            ): ?>

                                -
                                <?= h(
                                    $venue['building_name']
                                ) ?>

                            <?php endif; ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="primary-btn"
            >
                Create Event
            </button>

            <a
                href="organizer-dashboard.php?section=dashboard"
                class="secondary-btn"
            >
                Cancel
            </a>

        </div>

    </form>

</div>

<?php endif; ?>


<!-- =========================================================
     EVENTS
========================================================= -->

<?php if ($section === 'events'): ?>


<div class="panel">

    <div class="panel-header">

        <h3>
            My Events
        </h3>

        <a
            href="organizer-dashboard.php?section=create-event"
            class="view"
        >
            + Create Event
        </a>

    </div>


    <?php if ($edit_event): ?>

    <!-- EDIT FORM -->

    <form
        method="POST"
        action="organizer-dashboard.php?section=events"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h($csrf_token) ?>"
        >

        <input
            type="hidden"
            name="action"
            value="update_event"
        >

        <input
            type="hidden"
            name="event_id"
            value="<?= (int)$edit_event['event_id'] ?>"
        >


        <div class="form-grid">


            <div class="form-group full">

                <label>
                    Event Title
                </label>

                <input
                    type="text"
                    name="title"
                    class="form-control"
                    value="<?= h(
                        $edit_event['title']
                    ) ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Event Date
                </label>

                <input
                    type="date"
                    name="event_date"
                    class="form-control"
                    value="<?= h(
                        $edit_event['event_date']
                    ) ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Start Time
                </label>

                <input
                    type="time"
                    name="start_time"
                    class="form-control"
                    value="<?= h(
                        $edit_event['start_time']
                    ) ?>"
                >

            </div>


            <div class="form-group">

                <label>
                    Maximum Capacity
                </label>

                <input
                    type="number"
                    name="max_capacity"
                    class="form-control"
                    min="1"
                    value="<?= (int)$edit_event['max_capacity'] ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Category
                </label>

                <select
                    name="category_id"
                    class="form-control"
                >

                    <option value="0">
                        Select Category
                    </option>

                    <?php foreach ($categories as $category): ?>

                        <option
                            value="<?= (int)$category['category_id'] ?>"
                            <?= (int)$edit_event['category_id'] ===
                                (int)$category['category_id']
                                ? 'selected'
                                : ''
                            ?>
                        >

                            <?= h(
                                $category['category_name']
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="form-group full">

                <label>
                    Venue
                </label>

                <select
                    name="venue_id"
                    class="form-control"
                >

                    <option value="0">
                        Select Venue
                    </option>

                    <?php foreach ($venues as $venue): ?>

                        <option
                            value="<?= (int)$venue['venue_id'] ?>"
                            <?= (int)$edit_event['venue_id'] ===
                                (int)$venue['venue_id']
                                ? 'selected'
                                : ''
                            ?>
                        >

                            <?= h(
                                $venue['venue_name']
                            ) ?>

                            <?php if (
                                !empty(
                                    $venue['building_name']
                                )
                            ): ?>

                                -
                                <?= h(
                                    $venue['building_name']
                                ) ?>

                            <?php endif; ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="primary-btn"
            >
                Save Changes
            </button>

            <a
                href="organizer-dashboard.php?section=events"
                class="secondary-btn"
            >
                Cancel
            </a>

        </div>

    </form>

    <?php endif; ?>


    <!-- EVENTS TABLE -->

    <div class="table-wrap">

        <?php if ($events_data): ?>

        <table>

            <thead>

                <tr>

                    <th>
                        Event
                    </th>

                    <th>
                        Date
                    </th>

                    <th>
                        Venue
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Registrations
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

            <?php foreach ($events_data as $event): ?>

                <?php

                $status =
                    strtolower(
                        trim(
                            (string)(
                                $event['event_status']
                                ?? 'unknown'
                            )
                        )
                    );

                ?>

                <tr>

                    <td>

                        <strong>
                            <?= h(
                                $event['title']
                            ) ?>
                        </strong>

                    </td>


                    <td>

                        <?= h(
                            $event['event_date']
                        ) ?>

                        <?php if (
                            !empty(
                                $event['start_time']
                            )
                        ): ?>

                            <br>

                            <small>
                                <?= h(
                                    $event['start_time']
                                ) ?>
                            </small>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= h(
                            $event['venue_name']
                            ?? 'Not assigned'
                        ) ?>

                    </td>


                    <td>

                        <span
                            class="badge <?= h($status) ?>"
                        >
                            <?= h(
                                str_replace(
                                    '_',
                                    ' ',
                                    $status
                                )
                            ) ?>
                        </span>

                    </td>


                    <td>

                        <?= number_format(
                            (int)(
                                $event[
                                    'registration_count'
                                ] ?? 0
                            )
                        ) ?>

                        /

                        <?= number_format(
                            (int)(
                                $event[
                                    'max_capacity'
                                ] ?? 0
                            )
                        ) ?>

                    </td>


                    <td>

                        <a
                            href="organizer-dashboard.php?section=events&edit=<?= (int)$event['event_id'] ?>"
                            class="small-btn edit"
                        >
                            Edit
                        </a>


                        <form
                            method="POST"
                            action="organizer-dashboard.php?section=events"
                            style="display:inline"
                            onsubmit="return confirm('Are you sure you want to delete this event?');"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= h($csrf_token) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="delete_event"
                            >

                            <input
                                type="hidden"
                                name="event_id"
                                value="<?= (int)$event['event_id'] ?>"
                            >

                            <button
                                type="submit"
                                class="small-btn delete"
                            >
                                Delete
                            </button>

                        </form>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ◈
                </div>

                <p>
                    You have not created any events yet.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php endif; ?>


<!-- =========================================================
     REGISTRATIONS
========================================================= -->

<?php if ($section === 'registrations'): ?>

<div class="panel">

    <div class="panel-header">

        <h3>
            Event Registrations
        </h3>

        <span class="view">
            <?= number_format(
                count($registrations)
            ) ?>
            records
        </span>

    </div>


    <div class="table-wrap">

        <?php if ($registrations): ?>

        <table>

            <thead>

                <tr>

                    <th>
                        Participant
                    </th>

                    <th>
                        Event
                    </th>

                    <th>
                        Registration Code
                    </th>

                    <th>
                        Registered
                    </th>

                    <th>
                        Status
                    </th>

                </tr>

            </thead>


            <tbody>

            <?php foreach (
                $registrations
                as $registration
            ): ?>

                <?php

                $status =
                    strtolower(
                        trim(
                            (string)(
                                $registration['status']
                                ?? 'pending'
                            )
                        )
                    );

                ?>

                <tr>

                    <td>

                        <strong>
                            <?= h(
                                $registration['student_name']
                                ?? 'Participant'
                            ) ?>
                        </strong>

                    </td>


                    <td>

                        <?= h(
                            $registration['event_title']
                            ?? 'Event'
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $registration[
                                'registration_code'
                            ] ?? '-'
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $registration[
                                'registered_at'
                            ] ?? '-'
                        ) ?>

                    </td>


                    <td>

                        <form
                            method="POST"
                            action="organizer-dashboard.php?section=registrations"
                            class="status-form"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= h($csrf_token) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="update_registration"
                            >

                            <input
                                type="hidden"
                                name="registration_id"
                                value="<?= (int)$registration['registration_id'] ?>"
                            >


                            <select
                                name="status"
                                class="status-select"
                            >

                                <?php
                                $statuses = [
                                    'pending',
                                    'confirmed',
                                    'attended',
                                    'no_show',
                                    'cancelled'
                                ];
                                ?>

                                <?php foreach (
                                    $statuses
                                    as $status_option
                                ): ?>

                                    <option
                                        value="<?= h($status_option) ?>"
                                        <?= $status === $status_option
                                            ? 'selected'
                                            : ''
                                        ?>
                                    >
                                        <?= h(
                                            str_replace(
                                                '_',
                                                ' ',
                                                $status_option
                                            )
                                        ) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>


                            <button
                                type="submit"
                                class="update-btn"
                            >
                                Update
                            </button>

                        </form>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ♙
                </div>

                <p>
                    No registrations found.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php endif; ?>


<!-- =========================================================
     ATTENDANCE
========================================================= -->

<?php if ($section === 'attendance'): ?>

<div class="grid">


<div class="panel">

    <div class="panel-header">

        <h3>
            Attendance Overview
        </h3>

    </div>


    <div class="participation">

        <div class="part-grid">


            <div class="part-box">

                <span>
                    Registered
                </span>

                <strong>
                    <?= number_format(
                        $total_registrations
                    ) ?>
                </strong>

            </div>


            <div class="part-box">

                <span>
                    Attended
                </span>

                <strong>
                    <?= number_format(
                        $total_attendance
                    ) ?>
                </strong>

            </div>


        </div>


        <div class="progress-area">

            <div class="progress-head">

                <span>
                    Overall Attendance Rate
                </span>

                <strong>
                    <?= $attendance_rate ?>%
                </strong>

            </div>


            <div class="progress">

                <div
                    class="progress-bar"
                ></div>

            </div>

        </div>

    </div>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>
            Attendance Tip
        </h3>

    </div>


    <div class="participation">

        <p style="
            color:#64748b;
            font-size:11px;
            line-height:1.7;
        ">

            Use the Registrations section to mark each
            participant as attended, no-show, confirmed,
            pending or cancelled.

        </p>

        <br>

        <a
            href="organizer-dashboard.php?section=registrations"
            class="primary-btn"
        >
            Manage Attendance
        </a>

    </div>

</div>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>
            Participant Attendance
        </h3>

        <a
            href="organizer-dashboard.php?section=registrations"
            class="view"
        >
            Manage
        </a>

    </div>


    <div class="table-wrap">

        <table>

            <thead>

                <tr>

                    <th>
                        Participant
                    </th>

                    <th>
                        Event
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Action
                    </th>

                </tr>

            </thead>


            <tbody>

            <?php if ($registrations): ?>

                <?php foreach (
                    $registrations
                    as $registration
                ): ?>

                    <tr>

                        <td>
                            <?= h(
                                $registration['student_name']
                                ?? 'Participant'
                            ) ?>
                        </td>

                        <td>
                            <?= h(
                                $registration['event_title']
                                ?? 'Event'
                            ) ?>
                        </td>

                        <td>

                            <span
                                class="badge <?= h(
                                    strtolower(
                                        (string)(
                                            $registration[
                                                'status'
                                            ] ?? ''
                                        )
                                    )
                                ) ?>"
                            >

                                <?= h(
                                    str_replace(
                                        '_',
                                        ' ',
                                        (string)(
                                            $registration[
                                                'status'
                                            ] ?? ''
                                        )
                                    )
                                ) ?>

                            </span>

                        </td>

                        <td>

                            <a
                                href="organizer-dashboard.php?section=registrations"
                                class="small-btn edit"
                            >
                                Update
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>

                    <td colspan="4">
                        No attendance records available.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php endif; ?>


<!-- =========================================================
     FEEDBACK
========================================================= -->

<?php if ($section === 'feedback'): ?>

<div class="grid">


<div class="panel">

    <div class="panel-header">

        <h3>
            Average Rating
        </h3>

    </div>


    <div class="participation">

        <div class="part-box">

            <span>
                Overall Rating
            </span>

            <strong>
                <?= number_format(
                    $average_rating,
                    1
                ) ?>
                / 5
            </strong>

        </div>

    </div>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>
            Responses
        </h3>

    </div>


    <div class="participation">

        <div class="part-box">

            <span>
                Total Feedback
            </span>

            <strong>
                <?= number_format(
                    $total_feedback
                ) ?>
            </strong>

        </div>

    </div>

</div>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>
            Participant Feedback
        </h3>

    </div>


    <div class="feedback">

        <?php if ($feedback): ?>

            <?php foreach (
                $feedback
                as $item
            ): ?>

                <?php

                $rating =
                    max(
                        0,
                        min(
                            5,
                            (int)(
                                $item[
                                    'overall_rating'
                                ] ?? 0
                            )
                        )
                    );

                ?>

                <div class="feedback-item">

                    <div class="feedback-head">

                        <span class="feedback-name">

                            <?php if (
                                (int)(
                                    $item[
                                        'is_anonymous'
                                    ] ?? 0
                                ) === 1
                            ): ?>

                                Anonymous Participant

                            <?php else: ?>

                                <?= h(
                                    $item[
                                        'student_name'
                                    ] ?? 'Participant'
                                ) ?>

                            <?php endif; ?>

                        </span>


                        <span class="stars">

                            <?= str_repeat(
                                '★',
                                $rating
                            ) ?>

                            <?= str_repeat(
                                '☆',
                                5 - $rating
                            ) ?>

                        </span>

                    </div>


                    <div class="feedback-event">

                        <?= h(
                            $item[
                                'event_title'
                            ] ?? 'Event'
                        ) ?>

                    </div>


                    <?php if (
                        !empty(
                            $item['comments']
                        )
                    ): ?>

                        <div class="feedback-comment">

                            <?= h(
                                $item['comments']
                            ) ?>

                        </div>

                    <?php endif; ?>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty">

                <div class="empty-icon">
                    ★
                </div>

                <p>
                    No feedback available yet.
                </p>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php endif; ?>


<!-- =========================================================
     ANNOUNCEMENTS
========================================================= -->

<?php if ($section === 'announcements'): ?>

<div class="panel">

    <div class="panel-header">

        <h3>
            Create Announcement
        </h3>

    </div>


    <form
        method="POST"
        action="organizer-dashboard.php?section=announcements"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h($csrf_token) ?>"
        >

        <input
            type="hidden"
            name="action"
            value="create_announcement"
        >


        <div class="form-grid">


            <div class="form-group full">

                <label>
                    Announcement Title
                </label>

                <input
                    type="text"
                    name="announcement_title"
                    class="form-control"
                    placeholder="Important event announcement"
                    required
                >

            </div>


            <div class="form-group full">

                <label>
                    Event
                </label>

                <select
                    name="announcement_event_id"
                    class="form-control"
                >

                    <option value="0">
                        General Announcement
                    </option>

                    <?php foreach (
                        $events_data
                        as $event
                    ): ?>

                        <option
                            value="<?= (int)$event['event_id'] ?>"
                        >

                            <?= h(
                                $event['title']
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="form-group full">

                <label>
                    Message
                </label>

                <textarea
                    name="announcement_message"
                    class="form-control"
                    placeholder="Write your announcement..."
                    required
                ></textarea>

            </div>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="primary-btn"
            >
                Publish Announcement
            </button>

        </div>

    </form>

</div>


<div class="panel">

    <div class="panel-header">

        <h3>
            Previous Announcements
        </h3>

    </div>


    <?php if ($announcements): ?>

        <?php foreach (
            $announcements
            as $announcement
        ): ?>

            <div class="announcement">

                <h4>
                    <?= h(
                        $announcement['title']
                        ?? 'Announcement'
                    ) ?>
                </h4>

                <p>
                    <?= h(
                        $announcement['message']
                        ?? ''
                    ) ?>
                </p>

                <small>

                    <?= h(
                        $announcement['created_at']
                        ?? ''
                    ) ?>

                </small>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty">

            <div class="empty-icon">
                ◉
            </div>

            <p>
                No announcements yet.
            </p>

        </div>

    <?php endif; ?>

</div>

<?php endif; ?>


<!-- =========================================================
     PROFILE
========================================================= -->

<?php if ($section === 'profile'): ?>

<div class="panel">

    <div class="panel-header">

        <h3>
            Organizer Profile
        </h3>

    </div>


    <div class="profile-card">

        <div class="profile-head">

            <div class="profile-big-avatar">

                <?= h(
                    $organizer_initial
                ) ?>

            </div>


            <div>

                <h2>
                    <?= h(
                        $organizer_name
                    ) ?>
                </h2>

                <p>
                    Organizer Account
                </p>

            </div>

        </div>


        <form
            method="POST"
            action="organizer-dashboard.php?section=profile"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h($csrf_token) ?>"
            >

            <input
                type="hidden"
                name="action"
                value="update_profile"
            >


            <div class="form-grid">


                <div class="form-group full">

                    <label>
                        Full Name
                    </label>

                    <input
                        type="text"
                        name="full_name"
                        class="form-control"
                        value="<?= h(
                            $organizer_name
                        ) ?>"
                        required
                    >

                </div>


                <div class="form-group full">

                    <label>
                        Email Address
                    </label>

                    <input
                        type="email"
                        class="form-control"
                        value="<?= h(
                            $organizer_email
                        ) ?>"
                        readonly
                    >

                </div>


            </div>


            <div class="form-actions">

                <button
                    type="submit"
                    class="primary-btn"
                >
                    Save Profile
                </button>

            </div>

        </form>

    </div>

</div>

<?php endif; ?>


</section>

</main>

</div>


<script>

document.addEventListener(
    "DOMContentLoaded",
    function(){

        const items =
            document.querySelectorAll(
                ".stat, .panel, .welcome"
            );

        items.forEach(
            function(item,index){

                item.style.opacity = "0";

                item.style.transform =
                    "translateY(10px)";

                setTimeout(
                    function(){

                        item.style.transition =
                            "opacity .4s ease, transform .4s ease";

                        item.style.opacity = "1";

                        item.style.transform =
                            "translateY(0)";

                    },
                    40 + (index * 30)
                );

            }
        );

    }
);

</script>

</body>

</html>