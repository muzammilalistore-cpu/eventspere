
<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user']['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int)($_SESSION['user']['user_id'] ?? 0);
$userRole = strtolower(trim((string)($_SESSION['user']['role'] ?? '')));

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}

if ($userRole !== 'student') {
    header('Location: index.php');
    exit;
}

$title = 'My Certificates';

/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function h($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| GET STUDENT CERTIFICATES
|--------------------------------------------------------------------------
*/

$certificates = [];
$databaseError = '';

$sql = "
    SELECT
        c.certificate_id,
        c.event_id,
        c.student_id,
        c.registration_id,
        c.certificate_number,
        c.certificate_type,
        c.certificate_url,
        c.issued_at,

        e.title AS event_title,
        e.event_date,
        e.start_time,

        er.registration_code,

        a.attendance_status,
        a.marked_at

    FROM certificates c

    INNER JOIN events e
        ON e.event_id = c.event_id

    LEFT JOIN event_registrations er
        ON er.registration_id = c.registration_id
        AND er.event_id = c.event_id
        AND er.student_id = c.student_id

    LEFT JOIN attendance a
        ON a.event_id = c.event_id
        AND a.student_id = c.student_id
        AND a.registration_id = c.registration_id

    WHERE c.student_id = ?

    ORDER BY
        c.issued_at DESC,
        c.certificate_id DESC
";

$stmt = mysqli_prepare($conn, $sql);

if ($stmt === false) {

    $databaseError = 'Database query could not be prepared.';

} else {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    if (mysqli_stmt_execute($stmt)) {

        $result = mysqli_stmt_get_result($stmt);

        if ($result !== false) {

            while ($row = mysqli_fetch_assoc($result)) {
                $certificates[] = $row;
            }

            mysqli_free_result($result);
        }

    } else {

        $databaseError = 'Certificates could not be loaded right now.';

        if (defined('DEBUG') && DEBUG === true) {
            $databaseError .= ' ' . mysqli_stmt_error($stmt);
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| SUMMARY
|--------------------------------------------------------------------------
*/

$totalCertificates = count($certificates);

/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/header.php';

?>

<style>

/* =========================================================
   PAGE
========================================================= */

.certificate-page {
    padding: 42px 0 80px;
}

/* =========================================================
   HERO
========================================================= */

.certificate-hero {
    position: relative;
    overflow: hidden;
    padding: 42px;
    margin-bottom: 25px;
    border-radius: 24px;

    background:
        radial-gradient(
            circle at 85% 15%,
            rgba(99, 102, 241, .28),
            transparent 32%
        ),
        radial-gradient(
            circle at 10% 90%,
            rgba(34, 211, 238, .14),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #1e1b4b
        );

    color: #fff;

    box-shadow:
        0 22px 55px rgba(15, 23, 42, .15);
}

.certificate-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 7px 12px;

    border: 1px solid rgba(255,255,255,.13);
    border-radius: 999px;

    background: rgba(255,255,255,.06);

    color: #c7d2fe;

    font-size: 11px;
    font-weight: 800;

    letter-spacing: .08em;
    text-transform: uppercase;
}

.certificate-label::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #22c55e;
}

.certificate-hero h1 {
    margin: 17px 0 10px;

    color: #fff;

    font-size: clamp(2rem, 4vw, 3.15rem);

    line-height: 1.05;
    letter-spacing: -.045em;

    font-weight: 800;
}

.certificate-hero p {
    max-width: 690px;

    margin: 0;

    color: #cbd5e1;

    font-size: 14px;
    line-height: 1.7;
}

/* =========================================================
   ERROR
========================================================= */

.database-error {
    margin-bottom: 22px;

    padding: 15px 18px;

    border: 1px solid #fecaca;
    border-radius: 14px;

    background: #fef2f2;

    color: #b91c1c;

    font-size: 13px;
}

/* =========================================================
   SUMMARY
========================================================= */

.certificate-summary {
    display: grid;

    grid-template-columns: 1fr;

    gap: 15px;

    margin-bottom: 25px;
}

.summary-box {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 15px;

    min-height: 92px;

    padding: 18px 20px;

    background: #fff;

    border: 1px solid #e8edf3;
    border-radius: 17px;

    box-shadow:
        0 8px 28px rgba(15,23,42,.045);
}

.summary-info strong {
    display: block;

    color: #111827;

    font-size: 14px;
    font-weight: 800;
}

.summary-info span {
    display: block;

    margin-top: 4px;

    color: #94a3b8;

    font-size: 11px;
}

.summary-number {
    display: flex;

    align-items: center;
    justify-content: center;

    min-width: 43px;
    height: 38px;

    padding: 0 10px;

    border-radius: 999px;

    background: #eef2ff;

    color: #4338ca;

    font-size: 14px;
    font-weight: 800;
}

/* =========================================================
   GRID
========================================================= */

.certificate-grid {
    display: grid;

    grid-template-columns:
        repeat(auto-fit, minmax(330px, 1fr));

    gap: 22px;
}

/* =========================================================
   CARD
========================================================= */

.certificate-card {
    overflow: hidden;

    background: #fff;

    border: 1px solid #e5eaf0;
    border-radius: 21px;

    box-shadow:
        0 10px 35px rgba(15,23,42,.055);

    transition:
        transform .25s ease,
        box-shadow .25s ease,
        border-color .25s ease;
}

.certificate-card:hover {
    transform: translateY(-5px);

    border-color: #c7d2fe;

    box-shadow:
        0 20px 50px rgba(15,23,42,.10);
}

/* =========================================================
   CARD TOP
========================================================= */

.certificate-card-top {
    padding: 26px;

    background:
        linear-gradient(
            135deg,
            #f8fafc,
            #eef2ff
        );
}

.certificate-mark {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 54px;
    height: 54px;

    margin-bottom: 17px;

    border-radius: 16px;

    background: #fff;

    color: #4f46e5;

    font-size: 24px;

    box-shadow:
        0 8px 22px rgba(79,70,229,.10);
}

.certificate-card h2 {
    margin: 0 0 8px;

    color: #111827;

    font-size: 19px;
    font-weight: 800;

    line-height: 1.4;
}

.event-date {
    color: #64748b;

    font-size: 12px;
    line-height: 1.6;
}

/* =========================================================
   BODY
========================================================= */

.certificate-card-body {
    padding: 22px 26px 26px;
}

/* =========================================================
   STATUS
========================================================= */

.status-row {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 10px;

    margin-bottom: 18px;
}

.attendance-status {
    display: inline-flex;

    align-items: center;

    gap: 7px;

    color: #15803d;

    font-size: 11px;
    font-weight: 800;
}

.attendance-status::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #22c55e;
}

.issued-badge {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 6px 10px;

    border-radius: 999px;

    background: #ecfdf5;

    color: #15803d;

    font-size: 10px;
    font-weight: 800;

    text-transform: uppercase;
}

/* =========================================================
   META
========================================================= */

.certificate-meta {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 11px;

    margin-bottom: 20px;
}

.meta-item {
    min-width: 0;

    padding: 12px;

    border: 1px solid #edf0f4;
    border-radius: 12px;

    background: #fafbfc;
}

.meta-item span {
    display: block;

    margin-bottom: 5px;

    color: #94a3b8;

    font-size: 9px;
    font-weight: 800;

    letter-spacing: .04em;

    text-transform: uppercase;
}

.meta-item strong {
    display: block;

    overflow: hidden;

    color: #1e293b;

    font-size: 12px;
    font-weight: 750;

    text-overflow: ellipsis;

    word-break: break-word;
}

/* =========================================================
   ACTION BUTTONS
========================================================= */

.certificate-actions {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 10px;
}

.certificate-action {
    width: 100%;
    min-height: 46px;

    display: flex;

    align-items: center;
    justify-content: center;

    gap: 8px;

    border: 0;
    border-radius: 12px;

    text-decoration: none;

    font-size: 12px;
    font-weight: 800;

    transition:
        transform .2s ease,
        box-shadow .2s ease;
}

.certificate-action:hover {
    transform: translateY(-2px);
}

/* VIEW */

.action-view {
    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    color: #fff;

    box-shadow:
        0 8px 20px rgba(79,70,229,.16);
}

.action-view:hover {
    color: #fff;

    box-shadow:
        0 12px 25px rgba(79,70,229,.22);
}

/* DOWNLOAD */

.action-download {
    background:
        linear-gradient(
            135deg,
            #0f172a,
            #334155
        );

    color: #fff;

    box-shadow:
        0 8px 20px rgba(15,23,42,.14);
}

.action-download:hover {
    color: #fff;

    box-shadow:
        0 12px 25px rgba(15,23,42,.22);
}

/* =========================================================
   EMPTY
========================================================= */

.certificate-empty {
    padding: 70px 25px;

    text-align: center;

    background: #fff;

    border: 1px solid #e7ebf0;
    border-radius: 21px;

    box-shadow:
        0 10px 35px rgba(15,23,42,.045);
}

.empty-icon {
    display: flex;

    align-items: center;
    justify-content: center;

    width: 68px;
    height: 68px;

    margin: 0 auto 18px;

    border-radius: 19px;

    background: #f1f5f9;

    color: #475569;

    font-size: 28px;
}

.certificate-empty h2 {
    margin: 0 0 9px;

    color: #111827;

    font-size: 20px;
    font-weight: 800;
}

.certificate-empty p {
    max-width: 550px;

    margin: 0 auto;

    color: #64748b;

    font-size: 13px;
    line-height: 1.7;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 767px) {

    .certificate-page {
        padding: 25px 0 55px;
    }

    .certificate-hero {
        padding: 30px 22px;

        border-radius: 19px;
    }

    .certificate-grid {
        grid-template-columns: 1fr;
    }

    .certificate-meta {
        grid-template-columns: 1fr;
    }

    .certificate-actions {
        grid-template-columns: 1fr;
    }
}

</style>


<div class="container certificate-page">

    <!-- HERO -->

    <section class="certificate-hero">

        <span class="certificate-label">
            EventSphere Student Portal
        </span>

        <h1>
            My Certificates
        </h1>

        <p>
            View and download your event certificates.
            Certificates issued by organizers are available
            directly from this page.
        </p>

    </section>


    <!-- DATABASE ERROR -->

    <?php if ($databaseError !== ''): ?>

        <div class="database-error">
            <?= h($databaseError) ?>
        </div>

    <?php endif; ?>


    <!-- SUMMARY -->

    <div class="certificate-summary">

        <div class="summary-box">

            <div class="summary-info">

                <strong>
                    Total Certificates
                </strong>

                <span>
                    Certificates issued to you
                </span>

            </div>

            <div class="summary-number">
                <?= $totalCertificates ?>
            </div>

        </div>

    </div>


    <!-- CERTIFICATES -->

    <?php if (empty($certificates)): ?>

        <div class="certificate-empty">

            <div class="empty-icon">
                <i class="bi bi-award"></i>
            </div>

            <h2>
                No certificates available yet
            </h2>

            <p>
                Your certificate will appear here when an
                organizer creates a certificate for one of
                your registered events.
            </p>

        </div>

    <?php else: ?>


        <div class="certificate-grid">


            <?php foreach ($certificates as $certificate): ?>

                <?php

                /*
                |--------------------------------------------------------------------------
                | EVENT DATE
                |--------------------------------------------------------------------------
                */

                $eventDate = false;

                if (!empty($certificate['event_date'])) {

                    $eventDate = strtotime(
                        (string)$certificate['event_date']
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | ISSUED DATE
                |--------------------------------------------------------------------------
                */

                $issuedDate = false;

                if (!empty($certificate['issued_at'])) {

                    $issuedDate = strtotime(
                        (string)$certificate['issued_at']
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | CERTIFICATE URL
                |--------------------------------------------------------------------------
                */

                $certificateUrl = trim(
                    (string)(
                        $certificate['certificate_url'] ?? ''
                    )
                );

                $safeCertificateUrl = '';

                if ($certificateUrl !== '') {

                    /*
                    | Only allow relative/local paths.
                    */

                    $parsedScheme = parse_url(
                        $certificateUrl,
                        PHP_URL_SCHEME
                    );

                    $parsedHost = parse_url(
                        $certificateUrl,
                        PHP_URL_HOST
                    );

                    if (
                        ($parsedScheme === null ||
                         $parsedScheme === '') &&

                        ($parsedHost === null ||
                         $parsedHost === '') &&

                        !preg_match(
                            '/^\s*javascript:/i',
                            $certificateUrl
                        )
                    ) {

                        $safeCertificateUrl =
                            $certificateUrl;
                    }
                }


                /*
                |--------------------------------------------------------------------------
                | CERTIFICATE TYPE
                |--------------------------------------------------------------------------
                */

                $certificateType = trim(
                    (string)(
                        $certificate['certificate_type'] ?? ''
                    )
                );

                if ($certificateType === '') {
                    $certificateType = 'participation';
                }


                /*
                |--------------------------------------------------------------------------
                | ATTENDANCE
                |--------------------------------------------------------------------------
                */

                $attendanceStatus = strtolower(
                    trim(
                        (string)(
                            $certificate['attendance_status'] ?? ''
                        )
                    )
                );

                ?>


                <article class="certificate-card">


                    <!-- CARD TOP -->

                    <div class="certificate-card-top">

                        <div class="certificate-mark">
                            <i class="bi bi-award"></i>
                        </div>

                        <h2>
                            <?= h(
                                $certificate['event_title']
                                ?? 'Event Certificate'
                            ) ?>
                        </h2>


                        <?php if ($eventDate): ?>

                            <div class="event-date">

                                <i class="bi bi-calendar3"></i>

                                Event Date:

                                <?= h(
                                    date(
                                        'd M Y',
                                        $eventDate
                                    )
                                ) ?>


                                <?php if (
                                    !empty(
                                        $certificate['start_time']
                                    )
                                ): ?>

                                    ·

                                    <?= h(
                                        date(
                                            'h:i A',
                                            strtotime(
                                                (string)
                                                $certificate[
                                                    'start_time'
                                                ]
                                            )
                                        )
                                    ) ?>

                                <?php endif; ?>

                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- CARD BODY -->

                    <div class="certificate-card-body">


                        <!-- STATUS -->

                        <div class="status-row">

                            <span class="attendance-status">

                                <?php if (
                                    $attendanceStatus === 'present'
                                ): ?>

                                    Attendance Verified

                                <?php elseif (
                                    $attendanceStatus === ''
                                ): ?>

                                    Certificate Issued

                                <?php else: ?>

                                    Attendance Recorded

                                <?php endif; ?>

                            </span>


                            <span class="issued-badge">

                                <i class="bi bi-check-circle me-1"></i>

                                Issued

                            </span>

                        </div>


                        <!-- META -->

                        <div class="certificate-meta">


                            <div class="meta-item">

                                <span>
                                    Certificate No.
                                </span>

                                <strong>
                                    <?= h(
                                        $certificate[
                                            'certificate_number'
                                        ]
                                        ?? 'Not assigned'
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Type
                                </span>

                                <strong>
                                    <?= h(
                                        ucfirst(
                                            $certificateType
                                        )
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Registration
                                </span>

                                <strong>
                                    <?= h(
                                        $certificate[
                                            'registration_code'
                                        ]
                                        ?? 'N/A'
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Attendance
                                </span>

                                <strong>

                                    <?php if (
                                        $attendanceStatus === 'present'
                                    ): ?>

                                        Present

                                    <?php elseif (
                                        $attendanceStatus === ''
                                    ): ?>

                                        Verified

                                    <?php else: ?>

                                        Recorded

                                    <?php endif; ?>

                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Issued
                                </span>

                                <strong>

                                    <?php if ($issuedDate): ?>

                                        <?= h(
                                            date(
                                                'd M Y',
                                                $issuedDate
                                            )
                                        ) ?>

                                    <?php else: ?>

                                        Not specified

                                    <?php endif; ?>

                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Status
                                </span>

                                <strong>
                                    Certificate Issued
                                </strong>

                            </div>


                        </div>


                        <!-- ACTIONS -->

                        <?php if ($safeCertificateUrl !== ''): ?>

                            <div class="certificate-actions">

                                <!-- VIEW -->

                                <a
                                    href="<?= h($safeCertificateUrl) ?>"
                                    class="certificate-action action-view"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >

                                    <i class="bi bi-eye"></i>

                                    View Certificate

                                    <span>
                                        ↗
                                    </span>

                                </a>


                                <!-- DOWNLOAD -->

                                <a
                                    href="<?= h($safeCertificateUrl) ?>"
                                    class="certificate-action action-download"
                                    download
                                >

                                    <i class="bi bi-download"></i>

                                    Download

                                    <span>
                                        ↓
                                    </span>

                                </a>

                            </div>

                        <?php else: ?>

                            <div class="certificate-action action-disabled">

                                <i class="bi bi-hourglass-split"></i>

                                Certificate is being prepared.

                            </div>

                        <?php endif; ?>


                    </div>

                </article>


            <?php endforeach; ?>


        </div>

    <?php endif; ?>


</div>


<?php

/*
|--------------------------------------------------------------------------
| FOOTER
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/footer.php';

?>
