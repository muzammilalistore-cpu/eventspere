
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = $title ?? "EventSphere";

$isLoggedIn = isset($_SESSION["user"]["user_id"]) && !empty($_SESSION["user"]["user_id"]);
$currentUser = $_SESSION["user"] ?? [];

function headerSafe($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$displayName = $currentUser["name"]
    ?? $currentUser["username"]
    ?? $currentUser["email"]
    ?? "User";

$avatarLetter = strtoupper(substr($displayName, 0, 1));

$flashMessage = "";
$flashType = "info";

if (isset($_SESSION["flash"]) && is_array($_SESSION["flash"])) {
    $flashMessage = $_SESSION["flash"]["message"] ?? "";
    $flashType = $_SESSION["flash"]["type"] ?? "info";

    $allowedTypes = ["success", "danger", "warning", "info"];

    if (!in_array($flashType, $allowedTypes, true)) {
        $flashType = "info";
    }

    unset($_SESSION["flash"]);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="EventSphere - Discover, register and participate in college events."
    >

    <title><?= headerSafe($pageTitle) ?> | EventSphere</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>
        .event-navbar {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: rgba(15, 23, 42, .96);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-bottom: 1px solid rgba(255, 255, 255, .08);
            box-shadow: 0 8px 30px rgba(0, 0, 0, .08);
        }

        .event-brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            color: #fff !important;
            text-decoration: none;
            font-size: 21px;
            font-weight: 800;
        }

        .brand-mark {
            width: 37px;
            height: 37px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            color: #fff;
        }

        .event-nav-link {
            display: flex;
            align-items: center;
            gap: 6px;
            margin: 0 3px;
            padding: 10px 13px !important;
            border-radius: 9px;
            color: #cbd5e1 !important;
            font-size: 13px;
            font-weight: 600;
            transition: .25s ease;
        }

        .event-nav-link:hover,
        .event-nav-link.active {
            color: #fff !important;
            background: rgba(255, 255, 255, .07);
        }

        .nav-register {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin-left: 7px;
            padding: 9px 16px;
            border-radius: 9px;
            background: #0d6efd;
            color: #fff !important;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: .25s ease;
        }

        .nav-register:hover {
            background: #0b5ed7;
            color: #fff;
            transform: translateY(-2px);
        }

        .nav-user {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-left: 8px;
            padding-left: 12px;
            border-left: 1px solid rgba(255, 255, 255, .1);
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: linear-gradient(135deg, #0d6efd, #6f42c1);
            color: #fff;
            font-size: 11px;
            font-weight: 800;
        }

        .user-name {
            max-width: 120px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #e2e8f0;
            font-size: 12px;
            font-weight: 600;
        }

        .event-toggler {
            padding: 7px 10px;
            border: 1px solid rgba(255, 255, 255, .14);
            border-radius: 9px;
            color: #fff;
        }

        .event-toggler:focus {
            box-shadow: 0 0 0 3px rgba(13, 110, 253, .2);
        }

        .event-main {
            min-height: calc(100vh - 75px);
            background: #f8fafc;
        }

        .event-alert {
            margin-top: 20px;
            border: 0;
            border-radius: 12px;
            box-shadow: 0 7px 25px rgba(15, 23, 42, .06);
        }

        @media (max-width: 991px) {
            .event-navbar .navbar-collapse {
                margin-top: 14px;
                padding: 12px;
                border: 1px solid rgba(255, 255, 255, .08);
                border-radius: 14px;
                background: rgba(15, 23, 42, .98);
            }

            .event-nav-link {
                margin: 2px 0;
            }

            .nav-register {
                margin: 8px 0 2px;
            }

            .nav-user {
                margin: 10px 0 0;
                padding: 10px 0 0;
                border-left: 0;
                border-top: 1px solid rgba(255, 255, 255, .1);
            }
        }
    </style>

</head>

<body>

<nav class="navbar navbar-expand-lg event-navbar">
    <div class="container">

        <a class="event-brand" href="index.php">
            <span class="brand-mark">
                <i class="bi bi-calendar-event"></i>
            </span>
            EventSphere
        </a>

        <button
            class="navbar-toggler event-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#eventNavigation"
            aria-controls="eventNavigation"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <i class="bi bi-list"></i>
        </button>

        <div class="collapse navbar-collapse" id="eventNavigation">
            <ul class="navbar-nav ms-auto align-items-lg-center">

                <li class="nav-item">
                    <a class="nav-link event-nav-link" href="my-events.php">
                        <i class="bi bi-calendar3"></i>
                        Events
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link event-nav-link" href="gallery.php">
                        <i class="bi bi-images"></i>
                        Gallery
                    </a>
                </li>

                <?php if ($isLoggedIn): ?>

                    <li class="nav-item">
                        <a class="nav-link event-nav-link" href="student-dashboard.php">
                            <i class="bi bi-grid-1x2"></i>
                            Dashboard
                        </a>
                    </li>

                    <li class="nav-item">
                        <div class="nav-user">
                            <div class="user-avatar">
                                <?= headerSafe($avatarLetter) ?>
                            </div>

                            <span class="user-name">
                                <?= headerSafe($displayName) ?>
                            </span>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link event-nav-link" href="logout.php">
                            <i class="bi bi-box-arrow-right"></i>
                            Logout
                        </a>
                    </li>

                <?php else: ?>

                    <li class="nav-item">
                        <a class="nav-link event-nav-link" href="login.php">
                            <i class="bi bi-box-arrow-in-right"></i>
                            Login
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-register" href="register.php">
                            <i class="bi bi-person-plus"></i>
                            Create Account
                        </a>
                    </li>

                <?php endif; ?>

            </ul>
        </div>

    </div>
</nav>

<main class="event-main">

    <div class="container">

        <?php if ($flashMessage !== ""): ?>

            <div
                class="alert alert-<?= headerSafe($flashType) ?> event-alert alert-dismissible fade show"
                role="alert"
            >
                <?= headerSafe($flashMessage) ?>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"
                ></button>
            </div>

        <?php endif; ?>

    </div>

    <div class="container py-4">
