
<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

require_auth();

if (
    !isset($_SESSION['user']) ||
    !is_array($_SESSION['user']) ||
    !isset($_SESSION['user']['user_id'])
) {
    header('Location: login.php');
    exit;
}

$user = $_SESSION['user'];

$userId = (int)($user['user_id'] ?? 0);
$role   = strtolower(trim((string)($user['role'] ?? '')));

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| ROLE PROTECTION
|--------------------------------------------------------------------------
|
| Student attendance is handled here.
| Organizer attendance is handled separately.
|
*/

if ($role === 'organizer') {
    header('Location: organizer-attendance.php');
    exit;
}

if ($role !== 'student') {
    header('Location: dashboard.php');
    exit;
}

$title = 'Attendance | EventSphere';

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
|
| function_exists() prevents "Cannot redeclare h()" if the helper already
| exists inside functions.php.
|
*/

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

function safe_date(?string $date, string $format = 'd M Y'): string
{
    if (empty($date)) {
        return '—';
    }

    $timestamp = strtotime($date);

    if ($timestamp === false) {
        return '—';
    }

    return date($format, $timestamp);
}

function safe_time(?string $time): string
{
    if (empty($time)) {
        return '—';
    }

    $timestamp = strtotime($time);

    if ($timestamp === false) {
        return '—';
    }

    return date('h:i A', $timestamp);
}

/*
|--------------------------------------------------------------------------
| DEFAULT DATA
|--------------------------------------------------------------------------
*/

$studentName        = (string)($user['email'] ?? 'Student');
$departmentName     = 'Student';
$totalEvents        = 0;
$presentCount       = 0;
$absentCount        = 0;
$attendancePercentage = 0;
$attendanceRecords  = [];

/*
|--------------------------------------------------------------------------
| STUDENT PROFILE
|--------------------------------------------------------------------------
*/

$profileSql = "
    SELECT
        up.full_name,
        d.department_name
    FROM user_profiles AS up
    LEFT JOIN departments AS d
        ON d.department_id = up.department_id
    WHERE up.user_id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $profileSql);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    if (mysqli_stmt_execute($stmt)) {

        $result = mysqli_stmt_get_result($stmt);

        if ($result) {

            $profile = mysqli_fetch_assoc($result);

            if (
                is_array($profile) &&
                !empty($profile['full_name'])
            ) {
                $studentName = (string)$profile['full_name'];
            }

            if (
                is_array($profile) &&
                !empty($profile['department_name'])
            ) {
                $departmentName = (string)$profile['department_name'];
            }
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| ATTENDANCE STATISTICS
|--------------------------------------------------------------------------
*/

$statsSql = "
    SELECT
        COUNT(*) AS total_records,

        COALESCE(
            SUM(
                CASE
                    WHEN LOWER(TRIM(attendance_status)) = 'present'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS present_count,

        COALESCE(
            SUM(
                CASE
                    WHEN LOWER(TRIM(attendance_status)) = 'absent'
                    THEN 1
                    ELSE 0
                END
            ),
            0
        ) AS absent_count

    FROM attendance
    WHERE student_id = ?
";

$stmt = mysqli_prepare($conn, $statsSql);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    if (mysqli_stmt_execute($stmt)) {

        $result = mysqli_stmt_get_result($stmt);

        if ($result) {

            $stats = mysqli_fetch_assoc($result);

            if (is_array($stats)) {

                $totalEvents = (int)(
                    $stats['total_records'] ?? 0
                );

                $presentCount = (int)(
                    $stats['present_count'] ?? 0
                );

                $absentCount = (int)(
                    $stats['absent_count'] ?? 0
                );
            }
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| ATTENDANCE PERCENTAGE
|--------------------------------------------------------------------------
*/

if ($totalEvents > 0) {

    $attendancePercentage = (int)round(
        ($presentCount / $totalEvents) * 100
    );
}

/*
|--------------------------------------------------------------------------
| ATTENDANCE HISTORY
|--------------------------------------------------------------------------
*/

$recordsSql = "
    SELECT
        a.attendance_id,
        a.event_id,
        a.attendance_status,

        e.title,
        e.event_date,
        e.start_time,
        e.end_time,

        c.category_name,

        v.venue_name

    FROM attendance AS a

    INNER JOIN events AS e
        ON e.event_id = a.event_id

    LEFT JOIN event_categories AS c
        ON c.category_id = e.category_id

    LEFT JOIN venues AS v
        ON v.venue_id = e.venue_id

    WHERE a.student_id = ?

    ORDER BY
        e.event_date DESC,
        e.start_time DESC,
        a.attendance_id DESC
";

$stmt = mysqli_prepare($conn, $recordsSql);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    if (mysqli_stmt_execute($stmt)) {

        $result = mysqli_stmt_get_result($stmt);

        if ($result) {

            while ($row = mysqli_fetch_assoc($result)) {

                if (is_array($row)) {
                    $attendanceRecords[] = $row;
                }
            }
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| INITIAL LETTER
|--------------------------------------------------------------------------
*/

$avatarLetter = 'S';

$cleanStudentName = trim($studentName);

if ($cleanStudentName !== '') {

    $avatarLetter = strtoupper(
        substr($cleanStudentName, 0, 1)
    );
}

/*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

require __DIR__ . '/header.php';
?>

<style>

/* =========================================================
   EVENTSPHERE ATTENDANCE PAGE
   ========================================================= */

.attendance-page {
    padding: 42px 0 85px;
}

/* =========================================================
   HERO
   ========================================================= */

.attendance-hero {
    position: relative;
    overflow: hidden;
    padding: 42px;
    border-radius: 30px;
    color: #ffffff;

    background:
        radial-gradient(
            circle at 88% 12%,
            rgba(99, 102, 241, .38),
            transparent 30%
        ),
        radial-gradient(
            circle at 12% 88%,
            rgba(34, 211, 238, .16),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #0f172a 0%,
            #1e293b 52%,
            #312e81 100%
        );

    box-shadow:
        0 28px 70px rgba(15, 23, 42, .18);
}

.attendance-hero::before {
    content: "";
    position: absolute;
    width: 240px;
    height: 240px;
    right: -90px;
    top: -90px;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,.12);
}

.attendance-hero::after {
    content: "";
    position: absolute;
    width: 170px;
    height: 170px;
    right: 50px;
    bottom: -110px;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,.08);
}

.attendance-hero-content {
    position: relative;
    z-index: 2;
}

.attendance-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 14px;
    color: #a5b4fc;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.attendance-eyebrow::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #818cf8;
    box-shadow: 0 0 0 5px rgba(129,140,248,.12);
}

.attendance-hero h1 {
    margin: 0 0 10px;
    font-size: 38px;
    line-height: 1.15;
    font-weight: 850;
    letter-spacing: -.045em;
}

.attendance-hero-description {
    max-width: 700px;
    margin: 0;
    color: #cbd5e1;
    font-size: 14px;
    line-height: 1.75;
}

/* =========================================================
   STUDENT PROFILE
   ========================================================= */

.student-mini {
    display: inline-flex;
    align-items: center;
    gap: 13px;
    margin-top: 27px;
    padding: 8px 15px 8px 8px;
    border: 1px solid rgba(255,255,255,.13);
    border-radius: 999px;
    background: rgba(255,255,255,.07);
    backdrop-filter: blur(12px);
}

.student-avatar {
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 44px;
    border-radius: 50%;
    background: linear-gradient(
        135deg,
        #6366f1,
        #8b5cf6
    );
    color: #ffffff;
    font-size: 15px;
    font-weight: 850;
    box-shadow:
        0 8px 20px rgba(99,102,241,.3);
}

.student-mini-info strong {
    display: block;
    color: #ffffff;
    font-size: 13px;
    font-weight: 750;
}

.student-mini-info small {
    display: block;
    margin-top: 2px;
    color: #94a3b8;
    font-size: 10px;
}

/* =========================================================
   STATISTICS
   ========================================================= */

.attendance-stats {
    margin-top: 25px;
}

.attendance-stat {
    position: relative;
    overflow: hidden;
    height: 100%;
    padding: 23px;
    background: #ffffff;
    border: 1px solid #e8edf3;
    border-radius: 21px;
    box-shadow:
        0 9px 30px rgba(15,23,42,.045);
    transition:
        transform .3s ease,
        box-shadow .3s ease,
        border-color .3s ease;
}

.attendance-stat::after {
    content: "";
    position: absolute;
    width: 90px;
    height: 90px;
    right: -40px;
    bottom: -40px;
    border-radius: 50%;
    background: #f8fafc;
}

.attendance-stat:hover {
    transform: translateY(-6px);
    border-color: #dce3ef;
    box-shadow:
        0 20px 45px rgba(15,23,42,.09);
}

.stat-top {
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 18px;
}

.stat-icon {
    width: 43px;
    height: 43px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 13px;
    background: #f1f5f9;
    color: #334155;
    font-size: 16px;
    font-weight: 850;
}

.stat-label {
    color: #94a3b8;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .8px;
    text-transform: uppercase;
}

.attendance-stat h2 {
    position: relative;
    z-index: 2;
    margin: 0;
    color: #0f172a;
    font-size: 30px;
    line-height: 1;
    font-weight: 850;
    letter-spacing: -.04em;
}

.attendance-stat p {
    position: relative;
    z-index: 2;
    margin: 8px 0 0;
    color: #64748b;
    font-size: 11px;
}

/* =========================================================
   SECTION
   ========================================================= */

.attendance-section {
    margin-top: 36px;
}

.section-heading {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 17px;
}

.section-heading h2 {
    margin: 0;
    color: #0f172a;
    font-size: 22px;
    line-height: 1.2;
    font-weight: 850;
    letter-spacing: -.025em;
}

.section-heading p {
    margin: 6px 0 0;
    color: #94a3b8;
    font-size: 12px;
}

/* =========================================================
   TABLE CARD
   ========================================================= */

.attendance-card {
    overflow: hidden;
    background: #ffffff;
    border: 1px solid #e8edf3;
    border-radius: 22px;
    box-shadow:
        0 10px 34px rgba(15,23,42,.045);
}

.attendance-table-wrapper {
    overflow-x: auto;
}

.attendance-table {
    width: 100%;
    min-width: 880px;
    margin: 0;
    border-collapse: collapse;
}

.attendance-table thead {
    background: #f8fafc;
}

.attendance-table th {
    padding: 15px 20px;
    border-bottom: 1px solid #e8edf3;
    color: #64748b;
    font-size: 9px;
    font-weight: 850;
    text-align: left;
    text-transform: uppercase;
    letter-spacing: .8px;
    white-space: nowrap;
}

.attendance-table td {
    padding: 18px 20px;
    border-bottom: 1px solid #f1f5f9;
    color: #475569;
    font-size: 12px;
    vertical-align: middle;
}

.attendance-table tbody tr {
    transition: background .2s ease;
}

.attendance-table tbody tr:hover {
    background: #fafbff;
}

.attendance-table tbody tr:last-child td {
    border-bottom: 0;
}

/* =========================================================
   EVENT CELL
   ========================================================= */

.event-cell {
    display: flex;
    align-items: center;
    gap: 13px;
    min-width: 230px;
}

.event-date-box {
    width: 48px;
    height: 48px;
    flex: 0 0 48px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: 13px;
    background: linear-gradient(
        145deg,
        #eef2ff,
        #e0e7ff
    );
    color: #4f46e5;
}

.event-date-box strong {
    font-size: 16px;
    line-height: 1;
    font-weight: 850;
}

.event-date-box span {
    margin-top: 4px;
    font-size: 8px;
    font-weight: 850;
    text-transform: uppercase;
    letter-spacing: .5px;
}

.event-title {
    max-width: 250px;
    overflow: hidden;
    color: #172033;
    font-size: 13px;
    font-weight: 750;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.event-meta {
    margin-top: 4px;
    color: #94a3b8;
    font-size: 10px;
}

.category-text {
    display: inline-flex;
    padding: 6px 9px;
    border-radius: 8px;
    background: #f8fafc;
    color: #64748b;
    font-size: 10px;
    font-weight: 700;
}

.venue-text {
    max-width: 160px;
    color: #475569;
    font-size: 11px;
    font-weight: 600;
}

/* =========================================================
   STATUS
   ========================================================= */

.attendance-status {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 11px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 850;
    white-space: nowrap;
}

.attendance-status::before {
    content: "";
    width: 6px;
    height: 6px;
    flex: 0 0 6px;
    border-radius: 50%;
}

.status-present {
    background: #ecfdf5;
    color: #15803d;
}

.status-present::before {
    background: #22c55e;
    box-shadow: 0 0 0 3px rgba(34,197,94,.1);
}

.status-absent {
    background: #fef2f2;
    color: #b91c1c;
}

.status-absent::before {
    background: #ef4444;
    box-shadow: 0 0 0 3px rgba(239,68,68,.1);
}

.status-other {
    background: #f1f5f9;
    color: #475569;
}

.status-other::before {
    background: #94a3b8;
}

/* =========================================================
   EMPTY STATE
   ========================================================= */

.empty-attendance {
    padding: 80px 25px;
    text-align: center;
}

.empty-icon {
    width: 68px;
    height: 68px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 18px;
    border: 1px solid #e0e7ff;
    border-radius: 20px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 26px;
    font-weight: 850;
}

.empty-attendance h3 {
    margin: 0 0 7px;
    color: #1e293b;
    font-size: 18px;
    font-weight: 800;
}

.empty-attendance p {
    max-width: 460px;
    margin: auto;
    color: #94a3b8;
    font-size: 12px;
    line-height: 1.75;
}

/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 991px) {

    .attendance-hero {
        padding: 34px;
    }

    .attendance-hero h1 {
        font-size: 34px;
    }

    .section-heading {
        display: block;
    }
}

@media (max-width: 767px) {

    .attendance-page {
        padding: 25px 0 55px;
    }

    .attendance-hero {
        padding: 28px 22px;
        border-radius: 22px;
    }

    .attendance-hero h1 {
        font-size: 29px;
    }

    .attendance-hero-description {
        font-size: 12px;
    }

    .student-mini {
        max-width: 100%;
    }

    .attendance-stat {
        padding: 20px;
    }

    .attendance-section {
        margin-top: 28px;
    }

    .attendance-card {
        border-radius: 18px;
    }

    .empty-attendance {
        padding: 60px 20px;
    }
}

</style>

<div class="container attendance-page">

    <!-- =====================================================
         HERO
         ===================================================== -->

    <section class="attendance-hero">

        <div class="attendance-hero-content">

            <span class="attendance-eyebrow">
                EventSphere Student Portal
            </span>

            <h1>
                My Attendance
            </h1>

            <p class="attendance-hero-description">
                Track your event participation, attendance history
                and overall attendance performance from one place.
            </p>

            <div class="student-mini">

                <div class="student-avatar">
                    <?= h($avatarLetter) ?>
                </div>

                <div class="student-mini-info">

                    <strong>
                        <?= h($studentName) ?>
                    </strong>

                    <small>
                        <?= h($departmentName) ?>
                    </small>

                </div>

            </div>

        </div>

    </section>


    <!-- =====================================================
         STATISTICS
         ===================================================== -->

    <div class="row g-4 attendance-stats">

        <!-- Total -->

        <div class="col-12 col-sm-6 col-lg-3">

            <div class="attendance-stat">

                <div class="stat-top">

                    <div class="stat-icon">
                        #
                    </div>

                    <span class="stat-label">
                        Records
                    </span>

                </div>

                <h2>
                    <?= $totalEvents ?>
                </h2>

                <p>
                    Total attendance records
                </p>

            </div>

        </div>


        <!-- Present -->

        <div class="col-12 col-sm-6 col-lg-3">

            <div class="attendance-stat">

                <div class="stat-top">

                    <div class="stat-icon">
                        ✓
                    </div>

                    <span class="stat-label">
                        Present
                    </span>

                </div>

                <h2>
                    <?= $presentCount ?>
                </h2>

                <p>
                    Events successfully attended
                </p>

            </div>

        </div>


        <!-- Absent -->

        <div class="col-12 col-sm-6 col-lg-3">

            <div class="attendance-stat">

                <div class="stat-top">

                    <div class="stat-icon">
                        ×
                    </div>

                    <span class="stat-label">
                        Absent
                    </span>

                </div>

                <h2>
                    <?= $absentCount ?>
                </h2>

                <p>
                    Events missed
                </p>

            </div>

        </div>


        <!-- Percentage -->

        <div class="col-12 col-sm-6 col-lg-3">

            <div class="attendance-stat">

                <div class="stat-top">

                    <div class="stat-icon">
                        %
                    </div>

                    <span class="stat-label">
                        Rate
                    </span>

                </div>

                <h2>
                    <?= $attendancePercentage ?>%
                </h2>

                <p>
                    Overall attendance rate
                </p>

            </div>

        </div>

    </div>


    <!-- =====================================================
         ATTENDANCE HISTORY
         ===================================================== -->

    <section class="attendance-section">

        <div class="section-heading">

            <div>

                <h2>
                    Attendance History
                </h2>

                <p>
                    Official attendance records associated with your account.
                </p>

            </div>

        </div>


        <div class="attendance-card">

            <?php if (empty($attendanceRecords)): ?>

                <!-- EMPTY STATE -->

                <div class="empty-attendance">

                    <div class="empty-icon">
                        ✓
                    </div>

                    <h3>
                        No attendance records yet
                    </h3>

                    <p>
                        Your attendance history will appear here once
                        an organizer records your participation in an event.
                    </p>

                </div>

            <?php else: ?>

                <div class="attendance-table-wrapper">

                    <table class="attendance-table">

                        <thead>

                            <tr>

                                <th>
                                    Event
                                </th>

                                <th>
                                    Category
                                </th>

                                <th>
                                    Date
                                </th>

                                <th>
                                    Time
                                </th>

                                <th>
                                    Venue
                                </th>

                                <th>
                                    Status
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($attendanceRecords as $record): ?>

                            <?php

                            $status = strtolower(
                                trim(
                                    (string)(
                                        $record['attendance_status']
                                        ?? ''
                                    )
                                )
                            );

                            if ($status === 'present') {

                                $statusClass = 'status-present';
                                $statusText  = 'Present';

                            } elseif ($status === 'absent') {

                                $statusClass = 'status-absent';
                                $statusText  = 'Absent';

                            } else {

                                $statusClass = 'status-other';

                                $statusText = $status !== ''
                                    ? ucfirst($status)
                                    : 'Recorded';
                            }

                            $eventDate = !empty(
                                $record['event_date']
                            )
                                ? strtotime(
                                    (string)$record['event_date']
                                )
                                : false;

                            ?>

                            <tr>

                                <!-- EVENT -->

                                <td>

                                    <div class="event-cell">

                                        <div class="event-date-box">

                                            <?php if ($eventDate !== false): ?>

                                                <strong>
                                                    <?= date(
                                                        'd',
                                                        $eventDate
                                                    ) ?>
                                                </strong>

                                                <span>
                                                    <?= date(
                                                        'M',
                                                        $eventDate
                                                    ) ?>
                                                </span>

                                            <?php else: ?>

                                                <strong>
                                                    —
                                                </strong>

                                                <span>
                                                    DATE
                                                </span>

                                            <?php endif; ?>

                                        </div>


                                        <div>

                                            <div class="event-title">

                                                <?= h(
                                                    $record['title']
                                                    ?? 'Untitled Event'
                                                ) ?>

                                            </div>

                                            <div class="event-meta">

                                                Event #
                                                <?= (int)(
                                                    $record['event_id']
                                                    ?? 0
                                                ) ?>

                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <!-- CATEGORY -->

                                <td>

                                    <span class="category-text">

                                        <?= h(
                                            !empty(
                                                $record['category_name']
                                            )
                                                ? $record['category_name']
                                                : 'General Event'
                                        ) ?>

                                    </span>

                                </td>


                                <!-- DATE -->

                                <td>

                                    <?= $eventDate !== false
                                        ? h(
                                            date(
                                                'd M Y',
                                                $eventDate
                                            )
                                        )
                                        : '—'
                                    ?>

                                </td>


                                <!-- TIME -->

                                <td>

                                    <?= h(
                                        safe_time(
                                            !empty(
                                                $record['start_time']
                                            )
                                                ? (string)$record['start_time']
                                                : null
                                        )
                                    ) ?>

                                </td>


                                <!-- VENUE -->

                                <td>

                                    <span class="venue-text">

                                        <?= h(
                                            !empty(
                                                $record['venue_name']
                                            )
                                                ? $record['venue_name']
                                                : 'Venue not specified'
                                        ) ?>

                                    </span>

                                </td>


                                <!-- STATUS -->

                                <td>

                                    <span
                                        class="attendance-status <?= h(
                                            $statusClass
                                        ) ?>"
                                    >
                                        <?= h($statusText) ?>
                                    </span>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </section>

</div>

<?php
require __DIR__ . '/footer.php';
?>
