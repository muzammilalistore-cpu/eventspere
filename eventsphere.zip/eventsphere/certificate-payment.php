```php
<?php
declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| EventSphere - Certificate + Payment
|--------------------------------------------------------------------------
| File:
| C:\xampp\htdocs\eventsphere\certificate.php
|
| Single-file certificate system:
| - Student authentication
| - Attendance verification
| - Certificate listing
| - Certificate fee
| - Payment record creation
| - Demo card payment flow
| - Paid status synchronization
| - Certificate view/download
|
| IMPORTANT:
| A real debit/credit-card charge requires a payment gateway.
| This file does NOT store card numbers or CVV in the database.
|--------------------------------------------------------------------------
*/

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user']['user_id'])) {
    header('Location: login.php');
    exit;
}

$user = $_SESSION['user'];

$userId = (int)($user['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Student Only
|--------------------------------------------------------------------------
*/

if (($user['role'] ?? '') !== 'student') {
    header('Location: index.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function redirect_to(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['certificate_csrf'])) {
    $_SESSION['certificate_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['certificate_csrf'];

/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$successMessage = '';
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| Selected Certificate
|--------------------------------------------------------------------------
*/

$selectedCertificateId = isset($_GET['certificate_id'])
    ? (int)$_GET['certificate_id']
    : 0;

/*
|--------------------------------------------------------------------------
| PAYMENT POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedToken = (string)($_POST['csrf_token'] ?? '');

    if (
        $postedToken === '' ||
        !hash_equals($csrfToken, $postedToken)
    ) {
        $errorMessage = 'Invalid security request. Please refresh the page.';
    } else {

        $action = (string)($_POST['action'] ?? '');

        /*
        |--------------------------------------------------------------------------
        | START PAYMENT
        |--------------------------------------------------------------------------
        */

        if ($action === 'pay') {

            $certificateId = (int)($_POST['certificate_id'] ?? 0);

            $paymentMethod = trim(
                (string)($_POST['payment_method'] ?? 'card')
            );

            /*
            | Never save these values.
            | They are only used to validate the demo form.
            */

            $cardName = trim(
                (string)($_POST['card_name'] ?? '')
            );

            $cardNumber = preg_replace(
                '/\D+/',
                '',
                (string)($_POST['card_number'] ?? '')
            );

            $expiry = trim(
                (string)($_POST['expiry'] ?? '')
            );

            $cvv = preg_replace(
                '/\D+/',
                '',
                (string)($_POST['cvv'] ?? '')
            );

            if ($certificateId <= 0) {
                $errorMessage = 'Invalid certificate.';
            } elseif ($paymentMethod !== 'card') {
                $errorMessage = 'Please select debit or credit card.';
            } elseif ($cardName === '') {
                $errorMessage = 'Please enter the card holder name.';
            } elseif (strlen($cardNumber) < 13 || strlen($cardNumber) > 19) {
                $errorMessage = 'Please enter a valid card number.';
            } elseif (!preg_match('/^\d{2}\/\d{2}$/', $expiry)) {
                $errorMessage = 'Please enter expiry in MM/YY format.';
            } elseif (strlen($cvv) < 3 || strlen($cvv) > 4) {
                $errorMessage = 'Please enter a valid CVV.';
            } else {

                /*
                |--------------------------------------------------------------------------
                | Verify certificate belongs to student
                |--------------------------------------------------------------------------
                */

                $verifySql = "
                    SELECT
                        c.certificate_id,
                        c.student_id,
                        c.event_id,
                        c.registration_id,
                        c.certificate_number,
                        c.certificate_type,
                        c.certificate_url,
                        c.issued_at,
                        c.certificate_fee,
                        c.payment_status,

                        e.title AS event_title,
                        e.event_date,
                        e.start_time,

                        a.attendance_status

                    FROM certificates c

                    INNER JOIN events e
                        ON e.event_id = c.event_id

                    INNER JOIN attendance a
                        ON a.event_id = c.event_id
                        AND a.student_id = c.student_id
                        AND a.registration_id = c.registration_id
                        AND a.attendance_status = 'present'

                    WHERE
                        c.certificate_id = ?
                        AND c.student_id = ?

                    LIMIT 1
                ";

                $verifyStmt = mysqli_prepare($conn, $verifySql);

                if (!$verifyStmt) {

                    $errorMessage = 'Unable to verify certificate.';

                } else {

                    mysqli_stmt_bind_param(
                        $verifyStmt,
                        'ii',
                        $certificateId,
                        $userId
                    );

                    mysqli_stmt_execute($verifyStmt);

                    $verifyResult = mysqli_stmt_get_result($verifyStmt);

                    $certificate = $verifyResult
                        ? mysqli_fetch_assoc($verifyResult)
                        : null;

                    mysqli_stmt_close($verifyStmt);

                    if (!$certificate) {

                        $errorMessage =
                            'Certificate not found or attendance is not verified.';

                    } else {

                        $certificatePaymentStatus = strtolower(
                            trim(
                                (string)(
                                    $certificate['payment_status'] ?? 'unpaid'
                                )
                            )
                        );

                        /*
                        |--------------------------------------------------------------------------
                        | Already Paid
                        |--------------------------------------------------------------------------
                        */

                        if (
                            $certificatePaymentStatus === 'paid' ||
                            $certificatePaymentStatus === 'approved'
                        ) {

                            $successMessage =
                                'This certificate has already been paid.';

                            $selectedCertificateId = $certificateId;

                        } else {

                            $amount = (float)(
                                $certificate['certificate_fee'] ?? 0
                            );

                            /*
                            |--------------------------------------------------------------------------
                            | Default certificate fee
                            |--------------------------------------------------------------------------
                            */

                            if ($amount <= 0) {
                                $amount = 500.00;
                            }

                            $currency = 'PKR';

                            /*
                            |--------------------------------------------------------------------------
                            | Generate unique transaction reference
                            |--------------------------------------------------------------------------
                            */

                            $transactionReference =
                                'ES-' .
                                date('YmdHis') .
                                '-' .
                                strtoupper(
                                    bin2hex(random_bytes(4))
                                );

                            /*
                            |--------------------------------------------------------------------------
                            | Create payment record
                            |--------------------------------------------------------------------------
                            */

                            $insertSql = "
                                INSERT INTO certificate_payments
                                (
                                    certificate_id,
                                    student_id,
                                    amount,
                                    currency,
                                    payment_method,
                                    transaction_reference,
                                    status,
                                    gateway_name,
                                    gateway_transaction_id,
                                    failure_reason,
                                    created_at
                                )
                                VALUES
                                (
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    'processing',
                                    'EventSphere Demo Gateway',
                                    NULL,
                                    NULL,
                                    NOW()
                                )
                            ";

                            $insertStmt = mysqli_prepare(
                                $conn,
                                $insertSql
                            );

                            if (!$insertStmt) {

                                $errorMessage =
                                    'Payment could not be initialized.';

                            } else {

                                mysqli_stmt_bind_param(
                                    $insertStmt,
                                    'iidsss',
                                    $certificateId,
                                    $userId,
                                    $amount,
                                    $currency,
                                    $paymentMethod,
                                    $transactionReference
                                );

                                if (
                                    !mysqli_stmt_execute($insertStmt)
                                ) {

                                    $errorMessage =
                                        'Payment could not be created.';

                                } else {

                                    $paymentId =
                                        mysqli_insert_id($conn);

                                    /*
                                    |--------------------------------------------------------------------------
                                    | DEMO PAYMENT SUCCESS
                                    |--------------------------------------------------------------------------
                                    |
                                    | In a real gateway integration this section would NOT
                                    | blindly mark the payment paid.
                                    |
                                    | Instead the gateway would return a verified transaction.
                                    |
                                    */

                                    $gatewayTransactionId =
                                        'DEMO-' .
                                        strtoupper(
                                            bin2hex(random_bytes(8))
                                        );

                                    $updatePaymentSql = "
                                        UPDATE certificate_payments
                                        SET
                                            status = 'paid',
                                            gateway_transaction_id = ?,
                                            paid_at = NOW(),
                                            updated_at = NOW()
                                        WHERE
                                            payment_id = ?
                                            AND student_id = ?
                                    ";

                                    $updatePaymentStmt = mysqli_prepare(
                                        $conn,
                                        $updatePaymentSql
                                    );

                                    if (!$updatePaymentStmt) {

                                        $errorMessage =
                                            'Payment verification failed.';

                                    } else {

                                        mysqli_stmt_bind_param(
                                            $updatePaymentStmt,
                                            'sii',
                                            $gatewayTransactionId,
                                            $paymentId,
                                            $userId
                                        );

                                        if (
                                            mysqli_stmt_execute(
                                                $updatePaymentStmt
                                            )
                                        ) {

                                            /*
                                            |--------------------------------------------------------------------------
                                            | Synchronize certificate
                                            |--------------------------------------------------------------------------
                                            */

                                            $updateCertificateSql = "
                                                UPDATE certificates
                                                SET
                                                    payment_status = 'paid',
                                                    payment_method = ?,
                                                    payment_reference = ?,
                                                    paid_at = NOW()
                                                WHERE
                                                    certificate_id = ?
                                                    AND student_id = ?
                                            ";

                                            $updateCertificateStmt =
                                                mysqli_prepare(
                                                    $conn,
                                                    $updateCertificateSql
                                                );

                                            if (
                                                $updateCertificateStmt
                                            ) {

                                                mysqli_stmt_bind_param(
                                                    $updateCertificateStmt,
                                                    'ssii',
                                                    $paymentMethod,
                                                    $transactionReference,
                                                    $certificateId,
                                                    $userId
                                                );

                                                mysqli_stmt_execute(
                                                    $updateCertificateStmt
                                                );

                                                mysqli_stmt_close(
                                                    $updateCertificateStmt
                                                );

                                                $successMessage =
                                                    'Payment successful! Your certificate is now available.';

                                                $selectedCertificateId =
                                                    $certificateId;

                                            } else {

                                                $errorMessage =
                                                    'Payment completed but certificate status could not be updated.';
                                            }

                                        } else {

                                            $errorMessage =
                                                'Payment verification failed.';
                                        }

                                        mysqli_stmt_close(
                                            $updatePaymentStmt
                                        );
                                    }
                                }

                                mysqli_stmt_close($insertStmt);
                            }
                        }
                    }
                }
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| Load Certificates
|--------------------------------------------------------------------------
*/

$certificates = [];
$databaseError = '';

$sql = "
    SELECT
        c.certificate_id,
        c.event_id,
        c.student_id,
        c.registration_id,
        c.certificate_number,
        c.certificate_type,
        c.certificate_url,
        c.issued_at,
        c.certificate_fee,
        c.payment_status,
        c.payment_method,
        c.payment_reference,
        c.paid_at,

        e.title AS event_title,
        e.event_date,
        e.start_time,
        e.end_time,
        e.venue,

        er.registration_code,

        a.attendance_status,
        a.marked_at

    FROM certificates c

    INNER JOIN events e
        ON e.event_id = c.event_id

    INNER JOIN event_registrations er
        ON er.registration_id = c.registration_id
        AND er.event_id = c.event_id
        AND er.student_id = c.student_id

    INNER JOIN attendance a
        ON a.event_id = c.event_id
        AND a.student_id = c.student_id
        AND a.registration_id = c.registration_id
        AND a.attendance_status = 'present'

    WHERE c.student_id = ?

    ORDER BY
        c.issued_at DESC,
        c.certificate_id DESC
";

$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    if (mysqli_stmt_execute($stmt)) {

        $result = mysqli_stmt_get_result($stmt);

        if ($result) {

            while ($row = mysqli_fetch_assoc($result)) {
                $certificates[] = $row;
            }

            mysqli_free_result($result);
        }

    } else {

        $databaseError =
            'Certificates could not be loaded right now.';
    }

    mysqli_stmt_close($stmt);

} else {

    $databaseError =
        'Certificates could not be loaded right now.';
}

/*
|--------------------------------------------------------------------------
| Summary
|--------------------------------------------------------------------------
*/

$totalCertificates = count($certificates);

$pendingPayments = 0;
$paidCertificates = 0;
$failedPayments = 0;

foreach ($certificates as $certificate) {

    $status = strtolower(
        trim(
            (string)(
                $certificate['payment_status'] ?? 'unpaid'
            )
        )
    );

    if (
        $status === 'paid' ||
        $status === 'approved'
    ) {

        $paidCertificates++;

    } elseif (
        $status === 'failed'
    ) {

        $failedPayments++;

    } else {

        $pendingPayments++;
    }
}

/*
|--------------------------------------------------------------------------
| Selected Certificate
|--------------------------------------------------------------------------
*/

$selectedCertificate = null;

if ($selectedCertificateId > 0) {

    foreach ($certificates as $certificate) {

        if (
            (int)$certificate['certificate_id']
            === $selectedCertificateId
        ) {

            $selectedCertificate = $certificate;
            break;
        }
    }
}

$title = 'My Certificates';

require_once __DIR__ . '/header.php';

?>

<style>

/* =========================================================
   PAGE
========================================================= */

.certificate-page {
    padding: 45px 0 90px;
}

/* =========================================================
   HERO
========================================================= */

.certificate-hero {
    position: relative;
    overflow: hidden;

    padding: 45px;

    margin-bottom: 25px;

    border-radius: 28px;

    background:
        radial-gradient(
            circle at 85% 15%,
            rgba(99,102,241,.30),
            transparent 30%
        ),
        radial-gradient(
            circle at 10% 90%,
            rgba(34,211,238,.16),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #1e1b4b
        );

    color: #fff;

    box-shadow:
        0 25px 60px rgba(15,23,42,.15);
}

.certificate-label {
    display: inline-flex;

    align-items: center;
    gap: 8px;

    padding: 8px 13px;

    border:
        1px solid
        rgba(255,255,255,.13);

    border-radius: 999px;

    background:
        rgba(255,255,255,.07);

    color: #c7d2fe;

    font-size: .72rem;

    font-weight: 800;

    letter-spacing: .08em;

    text-transform: uppercase;
}

.certificate-label::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #34d399;
}

.certificate-hero h1 {
    margin: 18px 0 10px;

    font-size:
        clamp(2rem, 4vw, 3.2rem);

    line-height: 1;

    letter-spacing: -.05em;
}

.certificate-hero p {
    max-width: 700px;

    margin: 0;

    color: #cbd5e1;

    line-height: 1.7;
}

/* =========================================================
   MESSAGES
========================================================= */

.alert {
    padding: 15px 18px;

    margin-bottom: 22px;

    border-radius: 14px;

    font-size: .82rem;

    line-height: 1.6;
}

.alert-success {
    background: #ecfdf5;

    border: 1px solid #bbf7d0;

    color: #166534;
}

.alert-error {
    background: #fef2f2;

    border: 1px solid #fecaca;

    color: #b91c1c;
}

/* =========================================================
   SUMMARY
========================================================= */

.certificate-summary {
    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 16px;

    margin-bottom: 25px;
}

.summary-box {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 20px;

    background: #fff;

    border:
        1px solid
        #e8ecf2;

    border-radius: 18px;

    box-shadow:
        0 8px 30px
        rgba(15,23,42,.045);
}

.summary-info strong {
    display: block;

    color: #111827;

    font-size: .9rem;
}

.summary-info span {
    display: block;

    margin-top: 4px;

    color: #94a3b8;

    font-size: .72rem;
}

.summary-number {
    min-width: 44px;
    height: 38px;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 0 11px;

    border-radius: 999px;

    background: #eef2ff;

    color: #4338ca;

    font-size: .82rem;

    font-weight: 850;
}

/* =========================================================
   GRID
========================================================= */

.certificate-grid {
    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(330px, 1fr)
        );

    gap: 22px;
}

/* =========================================================
   CARD
========================================================= */

.certificate-card {
    overflow: hidden;

    background: #fff;

    border:
        1px solid
        #e8ecf2;

    border-radius: 22px;

    box-shadow:
        0 10px 35px
        rgba(15,23,42,.055);

    transition: .25s ease;
}

.certificate-card:hover {
    transform: translateY(-4px);

    border-color: #c7d2fe;

    box-shadow:
        0 22px 55px
        rgba(15,23,42,.10);
}

/* =========================================================
   CARD TOP
========================================================= */

.certificate-card-top {
    padding: 27px;

    background:
        linear-gradient(
            135deg,
            #f8fafc,
            #eef2ff
        );
}

.certificate-mark {
    width: 54px;
    height: 54px;

    display: flex;

    align-items: center;

    justify-content: center;

    margin-bottom: 17px;

    border-radius: 16px;

    background: #fff;

    font-size: 24px;

    box-shadow:
        0 8px 20px
        rgba(79,70,229,.10);
}

.certificate-card h2 {
    margin: 0 0 8px;

    color: #111827;

    font-size: 1.16rem;

    font-weight: 800;

    line-height: 1.4;
}

.event-date {
    color: #64748b;

    font-size: .76rem;
}

/* =========================================================
   CARD BODY
========================================================= */

.certificate-card-body {
    padding: 23px 27px 27px;
}

.status-row {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 10px;

    margin-bottom: 18px;
}

.attendance-status {
    display: inline-flex;

    align-items: center;

    gap: 7px;

    color: #15803d;

    font-size: .72rem;

    font-weight: 800;
}

.attendance-status::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #22c55e;
}

/* =========================================================
   BADGES
========================================================= */

.payment-badge {
    display: inline-flex;

    align-items: center;

    padding: 6px 10px;

    border-radius: 999px;

    font-size: .65rem;

    font-weight: 800;

    text-transform: uppercase;
}

.payment-badge.pending {
    background: #fff7ed;

    color: #c2410c;
}

.payment-badge.paid {
    background: #ecfdf5;

    color: #15803d;
}

.payment-badge.failed {
    background: #fef2f2;

    color: #b91c1c;
}

/* =========================================================
   META
========================================================= */

.certificate-meta {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 11px;

    margin-bottom: 20px;
}

.meta-item {
    padding: 12px;

    border:
        1px solid
        #edf0f4;

    border-radius: 12px;

    background: #fafbfc;
}

.meta-item span {
    display: block;

    margin-bottom: 4px;

    color: #94a3b8;

    font-size: .63rem;

    font-weight: 700;

    text-transform: uppercase;
}

.meta-item strong {
    display: block;

    color: #1e293b;

    font-size: .77rem;

    word-break: break-word;
}

/* =========================================================
   BUTTON
========================================================= */

.certificate-action {
    width: 100%;

    min-height: 47px;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 8px;

    border-radius: 12px;

    text-decoration: none;

    font-size: .79rem;

    font-weight: 800;

    transition: .25s ease;
}

.certificate-action:hover {
    transform: translateY(-2px);
}

.action-payment {
    background:
        linear-gradient(
            135deg,
            #f59e0b,
            #ea580c
        );

    color: #fff;
}

.action-payment:hover {
    color: #fff;
}

.action-download {
    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    color: #fff;
}

.action-download:hover {
    color: #fff;
}

/* =========================================================
   PAYMENT PANEL
========================================================= */

.payment-overlay {
    position: fixed;

    inset: 0;

    z-index: 9999;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 20px;

    background:
        rgba(15,23,42,.70);

    backdrop-filter:
        blur(8px);
}

.payment-modal {
    width: 100%;

    max-width: 520px;

    max-height: 92vh;

    overflow-y: auto;

    background: #fff;

    border-radius: 24px;

    box-shadow:
        0 30px 100px
        rgba(0,0,0,.25);
}

.payment-modal-header {
    padding: 27px;

    background:
        linear-gradient(
            135deg,
            #0f172a,
            #312e81
        );

    color: #fff;
}

.payment-modal-header-top {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;
}

.payment-modal-header h2 {
    margin: 0;

    font-size: 1.35rem;
}

.payment-close {
    width: 38px;
    height: 38px;

    display: flex;

    align-items: center;

    justify-content: center;

    border: 0;

    border-radius: 11px;

    background:
        rgba(255,255,255,.10);

    color: #fff;

    font-size: 1.1rem;

    cursor: pointer;

    text-decoration: none;
}

.payment-modal-header p {
    margin: 10px 0 0;

    color: #cbd5e1;

    font-size: .78rem;

    line-height: 1.6;
}

/* =========================================================
   PAYMENT AMOUNT
========================================================= */

.payment-amount {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 18px;

    margin-bottom: 22px;

    border:
        1px solid
        #e5e7eb;

    border-radius: 15px;

    background: #f8fafc;
}

.payment-amount span {
    color: #64748b;

    font-size: .75rem;

    font-weight: 700;
}

.payment-amount strong {
    color: #111827;

    font-size: 1.35rem;
}

/* =========================================================
   PAYMENT FORM
========================================================= */

.payment-form {
    padding: 27px;
}

.form-group {
    margin-bottom: 17px;
}

.form-group label {
    display: block;

    margin-bottom: 7px;

    color: #334155;

    font-size: .72rem;

    font-weight: 800;
}

.form-group input,
.form-group select {
    width: 100%;

    min-height: 45px;

    padding: 0 13px;

    border:
        1px solid
        #dbe1e8;

    border-radius: 11px;

    background: #fff;

    color: #111827;

    outline: none;

    font-size: .8rem;

    box-sizing: border-box;
}

.form-group input:focus,
.form-group select:focus {
    border-color: #6366f1;

    box-shadow:
        0 0 0 3px
        rgba(99,102,241,.10);
}

.form-row {
    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 12px;
}

.card-input {
    letter-spacing: .08em;
}

.payment-security {
    display: flex;

    gap: 10px;

    padding: 13px;

    margin: 17px 0;

    border:
        1px solid
        #dbeafe;

    border-radius: 12px;

    background: #eff6ff;

    color: #1e40af;

    font-size: .7rem;

    line-height: 1.5;
}

.pay-button {
    width: 100%;

    min-height: 49px;

    border: 0;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            #4f46e5,
            #4338ca
        );

    color: #fff;

    font-size: .8rem;

    font-weight: 850;

    cursor: pointer;

    box-shadow:
        0 12px 25px
        rgba(79,70,229,.20);
}

.pay-button:hover {
    transform: translateY(-1px);
}

.demo-note {
    margin-top: 13px;

    color: #94a3b8;

    text-align: center;

    font-size: .65rem;

    line-height: 1.5;
}

/* =========================================================
   EMPTY
========================================================= */

.certificate-empty {
    padding: 65px 25px;

    text-align: center;

    background: #fff;

    border:
        1px solid
        #e8ecf2;

    border-radius: 22px;

    box-shadow:
        0 10px 35px
        rgba(15,23,42,.045);
}

.empty-icon {
    width: 65px;
    height: 65px;

    display: flex;

    align-items: center;

    justify-content: center;

    margin: 0 auto 18px;

    border-radius: 18px;

    background: #f1f5f9;

    font-size: 26px;
}

.certificate-empty h2 {
    margin: 0 0 8px;

    color: #111827;

    font-size: 1.25rem;
}

.certificate-empty p {
    max-width: 530px;

    margin: auto;

    color: #64748b;

    font-size: .85rem;

    line-height: 1.7;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 800px) {

    .certificate-summary {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 767px) {

    .certificate-page {
        padding: 25px 0 55px;
    }

    .certificate-hero {
        padding: 30px 23px;
    }

    .certificate-grid {
        grid-template-columns: 1fr;
    }

    .certificate-meta {
        grid-template-columns: 1fr;
    }

    .form-row {
        grid-template-columns: 1fr;
    }

    .payment-modal {
        max-height: 95vh;
    }
}

</style>

<div class="container certificate-page">

    <!-- HERO -->

    <section class="certificate-hero">

        <span class="certificate-label">
            EventSphere Student Portal
        </span>

        <h1>
            My Certificates
        </h1>

        <p>
            Your certificates appear here after your event attendance
            has been verified. Once a certificate is available, you can
            securely complete the certificate fee and access your certificate.
        </p>

    </section>


    <!-- MESSAGES -->

    <?php if ($successMessage !== ''): ?>

        <div class="alert alert-success">
            <?= h($successMessage) ?>
        </div>

    <?php endif; ?>


    <?php if ($errorMessage !== ''): ?>

        <div class="alert alert-error">
            <?= h($errorMessage) ?>
        </div>

    <?php endif; ?>


    <?php if ($databaseError !== ''): ?>

        <div class="alert alert-error">
            <?= h($databaseError) ?>
        </div>

    <?php endif; ?>


    <!-- SUMMARY -->

    <div class="certificate-summary">

        <div class="summary-box">

            <div class="summary-info">

                <strong>
                    Total Certificates
                </strong>

                <span>
                    Attendance verified
                </span>

            </div>

            <div class="summary-number">
                <?= $totalCertificates ?>
            </div>

        </div>


        <div class="summary-box">

            <div class="summary-info">

                <strong>
                    Payment Pending
                </strong>

                <span>
                    Ready for payment
                </span>

            </div>

            <div class="summary-number">
                <?= $pendingPayments ?>
            </div>

        </div>


        <div class="summary-box">

            <div class="summary-info">

                <strong>
                    Paid
                </strong>

                <span>
                    Certificate available
                </span>

            </div>

            <div class="summary-number">
                <?= $paidCertificates ?>
            </div>

        </div>

    </div>


    <!-- CERTIFICATES -->

    <?php if (empty($certificates)): ?>

        <div class="certificate-empty">

            <div class="empty-icon">
                🎓
            </div>

            <h2>
                No certificates available yet
            </h2>

            <p>
                Your certificate will appear here after you attend an
                eligible event and the organizer verifies your attendance.
            </p>

        </div>

    <?php else: ?>

        <div class="certificate-grid">

            <?php foreach ($certificates as $certificate): ?>

                <?php

                $paymentStatus = strtolower(
                    trim(
                        (string)(
                            $certificate['payment_status']
                            ?? 'unpaid'
                        )
                    )
                );

                $fee = (float)(
                    $certificate['certificate_fee']
                    ?? 0
                );

                if ($fee <= 0) {
                    $fee = 500.00;
                }

                $eventDate = !empty(
                    $certificate['event_date']
                )
                    ? strtotime(
                        (string)$certificate['event_date']
                    )
                    : false;

                $issuedDate = !empty(
                    $certificate['issued_at']
                )
                    ? strtotime(
                        (string)$certificate['issued_at']
                    )
                    : false;

                $certificateUrl = trim(
                    (string)(
                        $certificate['certificate_url']
                        ?? ''
                    )
                );

                $safeCertificateUrl = '';

                if (
                    $certificateUrl !== '' &&
                    !preg_match(
                        '#^(?:https?:)?//#i',
                        $certificateUrl
                    )
                ) {
                    $safeCertificateUrl =
                        $certificateUrl;
                }

                $isPaid =
                    $paymentStatus === 'paid' ||
                    $paymentStatus === 'approved';

                ?>

                <article class="certificate-card">

                    <div class="certificate-card-top">

                        <div class="certificate-mark">
                            🎓
                        </div>

                        <h2>
                            <?= h(
                                $certificate['event_title']
                            ) ?>
                        </h2>

                        <?php if ($eventDate): ?>

                            <div class="event-date">

                                Event Date:
                                <?= h(
                                    date(
                                        'd M Y',
                                        $eventDate
                                    )
                                ) ?>

                                <?php if (
                                    !empty(
                                        $certificate['start_time']
                                    )
                                ): ?>

                                    ·

                                    <?= h(
                                        date(
                                            'h:i A',
                                            strtotime(
                                                (string)
                                                $certificate[
                                                    'start_time'
                                                ]
                                            )
                                        )
                                    ) ?>

                                <?php endif; ?>

                            </div>

                        <?php endif; ?>

                    </div>


                    <div class="certificate-card-body">

                        <div class="status-row">

                            <span class="attendance-status">
                                Attendance Verified
                            </span>


                            <?php if ($isPaid): ?>

                                <span
                                    class="payment-badge paid"
                                >
                                    Paid
                                </span>

                            <?php elseif (
                                $paymentStatus === 'failed'
                            ): ?>

                                <span
                                    class="payment-badge failed"
                                >
                                    Failed
                                </span>

                            <?php else: ?>

                                <span
                                    class="payment-badge pending"
                                >
                                    Payment Pending
                                </span>

                            <?php endif; ?>

                        </div>


                        <div class="certificate-meta">

                            <div class="meta-item">

                                <span>
                                    Certificate No.
                                </span>

                                <strong>
                                    <?= h(
                                        $certificate[
                                            'certificate_number'
                                        ]
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Type
                                </span>

                                <strong>
                                    <?= h(
                                        ucfirst(
                                            (string)
                                            $certificate[
                                                'certificate_type'
                                            ]
                                        )
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Registration
                                </span>

                                <strong>
                                    <?= h(
                                        $certificate[
                                            'registration_code'
                                        ]
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Certificate Fee
                                </span>

                                <strong>
                                    PKR
                                    <?= number_format(
                                        $fee,
                                        2
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Attendance
                                </span>

                                <strong>
                                    Present
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Issued
                                </span>

                                <strong>

                                    <?php if ($issuedDate): ?>

                                        <?= h(
                                            date(
                                                'd M Y',
                                                $issuedDate
                                            )
                                        ) ?>

                                    <?php else: ?>

                                        Pending

                                    <?php endif; ?>

                                </strong>

                            </div>

                        </div>


                        <?php if (!$isPaid): ?>

                            <a
                                href="certificate.php?certificate_id=<?= (int)$certificate['certificate_id'] ?>"
                                class="certificate-action action-payment"
                            >

                                Pay Certificate Fee

                                <span>
                                    →
                                </span>

                            </a>

                        <?php elseif (
                            $safeCertificateUrl !== ''
                        ): ?>

                            <a
                                href="<?= h(
                                    $safeCertificateUrl
                                ) ?>"
                                class="certificate-action action-download"
                                target="_blank"
                                rel="noopener noreferrer"
                            >

                                View Certificate

                                <span>
                                    ↗
                                </span>

                            </a>

                        <?php else: ?>

                            <div
                                class="certificate-action"
                                style="
                                    background:#f8fafc;
                                    color:#64748b;
                                "
                            >

                                Certificate is being prepared.

                            </div>

                        <?php endif; ?>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>


<!-- =========================================================
     PAYMENT MODAL
========================================================= -->

<?php if ($selectedCertificate): ?>

    <?php

    $selectedStatus = strtolower(
        trim(
            (string)(
                $selectedCertificate[
                    'payment_status'
                ] ?? 'unpaid'
            )
        )
    );

    $selectedPaid =
        $selectedStatus === 'paid' ||
        $selectedStatus === 'approved';

    $selectedFee = (float)(
        $selectedCertificate[
            'certificate_fee'
        ] ?? 0
    );

    if ($selectedFee <= 0) {
        $selectedFee = 500.00;
    }

    ?>

    <?php if (!$selectedPaid): ?>

        <div class="payment-overlay">

            <div class="payment-modal">

                <div class="payment-modal-header">

                    <div class="payment-modal-header-top">

                        <h2>
                            Certificate Payment
                        </h2>

                        <a
                            href="certificate.php"
                            class="payment-close"
                        >
                            ×
                        </a>

                    </div>

                    <p>
                        Complete your certificate payment using
                        a debit or credit card.
                    </p>

                </div>


                <form
                    method="POST"
                    class="payment-form"
                    autocomplete="off"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= h($csrfToken) ?>"
                    >

                    <input
                        type="hidden"
                        name="action"
                        value="pay"
                    >

                    <input
                        type="hidden"
                        name="certificate_id"
                        value="<?= (int)$selectedCertificate['certificate_id'] ?>"
                    >


                    <div class="payment-amount">

                        <div>

                            <span>
                                Certificate
                            </span>

                            <strong
                                style="
                                    display:block;
                                    font-size:.9rem;
                                    margin-top:4px;
                                "
                            >
                                <?= h(
                                    $selectedCertificate[
                                        'event_title'
                                    ]
                                ) ?>
                            </strong>

                        </div>

                        <strong>
                            PKR
                            <?= number_format(
                                $selectedFee,
                                2
                            ) ?>
                        </strong>

                    </div>


                    <div class="form-group">

                        <label>
                            Payment Method
                        </label>

                        <select
                            name="payment_method"
                            required
                        >

                            <option value="card">
                                Debit / Credit Card
                            </option>

                        </select>

                    </div>


                    <div class="form-group">

                        <label>
                            Card Holder Name
                        </label>

                        <input
                            type="text"
                            name="card_name"
                            placeholder="Name as shown on card"
                            maxlength="100"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            Card Number
                        </label>

                        <input
                            type="text"
                            name="card_number"
                            class="card-input"
                            placeholder="1234 5678 9012 3456"
                            inputmode="numeric"
                            maxlength="19"
                            required
                        >

                    </div>


                    <div class="form-row">

                        <div class="form-group">

                            <label>
                                Expiry
                            </label>

                            <input
                                type="text"
                                name="expiry"
                                placeholder="MM/YY"
                                maxlength="5"
                                inputmode="numeric"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label>
                                CVV
                            </label>

                            <input
                                type="password"
                                name="cvv"
                                placeholder="•••"
                                maxlength="4"
                                inputmode="numeric"
                                required
                            >

                        </div>

                    </div>


                    <div class="payment-security">

                        <div>
                            🔒
                        </div>

                        <div>
                            Card information is used only for the
                            payment request and is not stored in the
                            EventSphere database.
                        </div>

                    </div>


                    <button
                        type="submit"
                        class="pay-button"
                    >
                        Pay PKR
                        <?= number_format(
                            $selectedFee,
                            2
                        ) ?>
                    </button>


                    <div class="demo-note">
                        Demo payment mode: connect a real payment
                        gateway before accepting live card payments.
                    </div>

                </form>

            </div>

        </div>

    <?php endif; ?>

<?php endif; ?>


<?php require_once __DIR__ . '/footer.php'; ?>
```
