<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_auth();

/*
|--------------------------------------------------------------------------
| Helper Functions
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| Check whether an optional table exists
|--------------------------------------------------------------------------
| This prevents fatal errors when an optional module/table has not
| been created yet.
*/

function table_exists(mysqli $conn, string $table): bool
{
    $safeTable = mysqli_real_escape_string($conn, $table);

    $result = mysqli_query(
        $conn,
        "SHOW TABLES LIKE '{$safeTable}'"
    );

    if (!$result) {
        return false;
    }

    $exists = mysqli_num_rows($result) > 0;

    mysqli_free_result($result);

    return $exists;
}

/*
|--------------------------------------------------------------------------
| Organizer Session
|--------------------------------------------------------------------------
*/

$sessionUser = $_SESSION['user'] ?? [];

$userId = (int)($sessionUser['user_id'] ?? 0);

if ($userId < 1) {
    session_unset();
    session_destroy();

    header('Location: organizer-login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Verify Organizer Account
|--------------------------------------------------------------------------
*/

$authSql = "
    SELECT
        u.user_id,
        u.email,
        u.role,
        u.account_status,
        COALESCE(up.full_name, u.email) AS full_name
    FROM users u

    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id

    WHERE u.user_id = ?

    LIMIT 1
";

$authStmt = mysqli_prepare($conn, $authSql);

if (!$authStmt) {
    die('Unable to verify organizer account.');
}

mysqli_stmt_bind_param(
    $authStmt,
    'i',
    $userId
);

mysqli_stmt_execute($authStmt);

mysqli_stmt_bind_result(
    $authStmt,
    $dbUserId,
    $dbEmail,
    $dbRole,
    $dbStatus,
    $dbName
);

$accountFound = mysqli_stmt_fetch($authStmt);

mysqli_stmt_close($authStmt);

/*
|--------------------------------------------------------------------------
| Security Check
|--------------------------------------------------------------------------
*/

if (
    !$accountFound ||
    strtolower(trim((string)$dbRole)) !== 'organizer' ||
    strtolower(trim((string)$dbStatus)) !== 'active'
) {
    session_unset();
    session_destroy();

    header('Location: organizer-login.php');
    exit;
}

$user = [
    'user_id' => $dbUserId,
    'name' => $dbName,
    'email' => $dbEmail,
    'role' => $dbRole,
    'account_status' => $dbStatus
];

/*
|--------------------------------------------------------------------------
| Dashboard Variables
|--------------------------------------------------------------------------
*/

$totalEvents = 0;
$pendingEvents = 0;
$publishedEvents = 0;
$upcomingEvents = 0;
$ongoingEvents = 0;
$completedEvents = 0;
$cancelledEvents = 0;

$totalRegistrations = 0;

$averageRating = 0;

$events = [];
$recentRegistrations = [];

/*
|--------------------------------------------------------------------------
| EVENT STATISTICS
|--------------------------------------------------------------------------
*/

$eventStatsSql = "
    SELECT

        COUNT(*) AS total_events,

        COALESCE(
            SUM(event_status = 'pending_approval'),
            0
        ) AS pending_events,

        COALESCE(
            SUM(event_status = 'published'),
            0
        ) AS published_events,

        COALESCE(
            SUM(event_status = 'cancelled'),
            0
        ) AS cancelled_events,

        COALESCE(
            SUM(
                event_status = 'published'
                AND event_date > CURDATE()
            ),
            0
        ) AS upcoming_events,

        COALESCE(
            SUM(
                event_status = 'published'
                AND event_date = CURDATE()
            ),
            0
        ) AS ongoing_events,

        COALESCE(
            SUM(
                event_status = 'completed'
                OR (
                    event_status = 'published'
                    AND event_date < CURDATE()
                )
            ),
            0
        ) AS completed_events

    FROM events

    WHERE organizer_id = ?
";

$eventStatsStmt = mysqli_prepare(
    $conn,
    $eventStatsSql
);

if ($eventStatsStmt) {

    mysqli_stmt_bind_param(
        $eventStatsStmt,
        'i',
        $userId
    );

    mysqli_stmt_execute(
        $eventStatsStmt
    );

    mysqli_stmt_bind_result(
        $eventStatsStmt,

        $totalEvents,
        $pendingEvents,
        $publishedEvents,
        $cancelledEvents,
        $upcomingEvents,
        $ongoingEvents,
        $completedEvents
    );

    mysqli_stmt_fetch(
        $eventStatsStmt
    );

    mysqli_stmt_close(
        $eventStatsStmt
    );
}

$totalEvents = (int)$totalEvents;
$pendingEvents = (int)$pendingEvents;
$publishedEvents = (int)$publishedEvents;
$cancelledEvents = (int)$cancelledEvents;
$upcomingEvents = (int)$upcomingEvents;
$ongoingEvents = (int)$ongoingEvents;
$completedEvents = (int)$completedEvents;

/*
|--------------------------------------------------------------------------
| TOTAL REGISTRATIONS
|--------------------------------------------------------------------------
| Uses only confirmed columns from event_registrations.
*/

if (table_exists($conn, 'event_registrations')) {

    $registrationSql = "
        SELECT
            COUNT(er.registration_id)

        FROM event_registrations er

        INNER JOIN events e
            ON e.event_id = er.event_id

        WHERE e.organizer_id = ?
    ";

    $registrationStmt = mysqli_prepare(
        $conn,
        $registrationSql
    );

    if ($registrationStmt) {

        mysqli_stmt_bind_param(
            $registrationStmt,
            'i',
            $userId
        );

        mysqli_stmt_execute(
            $registrationStmt
        );

        mysqli_stmt_bind_result(
            $registrationStmt,
            $totalRegistrations
        );

        mysqli_stmt_fetch(
            $registrationStmt
        );

        mysqli_stmt_close(
            $registrationStmt
        );
    }
}

$totalRegistrations = (int)$totalRegistrations;

/*
|--------------------------------------------------------------------------
| OPTIONAL FEEDBACK RATING
|--------------------------------------------------------------------------
| If event_feedback does not exist, dashboard simply shows 0.0.
|--------------------------------------------------------------------------
*/

if (table_exists($conn, 'event_feedback')) {

    $feedbackSql = "
        SELECT
            COALESCE(AVG(ef.rating), 0)

        FROM event_feedback ef

        INNER JOIN events e
            ON e.event_id = ef.event_id

        WHERE e.organizer_id = ?
    ";

    $feedbackStmt = mysqli_prepare(
        $conn,
        $feedbackSql
    );

    if ($feedbackStmt) {

        mysqli_stmt_bind_param(
            $feedbackStmt,
            'i',
            $userId
        );

        mysqli_stmt_execute(
            $feedbackStmt
        );

        mysqli_stmt_bind_result(
            $feedbackStmt,
            $averageRating
        );

        mysqli_stmt_fetch(
            $feedbackStmt
        );

        mysqli_stmt_close(
            $feedbackStmt
        );
    }
}

$averageRating = round(
    (float)$averageRating,
    1
);

/*
|--------------------------------------------------------------------------
| ORGANIZER EVENTS
|--------------------------------------------------------------------------
*/

$eventsSql = "
    SELECT

        e.event_id,
        e.title,
        e.event_date,
        e.start_time,
        e.end_time,
        e.event_status,
        e.featured_image,
        e.max_capacity,

        c.category_name,

        v.venue_name,

        (
            SELECT COUNT(*)

            FROM event_registrations er2

            WHERE er2.event_id = e.event_id

        ) AS registration_count

    FROM events e

    LEFT JOIN event_categories c
        ON c.category_id = e.category_id

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    WHERE e.organizer_id = ?

    ORDER BY

        CASE

            WHEN e.event_status = 'pending_approval'
                THEN 0

            WHEN e.event_status = 'published'
                 AND e.event_date >= CURDATE()
                THEN 1

            WHEN e.event_status = 'published'
                THEN 2

            WHEN e.event_status = 'completed'
                THEN 3

            WHEN e.event_status = 'cancelled'
                THEN 4

            ELSE 5

        END,

        e.event_date ASC,
        e.start_time ASC

    LIMIT 6
";

$eventsStmt = mysqli_prepare(
    $conn,
    $eventsSql
);

if ($eventsStmt) {

    mysqli_stmt_bind_param(
        $eventsStmt,
        'i',
        $userId
    );

    mysqli_stmt_execute(
        $eventsStmt
    );

    $eventsResult = mysqli_stmt_get_result(
        $eventsStmt
    );

    if ($eventsResult) {

        while (
            $row = mysqli_fetch_assoc(
                $eventsResult
            )
        ) {
            $events[] = $row;
        }

        mysqli_free_result(
            $eventsResult
        );
    }

    mysqli_stmt_close(
        $eventsStmt
    );
}

/*
|--------------------------------------------------------------------------
| RECENT REGISTRATIONS
|--------------------------------------------------------------------------
*/

if (table_exists($conn, 'event_registrations')) {

    $registrationListSql = "
        SELECT

            er.registration_id,
            er.created_at,

            e.title,

            COALESCE(
                up.full_name,
                u.email
            ) AS participant_name,

            u.email AS participant_email

        FROM event_registrations er

        INNER JOIN events e
            ON e.event_id = er.event_id

        INNER JOIN users u
            ON u.user_id = er.user_id

        LEFT JOIN user_profiles up
            ON up.user_id = u.user_id

        WHERE e.organizer_id = ?

        ORDER BY er.created_at DESC

        LIMIT 8
    ";

    $registrationListStmt = mysqli_prepare(
        $conn,
        $registrationListSql
    );

    if ($registrationListStmt) {

        mysqli_stmt_bind_param(
            $registrationListStmt,
            'i',
            $userId
        );

        mysqli_stmt_execute(
            $registrationListStmt
        );

        $registrationResult = mysqli_stmt_get_result(
            $registrationListStmt
        );

        if ($registrationResult) {

            while (
                $row = mysqli_fetch_assoc(
                    $registrationResult
                )
            ) {
                $recentRegistrations[] = $row;
            }

            mysqli_free_result(
                $registrationResult
            );
        }

        mysqli_stmt_close(
            $registrationListStmt
        );
    }
}

/*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

$pageTitle = 'Organizer Dashboard | EventSphere';

require 'header.php';

?>

<style>

/* =========================================================
   EVENTSPHERE ORGANIZER DASHBOARD
   ========================================================= */

.organizer-dashboard {
    padding: 38px 0 75px;
}

/* =========================================================
   HERO
   ========================================================= */

.dashboard-hero {
    position: relative;
    overflow: hidden;

    padding: 38px;

    border-radius: 26px;

    color: #fff;

    background:
        radial-gradient(
            circle at 90% 5%,
            rgba(129,140,248,.30),
            transparent 28%
        ),
        radial-gradient(
            circle at 15% 100%,
            rgba(79,70,229,.22),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #1e1b4b
        );

    box-shadow:
        0 24px 60px rgba(15,23,42,.15);
}

.dashboard-eyebrow {
    color: #a5b4fc;

    font-size: 10px;
    font-weight: 850;

    letter-spacing: 1.6px;

    text-transform: uppercase;
}

.dashboard-hero h1 {
    margin: 8px 0;

    font-size: 35px;
    font-weight: 850;

    letter-spacing: -.8px;
}

.dashboard-hero p {
    max-width: 680px;

    margin: 0;

    color: #cbd5e1;

    font-size: 13px;

    line-height: 1.75;
}

.dashboard-user {
    margin-top: 19px;

    color: #94a3b8;

    font-size: 11px;
}

/* =========================================================
   STATS
   ========================================================= */

.stats-grid {
    margin-top: 24px;
}

.dashboard-stat {
    height: 100%;

    padding: 21px;

    border: 1px solid #e8edf3;

    border-radius: 18px;

    background: #fff;

    box-shadow:
        0 8px 26px rgba(15,23,42,.045);

    transition:
        transform .25s ease,
        box-shadow .25s ease,
        border-color .25s ease;
}

.dashboard-stat:hover {
    transform: translateY(-5px);

    border-color: #d9defe;

    box-shadow:
        0 18px 38px rgba(15,23,42,.09);
}

.dashboard-stat-label {
    color: #94a3b8;

    font-size: 9px;
    font-weight: 850;

    letter-spacing: .75px;

    text-transform: uppercase;
}

.dashboard-stat-number {
    margin-top: 7px;

    color: #0f172a;

    font-size: 29px;
    font-weight: 850;

    letter-spacing: -.5px;
}

.dashboard-stat-text {
    margin-top: 5px;

    color: #64748b;

    font-size: 10px;
}

/* =========================================================
   SECTION
   ========================================================= */

.dashboard-section {
    margin-top: 26px;

    padding: 25px;

    border: 1px solid #e8edf3;

    border-radius: 21px;

    background: #fff;

    box-shadow:
        0 9px 30px rgba(15,23,42,.04);
}

.section-heading {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    margin-bottom: 20px;
}

.section-heading h2 {
    margin: 0;

    color: #0f172a;

    font-size: 19px;
    font-weight: 850;
}

.section-heading p {
    margin: 4px 0 0;

    color: #94a3b8;

    font-size: 11px;
}

.section-link {
    color: #4f46e5;

    font-size: 11px;
    font-weight: 850;

    text-decoration: none;

    transition: .2s ease;
}

.section-link:hover {
    color: #3730a3;
}

/* =========================================================
   EVENT CARDS
   ========================================================= */

.event-mini-card {
    height: 100%;

    overflow: hidden;

    border: 1px solid #e8edf3;

    border-radius: 17px;

    background: #fff;

    transition:
        transform .25s ease,
        box-shadow .25s ease;
}

.event-mini-card:hover {
    transform: translateY(-5px);

    box-shadow:
        0 17px 35px rgba(15,23,42,.09);
}

.event-mini-image {
    width: 100%;
    height: 145px;

    display: block;

    object-fit: cover;

    background:
        linear-gradient(
            135deg,
            #eef2ff,
            #f8fafc
        );
}

.event-mini-content {
    padding: 17px;
}

.event-mini-category {
    display: inline-flex;

    padding: 5px 9px;

    border-radius: 999px;

    color: #4f46e5;

    background: #eef2ff;

    font-size: 8px;
    font-weight: 850;

    text-transform: uppercase;
}

.event-mini-title {
    margin: 10px 0 8px;

    color: #172033;

    font-size: 14px;
    font-weight: 850;

    line-height: 1.45;
}

.event-mini-meta {
    color: #64748b;

    font-size: 10px;

    line-height: 1.9;
}

.event-mini-footer {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 10px;

    margin-top: 14px;

    padding-top: 12px;

    border-top: 1px solid #eef1f5;
}

/* =========================================================
   STATUS
   ========================================================= */

.status {
    display: inline-flex;

    padding: 5px 9px;

    border-radius: 999px;

    font-size: 8px;
    font-weight: 850;

    text-transform: uppercase;
}

.status-pending {
    color: #92400e;
    background: #fffbeb;
}

.status-published {
    color: #047857;
    background: #ecfdf5;
}

.status-cancelled {
    color: #b91c1c;
    background: #fef2f2;
}

.status-completed {
    color: #475569;
    background: #f1f5f9;
}

.event-view {
    color: #4f46e5;

    font-size: 10px;
    font-weight: 850;

    text-decoration: none;
}

/* =========================================================
   REGISTRATION TABLE
   ========================================================= */

.registration-table {
    width: 100%;

    border-collapse: collapse;
}

.registration-table th {
    padding: 12px;

    color: #94a3b8;

    background: #f8fafc;

    font-size: 9px;
    font-weight: 850;

    text-align: left;

    text-transform: uppercase;

    letter-spacing: .5px;
}

.registration-table td {
    padding: 14px 12px;

    border-bottom: 1px solid #eef1f5;

    color: #475569;

    font-size: 11px;

    vertical-align: middle;
}

.registration-table strong {
    color: #172033;

    font-weight: 800;
}

/* =========================================================
   QUICK ACTIONS
   ========================================================= */

.quick-actions {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 10px;
}

.quick-action {
    display: flex;

    align-items: center;

    min-height: 56px;

    padding: 13px 14px;

    border: 1px solid #e8edf3;

    border-radius: 13px;

    color: #334155;

    background: #fafbfc;

    font-size: 11px;
    font-weight: 800;

    text-decoration: none;

    transition: .2s ease;
}

.quick-action:hover {
    color: #4f46e5;

    border-color: #c7d2fe;

    background: #eef2ff;

    transform: translateY(-2px);
}

/* =========================================================
   EMPTY STATE
   ========================================================= */

.empty-dashboard {
    padding: 38px 20px;

    border: 1px dashed #dbe2ea;

    border-radius: 15px;

    color: #94a3b8;

    background: #fafbfc;

    text-align: center;

    font-size: 11px;
}

/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 767px) {

    .organizer-dashboard {
        padding: 25px 0 50px;
    }

    .dashboard-hero {
        padding: 27px 21px;

        border-radius: 21px;
    }

    .dashboard-hero h1 {
        font-size: 27px;
    }

    .dashboard-section {
        padding: 19px;
    }

    .section-heading {
        align-items: flex-start;

        flex-direction: column;
    }

    .registration-table {
        min-width: 580px;
    }

    .table-scroll {
        overflow-x: auto;
    }

    .quick-actions {
        grid-template-columns: 1fr;
    }
}

</style>


<div class="container organizer-dashboard">


    <!-- =====================================================
         HERO
         ===================================================== -->

    <section class="dashboard-hero">

        <div class="dashboard-eyebrow">
            EventSphere Organizer Portal
        </div>

        <h1>
            Welcome, <?= h($user['name'] ?: 'Organizer') ?>
        </h1>

        <p>
            Manage your events, registrations and participant activity
            from one organized workspace.
        </p>

        <div class="dashboard-user">
            <?= h($user['email']) ?>
            ·
            Organizer Account
        </div>

    </section>


    <!-- =====================================================
         STATISTICS
         ===================================================== -->

    <div class="row g-3 stats-grid">


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Total Events
                </div>

                <div class="dashboard-stat-number">
                    <?= $totalEvents ?>
                </div>

                <div class="dashboard-stat-text">
                    Events created by you
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Pending Approval
                </div>

                <div class="dashboard-stat-number">
                    <?= $pendingEvents ?>
                </div>

                <div class="dashboard-stat-text">
                    Waiting for review
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Published
                </div>

                <div class="dashboard-stat-number">
                    <?= $publishedEvents ?>
                </div>

                <div class="dashboard-stat-text">
                    Published events
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Upcoming
                </div>

                <div class="dashboard-stat-number">
                    <?= $upcomingEvents ?>
                </div>

                <div class="dashboard-stat-text">
                    Future events
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Registrations
                </div>

                <div class="dashboard-stat-number">
                    <?= $totalRegistrations ?>
                </div>

                <div class="dashboard-stat-text">
                    Across your events
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Rating
                </div>

                <div class="dashboard-stat-number">
                    <?= number_format($averageRating, 1) ?>/5
                </div>

                <div class="dashboard-stat-text">
                    Participant feedback
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Completed
                </div>

                <div class="dashboard-stat-number">
                    <?= $completedEvents ?>
                </div>

                <div class="dashboard-stat-text">
                    Finished events
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="dashboard-stat">

                <div class="dashboard-stat-label">
                    Cancelled
                </div>

                <div class="dashboard-stat-number">
                    <?= $cancelledEvents ?>
                </div>

                <div class="dashboard-stat-text">
                    Cancelled events
                </div>

            </div>

        </div>


    </div>


    <!-- =====================================================
         EVENTS
         ===================================================== -->

    <section class="dashboard-section">


        <div class="section-heading">

            <div>

                <h2>
                    Your Events
                </h2>

                <p>
                    Latest events, upcoming schedules and approval status.
                </p>

            </div>

            <a
                href="organizer-events.php"
                class="section-link"
            >
                Manage Events →
            </a>

        </div>


        <?php if (!empty($events)): ?>


            <div class="row g-3">


                <?php foreach ($events as $event): ?>


                    <?php

                    $status = strtolower(
                        trim(
                            (string)$event['event_status']
                        )
                    );

                    $statusClass = 'status-completed';

                    if (
                        $status === 'pending_approval'
                    ) {

                        $statusClass = 'status-pending';

                    } elseif (
                        $status === 'published'
                    ) {

                        $statusClass = 'status-published';

                    } elseif (
                        $status === 'cancelled'
                    ) {

                        $statusClass = 'status-cancelled';

                    }

                    ?>


                    <div class="col-md-6 col-xl-4">


                        <article class="event-mini-card">


                            <?php if (!empty($event['featured_image'])): ?>

                                <img
                                    src="<?= h($event['featured_image']) ?>"
                                    alt="<?= h($event['title']) ?>"
                                    class="event-mini-image"
                                >

                            <?php else: ?>

                                <div class="event-mini-image"></div>

                            <?php endif; ?>


                            <div class="event-mini-content">


                                <span class="event-mini-category">

                                    <?= h(
                                        $event['category_name']
                                        ?: 'Event'
                                    ) ?>

                                </span>


                                <div class="event-mini-title">

                                    <?= h(
                                        $event['title']
                                    ) ?>

                                </div>


                                <div class="event-mini-meta">


                                    <?php if (!empty($event['event_date'])): ?>

                                        <?= h(
                                            date(
                                                'd M Y',
                                                strtotime(
                                                    $event['event_date']
                                                )
                                            )
                                        ) ?>

                                    <?php endif; ?>


                                    <?php if (!empty($event['start_time'])): ?>

                                        ·

                                        <?= h(
                                            date(
                                                'h:i A',
                                                strtotime(
                                                    $event['start_time']
                                                )
                                            )
                                        ) ?>

                                    <?php endif; ?>


                                    <br>


                                    <?= h(
                                        $event['venue_name']
                                        ?: 'Venue not assigned'
                                    ) ?>


                                    <br>


                                    <?= (int)$event['registration_count'] ?>

                                    registrations

                                    <?php if (
                                        $event['max_capacity'] !== null
                                        && $event['max_capacity'] !== ''
                                    ): ?>

                                        /

                                        <?= (int)$event['max_capacity'] ?>

                                        seats

                                    <?php endif; ?>


                                </div>


                                <div class="event-mini-footer">


                                    <span
                                        class="status <?= h($statusClass) ?>"
                                    >

                                        <?= h(
                                            str_replace(
                                                '_',
                                                ' ',
                                                $status
                                            )
                                        ) ?>

                                    </span>


                                    <a
                                        href="event_details.php?id=<?= (int)$event['event_id'] ?>"
                                        class="event-view"
                                    >
                                        View Event
                                    </a>


                                </div>


                            </div>


                        </article>


                    </div>


                <?php endforeach; ?>


            </div>


        <?php else: ?>


            <div class="empty-dashboard">

                You have not created any events yet.

            </div>


        <?php endif; ?>


    </section>


    <!-- =====================================================
         LOWER DASHBOARD
         ===================================================== -->

    <div class="row g-3">


        <!-- =================================================
             RECENT REGISTRATIONS
             ================================================= -->

        <div class="col-lg-8">


            <section class="dashboard-section">


                <div class="section-heading">


                    <div>

                        <h2>
                            Recent Registrations
                        </h2>

                        <p>
                            Latest participants across your events.
                        </p>

                    </div>


                    <a
                        href="organizer-registrations.php"
                        class="section-link"
                    >
                        View All →
                    </a>


                </div>


                <?php if (!empty($recentRegistrations)): ?>


                    <div class="table-scroll">


                        <table class="registration-table">


                            <thead>

                                <tr>

                                    <th>
                                        Participant
                                    </th>

                                    <th>
                                        Event
                                    </th>

                                    <th>
                                        Registered
                                    </th>

                                </tr>

                            </thead>


                            <tbody>


                                <?php foreach (
                                    $recentRegistrations
                                    as $registration
                                ): ?>


                                    <tr>


                                        <td>

                                            <strong>

                                                <?= h(
                                                    $registration[
                                                        'participant_name'
                                                    ]
                                                ) ?>

                                            </strong>

                                            <br>

                                            <?= h(
                                                $registration[
                                                    'participant_email'
                                                ]
                                            ) ?>

                                        </td>


                                        <td>

                                            <?= h(
                                                $registration['title']
                                            ) ?>

                                        </td>


                                        <td>

                                            <?php if (
                                                !empty(
                                                    $registration[
                                                        'created_at'
                                                    ]
                                                )
                                            ): ?>

                                                <?= h(
                                                    date(
                                                        'd M Y',
                                                        strtotime(
                                                            $registration[
                                                                'created_at'
                                                            ]
                                                        )
                                                    )
                                                ) ?>

                                            <?php else: ?>

                                                —

                                            <?php endif; ?>

                                        </td>


                                    </tr>


                                <?php endforeach; ?>


                            </tbody>


                        </table>


                    </div>


                <?php else: ?>


                    <div class="empty-dashboard">

                        No registrations have been received yet.

                    </div>


                <?php endif; ?>


            </section>


        </div>


        <!-- =================================================
             QUICK ACTIONS
             ================================================= -->

        <div class="col-lg-4">


            <section class="dashboard-section">


                <div class="section-heading">


                    <div>

                        <h2>
                            Quick Actions
                        </h2>

                        <p>
                            Organizer tools
                        </p>

                    </div>


                </div>


                <div class="quick-actions">


                    <a
                        href="organizer-events.php"
                        class="quick-action"
                    >
                        Manage Events
                    </a>


                    <a
                        href="organizer-registrations.php"
                        class="quick-action"
                    >
                        Registrations
                    </a>


                    <a
                        href="organizer-attendance.php"
                        class="quick-action"
                    >
                        Attendance
                    </a>


                    <a
                        href="organizer-certificates.php"
                        class="quick-action"
                    >
                        Certificates
                    </a>


                    <a
                        href="organizer-gallery.php"
                        class="quick-action"
                    >
                        Event Gallery
                    </a>


                    <a
                        href="organizer-announcements.php"
                        class="quick-action"
                    >
                        Announcements
                    </a>


                </div>


            </section>


        </div>


    </div>


</div>


<?php require 'footer.php'; ?>