<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| EventSphere - Organizer Event Management
|--------------------------------------------------------------------------
| File:
| organizer-manage-event.php
|
| Organizer can:
| - View event information
| - Edit event
| - Delete event
| - Publish / unpublish
| - Cancel event
| - Mark event completed
| - Manage registrations
| - Cancel registrations
| - Mark attendance
| - Manage waitlist
| - View feedback
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user']['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int)($_SESSION['user']['user_id'] ?? 0);
$userRole = strtolower(
    trim((string)($_SESSION['user']['role'] ?? ''))
);

if ($userRole !== 'organizer') {
    header('Location: events.php');
    exit;
}

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Event ID
|--------------------------------------------------------------------------
*/

$eventId = max(
    0,
    (int)($_GET['id'] ?? $_POST['event_id'] ?? 0)
);

if ($eventId <= 0) {
    header('Location: organizer-dashboard.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function redirectToEvent(int $eventId, string $message = ''): never
{
    $url = 'organizer-manage-event.php?id=' . $eventId;

    if ($message !== '') {
        $url .= '&message=' . urlencode($message);
    }

    header('Location: ' . $url);
    exit;
}

function getEvent(
    mysqli $conn,
    int $eventId,
    int $organizerId
): ?array {

    $sql = "
        SELECT
            e.*,

            c.category_name,

            d.department_name,

            v.venue_name,

            u.email AS organizer_email

        FROM events e

        LEFT JOIN event_categories c
            ON c.category_id = e.category_id

        LEFT JOIN departments d
            ON d.department_id = e.department_id

        LEFT JOIN venues v
            ON v.venue_id = e.venue_id

        LEFT JOIN users u
            ON u.user_id = e.organizer_id

        WHERE e.event_id = ?
          AND e.organizer_id = ?

        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return null;
    }

    mysqli_stmt_bind_param(
        $stmt,
        'ii',
        $eventId,
        $organizerId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    $event = $result
        ? mysqli_fetch_assoc($result)
        : null;

    mysqli_stmt_close($stmt);

    return $event ?: null;
}

function countRows(
    mysqli $conn,
    string $sql,
    int $eventId
): int {

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return 0;
    }

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $eventId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        mysqli_stmt_close($stmt);
        return 0;
    }

    $row = mysqli_fetch_row($result);

    mysqli_stmt_close($stmt);

    return $row ? (int)$row[0] : 0;
}

/*
|--------------------------------------------------------------------------
| Verify ownership
|--------------------------------------------------------------------------
*/

$event = getEvent(
    $conn,
    $eventId,
    $userId
);

if (!$event) {
    http_response_code(403);
    exit('You are not authorized to manage this event.');
}

/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

$action = trim(
    (string)($_POST['action'] ?? '')
);

/*
|--------------------------------------------------------------------------
| DELETE EVENT
|--------------------------------------------------------------------------
*/

if ($action === 'delete_event') {

    /*
    | Delete dependent records first.
    */

    mysqli_begin_transaction($conn);

    try {

        $tables = [
            'attendance',
            'event_feedback',
            'event_waitlist',
            'event_registrations',
            'event_share_logs',
            'event_organizers'
        ];

        foreach ($tables as $table) {

            $sql = "
                DELETE FROM {$table}
                WHERE event_id = ?
            ";

            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {

                mysqli_stmt_bind_param(
                    $stmt,
                    'i',
                    $eventId
                );

                mysqli_stmt_execute($stmt);

                mysqli_stmt_close($stmt);
            }
        }

        $stmt = mysqli_prepare(
            $conn,
            "
                DELETE FROM events
                WHERE event_id = ?
                  AND organizer_id = ?
                LIMIT 1
            "
        );

        if (!$stmt) {
            throw new Exception(
                'Unable to delete event.'
            );
        }

        mysqli_stmt_bind_param(
            $stmt,
            'ii',
            $eventId,
            $userId
        );

        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) <= 0) {
            throw new Exception(
                'Event could not be deleted.'
            );
        }

        mysqli_stmt_close($stmt);

        mysqli_commit($conn);

        header(
            'Location: organizer-dashboard.php?deleted=1'
        );

        exit;

    } catch (Throwable $e) {

        mysqli_rollback($conn);

        redirectToEvent(
            $eventId,
            'Unable to delete event.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| CHANGE EVENT STATUS
|--------------------------------------------------------------------------
*/

if ($action === 'change_status') {

    $newStatus = strtolower(
        trim((string)($_POST['status'] ?? ''))
    );

    $allowedStatuses = [
        'draft',
        'pending_approval',
        'approved',
        'published',
        'cancelled',
        'completed'
    ];

    if (!in_array(
        $newStatus,
        $allowedStatuses,
        true
    )) {

        redirectToEvent(
            $eventId,
            'Invalid event status.'
        );
    }

    $stmt = mysqli_prepare(
        $conn,
        "
            UPDATE events
            SET event_status = ?
            WHERE event_id = ?
              AND organizer_id = ?
        "
    );

    if ($stmt) {

        mysqli_stmt_bind_param(
            $stmt,
            'sii',
            $newStatus,
            $eventId,
            $userId
        );

        mysqli_stmt_execute($stmt);

        mysqli_stmt_close($stmt);
    }

    redirectToEvent(
        $eventId,
        'Event status updated.'
    );
}

/*
|--------------------------------------------------------------------------
| CANCEL EVENT
|--------------------------------------------------------------------------
*/

if ($action === 'cancel_event') {

    $reason = trim(
        (string)($_POST['cancellation_reason'] ?? '')
    );

    $stmt = mysqli_prepare(
        $conn,
        "
            UPDATE events
            SET
                event_status = 'cancelled',
                cancelled_at = NOW(),
                cancellation_reason = ?
            WHERE event_id = ?
              AND organizer_id = ?
        "
    );

    if ($stmt) {

        mysqli_stmt_bind_param(
            $stmt,
            'sii',
            $reason,
            $eventId,
            $userId
        );

        mysqli_stmt_execute($stmt);

        mysqli_stmt_close($stmt);
    }

    redirectToEvent(
        $eventId,
        'Event cancelled.'
    );
}

/*
|--------------------------------------------------------------------------
| UPDATE EVENT
|--------------------------------------------------------------------------
*/

if ($action === 'update_event') {

    $title = trim(
        (string)($_POST['title'] ?? '')
    );

    $slug = trim(
        (string)($_POST['slug'] ?? '')
    );

    $shortDescription = trim(
        (string)($_POST['short_description'] ?? '')
    );

    $description = trim(
        (string)($_POST['description'] ?? '')
    );

    $categoryId = (int)(
        $_POST['category_id'] ?? 0
    );

    $departmentId = (int)(
        $_POST['department_id'] ?? 0
    );

    $venueId = (int)(
        $_POST['venue_id'] ?? 0
    );

    $eventDate = trim(
        (string)($_POST['event_date'] ?? '')
    );

    $startTime = trim(
        (string)($_POST['start_time'] ?? '')
    );

    $endTime = trim(
        (string)($_POST['end_time'] ?? '')
    );

    $registrationOpen = trim(
        (string)($_POST['registration_open'] ?? '')
    );

    $registrationClose = trim(
        (string)($_POST['registration_close'] ?? '')
    );

    $eventStatus = trim(
        (string)($_POST['event_status'] ?? '')
    );

    $maxCapacity = max(
        1,
        (int)($_POST['max_capacity'] ?? 1)
    );

    $waitlistEnabled = isset(
        $_POST['waitlist_enabled']
    ) ? 1 : 0;

    $errors = [];

    if ($title === '') {
        $errors[] = 'Event title is required.';
    }

    if ($description === '') {
        $errors[] = 'Event description is required.';
    }

    if ($categoryId <= 0) {
        $errors[] = 'Please select a category.';
    }

    if ($departmentId <= 0) {
        $errors[] = 'Please select a department.';
    }

    if ($venueId <= 0) {
        $errors[] = 'Please select a venue.';
    }

    if ($eventDate === '') {
        $errors[] = 'Event date is required.';
    }

    if ($startTime === '') {
        $errors[] = 'Start time is required.';
    }

    if ($endTime === '') {
        $errors[] = 'End time is required.';
    }

    if ($maxCapacity < 1) {
        $errors[] = 'Capacity must be greater than zero.';
    }

    /*
    | Prevent capacity from becoming lower than
    | already confirmed registrations.
    */

    $confirmedCount = countRows(
        $conn,
        "
            SELECT COUNT(*)
            FROM event_registrations
            WHERE event_id = ?
              AND status IN ('confirmed','attended')
        ",
        $eventId
    );

    if ($maxCapacity < $confirmedCount) {

        $errors[] =
            'Capacity cannot be lower than the current registered participants (' .
            $confirmedCount .
            ').';
    }

    /*
    | If no slug supplied, create one.
    */

    if ($slug === '') {

        $slug = strtolower(
            preg_replace(
                '/[^a-z0-9]+/',
                '-',
                $title
            ) ?? ''
        );

        $slug = trim(
            $slug,
            '-'
        );
    }

    if (empty($errors)) {

        /*
        | Check slug belongs to another event.
        */

        $slugCheck = mysqli_prepare(
            $conn,
            "
                SELECT event_id
                FROM events
                WHERE slug = ?
                  AND event_id <> ?
                LIMIT 1
            "
        );

        if ($slugCheck) {

            mysqli_stmt_bind_param(
                $slugCheck,
                'si',
                $slug,
                $eventId
            );

            mysqli_stmt_execute(
                $slugCheck
            );

            $slugResult =
                mysqli_stmt_get_result(
                    $slugCheck
                );

            if (
                $slugResult &&
                mysqli_num_rows($slugResult) > 0
            ) {
                $errors[] =
                    'This event slug is already in use.';
            }

            mysqli_stmt_close(
                $slugCheck
            );
        }
    }

    /*
    | Handle featured image URL/path.
    */

    $featuredImage = trim(
        (string)($event['featured_image'] ?? '')
    );

    if (
        isset($_POST['featured_image']) &&
        trim((string)$_POST['featured_image']) !== ''
    ) {

        $featuredImage = trim(
            (string)$_POST['featured_image']
        );
    }

    if (empty($errors)) {

        $sql = "
            UPDATE events
            SET
                title = ?,
                slug = ?,
                short_description = ?,
                description = ?,
                category_id = ?,
                department_id = ?,
                venue_id = ?,
                event_date = ?,
                start_time = ?,
                end_time = ?,
                registration_open = ?,
                registration_close = ?,
                event_status = ?,
                featured_image = ?,
                max_capacity = ?,
                waitlist_enabled = ?
            WHERE event_id = ?
              AND organizer_id = ?
        ";

        $stmt = mysqli_prepare(
            $conn,
            $sql
        );

        if (!$stmt) {

            $errors[] =
                'Unable to prepare update query: ' .
                mysqli_error($conn);

        } else {

            mysqli_stmt_bind_param(
                $stmt,
                'ssssiiisssssssi ii',
                $title,
                $slug,
                $shortDescription,
                $description,
                $categoryId,
                $departmentId,
                $venueId,
                $eventDate,
                $startTime,
                $endTime,
                $registrationOpen,
                $registrationClose,
                $eventStatus,
                $featuredImage,
                $maxCapacity,
                $waitlistEnabled,
                $eventId,
                $userId
            );

            /*
            | Fix spaces from the type string.
            */

            $stmt->bind_param(
                'ssssiiisssssssi ii',
                $title,
                $slug,
                $shortDescription,
                $description,
                $categoryId,
                $departmentId,
                $venueId,
                $eventDate,
                $startTime,
                $endTime,
                $registrationOpen,
                $registrationClose,
                $eventStatus,
                $featuredImage,
                $maxCapacity,
                $waitlistEnabled,
                $eventId,
                $userId
            );

            /*
            | The bind above is replaced below with the exact
            | 18-character type definition.
            */

            mysqli_stmt_close($stmt);

            $stmt = mysqli_prepare(
                $conn,
                $sql
            );

            if ($stmt) {

                mysqli_stmt_bind_param(
                    $stmt,
                    'ssssiiissssssssii',
                    $title,
                    $slug,
                    $shortDescription,
                    $description,
                    $categoryId,
                    $departmentId,
                    $venueId,
                    $eventDate,
                    $startTime,
                    $endTime,
                    $registrationOpen,
                    $registrationClose,
                    $eventStatus,
                    $featuredImage,
                    $maxCapacity,
                    $waitlistEnabled,
                    $eventId,
                    $userId
                );

                if (
                    !mysqli_stmt_execute($stmt)
                ) {

                    $errors[] =
                        'Unable to update event: ' .
                        mysqli_stmt_error($stmt);
                }

                mysqli_stmt_close($stmt);

            } else {

                $errors[] =
                    'Unable to prepare event update.';
            }
        }
    }

    if (empty($errors)) {

        redirectToEvent(
            $eventId,
            'Event updated successfully.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| REGISTRATION ACTION
|--------------------------------------------------------------------------
*/

if ($action === 'registration_status') {

    $registrationId = (int)(
        $_POST['registration_id'] ?? 0
    );

    $newStatus = strtolower(
        trim((string)(
            $_POST['registration_status'] ?? ''
        ))
    );

    $allowed = [
        'confirmed',
        'cancelled',
        'attended',
        'no_show'
    ];

    if (
        $registrationId > 0 &&
        in_array(
            $newStatus,
            $allowed,
            true
        )
    ) {

        /*
        | Make sure registration belongs
        | to this organizer's event.
        */

        $stmt = mysqli_prepare(
            $conn,
            "
                UPDATE event_registrations er

                INNER JOIN events e
                    ON e.event_id = er.event_id

                SET
                    er.status = ?,

                    er.cancelled_at =
                        CASE
                            WHEN ? = 'cancelled'
                            THEN NOW()
                            ELSE NULL
                        END

                WHERE er.registration_id = ?
                  AND e.event_id = ?
                  AND e.organizer_id = ?
            "
        );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                'ssiii',
                $newStatus,
                $newStatus,
                $registrationId,
                $eventId,
                $userId
            );

            mysqli_stmt_execute($stmt);

            mysqli_stmt_close($stmt);
        }

        redirectToEvent(
            $eventId,
            'Registration status updated.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| ATTENDANCE ACTION
|--------------------------------------------------------------------------
*/

if ($action === 'attendance') {

    $registrationId = (int)(
        $_POST['registration_id'] ?? 0
    );

    $attendanceStatus = strtolower(
        trim((string)(
            $_POST['attendance_status'] ?? 'absent'
        ))
    );

    $allowed = [
        'present',
        'absent',
        'late'
    ];

    if (
        $registrationId > 0 &&
        in_array(
            $attendanceStatus,
            $allowed,
            true
        )
    ) {

        /*
        | Get registration information.
        */

        $stmt = mysqli_prepare(
            $conn,
            "
                SELECT
                    er.registration_id,
                    er.event_id,
                    er.student_id

                FROM event_registrations er

                INNER JOIN events e
                    ON e.event_id = er.event_id

                WHERE er.registration_id = ?
                  AND e.event_id = ?
                  AND e.organizer_id = ?

                LIMIT 1
            "
        );

        $registration = null;

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                'iii',
                $registrationId,
                $eventId,
                $userId
            );

            mysqli_stmt_execute($stmt);

            $result =
                mysqli_stmt_get_result($stmt);

            if ($result) {
                $registration =
                    mysqli_fetch_assoc($result);
            }

            mysqli_stmt_close($stmt);
        }

        if ($registration) {

            $registrationEventId =
                (int)$registration['event_id'];

            $studentId =
                (int)$registration['student_id'];

            /*
            | Check existing attendance.
            */

            $check = mysqli_prepare(
                $conn,
                "
                    SELECT attendance_id
                    FROM attendance
                    WHERE registration_id = ?
                    LIMIT 1
                "
            );

            $attendanceId = 0;

            if ($check) {

                mysqli_stmt_bind_param(
                    $check,
                    'i',
                    $registrationId
                );

                mysqli_stmt_execute($check);

                $result =
                    mysqli_stmt_get_result($check);

                if ($result) {

                    $row =
                        mysqli_fetch_assoc($result);

                    if ($row) {
                        $attendanceId =
                            (int)$row['attendance_id'];
                    }
                }

                mysqli_stmt_close($check);
            }

            if ($attendanceId > 0) {

                $stmt = mysqli_prepare(
                    $conn,
                    "
                        UPDATE attendance
                        SET
                            attendance_status = ?,
                            check_in_time =
                                CASE
                                    WHEN ? IN ('present','late')
                                    AND check_in_time IS NULL
                                    THEN NOW()
                                    ELSE check_in_time
                                END,
                            marked_by = ?,
                            marked_at = NOW()
                        WHERE attendance_id = ?
                    "
                );

                if ($stmt) {

                    mysqli_stmt_bind_param(
                        $stmt,
                        'ssii',
                        $attendanceStatus,
                        $attendanceStatus,
                        $userId,
                        $attendanceId
                    );

                    mysqli_stmt_execute($stmt);

                    mysqli_stmt_close($stmt);
                }

            } else {

                $stmt = mysqli_prepare(
                    $conn,
                    "
                        INSERT INTO attendance
                        (
                            registration_id,
                            event_id,
                            student_id,
                            attendance_status,
                            check_in_time,
                            marked_by,
                            marked_at
                        )
                        VALUES
                        (
                            ?,
                            ?,
                            ?,
                            ?,
                            CASE
                                WHEN ? IN ('present','late')
                                THEN NOW()
                                ELSE NULL
                            END,
                            ?,
                            NOW()
                        )
                    "
                );

                if ($stmt) {

                    mysqli_stmt_bind_param(
                        $stmt,
                        'iiiss i',
                        $registrationId,
                        $registrationEventId,
                        $studentId,
                        $attendanceStatus,
                        $attendanceStatus,
                        $userId
                    );

                    /*
                    | Correct exact bind type.
                    */

                    mysqli_stmt_close($stmt);

                    $stmt = mysqli_prepare(
                        $conn,
                        "
                            INSERT INTO attendance
                            (
                                registration_id,
                                event_id,
                                student_id,
                                attendance_status,
                                check_in_time,
                                marked_by,
                                marked_at
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                ?,
                                CASE
                                    WHEN ? IN ('present','late')
                                    THEN NOW()
                                    ELSE NULL
                                END,
                                ?,
                                NOW()
                            )
                        "
                    );

                    if ($stmt) {

                        mysqli_stmt_bind_param(
                            $stmt,
                            'iiissi',
                            $registrationId,
                            $registrationEventId,
                            $studentId,
                            $attendanceStatus,
                            $attendanceStatus,
                            $userId
                        );

                        mysqli_stmt_execute($stmt);

                        mysqli_stmt_close($stmt);
                    }
                }
            }

            /*
            | Keep registration status synchronized.
            */

            $registrationStatus =
                in_array(
                    $attendanceStatus,
                    ['present','late'],
                    true
                )
                ? 'attended'
                : 'confirmed';

            $stmt = mysqli_prepare(
                $conn,
                "
                    UPDATE event_registrations
                    SET status = ?
                    WHERE registration_id = ?
                      AND event_id = ?
                "
            );

            if ($stmt) {

                mysqli_stmt_bind_param(
                    $stmt,
                    'sii',
                    $registrationStatus,
                    $registrationId,
                    $eventId
                );

                mysqli_stmt_execute($stmt);

                mysqli_stmt_close($stmt);
            }
        }

        redirectToEvent(
            $eventId,
            'Attendance updated.'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Refresh event after actions
|--------------------------------------------------------------------------
*/

$event = getEvent(
    $conn,
    $eventId,
    $userId
);

if (!$event) {
    exit('Event no longer exists.');
}

/*
|--------------------------------------------------------------------------
| Categories
|--------------------------------------------------------------------------
*/

$categories = [];

$result = mysqli_query(
    $conn,
    "
        SELECT
            category_id,
            category_name

        FROM event_categories

        ORDER BY category_name ASC
    "
);

if ($result) {

    while (
        $row = mysqli_fetch_assoc($result)
    ) {

        $categories[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| Departments
|--------------------------------------------------------------------------
*/

$departments = [];

$result = mysqli_query(
    $conn,
    "
        SELECT
            department_id,
            department_name

        FROM departments

        ORDER BY department_name ASC
    "
);

if ($result) {

    while (
        $row = mysqli_fetch_assoc($result)
    ) {

        $departments[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| Venues
|--------------------------------------------------------------------------
*/

$venues = [];

$result = mysqli_query(
    $conn,
    "
        SELECT
            venue_id,
            venue_name

        FROM venues

        ORDER BY venue_name ASC
    "
);

if ($result) {

    while (
        $row = mysqli_fetch_assoc($result)
    ) {

        $venues[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| Registration count
|--------------------------------------------------------------------------
*/

$totalRegistrations = countRows(
    $conn,
    "
        SELECT COUNT(*)
        FROM event_registrations
        WHERE event_id = ?
          AND status <> 'cancelled'
    ",
    $eventId
);

$confirmedRegistrations = countRows(
    $conn,
    "
        SELECT COUNT(*)
        FROM event_registrations
        WHERE event_id = ?
          AND status = 'confirmed'
    ",
    $eventId
);

$attendedCount = countRows(
    $conn,
    "
        SELECT COUNT(*)
        FROM event_registrations
        WHERE event_id = ?
          AND status = 'attended'
    ",
    $eventId
);

$cancelledRegistrations = countRows(
    $conn,
    "
        SELECT COUNT(*)
        FROM event_registrations
        WHERE event_id = ?
          AND status = 'cancelled'
    ",
    $eventId
);

$waitlistCount = countRows(
    $conn,
    "
        SELECT COUNT(*)
        FROM event_waitlist
        WHERE event_id = ?
          AND status = 'waiting'
    ",
    $eventId
);

/*
|--------------------------------------------------------------------------
| Feedback count
|--------------------------------------------------------------------------
*/

$feedbackCount = countRows(
    $conn,
    "
        SELECT COUNT(*)
        FROM event_feedback
        WHERE event_id = ?
          AND status = 'visible'
    ",
    $eventId
);

/*
|--------------------------------------------------------------------------
| Average rating
|--------------------------------------------------------------------------
*/

$averageRating = 0;

$stmt = mysqli_prepare(
    $conn,
    "
        SELECT
            COALESCE(
                AVG(overall_rating),
                0
            )
        FROM event_feedback

        WHERE event_id = ?

          AND status = 'visible'
    "
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $eventId
    );

    mysqli_stmt_execute($stmt);

    $result =
        mysqli_stmt_get_result($stmt);

    if ($result) {

        $row =
            mysqli_fetch_row($result);

        $averageRating =
            round(
                (float)($row[0] ?? 0),
                1
            );
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Registrations + students
|--------------------------------------------------------------------------
*/

$registrations = [];

$sql = "
    SELECT

        er.registration_id,
        er.registration_code,
        er.registered_at,
        er.status,
        er.cancelled_at,
        er.cancellation_reason,

        er.student_id,

        u.email,
        u.full_name,
        u.username,

        a.attendance_status,
        a.check_in_time,
        a.check_out_time

    FROM event_registrations er

    INNER JOIN users u
        ON u.user_id = er.student_id

    LEFT JOIN attendance a
        ON a.registration_id = er.registration_id

    WHERE er.event_id = ?

    ORDER BY
        er.registered_at DESC
";

$stmt = mysqli_prepare(
    $conn,
    $sql
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $eventId
    );

    mysqli_stmt_execute($stmt);

    $result =
        mysqli_stmt_get_result($stmt);

    if ($result) {

        while (
            $row = mysqli_fetch_assoc($result)
        ) {

            $registrations[] = $row;
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Waitlist
|--------------------------------------------------------------------------
*/

$waitlist = [];

$stmt = mysqli_prepare(
    $conn,
    "
        SELECT
            ew.*,

            u.email,
            u.full_name,
            u.username

        FROM event_waitlist ew

        INNER JOIN users u
            ON u.user_id = ew.student_id

        WHERE ew.event_id = ?

        ORDER BY
            ew.queue_position ASC
    "
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $eventId
    );

    mysqli_stmt_execute($stmt);

    $result =
        mysqli_stmt_get_result($stmt);

    if ($result) {

        while (
            $row = mysqli_fetch_assoc($result)
        ) {

            $waitlist[] = $row;
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Feedback
|--------------------------------------------------------------------------
*/

$feedback = [];

$stmt = mysqli_prepare(
    $conn,
    "
        SELECT

            ef.*,

            u.full_name,
            u.username,
            u.email

        FROM event_feedback ef

        INNER JOIN users u
            ON u.user_id = ef.student_id

        WHERE ef.event_id = ?

        ORDER BY
            ef.submitted_at DESC
    "
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $eventId
    );

    mysqli_stmt_execute($stmt);

    $result =
        mysqli_stmt_get_result($stmt);

    if ($result) {

        while (
            $row = mysqli_fetch_assoc($result)
        ) {

            $feedback[] = $row;
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Message
|--------------------------------------------------------------------------
*/

$message = trim(
    (string)($_GET['message'] ?? '')
);

$title =
    'Manage Event | EventSphere';

require_once __DIR__ . '/header.php';

?>

<style>

.manage-page {
    min-height: 100vh;
    background: #f6f7fb;
    color: #172033;
    padding: 35px 0 80px;
}

.manage-container {
    width: min(1280px, calc(100% - 40px));
    margin: auto;
}

.manage-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
    margin-bottom: 25px;
}

.manage-header h1 {
    margin: 0;
    font-size: 32px;
    font-weight: 850;
    letter-spacing: -.04em;
}

.manage-header p {
    margin: 8px 0 0;
    color: #64748b;
    font-size: 13px;
}

.header-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    padding: 0 14px;
    border-radius: 9px;
    border: 1px solid #e2e8f0;
    background: #fff;
    color: #475569;
    text-decoration: none;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
}

.btn-primary {
    border-color: #4f46e5;
    background: #4f46e5;
    color: #fff;
}

.btn-danger {
    border-color: #fecaca;
    background: #fff1f2;
    color: #dc2626;
}

.btn-success {
    border-color: #a7f3d0;
    background: #ecfdf5;
    color: #047857;
}

.btn-warning {
    border-color: #fde68a;
    background: #fffbeb;
    color: #b45309;
}

.message {
    margin-bottom: 20px;
    padding: 13px 15px;
    border-radius: 10px;
    background: #ecfdf5;
    border: 1px solid #bbf7d0;
    color: #166534;
    font-size: 12px;
    font-weight: 700;
}

.event-summary {
    display: grid;
    grid-template-columns: 1.5fr repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 25px;
}

.summary-card {
    padding: 18px;
    border: 1px solid #e5e7eb;
    border-radius: 15px;
    background: #fff;
    box-shadow: 0 6px 20px rgba(15,23,42,.04);
}

.summary-card span {
    display: block;
    color: #94a3b8;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .07em;
}

.summary-card strong {
    display: block;
    margin-top: 7px;
    color: #111827;
    font-size: 25px;
    font-weight: 850;
}

.summary-event strong {
    font-size: 18px;
}

.status-pill {
    display: inline-flex;
    margin-top: 8px;
    padding: 5px 9px;
    border-radius: 999px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 9px;
    font-weight: 850;
}

.panel {
    margin-bottom: 22px;
    border: 1px solid #e5e7eb;
    border-radius: 17px;
    background: #fff;
    box-shadow: 0 7px 25px rgba(15,23,42,.04);
    overflow: hidden;
}

.panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 18px 20px;
    border-bottom: 1px solid #edf0f4;
}

.panel-header h2 {
    margin: 0;
    font-size: 17px;
    font-weight: 850;
}

.panel-header p {
    margin: 4px 0 0;
    color: #94a3b8;
    font-size: 10px;
}

.panel-body {
    padding: 20px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0,1fr));
    gap: 16px;
}

.form-grid.three {
    grid-template-columns: repeat(3, minmax(0,1fr));
}

.field-full {
    grid-column: 1 / -1;
}

.field label {
    display: block;
    margin-bottom: 7px;
    color: #475569;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
}

.input,
.select,
.textarea {
    width: 100%;
    border: 1px solid #dfe4ec;
    border-radius: 9px;
    background: #f8fafc;
    color: #172033;
    font: inherit;
    font-size: 12px;
    outline: none;
    padding: 11px 12px;
}

.input,
.select {
    height: 43px;
}

.textarea {
    min-height: 130px;
    resize: vertical;
}

.input:focus,
.select:focus,
.textarea:focus {
    border-color: #6366f1;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(99,102,241,.08);
}

.check-row {
    display: flex;
    align-items: center;
    gap: 9px;
    min-height: 43px;
    padding: 0 12px;
    border: 1px solid #e2e8f0;
    border-radius: 9px;
    background: #f8fafc;
}

.check-row input {
    width: 16px;
    height: 16px;
}

.check-row label {
    margin: 0;
    text-transform: none;
    font-size: 11px;
}

.form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
    margin-top: 20px;
    padding-top: 18px;
    border-top: 1px solid #edf0f4;
}

.table-wrap {
    overflow-x: auto;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 850px;
}

.data-table th {
    padding: 11px 12px;
    background: #f8fafc;
    color: #64748b;
    font-size: 9px;
    text-align: left;
    text-transform: uppercase;
    letter-spacing: .06em;
}

.data-table td {
    padding: 12px;
    border-top: 1px solid #eef1f5;
    color: #334155;
    font-size: 11px;
    vertical-align: middle;
}

.student-name {
    color: #111827;
    font-weight: 800;
}

.student-email {
    margin-top: 2px;
    color: #94a3b8;
    font-size: 9px;
}

.small-form {
    display: inline-flex;
    gap: 5px;
    flex-wrap: wrap;
}

.small-select {
    height: 32px;
    padding: 0 7px;
    border: 1px solid #e2e8f0;
    border-radius: 7px;
    background: #fff;
    font-size: 9px;
}

.small-btn {
    min-height: 32px;
    padding: 0 9px;
    border: 0;
    border-radius: 7px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 9px;
    font-weight: 800;
    cursor: pointer;
}

.danger-action {
    background: #fff1f2;
    color: #dc2626;
}

.status {
    display: inline-flex;
    padding: 5px 8px;
    border-radius: 999px;
    background: #f1f5f9;
    color: #475569;
    font-size: 8px;
    font-weight: 850;
    text-transform: uppercase;
}

.status-confirmed {
    background: #ecfdf5;
    color: #047857;
}

.status-attended {
    background: #eef2ff;
    color: #4338ca;
}

.status-cancelled {
    background: #fff1f2;
    color: #dc2626;
}

.status-no_show {
    background: #fff7ed;
    color: #c2410c;
}

.rating {
    color: #f59e0b;
    font-weight: 900;
}

.empty {
    padding: 35px;
    text-align: center;
    color: #94a3b8;
    font-size: 12px;
}

.danger-zone {
    border-color: #fecaca;
}

.danger-zone .panel-header {
    background: #fff7f7;
}

@media (max-width: 1050px) {

    .event-summary {
        grid-template-columns: repeat(3,1fr);
    }

    .summary-event {
        grid-column: 1 / -1;
    }

}

@media (max-width: 760px) {

    .manage-container {
        width: min(100% - 26px, 1280px);
    }

    .manage-header {
        flex-direction: column;
    }

    .event-summary {
        grid-template-columns: repeat(2,1fr);
    }

    .form-grid,
    .form-grid.three {
        grid-template-columns: 1fr;
    }

    .field-full {
        grid-column: auto;
    }

    .form-actions {
        flex-direction: column;
    }

    .form-actions .btn {
        width: 100%;
    }

}

</style>

<div class="manage-page">

<div class="manage-container">

    <div class="manage-header">

        <div>

            <h1>
                Manage Event
            </h1>

            <p>
                Edit, control registrations and manage
                attendance for your event.
            </p>

        </div>

        <div class="header-actions">

            <a
                href="organizer-dashboard.php"
                class="btn"
            >
                ← Dashboard
            </a>

            <a
                href="event-details.php?id=<?= (int)$event['event_id'] ?>"
                class="btn"
            >
                View Event
            </a>

        </div>

    </div>

    <?php if ($message !== ''): ?>

        <div class="message">
            <?= h($message) ?>
        </div>

    <?php endif; ?>


    <!-- =========================================================
         SUMMARY
    ========================================================== -->

    <div class="event-summary">

        <div class="summary-card summary-event">

            <span>
                Event
            </span>

            <strong>
                <?= h($event['title']) ?>
            </strong>

            <div class="status-pill">
                <?= h(
                    ucwords(
                        str_replace(
                            '_',
                            ' ',
                            (string)$event['event_status']
                        )
                    )
                ) ?>
            </div>

        </div>

        <div class="summary-card">

            <span>
                Registrations
            </span>

            <strong>
                <?= $totalRegistrations ?>
            </strong>

        </div>

        <div class="summary-card">

            <span>
                Confirmed
            </span>

            <strong>
                <?= $confirmedRegistrations ?>
            </strong>

        </div>

        <div class="summary-card">

            <span>
                Attended
            </span>

            <strong>
                <?= $attendedCount ?>
            </strong>

        </div>

        <div class="summary-card">

            <span>
                Rating
            </span>

            <strong>
                <?= number_format(
                    $averageRating,
                    1
                ) ?>
            </strong>

        </div>

    </div>


    <!-- =========================================================
         STATUS CONTROL
    ========================================================== -->

    <div class="panel">

        <div class="panel-header">

            <div>

                <h2>
                    Event Status
                </h2>

                <p>
                    Control the current lifecycle of this event.
                </p>

            </div>

        </div>

        <div class="panel-body">

            <div class="header-actions">

                <?php if (
                    $event['event_status'] !== 'published'
                ): ?>

                    <form
                        method="post"
                        action=""
                    >

                        <input
                            type="hidden"
                            name="event_id"
                            value="<?= $eventId ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="change_status"
                        >

                        <input
                            type="hidden"
                            name="status"
                            value="published"
                        >

                        <button
                            type="submit"
                            class="btn btn-success"
                        >
                            Publish Event
                        </button>

                    </form>

                <?php else: ?>

                    <form
                        method="post"
                        action=""
                    >

                        <input
                            type="hidden"
                            name="event_id"
                            value="<?= $eventId ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="change_status"
                        >

                        <input
                            type="hidden"
                            name="status"
                            value="draft"
                        >

                        <button
                            type="submit"
                            class="btn btn-warning"
                        >
                            Unpublish
                        </button>

                    </form>

                <?php endif; ?>


                <?php if (
                    $event['event_status'] !== 'completed'
                ): ?>

                    <form
                        method="post"
                        action=""
                    >

                        <input
                            type="hidden"
                            name="event_id"
                            value="<?= $eventId ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="change_status"
                        >

                        <input
                            type="hidden"
                            name="status"
                            value="completed"
                        >

                        <button
                            type="submit"
                            class="btn"
                        >
                            Mark Completed
                        </button>

                    </form>

                <?php endif; ?>


                <?php if (
                    $event['event_status'] !== 'cancelled'
                ): ?>

                    <form
                        method="post"
                        action=""
                        onsubmit="return confirm('Cancel this event?');"
                    >

                        <input
                            type="hidden"
                            name="event_id"
                            value="<?= $eventId ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="cancel_event"
                        >

                        <input
                            type="hidden"
                            name="cancellation_reason"
                            value="Cancelled by organizer."
                        >

                        <button
                            type="submit"
                            class="btn btn-danger"
                        >
                            Cancel Event
                        </button>

                    </form>

                <?php endif; ?>

            </div>

        </div>

    </div>


    <!-- =========================================================
         EDIT EVENT
    ========================================================== -->

    <div class="panel">

        <div class="panel-header">

            <div>

                <h2>
                    Event Information
                </h2>

                <p>
                    Update all important event details.
                </p>

            </div>

        </div>

        <div class="panel-body">

            <form
                method="post"
                action=""
            >

                <input
                    type="hidden"
                    name="event_id"
                    value="<?= $eventId ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="update_event"
                >

                <div class="form-grid">

                    <div class="field">

                        <label>
                            Event Title
                        </label>

                        <input
                            type="text"
                            name="title"
                            class="input"
                            maxlength="180"
                            required
                            value="<?= h(
                                $event['title']
                            ) ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Slug
                        </label>

                        <input
                            type="text"
                            name="slug"
                            class="input"
                            maxlength="220"
                            value="<?= h(
                                $event['slug']
                            ) ?>"
                        >

                    </div>


                    <div class="field field-full">

                        <label>
                            Short Description
                        </label>

                        <input
                            type="text"
                            name="short_description"
                            class="input"
                            maxlength="300"
                            value="<?= h(
                                $event['short_description']
                            ) ?>"
                        >

                    </div>


                    <div class="field field-full">

                        <label>
                            Full Description
                        </label>

                        <textarea
                            name="description"
                            class="textarea"
                            required
                        ><?= h(
                            $event['description']
                        ) ?></textarea>

                    </div>


                    <div class="field">

                        <label>
                            Category
                        </label>

                        <select
                            name="category_id"
                            class="select"
                            required
                        >

                            <?php foreach (
                                $categories as $category
                            ): ?>

                                <option
                                    value="<?= (int)$category['category_id'] ?>"
                                    <?= (int)$event['category_id'] ===
                                        (int)$category['category_id']
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= h(
                                        $category['category_name']
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="field">

                        <label>
                            Department
                        </label>

                        <select
                            name="department_id"
                            class="select"
                            required
                        >

                            <?php foreach (
                                $departments as $department
                            ): ?>

                                <option
                                    value="<?= (int)$department['department_id'] ?>"
                                    <?= (int)$event['department_id'] ===
                                        (int)$department['department_id']
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= h(
                                        $department['department_name']
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="field">

                        <label>
                            Venue
                        </label>

                        <select
                            name="venue_id"
                            class="select"
                            required
                        >

                            <?php foreach (
                                $venues as $venue
                            ): ?>

                                <option
                                    value="<?= (int)$venue['venue_id'] ?>"
                                    <?= (int)$event['venue_id'] ===
                                        (int)$venue['venue_id']
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= h(
                                        $venue['venue_name']
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="field">

                        <label>
                            Event Date
                        </label>

                        <input
                            type="date"
                            name="event_date"
                            class="input"
                            required
                            value="<?= h(
                                $event['event_date']
                            ) ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Start Time
                        </label>

                        <input
                            type="time"
                            name="start_time"
                            class="input"
                            required
                            value="<?= h(
                                $event['start_time']
                            ) ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            End Time
                        </label>

                        <input
                            type="time"
                            name="end_time"
                            class="input"
                            required
                            value="<?= h(
                                $event['end_time']
                            ) ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Registration Opens
                        </label>

                        <input
                            type="datetime-local"
                            name="registration_open"
                            class="input"
                            value="<?= h(
                                date(
                                    'Y-m-d\TH:i',
                                    strtotime(
                                        (string)$event['registration_open']
                                    )
                                )
                            ) ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Registration Closes
                        </label>

                        <input
                            type="datetime-local"
                            name="registration_close"
                            class="input"
                            value="<?= h(
                                date(
                                    'Y-m-d\TH:i',
                                    strtotime(
                                        (string)$event['registration_close']
                                    )
                                )
                            ) ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Maximum Capacity
                        </label>

                        <input
                            type="number"
                            name="max_capacity"
                            class="input"
                            min="1"
                            required
                            value="<?= (int)$event['max_capacity'] ?>"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Event Status
                        </label>

                        <select
                            name="event_status"
                            class="select"
                        >

                            <?php

                            $statuses = [
                                'draft',
                                'pending_approval',
                                'approved',
                                'published',
                                'cancelled',
                                'completed'
                            ];

                            foreach (
                                $statuses as $status
                            ):

                            ?>

                                <option
                                    value="<?= h($status) ?>"
                                    <?= $event['event_status'] === $status
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= h(
                                        ucwords(
                                            str_replace(
                                                '_',
                                                ' ',
                                                $status
                                            )
                                        )
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="field field-full">

                        <label>
                            Featured Image
                        </label>

                        <input
                            type="text"
                            name="featured_image"
                            class="input"
                            maxlength="500"
                            placeholder="uploads/event-image.jpg"
                            value="<?= h(
                                $event['featured_image']
                            ) ?>"
                        >

                    </div>


                    <div class="field field-full">

                        <div class="check-row">

                            <input
                                type="checkbox"
                                id="waitlist_enabled"
                                name="waitlist_enabled"
                                value="1"
                                <?= !empty(
                                    $event['waitlist_enabled']
                                )
                                    ? 'checked'
                                    : '' ?>
                            >

                            <label for="waitlist_enabled">
                                Enable waitlist when the event is full
                            </label>

                        </div>

                    </div>

                </div>


                <div class="form-actions">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Save Event Changes
                    </button>

                </div>

            </form>

        </div>

    </div>


    <!-- =========================================================
         REGISTRATIONS
    ========================================================== -->

    <div class="panel">

        <div class="panel-header">

            <div>

                <h2>
                    Attendees & Registrations
                </h2>

                <p>
                    Manage student registrations and attendance.
                </p>

            </div>

            <span class="status">
                <?= count($registrations) ?> Records
            </span>

        </div>

        <div class="table-wrap">

            <?php if (
                empty($registrations)
            ): ?>

                <div class="empty">
                    No registrations yet.
                </div>

            <?php else: ?>

                <table class="data-table">

                    <thead>

                        <tr>

                            <th>
                                Student
                            </th>

                            <th>
                                Registration
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Attendance
                            </th>

                            <th>
                                Action
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php foreach (
                        $registrations as $registration
                    ): ?>

                        <tr>

                            <td>

                                <div class="student-name">

                                    <?= h(
                                        $registration['full_name']
                                        ?: $registration['username']
                                        ?: 'Student'
                                    ) ?>

                                </div>

                                <div class="student-email">

                                    <?= h(
                                        $registration['email']
                                    ) ?>

                                </div>

                            </td>


                            <td>

                                <strong>
                                    <?= h(
                                        $registration[
                                            'registration_code'
                                        ]
                                    ) ?>
                                </strong>

                                <div class="student-email">

                                    <?= h(
                                        $registration[
                                            'registered_at'
                                        ]
                                    ) ?>

                                </div>

                            </td>


                            <td>

                                <span class="status status-<?= h(
                                    $registration['status']
                                ) ?>">

                                    <?= h(
                                        str_replace(
                                            '_',
                                            ' ',
                                            $registration['status']
                                        )
                                    ) ?>

                                </span>

                            </td>


                            <td>

                                <?php if (
                                    !empty(
                                        $registration[
                                            'attendance_status'
                                        ]
                                    )
                                ): ?>

                                    <span class="status">

                                        <?= h(
                                            $registration[
                                                'attendance_status'
                                            ]
                                        ) ?>

                                    </span>

                                    <?php if (
                                        !empty(
                                            $registration[
                                                'check_in_time'
                                            ]
                                        )
                                    ): ?>

                                        <div class="student-email">

                                            <?= h(
                                                $registration[
                                                    'check_in_time'
                                                ]
                                            ) ?>

                                        </div>

                                    <?php endif; ?>

                                <?php else: ?>

                                    <span class="status">
                                        Not Marked
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <form
                                    method="post"
                                    class="small-form"
                                >

                                    <input
                                        type="hidden"
                                        name="event_id"
                                        value="<?= $eventId ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="registration_id"
                                        value="<?= (int)$registration['registration_id'] ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="action"
                                        value="registration_status"
                                    >

                                    <select
                                        name="registration_status"
                                        class="small-select"
                                    >

                                        <option value="confirmed">
                                            Confirm
                                        </option>

                                        <option value="cancelled">
                                            Cancel
                                        </option>

                                        <option value="attended">
                                            Attended
                                        </option>

                                        <option value="no_show">
                                            No Show
                                        </option>

                                    </select>

                                    <button
                                        type="submit"
                                        class="small-btn"
                                    >
                                        Update
                                    </button>

                                </form>


                                <form
                                    method="post"
                                    class="small-form"
                                    style="margin-top:5px;"
                                >

                                    <input
                                        type="hidden"
                                        name="event_id"
                                        value="<?= $eventId ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="registration_id"
                                        value="<?= (int)$registration['registration_id'] ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="action"
                                        value="attendance"
                                    >

                                    <select
                                        name="attendance_status"
                                        class="small-select"
                                    >

                                        <option value="present">
                                            Present
                                        </option>

                                        <option value="late">
                                            Late
                                        </option>

                                        <option value="absent">
                                            Absent
                                        </option>

                                    </select>

                                    <button
                                        type="submit"
                                        class="small-btn"
                                    >
                                        Attendance
                                    </button>

                                </form>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php endif; ?>

        </div>

    </div>


    <!-- =========================================================
         WAITLIST
    ========================================================== -->

    <div class="panel">

        <div class="panel-header">

            <div>

                <h2>
                    Waitlist
                </h2>

                <p>
                    Students waiting for available seats.
                </p>

            </div>

            <span class="status">
                <?= $waitlistCount ?> Waiting
            </span>

        </div>

        <div class="table-wrap">

            <?php if (
                empty($waitlist)
            ): ?>

                <div class="empty">
                    No students are currently waiting.
                </div>

            <?php else: ?>

                <table class="data-table">

                    <thead>

                        <tr>

                            <th>
                                Position
                            </th>

                            <th>
                                Student
                            </th>

                            <th>
                                Joined
                            </th>

                            <th>
                                Status
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php foreach (
                        $waitlist as $item
                    ): ?>

                        <tr>

                            <td>

                                <strong>
                                    #<?= (int)$item[
                                        'queue_position'
                                    ] ?>
                                </strong>

                            </td>

                            <td>

                                <div class="student-name">

                                    <?= h(
                                        $item['full_name']
                                        ?: $item['username']
                                        ?: 'Student'
                                    ) ?>

                                </div>

                                <div class="student-email">

                                    <?= h(
                                        $item['email']
                                    ) ?>

                                </div>

                            </td>

                            <td>
                                <?= h(
                                    $item['joined_at']
                                ) ?>
                            </td>

                            <td>

                                <span class="status">

                                    <?= h(
                                        $item['status']
                                    ) ?>

                                </span>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php endif; ?>

        </div>

    </div>


    <!-- =========================================================
         FEEDBACK
    ========================================================== -->

    <div class="panel">

        <div class="panel-header">

            <div>

                <h2>
                    Event Feedback
                </h2>

                <p>
                    Review feedback submitted by participants.
                </p>

            </div>

            <span class="status">
                <?= $feedbackCount ?> Reviews
            </span>

        </div>

        <div class="table-wrap">

            <?php if (
                empty($feedback)
            ): ?>

                <div class="empty">
                    No feedback has been submitted yet.
                </div>

            <?php else: ?>

                <table class="data-table">

                    <thead>

                        <tr>

                            <th>
                                Student
                            </th>

                            <th>
                                Rating
                            </th>

                            <th>
                                Feedback
                            </th>

                            <th>
                                Date
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php foreach (
                        $feedback as $review
                    ): ?>

                        <tr>

                            <td>

                                <div class="student-name">

                                    <?= h(
                                        $review['is_anonymous']
                                            ? 'Anonymous'
                                            : (
                                                $review['full_name']
                                                ?: $review['username']
                                                ?: 'Student'
                                            )
                                    ) ?>

                                </div>

                            </td>

                            <td>

                                <span class="rating">

                                    <?= str_repeat(
                                        '★',
                                        max(
                                            0,
                                            min(
                                                5,
                                                (int)$review[
                                                    'overall_rating'
                                                ]
                                            )
                                        )
                                    ) ?>

                                </span>

                                <span class="student-email">

                                    <?= (int)$review[
                                        'overall_rating'
                                    ] ?>/5

                                </span>

                            </td>

                            <td>

                                <?= h(
                                    $review['comments']
                                    ?: 'No written feedback.'
                                ) ?>

                            </td>

                            <td>

                                <?= h(
                                    $review['submitted_at']
                                ) ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            <?php endif; ?>

        </div>

    </div>


    <!-- =========================================================
         DANGER ZONE
    ========================================================== -->

    <div class="panel danger-zone">

        <div class="panel-header">

            <div>

                <h2>
                    Danger Zone
                </h2>

                <p>
                    Permanently remove this event and its related records.
                </p>

            </div>

        </div>

        <div class="panel-body">

            <form
                method="post"
                action=""
                onsubmit="return confirm('WARNING: This will permanently delete the event, registrations, attendance, feedback and waitlist data. Continue?');"
            >

                <input
                    type="hidden"
                    name="event_id"
                    value="<?= $eventId ?>"
                >

                <input
                    type="hidden"
                    name="action"
                    value="delete_event"
                >

                <button
                    type="submit"
                    class="btn btn-danger"
                >
                    Permanently Delete Event
                </button>

            </form>

        </div>

    </div>

</div>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>