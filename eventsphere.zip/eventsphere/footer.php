<?php
/*
|--------------------------------------------------------------------------
| EventSphere - Global Footer
|--------------------------------------------------------------------------
*/
?>

</div><!-- /.container -->

</main>


<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="event-footer">

    <div class="container">

        <div class="row g-4 align-items-center">


            <!-- Brand -->

            <div class="col-lg-5">

                <a
                    href="index.php"
                    class="footer-brand"
                >

                    <span class="footer-brand-icon">
                        <i class="bi bi-calendar-event"></i>
                    </span>

                    <span>
                        EventSphere
                    </span>

                </a>

                <p class="footer-description">
                    Discover college events, register for
                    activities, connect with your campus
                    community and keep track of your
                    participation.
                </p>

            </div>


            <!-- Quick Links -->

            <div class="col-6 col-lg-3">

                <h6 class="footer-heading">
                    Quick Links
                </h6>

                <ul class="footer-links">

                    <li>
                        <a href="index.php">
                            Home
                        </a>
                    </li>

                    <li>
                        <a href="my-events.php">
                            Events
                        </a>
                    </li>

                    <li>
                        <a href="gallery.php">
                            Gallery
                        </a>
                    </li>

                    <li>
                        <a href="about.php">
                            About Us
                        </a>
                    </li>

                </ul>

            </div>


            <!-- Support -->

            <div class="col-6 col-lg-4">

                <h6 class="footer-heading">
                    Support
                </h6>

                <ul class="footer-links">

                    <li>
                        <a href="contact-us.php">
                            Contact Us
                        </a>
                    </li>

                    <li>
                        <a href="faq.php">
                            FAQs
                        </a>
                    </li>

                    <li>
                        <a href="sitemap.php">
                            Sitemap
                        </a>
                    </li>

                    <li>
                        <a href="events.php">
                            Explore Events
                        </a>
                    </li>

                </ul>

            </div>

        </div>


        <!-- Divider -->

        <div class="footer-divider"></div>


        <!-- Bottom -->

        <div class="footer-bottom">

            <span>
                © <?= date("Y") ?> EventSphere.
                All rights reserved.
            </span>

            <span class="footer-tagline">
                Built for campus events &amp; experiences.
            </span>

        </div>

    </div>

</footer>


<!-- =========================================================
     FOOTER STYLES
========================================================= -->

<style>

    /* =====================================================
       EVENTSPHERE FOOTER
    ===================================================== */

    .event-footer {

        margin-top: 70px;

        padding: 55px 0 22px;

        background:
            #0f172a;

        color: #cbd5e1;

    }


    /* =====================================================
       BRAND
    ===================================================== */

    .footer-brand {

        display: inline-flex;

        align-items: center;

        gap: 10px;

        margin-bottom: 15px;

        color: #ffffff;

        text-decoration: none;

        font-size: 20px;

        font-weight: 850;

        letter-spacing: -.4px;

    }


    .footer-brand:hover {

        color: #ffffff;

    }


    .footer-brand-icon {

        display: flex;

        align-items: center;

        justify-content: center;

        width: 36px;

        height: 36px;

        border-radius: 10px;

        background:
            linear-gradient(
                135deg,
                #0d6efd,
                #6f42c1
            );

        color: #ffffff;

        box-shadow:
            0 8px 20px
            rgba(13,110,253,.20);

    }


    .footer-description {

        max-width: 520px;

        margin: 0;

        color: #94a3b8;

        font-size: 13px;

        line-height: 1.8;

    }


    /* =====================================================
       HEADINGS
    ===================================================== */

    .footer-heading {

        margin-bottom: 17px;

        color: #ffffff;

        font-size: 12px;

        font-weight: 800;

        text-transform: uppercase;

        letter-spacing: 1px;

    }


    /* =====================================================
       LINKS
    ===================================================== */

    .footer-links {

        margin: 0;

        padding: 0;

        list-style: none;

    }


    .footer-links li {

        margin-bottom: 9px;

    }


    .footer-links a {

        color: #94a3b8;

        text-decoration: none;

        font-size: 13px;

        transition:
            color .2s ease,
            padding-left .2s ease;

    }


    .footer-links a:hover {

        padding-left: 4px;

        color: #ffffff;

    }


    /* =====================================================
       DIVIDER
    ===================================================== */

    .footer-divider {

        height: 1px;

        margin: 38px 0 20px;

        background:
            rgba(255,255,255,.08);

    }


    /* =====================================================
       BOTTOM
    ===================================================== */

    .footer-bottom {

        display: flex;

        align-items: center;

        justify-content: space-between;

        gap: 15px;

        color: #64748b;

        font-size: 11px;

    }


    .footer-tagline {

        color: #64748b;

    }


    /* =====================================================
       MOBILE
    ===================================================== */

    @media (max-width: 767px) {

        .event-footer {

            margin-top: 50px;

            padding: 42px 0 20px;

        }


        .footer-bottom {

            align-items: flex-start;

            flex-direction: column;

        }


        .footer-divider {

            margin-top: 25px;

        }

    }

</style>


<!-- =========================================================
     JAVASCRIPT
========================================================= -->

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

<script src="script.js"></script>


</body>

</html>