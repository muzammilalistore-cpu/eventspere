
<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_auth();

$userId = (int)($_SESSION['user']['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}

$title = 'Notifications | EventSphere';

function notification_escape($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Mark selected notification as read
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['mark_read'])
) {
    $userNotificationId = (int)$_POST['mark_read'];

    if ($userNotificationId > 0) {

        $stmt = mysqli_prepare(
            $conn,
            "UPDATE user_notifications
             SET
                is_read = 1,
                read_at = NOW()
             WHERE user_notification_id = ?
             AND user_id = ?"
        );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                'ii',
                $userNotificationId,
                $userId
            );

            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }

    header('Location: notifications.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Mark all notifications as read
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['mark_all_read'])
) {

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE user_notifications
         SET
            is_read = 1,
            read_at = NOW()
         WHERE user_id = ?
         AND is_read = 0"
    );

    if ($stmt) {

        mysqli_stmt_bind_param(
            $stmt,
            'i',
            $userId
        );

        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    header('Location: notifications.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Notification statistics
|--------------------------------------------------------------------------
*/

$totalNotifications = 0;
$unreadNotifications = 0;
$readNotifications = 0;

$stmt = mysqli_prepare(
    $conn,
    "SELECT
        COUNT(*) AS total_notifications,
        SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END) AS unread_notifications,
        SUM(CASE WHEN is_read = 1 THEN 1 ELSE 0 END) AS read_notifications
     FROM user_notifications
     WHERE user_id = ?"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $stats = mysqli_fetch_assoc($result);

    $totalNotifications = (int)($stats['total_notifications'] ?? 0);
    $unreadNotifications = (int)($stats['unread_notifications'] ?? 0);
    $readNotifications = (int)($stats['read_notifications'] ?? 0);

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Load notifications
|--------------------------------------------------------------------------
*/

$notifications = [];

$stmt = mysqli_prepare(
    $conn,
    "SELECT
        un.user_notification_id,
        un.notification_id,
        un.is_read,
        un.read_at,
        un.created_at AS user_notification_created_at,

        n.title,
        n.message,
        n.notification_type,
        n.event_id,
        n.created_at AS notification_created_at,

        e.title AS event_title

     FROM user_notifications un

     INNER JOIN notifications n
        ON n.notification_id = un.notification_id

     LEFT JOIN events e
        ON e.event_id = n.event_id

     WHERE un.user_id = ?

     ORDER BY
        un.is_read ASC,
        un.created_at DESC,
        n.created_at DESC"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        'i',
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $notifications[] = $row;
    }

    mysqli_stmt_close($stmt);
}

require_once __DIR__ . '/header.php';
?>

<style>
.notifications-page {
    padding: 42px 0 80px;
}

.notifications-hero {
    position: relative;
    overflow: hidden;
    padding: 34px 38px;
    border-radius: 26px;
    color: #fff;

    background:
        radial-gradient(
            circle at 90% 10%,
            rgba(99, 102, 241, .35),
            transparent 30%
        ),
        radial-gradient(
            circle at 10% 90%,
            rgba(34, 211, 238, .14),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #1e293b 55%,
            #312e81
        );

    box-shadow:
        0 24px 60px rgba(15, 23, 42, .14);
}

.notifications-eyebrow {
    display: inline-block;
    margin-bottom: 10px;
    color: #a5b4fc;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.4px;
    text-transform: uppercase;
}

.notifications-hero h1 {
    margin: 0 0 8px;
    font-size: 34px;
    font-weight: 850;
    letter-spacing: -.04em;
}

.notifications-hero p {
    max-width: 680px;
    margin: 0;
    color: #cbd5e1;
    line-height: 1.7;
}

.notification-stats {
    margin-top: 22px;
}

.notification-stat {
    height: 100%;
    padding: 20px;
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 19px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .045);
}

.notification-stat-label {
    color: #94a3b8;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
    text-transform: uppercase;
}

.notification-stat-value {
    margin-top: 7px;
    color: #0f172a;
    font-size: 27px;
    font-weight: 850;
}

.notification-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin: 30px 0 15px;
}

.notification-toolbar h2 {
    margin: 0;
    color: #0f172a;
    font-size: 21px;
    font-weight: 850;
}

.notification-toolbar p {
    margin: 4px 0 0;
    color: #94a3b8;
    font-size: 12px;
}

.mark-all-btn {
    border: 1px solid #e2e8f0;
    background: #fff;
    color: #475569;
    padding: 9px 14px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 750;
    cursor: pointer;
    transition: .25s ease;
}

.mark-all-btn:hover {
    border-color: #6366f1;
    color: #4f46e5;
    background: #eef2ff;
}

.notifications-list {
    display: grid;
    gap: 12px;
}

.notification-item {
    position: relative;
    display: flex;
    gap: 16px;
    padding: 20px;
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 18px;
    box-shadow: 0 8px 28px rgba(15, 23, 42, .035);
    transition: .25s ease;
}

.notification-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 15px 35px rgba(15, 23, 42, .07);
}

.notification-item.unread {
    border-color: #c7d2fe;
    background: #fafaff;
}

.notification-icon {
    width: 45px;
    height: 45px;
    min-width: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 13px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 18px;
}

.notification-content {
    min-width: 0;
    flex: 1;
}

.notification-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 15px;
}

.notification-title {
    color: #172033;
    font-size: 14px;
    font-weight: 800;
}

.notification-message {
    margin-top: 5px;
    color: #64748b;
    font-size: 12px;
    line-height: 1.7;
}

.notification-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 10px;
    color: #94a3b8;
    font-size: 10px;
}

.notification-type {
    display: inline-flex;
    align-items: center;
    padding: 5px 8px;
    border-radius: 999px;
    background: #f1f5f9;
    color: #475569;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
}

.unread-dot {
    width: 8px;
    height: 8px;
    margin-top: 6px;
    border-radius: 50%;
    background: #4f46e5;
}

.notification-actions {
    margin-top: 12px;
}

.read-btn {
    border: 0;
    background: transparent;
    color: #4f46e5;
    padding: 0;
    font-size: 10px;
    font-weight: 800;
    cursor: pointer;
}

.read-btn:hover {
    text-decoration: underline;
}

.empty-notifications {
    padding: 75px 25px;
    text-align: center;
    background: #fff;
    border: 1px solid #e8edf3;
    border-radius: 21px;
}

.empty-notification-icon {
    width: 66px;
    height: 66px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 17px;
    border-radius: 19px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 26px;
}

.empty-notifications h3 {
    margin: 0 0 7px;
    color: #1e293b;
    font-size: 17px;
    font-weight: 800;
}

.empty-notifications p {
    max-width: 450px;
    margin: auto;
    color: #94a3b8;
    font-size: 12px;
    line-height: 1.7;
}

@media (max-width: 767px) {

    .notifications-page {
        padding: 25px 0 55px;
    }

    .notifications-hero {
        padding: 27px 22px;
        border-radius: 21px;
    }

    .notifications-hero h1 {
        font-size: 29px;
    }

    .notification-toolbar {
        align-items: flex-start;
        flex-direction: column;
    }

    .notification-item {
        padding: 16px;
    }

    .notification-top {
        gap: 8px;
    }
}
</style>

<div class="container notifications-page">

    <section class="notifications-hero">

        <span class="notifications-eyebrow">
            EventSphere
        </span>

        <h1>
            Notifications
        </h1>

        <p>
            Keep track of event updates, registration changes,
            reminders, announcements and other important activity.
        </p>

    </section>

    <div class="row g-4 notification-stats">

        <div class="col-md-4">
            <div class="notification-stat">
                <div class="notification-stat-label">
                    Total Notifications
                </div>

                <div class="notification-stat-value">
                    <?= $totalNotifications ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="notification-stat">
                <div class="notification-stat-label">
                    Unread
                </div>

                <div class="notification-stat-value">
                    <?= $unreadNotifications ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="notification-stat">
                <div class="notification-stat-label">
                    Read
                </div>

                <div class="notification-stat-value">
                    <?= $readNotifications ?>
                </div>
            </div>
        </div>

    </div>

    <div class="notification-toolbar">

        <div>
            <h2>Recent Notifications</h2>

            <p>
                Your latest EventSphere updates are shown here.
            </p>
        </div>

        <?php if ($unreadNotifications > 0): ?>

            <form method="POST">

                <button
                    type="submit"
                    name="mark_all_read"
                    value="1"
                    class="mark-all-btn"
                >
                    Mark all as read
                </button>

            </form>

        <?php endif; ?>

    </div>

    <?php if (empty($notifications)): ?>

        <div class="empty-notifications">

            <div class="empty-notification-icon">
                ✓
            </div>

            <h3>
                You're all caught up
            </h3>

            <p>
                There are no notifications to display right now.
                New event updates and important messages will appear here.
            </p>

        </div>

    <?php else: ?>

        <div class="notifications-list">

            <?php foreach ($notifications as $notification): ?>

                <?php

                $type = strtolower(
                    trim(
                        (string)(
                            $notification['notification_type'] ?? 'system'
                        )
                    )
                );

                $icon = '•';

                switch ($type) {

                    case 'event':
                        $icon = '◆';
                        break;

                    case 'registration':
                        $icon = '✓';
                        break;

                    case 'reminder':
                        $icon = '◷';
                        break;

                    case 'deadline':
                        $icon = '!';
                        break;

                    case 'certificate':
                        $icon = '★';
                        break;

                    case 'announcement':
                        $icon = '📢';
                        break;

                    default:
                        $icon = '•';
                }

                $createdAt = $notification['user_notification_created_at']
                    ?? $notification['notification_created_at']
                    ?? null;

                ?>

                <article
                    class="notification-item <?= (int)$notification['is_read'] === 0 ? 'unread' : '' ?>"
                >

                    <div class="notification-icon">
                        <?= notification_escape($icon) ?>
                    </div>

                    <div class="notification-content">

                        <div class="notification-top">

                            <div class="notification-title">
                                <?= notification_escape(
                                    $notification['title']
                                ) ?>
                            </div>

                            <?php if ((int)$notification['is_read'] === 0): ?>

                                <span
                                    class="unread-dot"
                                    title="Unread notification"
                                ></span>

                            <?php endif; ?>

                        </div>

                        <div class="notification-message">
                            <?= nl2br(
                                notification_escape(
                                    $notification['message']
                                )
                            ) ?>
                        </div>

                        <div class="notification-meta">

                            <span class="notification-type">
                                <?= notification_escape($type) ?>
                            </span>

                            <?php if (!empty($notification['event_title'])): ?>

                                <span>
                                    Event:
                                    <?= notification_escape(
                                        $notification['event_title']
                                    ) ?>
                                </span>

                            <?php endif; ?>

                            <?php if (!empty($createdAt)): ?>

                                <span>
                                    <?= notification_escape(
                                        date(
                                            'd M Y, h:i A',
                                            strtotime($createdAt)
                                        )
                                    ) ?>
                                </span>

                            <?php endif; ?>

                        </div>

                        <?php if ((int)$notification['is_read'] === 0): ?>

                            <div class="notification-actions">

                                <form method="POST">

                                    <input
                                        type="hidden"
                                        name="mark_read"
                                        value="<?= (int)$notification['user_notification_id'] ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="read-btn"
                                    >
                                        Mark as read
                                    </button>

                                </form>

                            </div>

                        <?php endif; ?>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>
