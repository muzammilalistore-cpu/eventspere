<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';

/*
|--------------------------------------------------------------------------
| EventSphere - Create Event
|--------------------------------------------------------------------------
| Compatible with current EventSphere database structure.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Database connection
|--------------------------------------------------------------------------
*/

if (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} elseif (isset($mysqli) && $mysqli instanceof mysqli) {
    $db = $mysqli;
} elseif (isset($connection) && $connection instanceof mysqli) {
    $db = $connection;
} else {
    die('Database connection not found. Check db.php');
}

if ($db->connect_errno) {
    die('Database connection failed: ' . $db->connect_error);
}

$db->set_charset('utf8mb4');


/*
|--------------------------------------------------------------------------
| Session
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Helper functions
|--------------------------------------------------------------------------
| Unique names are used so there is no conflict with functions.php.
|--------------------------------------------------------------------------
*/

function ce_h(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function ce_redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function ce_slug(string $text): string
{
    $text = trim($text);

    $text = preg_replace(
        '/[^a-zA-Z0-9]+/',
        '-',
        $text
    ) ?? '';

    $text = trim($text, '-');

    $text = strtolower($text);

    return $text !== '' ? $text : 'event-' . time();
}

function ce_table_has_column(
    mysqli $db,
    string $table,
    string $column
): bool {
    $table = $db->real_escape_string($table);
    $column = $db->real_escape_string($column);

    $result = $db->query(
        "SHOW COLUMNS FROM `{$table}` LIKE '{$column}'"
    );

    return $result instanceof mysqli_result
        && $result->num_rows > 0;
}

function ce_get_id_from_session(): int
{
    if (
        isset($_SESSION['user']['user_id']) &&
        is_numeric($_SESSION['user']['user_id'])
    ) {
        return (int)$_SESSION['user']['user_id'];
    }

    if (
        isset($_SESSION['user_id']) &&
        is_numeric($_SESSION['user_id'])
    ) {
        return (int)$_SESSION['user_id'];
    }

    return 0;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

$organizerId = ce_get_id_from_session();

if ($organizerId <= 0) {
    ce_redirect('login.php');
}


/*
|--------------------------------------------------------------------------
| Verify organizer account
|--------------------------------------------------------------------------
*/

$organizerStmt = $db->prepare(
    "SELECT user_id, email, role
     FROM users
     WHERE user_id = ?
     LIMIT 1"
);

if (!$organizerStmt) {
    die('Organizer query failed: ' . $db->error);
}

$organizerStmt->bind_param(
    'i',
    $organizerId
);

$organizerStmt->execute();

$organizerResult = $organizerStmt->get_result();

$organizer = $organizerResult->fetch_assoc();

$organizerStmt->close();

if (!$organizer) {
    session_destroy();
    ce_redirect('login.php');
}


/*
|--------------------------------------------------------------------------
| Allow organizer role
|--------------------------------------------------------------------------
*/

$role = strtolower(
    trim((string)($organizer['role'] ?? ''))
);

if (
    $role !== 'organizer' &&
    $role !== 'admin'
) {
    die(
        '<div style="
            font-family:Arial;
            max-width:700px;
            margin:80px auto;
            padding:30px;
            border-radius:16px;
            background:#fff1f2;
            color:#991b1b;
        ">
            <h2>Access denied</h2>
            <p>Your account is not registered as an organizer.</p>
        </div>'
    );
}


/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/

if (
    empty($_SESSION['create_event_token']) ||
    !is_string($_SESSION['create_event_token'])
) {
    $_SESSION['create_event_token'] =
        bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['create_event_token'];


/*
|--------------------------------------------------------------------------
| Load Categories
|--------------------------------------------------------------------------
| We do NOT assume the name column.
|--------------------------------------------------------------------------
*/

$categories = [];

$categoryNameColumn = null;

$possibleCategoryColumns = [
    'category_name',
    'name',
    'title'
];

foreach ($possibleCategoryColumns as $column) {
    if (
        ce_table_has_column(
            $db,
            'event_categories',
            $column
        )
    ) {
        $categoryNameColumn = $column;
        break;
    }
}

if ($categoryNameColumn !== null) {

    $categorySql = "
        SELECT
            category_id,
            `{$categoryNameColumn}` AS category_label
        FROM event_categories
        ORDER BY `{$categoryNameColumn}` ASC
    ";

    $categoryResult = $db->query($categorySql);

    if ($categoryResult instanceof mysqli_result) {
        while ($row = $categoryResult->fetch_assoc()) {
            $categories[] = $row;
        }
    }
}


/*
|--------------------------------------------------------------------------
| Load Departments
|--------------------------------------------------------------------------
| Again, no fixed `name` assumption.
|--------------------------------------------------------------------------
*/

$departments = [];

$departmentNameColumn = null;

$possibleDepartmentColumns = [
    'department_name',
    'name',
    'title'
];

foreach ($possibleDepartmentColumns as $column) {
    if (
        ce_table_has_column(
            $db,
            'departments',
            $column
        )
    ) {
        $departmentNameColumn = $column;
        break;
    }
}

if ($departmentNameColumn !== null) {

    $departmentSql = "
        SELECT
            department_id,
            `{$departmentNameColumn}` AS department_label
        FROM departments
        ORDER BY `{$departmentNameColumn}` ASC
    ";

    $departmentResult = $db->query($departmentSql);

    if ($departmentResult instanceof mysqli_result) {
        while ($row = $departmentResult->fetch_assoc()) {
            $departments[] = $row;
        }
    }
}


/*
|--------------------------------------------------------------------------
| Load available venues
|--------------------------------------------------------------------------
| Uses your exact venues structure.
|--------------------------------------------------------------------------
*/

$venues = [];

$venueResult = $db->query(
    "SELECT
        venue_id,
        venue_name,
        building_name,
        floor_no,
        location_description,
        default_capacity,
        status
     FROM venues
     WHERE status = 'available'
     ORDER BY venue_name ASC"
);

if ($venueResult instanceof mysqli_result) {
    while ($row = $venueResult->fetch_assoc()) {
        $venues[] = $row;
    }
}


/*
|--------------------------------------------------------------------------
| Form values
|--------------------------------------------------------------------------
*/

$title = '';
$shortDescription = '';
$description = '';
$categoryId = 0;
$departmentId = 0;
$venueId = 0;

$eventDate = '';
$startTime = '';
$endTime = '';

$registrationOpen = '';
$registrationClose = '';

$maxCapacity = '';
$waitlistEnabled = 1;

$error = '';
$success = '';


/*
|--------------------------------------------------------------------------
| Form submission
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF
    |--------------------------------------------------------------------------
    */

    $postedToken = (string)(
        $_POST['csrf_token'] ?? ''
    );

    if (
        !hash_equals(
            $csrfToken,
            $postedToken
        )
    ) {
        $error = 'Invalid form request. Please refresh the page and try again.';
    }


    /*
    |--------------------------------------------------------------------------
    | Get fields
    |--------------------------------------------------------------------------
    */

    $title = trim(
        (string)($_POST['title'] ?? '')
    );

    $shortDescription = trim(
        (string)($_POST['short_description'] ?? '')
    );

    $description = trim(
        (string)($_POST['description'] ?? '')
    );

    $categoryId = (int)(
        $_POST['category_id'] ?? 0
    );

    $departmentId = (int)(
        $_POST['department_id'] ?? 0
    );

    $venueId = (int)(
        $_POST['venue_id'] ?? 0
    );

    $eventDate = trim(
        (string)($_POST['event_date'] ?? '')
    );

    $startTime = trim(
        (string)($_POST['start_time'] ?? '')
    );

    $endTime = trim(
        (string)($_POST['end_time'] ?? '')
    );

    $registrationOpen = trim(
        (string)($_POST['registration_open'] ?? '')
    );

    $registrationClose = trim(
        (string)($_POST['registration_close'] ?? '')
    );

    $maxCapacity = trim(
        (string)($_POST['max_capacity'] ?? '')
    );

    $waitlistEnabled = isset(
        $_POST['waitlist_enabled']
    ) ? 1 : 0;


    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        if ($title === '') {
            $error = 'Event title is required.';
        } elseif (mb_strlen($title) < 3) {
            $error = 'Event title must contain at least 3 characters.';
        }

    }


    if ($error === '' && $shortDescription === '') {
        $error = 'Short description is required.';
    }


    if ($error === '' && $description === '') {
        $error = 'Full event description is required.';
    }


    if ($error === '' && $categoryId <= 0) {
        $error = 'Please select an event category.';
    }


    if ($error === '' && $departmentId <= 0) {
        $error = 'Please select a department.';
    }


    if ($error === '' && $venueId <= 0) {
        $error = 'Please select a venue.';
    }


    if ($error === '' && $eventDate === '') {
        $error = 'Please select the event date.';
    }


    if ($error === '' && $startTime === '') {
        $error = 'Please select the event start time.';
    }


    if ($error === '' && $endTime === '') {
        $error = 'Please select the event end time.';
    }


    /*
    |--------------------------------------------------------------------------
    | Validate date/time
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $eventTimestamp = strtotime(
            $eventDate . ' ' . $startTime
        );

        $startTimestamp = strtotime(
            $eventDate . ' ' . $startTime
        );

        $endTimestamp = strtotime(
            $eventDate . ' ' . $endTime
        );

        if ($eventTimestamp === false) {
            $error = 'Invalid event date.';
        } elseif (
            $startTimestamp === false ||
            $endTimestamp === false
        ) {
            $error = 'Invalid event time.';
        } elseif ($endTimestamp <= $startTimestamp) {
            $error = 'End time must be after start time.';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Registration dates
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        if ($registrationOpen === '') {

            $registrationOpen =
                date(
                    'Y-m-d H:i:s'
                );

        } else {

            $registrationOpen =
                str_replace(
                    'T',
                    ' ',
                    $registrationOpen
                );

            if (
                strlen($registrationOpen) === 16
            ) {
                $registrationOpen .= ':00';
            }
        }


        if ($registrationClose === '') {

            $registrationClose =
                date(
                    'Y-m-d H:i:s',
                    strtotime(
                        $eventDate . ' 23:59:59'
                    )
                );

        } else {

            $registrationClose =
                str_replace(
                    'T',
                    ' ',
                    $registrationClose
                );

            if (
                strlen($registrationClose) === 16
            ) {
                $registrationClose .= ':00';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Capacity
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $maxCapacityInt = (int)$maxCapacity;

        if ($maxCapacityInt <= 0) {

            /*
             * Automatically use venue capacity
             */

            $venueCapacityStmt = $db->prepare(
                "SELECT default_capacity
                 FROM venues
                 WHERE venue_id = ?
                   AND status = 'available'
                 LIMIT 1"
            );

            if (!$venueCapacityStmt) {
                $error = 'Unable to check venue capacity.';
            } else {

                $venueCapacityStmt->bind_param(
                    'i',
                    $venueId
                );

                $venueCapacityStmt->execute();

                $venueCapacityResult =
                    $venueCapacityStmt->get_result();

                $venueData =
                    $venueCapacityResult->fetch_assoc();

                $venueCapacityStmt->close();

                if (!$venueData) {

                    $error =
                        'Selected venue is not available.';

                } else {

                    $maxCapacityInt =
                        (int)$venueData['default_capacity'];

                    $maxCapacity =
                        (string)$maxCapacityInt;
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Verify category
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $checkCategory = $db->prepare(
            "SELECT category_id
             FROM event_categories
             WHERE category_id = ?
             LIMIT 1"
        );

        if (!$checkCategory) {

            $error =
                'Category table could not be checked: '
                . $db->error;

        } else {

            $checkCategory->bind_param(
                'i',
                $categoryId
            );

            $checkCategory->execute();

            $categoryExists =
                $checkCategory->get_result()->fetch_assoc();

            $checkCategory->close();

            if (!$categoryExists) {
                $error =
                    'Selected category does not exist.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Verify department
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $checkDepartment = $db->prepare(
            "SELECT department_id
             FROM departments
             WHERE department_id = ?
             LIMIT 1"
        );

        if (!$checkDepartment) {

            $error =
                'Department table could not be checked: '
                . $db->error;

        } else {

            $checkDepartment->bind_param(
                'i',
                $departmentId
            );

            $checkDepartment->execute();

            $departmentExists =
                $checkDepartment->get_result()->fetch_assoc();

            $checkDepartment->close();

            if (!$departmentExists) {
                $error =
                    'Selected department does not exist.';
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Verify venue
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $checkVenue = $db->prepare(
            "SELECT
                venue_id,
                default_capacity
             FROM venues
             WHERE venue_id = ?
               AND status = 'available'
             LIMIT 1"
        );

        if (!$checkVenue) {

            $error =
                'Venue table could not be checked: '
                . $db->error;

        } else {

            $checkVenue->bind_param(
                'i',
                $venueId
            );

            $checkVenue->execute();

            $venueExists =
                $checkVenue->get_result()->fetch_assoc();

            $checkVenue->close();

            if (!$venueExists) {

                $error =
                    'Selected venue is not available.';

            } else {

                $venueDefaultCapacity =
                    (int)$venueExists['default_capacity'];

                if (
                    $maxCapacityInt >
                    $venueDefaultCapacity
                ) {
                    $error =
                        'Maximum capacity cannot exceed the selected venue capacity of '
                        . $venueDefaultCapacity
                        . '.';
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Image upload
    |--------------------------------------------------------------------------
    */

    $imagePath = null;

    if (
        $error === '' &&
        isset($_FILES['featured_image']) &&
        is_array($_FILES['featured_image']) &&
        ($_FILES['featured_image']['error'] ?? UPLOAD_ERR_NO_FILE)
            !== UPLOAD_ERR_NO_FILE
    ) {

        $uploadError =
            (int)$_FILES['featured_image']['error'];

        if (
            $uploadError !== UPLOAD_ERR_OK
        ) {

            $error =
                'Image upload failed. Please try another image.';

        } else {

            $tmpName =
                (string)$_FILES['featured_image']['tmp_name'];

            $originalName =
                (string)$_FILES['featured_image']['name'];

            $fileSize =
                (int)$_FILES['featured_image']['size'];

            if ($fileSize > 5 * 1024 * 1024) {

                $error =
                    'Featured image must be smaller than 5MB.';

            } else {

                $imageInfo =
                    @getimagesize($tmpName);

                if ($imageInfo === false) {

                    $error =
                        'Please upload a valid image file.';

                } else {

                    $mime =
                        (string)($imageInfo['mime'] ?? '');

                    $allowedMime = [
                        'image/jpeg' => 'jpg',
                        'image/png'  => 'png',
                        'image/webp' => 'webp'
                    ];

                    if (
                        !isset(
                            $allowedMime[$mime]
                        )
                    ) {

                        $error =
                            'Only JPG, PNG and WEBP images are allowed.';

                    } else {

                        $uploadDir =
                            __DIR__
                            . DIRECTORY_SEPARATOR
                            . 'uploads'
                            . DIRECTORY_SEPARATOR
                            . 'events';

                        if (
                            !is_dir($uploadDir)
                        ) {
                            mkdir(
                                $uploadDir,
                                0755,
                                true
                            );
                        }

                        $extension =
                            $allowedMime[$mime];

                        $fileName =
                            ce_slug($title)
                            . '-'
                            . date('YmdHis')
                            . '-'
                            . bin2hex(
                                random_bytes(3)
                            )
                            . '.'
                            . $extension;

                        $destination =
                            $uploadDir
                            . DIRECTORY_SEPARATOR
                            . $fileName;

                        if (
                            !move_uploaded_file(
                                $tmpName,
                                $destination
                            )
                        ) {

                            $error =
                                'Unable to save the uploaded image.';

                        } else {

                            $imagePath =
                                'uploads/events/'
                                . $fileName;
                        }
                    }
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Insert Event
    |--------------------------------------------------------------------------
    */

    if ($error === '') {

        $slug = ce_slug($title);

        /*
        |--------------------------------------------------------------------------
        | Make slug unique
        |--------------------------------------------------------------------------
        */

        $originalSlug = $slug;
        $counter = 2;

        while (true) {

            $slugCheck = $db->prepare(
                "SELECT event_id
                 FROM events
                 WHERE slug = ?
                 LIMIT 1"
            );

            if (!$slugCheck) {
                $error =
                    'Unable to check event slug.';
                break;
            }

            $slugCheck->bind_param(
                's',
                $slug
            );

            $slugCheck->execute();

            $slugExists =
                $slugCheck->get_result()->fetch_assoc();

            $slugCheck->close();

            if (!$slugExists) {
                break;
            }

            $slug =
                $originalSlug
                . '-'
                . $counter;

            $counter++;
        }
    }


    if ($error === '') {

        /*
        |--------------------------------------------------------------------------
        | Status
        |--------------------------------------------------------------------------
        |
        | Existing database contains `published`.
        | New organizer-created events are submitted as pending.
        |
        */

        $eventStatus = 'pending';


        /*
        |--------------------------------------------------------------------------
        | Date formatting
        |--------------------------------------------------------------------------
        */

        $eventDateDb = $eventDate;

        $startTimeDb = $startTime;

        $endTimeDb = $endTime;


        /*
        |--------------------------------------------------------------------------
        | Insert
        |--------------------------------------------------------------------------
        |
        | EXACT events columns from your database:
        |
        | title
        | slug
        | short_description
        | description
        | category_id
        | department_id
        | organizer_id
        | venue_id
        | event_date
        | start_time
        | end_time
        | registration_open
        | registration_close
        | event_status
        | featured_image
        | max_capacity
        | waitlist_enabled
        |
        */

        $insertSql = "
            INSERT INTO events (
                title,
                slug,
                short_description,
                description,
                category_id,
                department_id,
                organizer_id,
                venue_id,
                event_date,
                start_time,
                end_time,
                registration_open,
                registration_close,
                event_status,
                featured_image,
                max_capacity,
                waitlist_enabled
            )
            VALUES (
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?,
                ?,
                ?, ?,
                ?
            )
        ";

        $insertStmt =
            $db->prepare($insertSql);

        if (!$insertStmt) {

            $error =
                'Event insert preparation failed: '
                . $db->error;

        } else {

            /*
            |--------------------------------------------------------------------------
            | 17 values
            |--------------------------------------------------------------------------
            | s s s s i i i i s s s s s s s i i
            |--------------------------------------------------------------------------
            */

            $types =
                'ssssiiiissssss s i i';

            /*
             * Remove whitespace from type definition.
             */
            $types =
                str_replace(
                    ' ',
                    '',
                    $types
                );

            $insertStmt->bind_param(
                $types,
                $title,
                $slug,
                $shortDescription,
                $description,
                $categoryId,
                $departmentId,
                $organizerId,
                $venueId,
                $eventDateDb,
                $startTimeDb,
                $endTimeDb,
                $registrationOpen,
                $registrationClose,
                $eventStatus,
                $imagePath,
                $maxCapacityInt,
                $waitlistEnabled
            );


            if (!$insertStmt->execute()) {

                $error =
                    'Unable to create event: '
                    . $insertStmt->error;

            } else {

                $newEventId =
                    (int)$insertStmt->insert_id;

                $insertStmt->close();


                /*
                |--------------------------------------------------------------------------
                | Add organizer relation
                |--------------------------------------------------------------------------
                */

                $relationStmt = $db->prepare(
                    "INSERT INTO event_organizers (
                        event_id,
                        user_id,
                        organizer_role
                    )
                    VALUES (?, ?, 'lead')"
                );

                if ($relationStmt) {

                    $relationStmt->bind_param(
                        'ii',
                        $newEventId,
                        $organizerId
                    );

                    /*
                     * Don't fail the event creation if relation
                     * already exists.
                     */
                    @$relationStmt->execute();

                    $relationStmt->close();
                }


                /*
                |--------------------------------------------------------------------------
                | Success
                |--------------------------------------------------------------------------
                */

                $success =
                    'Event created successfully.';

                /*
                 * Reset form.
                 */
                $title = '';
                $shortDescription = '';
                $description = '';
                $categoryId = 0;
                $departmentId = 0;
                $venueId = 0;
                $eventDate = '';
                $startTime = '';
                $endTime = '';
                $registrationOpen = '';
                $registrationClose = '';
                $maxCapacity = '';
                $waitlistEnabled = 1;
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Create Event | EventSphere</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family:
                Inter,
                ui-sans-serif,
                system-ui,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f8fafc,
                    #eef2ff
                );

            color: #172033;
            min-height: 100vh;
        }

        .topbar {
            height: 72px;
            background: rgba(255,255,255,.92);
            backdrop-filter: blur(18px);
            border-bottom: 1px solid #e5e7eb;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 6%;
            position: sticky;
            top: 0;
            z-index: 20;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 21px;
            font-weight: 800;
            color: #111827;
            text-decoration: none;
        }

        .brand-icon {
            width: 40px;
            height: 40px;
            border-radius: 13px;

            display: grid;
            place-items: center;

            background:
                linear-gradient(
                    135deg,
                    #4f46e5,
                    #7c3aed
                );

            color: white;
            box-shadow:
                0 10px 25px rgba(79,70,229,.25);
        }

        .top-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-pill {
            padding: 10px 15px;
            border-radius: 999px;
            background: #f3f4f6;
            font-size: 13px;
            color: #4b5563;
        }

        .back-btn {
            text-decoration: none;
            color: #4f46e5;
            font-weight: 700;
            font-size: 14px;
        }

        .page {
            width: min(1180px, 92%);
            margin: 45px auto 70px;
        }

        .hero {
            margin-bottom: 30px;
        }

        .eyebrow {
            color: #6366f1;
            font-size: 13px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: .12em;
            margin-bottom: 8px;
        }

        h1 {
            font-size: clamp(30px, 5vw, 46px);
            line-height: 1.08;
            letter-spacing: -.04em;
            color: #111827;
        }

        .hero p {
            margin-top: 12px;
            color: #6b7280;
            max-width: 700px;
            line-height: 1.7;
        }

        .alert {
            padding: 16px 18px;
            border-radius: 15px;
            margin-bottom: 22px;
            font-size: 14px;
            line-height: 1.6;
        }

        .alert-error {
            background: #fff1f2;
            color: #9f1239;
            border: 1px solid #fecdd3;
        }

        .alert-success {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }

        .form-card {
            background: rgba(255,255,255,.95);
            border: 1px solid #e5e7eb;
            border-radius: 25px;
            box-shadow:
                0 20px 60px rgba(15,23,42,.08);
            overflow: hidden;
        }

        .section {
            padding: 30px;
            border-bottom: 1px solid #eef0f4;
        }

        .section:last-child {
            border-bottom: 0;
        }

        .section-title {
            font-size: 18px;
            font-weight: 800;
            color: #111827;
            margin-bottom: 6px;
        }

        .section-subtitle {
            font-size: 13px;
            color: #6b7280;
            margin-bottom: 23px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 20px;
        }

        .grid-3 {
            display: grid;
            grid-template-columns:
                repeat(3, minmax(0,1fr));
            gap: 20px;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .full {
            grid-column: 1 / -1;
        }

        label {
            font-size: 13px;
            font-weight: 750;
            color: #374151;
        }

        input,
        select,
        textarea {
            width: 100%;
            border: 1px solid #dbe0e8;
            background: #fff;
            border-radius: 13px;
            padding: 13px 14px;
            font: inherit;
            color: #111827;
            outline: none;

            transition:
                border-color .2s ease,
                box-shadow .2s ease,
                transform .2s ease;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #6366f1;
            box-shadow:
                0 0 0 4px rgba(99,102,241,.10);
        }

        textarea {
            min-height: 145px;
            resize: vertical;
        }

        .hint {
            font-size: 12px;
            color: #9ca3af;
            line-height: 1.5;
        }

        .venue-info {
            margin-top: 7px;
            padding: 11px 13px;
            background: #f8fafc;
            border-radius: 11px;
            color: #64748b;
            font-size: 12px;
            line-height: 1.5;
        }

        .upload {
            border: 1.5px dashed #c7d2fe;
            background: #f8faff;
            border-radius: 17px;
            padding: 25px;
        }

        .upload input {
            border: 0;
            padding: 0;
            background: transparent;
        }

        .switch-row {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 10px;
        }

        .switch-row input {
            width: 20px;
            height: 20px;
            accent-color: #4f46e5;
        }

        .actions {
            padding: 25px 30px;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            background: #fafafa;
        }

        .btn {
            border: 0;
            border-radius: 13px;
            padding: 13px 21px;
            font-weight: 800;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-secondary {
            background: #eef2f7;
            color: #374151;
        }

        .btn-primary {
            color: white;
            background:
                linear-gradient(
                    135deg,
                    #4f46e5,
                    #7c3aed
                );

            box-shadow:
                0 10px 25px rgba(79,70,229,.22);
        }

        .btn-primary:hover {
            transform: translateY(-1px);
        }

        @media (max-width: 800px) {

            .grid,
            .grid-3 {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            .topbar {
                padding: 0 4%;
            }

            .user-pill {
                display: none;
            }

            .section {
                padding: 22px;
            }

            .actions {
                padding: 20px 22px;
                flex-direction: column;
            }

            .btn {
                text-align: center;
            }
        }

    </style>

</head>

<body>

<header class="topbar">

    <a
        href="dashboard.php"
        class="brand"
    >
        <span class="brand-icon">E</span>
        <span>EventSphere</span>
    </a>

    <div class="top-right">

        <span class="user-pill">
            <?= ce_h($organizer['email'] ?? 'Organizer') ?>
        </span>

        <a
            href="dashboard.php"
            class="back-btn"
        >
            ← Dashboard
        </a>

    </div>

</header>


<main class="page">

    <div class="hero">

        <div class="eyebrow">
            Organizer Workspace
        </div>

        <h1>Create a new event</h1>

        <p>
            Add your event details, select a venue,
            set registration dates and publish it
            for review.
        </p>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-error">
            <strong>Unable to create event.</strong><br>
            <?= ce_h($error) ?>
        </div>

    <?php endif; ?>


    <?php if ($success !== ''): ?>

        <div class="alert alert-success">
            <strong>Success!</strong><br>
            <?= ce_h($success) ?>
            Your event has been submitted successfully.
        </div>

    <?php endif; ?>


    <form
        method="POST"
        enctype="multipart/form-data"
        class="form-card"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= ce_h($csrfToken) ?>"
        >


        <!-- EVENT DETAILS -->

        <section class="section">

            <div class="section-title">
                Event Details
            </div>

            <div class="section-subtitle">
                Give students clear information about your event.
            </div>

            <div class="grid">

                <div class="field full">

                    <label for="title">
                        Event Title *
                    </label>

                    <input
                        type="text"
                        id="title"
                        name="title"
                        maxlength="180"
                        required
                        value="<?= ce_h($title) ?>"
                        placeholder="e.g. CodeSprint 2026"
                    >

                </div>


                <div class="field full">

                    <label for="short_description">
                        Short Description *
                    </label>

                    <input
                        type="text"
                        id="short_description"
                        name="short_description"
                        maxlength="500"
                        required
                        value="<?= ce_h($shortDescription) ?>"
                        placeholder="A short summary of your event"
                    >

                </div>


                <div class="field full">

                    <label for="description">
                        Full Description *
                    </label>

                    <textarea
                        id="description"
                        name="description"
                        required
                        placeholder="Describe the event, activities, eligibility, schedule and important information..."
                    ><?= ce_h($description) ?></textarea>

                </div>

            </div>

        </section>


        <!-- CLASSIFICATION -->

        <section class="section">

            <div class="section-title">
                Classification
            </div>

            <div class="section-subtitle">
                Choose the category and department responsible for this event.
            </div>

            <div class="grid">

                <div class="field">

                    <label for="category_id">
                        Event Category *
                    </label>

                    <select
                        id="category_id"
                        name="category_id"
                        required
                    >

                        <option value="">
                            Select category
                        </option>

                        <?php foreach ($categories as $category): ?>

                            <option
                                value="<?= (int)$category['category_id'] ?>"
                                <?= $categoryId === (int)$category['category_id']
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= ce_h($category['category_label']) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <?php if (!$categories): ?>

                        <div class="hint">
                            No categories found in event_categories.
                        </div>

                    <?php endif; ?>

                </div>


                <div class="field">

                    <label for="department_id">
                        Department *
                    </label>

                    <select
                        id="department_id"
                        name="department_id"
                        required
                    >

                        <option value="">
                            Select department
                        </option>

                        <?php foreach ($departments as $department): ?>

                            <option
                                value="<?= (int)$department['department_id'] ?>"
                                <?= $departmentId === (int)$department['department_id']
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= ce_h($department['department_label']) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                    <?php if (!$departments): ?>

                        <div class="hint">
                            No departments found.
                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </section>


        <!-- DATE AND TIME -->

        <section class="section">

            <div class="section-title">
                Event Schedule
            </div>

            <div class="section-subtitle">
                Set when the event will take place.
            </div>

            <div class="grid-3">

                <div class="field">

                    <label for="event_date">
                        Event Date *
                    </label>

                    <input
                        type="date"
                        id="event_date"
                        name="event_date"
                        required
                        value="<?= ce_h($eventDate) ?>"
                    >

                </div>


                <div class="field">

                    <label for="start_time">
                        Start Time *
                    </label>

                    <input
                        type="time"
                        id="start_time"
                        name="start_time"
                        required
                        value="<?= ce_h($startTime) ?>"
                    >

                </div>


                <div class="field">

                    <label for="end_time">
                        End Time *
                    </label>

                    <input
                        type="time"
                        id="end_time"
                        name="end_time"
                        required
                        value="<?= ce_h($endTime) ?>"
                    >

                </div>

            </div>

        </section>


        <!-- VENUE -->

        <section class="section">

            <div class="section-title">
                Venue & Capacity
            </div>

            <div class="section-subtitle">
                Select an available venue and set the expected capacity.
            </div>

            <div class="grid">

                <div class="field">

                    <label for="venue_id">
                        Venue *
                    </label>

                    <select
                        id="venue_id"
                        name="venue_id"
                        required
                    >

                        <option value="">
                            Select available venue
                        </option>

                        <?php foreach ($venues as $venue): ?>

                            <option
                                value="<?= (int)$venue['venue_id'] ?>"
                                data-capacity="<?= (int)$venue['default_capacity'] ?>"
                                <?= $venueId === (int)$venue['venue_id']
                                    ? 'selected'
                                    : '' ?>
                            >

                                <?= ce_h($venue['venue_name']) ?>
                                —
                                <?= ce_h($venue['building_name']) ?>

                                (Capacity:
                                <?= (int)$venue['default_capacity'] ?>)

                            </option>

                        <?php endforeach; ?>

                    </select>

                    <div
                        class="venue-info"
                        id="venueInfo"
                    >
                        Select a venue to see its capacity.
                    </div>

                </div>


                <div class="field">

                    <label for="max_capacity">
                        Maximum Capacity *
                    </label>

                    <input
                        type="number"
                        id="max_capacity"
                        name="max_capacity"
                        min="1"
                        value="<?= ce_h($maxCapacity) ?>"
                        placeholder="e.g. 120"
                        required
                    >

                    <div class="hint">
                        Capacity cannot be greater than the selected venue capacity.
                    </div>

                </div>

            </div>


            <div class="switch-row">

                <input
                    type="checkbox"
                    id="waitlist_enabled"
                    name="waitlist_enabled"
                    value="1"
                    <?= $waitlistEnabled
                        ? 'checked'
                        : '' ?>
                >

                <label
                    for="waitlist_enabled"
                >
                    Enable waiting list when the event is full
                </label>

            </div>

        </section>


        <!-- REGISTRATION -->

        <section class="section">

            <div class="section-title">
                Registration
            </div>

            <div class="section-subtitle">
                Define when students can register for this event.
            </div>

            <div class="grid">

                <div class="field">

                    <label for="registration_open">
                        Registration Opens
                    </label>

                    <input
                        type="datetime-local"
                        id="registration_open"
                        name="registration_open"
                        value="<?= ce_h(
                            $registrationOpen !== ''
                                ? date(
                                    'Y-m-d\TH:i',
                                    strtotime($registrationOpen)
                                )
                                : ''
                        ) ?>"
                    >

                    <div class="hint">
                        Leave empty to open registration immediately.
                    </div>

                </div>


                <div class="field">

                    <label for="registration_close">
                        Registration Closes
                    </label>

                    <input
                        type="datetime-local"
                        id="registration_close"
                        name="registration_close"
                        value="<?= ce_h(
                            $registrationClose !== ''
                                ? date(
                                    'Y-m-d\TH:i',
                                    strtotime($registrationClose)
                                )
                                : ''
                        ) ?>"
                    >

                    <div class="hint">
                        Leave empty to close registration on the event date.
                    </div>

                </div>

            </div>

        </section>


        <!-- IMAGE -->

        <section class="section">

            <div class="section-title">
                Featured Image
            </div>

            <div class="section-subtitle">
                Add an attractive image for the event listing.
            </div>

            <div class="upload">

                <div class="field">

                    <label for="featured_image">
                        Event Image
                    </label>

                    <input
                        type="file"
                        id="featured_image"
                        name="featured_image"
                        accept="image/jpeg,image/png,image/webp"
                    >

                    <div class="hint">
                        JPG, PNG or WEBP. Maximum size: 5MB.
                    </div>

                </div>

            </div>

        </section>


        <!-- ACTIONS -->

        <div class="actions">

            <a
                href="dashboard.php"
                class="btn btn-secondary"
            >
                Cancel
            </a>

            <button
                type="submit"
                class="btn btn-primary"
            >
                Create Event
            </button>

        </div>

    </form>

</main>


<script>

    const venueSelect =
        document.getElementById('venue_id');

    const capacityInput =
        document.getElementById('max_capacity');

    const venueInfo =
        document.getElementById('venueInfo');


    function updateVenueInfo() {

        const selected =
            venueSelect.options[
                venueSelect.selectedIndex
            ];

        if (
            !selected ||
            !selected.value
        ) {

            venueInfo.textContent =
                'Select a venue to see its capacity.';

            return;
        }

        const capacity =
            selected.dataset.capacity || '0';

        venueInfo.textContent =
            'Maximum venue capacity: '
            + capacity
            + ' participants.';

        if (
            !capacityInput.value ||
            Number(capacityInput.value) > Number(capacity)
        ) {
            capacityInput.value = capacity;
        }

        capacityInput.max = capacity;
    }


    venueSelect.addEventListener(
        'change',
        updateVenueInfo
    );

    updateVenueInfo();


    /*
    |--------------------------------------------------------------------------
    | Registration close cannot be before opening
    |--------------------------------------------------------------------------
    */

    const registrationOpen =
        document.getElementById(
            'registration_open'
        );

    const registrationClose =
        document.getElementById(
            'registration_close'
        );

    registrationOpen.addEventListener(
        'change',
        function () {

            registrationClose.min =
                registrationOpen.value;

        }
    );


    /*
    |--------------------------------------------------------------------------
    | Event end time validation
    |--------------------------------------------------------------------------
    */

    const startTime =
        document.getElementById(
            'start_time'
        );

    const endTime =
        document.getElementById(
            'end_time'
        );

    endTime.addEventListener(
        'change',
        function () {

            if (
                startTime.value &&
                endTime.value &&
                endTime.value <= startTime.value
            ) {

                endTime.setCustomValidity(
                    'End time must be after start time.'
                );

            } else {

                endTime.setCustomValidity('');

            }

        }
    );

</script>

</body>
</html>