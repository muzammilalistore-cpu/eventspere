<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (isset($_SESSION['user']['user_id'])) {
    $role = strtolower(trim((string)($_SESSION['user']['role'] ?? '')));

    if ($role === 'student') {
        header('Location: student-dashboard.php');
        exit;
    }

    if ($role === 'organizer') {
        header('Location: organizer-dashboard.php');
        exit;
    }

    $_SESSION = [];
    session_destroy();
}

$email = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $sql = "
            SELECT
                user_id,
                email,
                password_hash,
                role,
                account_status
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            $error = 'Unable to process login. Please try again.';
        } else {
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $user = $result ? mysqli_fetch_assoc($result) : null;

            mysqli_stmt_close($stmt);

            if (!$user) {
                $error = 'Invalid email or password.';
            } else {
                $accountStatus = strtolower(
                    trim((string)($user['account_status'] ?? ''))
                );

                $role = strtolower(
                    trim((string)($user['role'] ?? ''))
                );

                if ($accountStatus !== 'active') {
                    if ($accountStatus === 'pending') {
                        $error = 'Your account is still pending approval.';
                    } elseif ($accountStatus === 'suspended') {
                        $error = 'Your account has been suspended.';
                    } elseif ($accountStatus === 'blocked') {
                        $error = 'Your account has been blocked.';
                    } else {
                        $error = 'Your account is not active.';
                    }
                } elseif (
                    !password_verify(
                        $password,
                        (string)$user['password_hash']
                    )
                ) {
                    $error = 'Invalid email or password.';
                } elseif (
                    $role !== 'student' &&
                    $role !== 'organizer'
                ) {
                    $error = 'Your account role is not authorized.';
                } else {
                    session_regenerate_id(true);

                    $_SESSION['user'] = [
                        'user_id' => (int)$user['user_id'],
                        'email' => (string)$user['email'],
                        'role' => $role,
                        'account_status' => $accountStatus
                    ];

                    if ($role === 'student') {
                        header('Location: student-dashboard.php');
                        exit;
                    }

                    if ($role === 'organizer') {
                        header('Location: organizer-dashboard.php');
                        exit;
                    }
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login | EventSphere</title>

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family:
                Inter,
                ui-sans-serif,
                system-ui,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;
            color: #111827;
            background:
                radial-gradient(
                    circle at 8% 10%,
                    rgba(99, 102, 241, .12),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 92% 90%,
                    rgba(34, 211, 238, .10),
                    transparent 28%
                ),
                #f8fafc;
        }

        .login-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 45px 20px;
        }

        .login-wrapper {
            position: relative;
            width: 100%;
            max-width: 1120px;
            overflow: hidden;
            display: grid;
            grid-template-columns: 1.05fr .95fr;
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 28px;
            box-shadow:
                0 30px 80px
                rgba(15, 23, 42, .12);
        }

        .login-wrapper::before {
            content: "";
            position: absolute;
            width: 320px;
            height: 320px;
            right: -160px;
            top: -160px;
            border-radius: 50%;
            background:
                rgba(99, 102, 241, .08);
            filter: blur(4px);
            pointer-events: none;
        }

        .login-info {
            position: relative;
            min-height: 650px;
            padding: 58px 48px;
            overflow: hidden;
            color: #ffffff;
            background:
                radial-gradient(
                    circle at 85% 15%,
                    rgba(129, 140, 248, .30),
                    transparent 31%
                ),
                radial-gradient(
                    circle at 10% 85%,
                    rgba(34, 211, 238, .15),
                    transparent 30%
                ),
                linear-gradient(
                    145deg,
                    #070b16,
                    #111827 55%,
                    #1e1b4b
                );
        }

        .login-info::before {
            content: "";
            position: absolute;
            width: 180px;
            height: 180px;
            left: -100px;
            top: 45%;
            border: 1px solid
                rgba(255,255,255,.08);
            border-radius: 50%;
        }

        .login-info::after {
            content: "";
            position: absolute;
            width: 280px;
            height: 280px;
            right: -135px;
            bottom: -135px;
            border:
                1px solid
                rgba(255,255,255,.10);
            border-radius: 50%;
        }

        .login-info-content {
            position: relative;
            z-index: 2;
        }

        .login-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 42px;
        }

        .login-brand-icon {
            width: 46px;
            height: 46px;
            display: grid;
            place-items: center;
            border-radius: 13px;
            color: #ffffff;
            font-size: 13px;
            font-weight: 900;
            background:
                linear-gradient(
                    135deg,
                    #6366f1,
                    #7c3aed
                );
            box-shadow:
                0 12px 30px
                rgba(99,102,241,.30);
        }

        .login-brand-text strong {
            display: block;
            font-size: 1rem;
            font-weight: 850;
            letter-spacing: -.02em;
        }

        .login-brand-text span {
            display: block;
            margin-top: 2px;
            color: #94a3b8;
            font-size: .7rem;
        }

        .login-label {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 13px;
            border:
                1px solid
                rgba(255,255,255,.13);
            border-radius: 999px;
            background:
                rgba(255,255,255,.06);
            color: #c7d2fe;
            font-size: .7rem;
            font-weight: 800;
            letter-spacing: .08em;
            text-transform: uppercase;
        }

        .login-label::before {
            content: "";
            width: 7px;
            height: 7px;
            flex: 0 0 7px;
            border-radius: 50%;
            background: #34d399;
            box-shadow:
                0 0 14px
                #34d399;
        }

        .login-heading {
            margin: 25px 0 0;
            max-width: 550px;
            font-size:
                clamp(
                    2.5rem,
                    5vw,
                    4.2rem
                );
            line-height: .98;
            font-weight: 850;
            letter-spacing: -.06em;
        }

        .login-heading span {
            background:
                linear-gradient(
                    100deg,
                    #a5b4fc,
                    #67e8f9
                );
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .login-description {
            max-width: 470px;
            margin-top: 21px;
            color: #cbd5e1;
            font-size: .92rem;
            line-height: 1.75;
        }

        .login-benefits {
            display: grid;
            gap: 12px;
            margin-top: 34px;
        }

        .login-benefit {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 13px 14px;
            border:
                1px solid
                rgba(255,255,255,.09);
            border-radius: 14px;
            background:
                rgba(255,255,255,.045);
            transition:
                transform .25s ease,
                *background* .25s ease,
                border-color .25s ease;
        }

        .login-benefit:hover {
            transform: translateX(5px);
            background:
                rgba(255,255,255,.075);
            border-color:
                rgba(255,255,255,.14);
        }

        .login-benefit-icon {
            width: 39px;
            height: 39px;
            flex: 0 0 39px;
            display: grid;
            place-items: center;
            border-radius: 11px;
            background:
                rgba(99,102,241,.18);
            color: #a5b4fc;
            font-size: .72rem;
            font-weight: 850;
        }

        .login-benefit strong {
            display: block;
            color: #ffffff;
            font-size: .86rem;
            font-weight: 750;
        }

        .login-benefit small {
            display: block;
            margin-top: 2px;
            color: #94a3b8;
            font-size: .72rem;
        }

        .login-form-area {
            position: relative;
            z-index: 2;
            display: flex;
            align-items: center;
            padding: 58px 48px;
            background: #ffffff;
        }

        .login-form-inner {
            width: 100%;
            max-width: 430px;
            margin: 0 auto;
        }

        .login-form-heading {
            margin-bottom: 29px;
        }

        .login-form-heading h2 {
            margin: 0;
            color: #111827;
            font-size: 2rem;
            font-weight: 850;
            letter-spacing: -.045em;
        }

        .login-form-heading p {
            margin: 8px 0 0;
            color: #64748b;
            font-size: .88rem;
            line-height: 1.6;
        }

        .login-alert {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            margin-bottom: 20px;
            padding: 12px 14px;
            border:
                1px solid
                #fecaca;
            border-radius: 11px;
            background: #fef2f2;
            color: #dc2626;
            font-size: .78rem;
            line-height: 1.5;
        }

        .login-alert-icon {
            flex: 0 0 auto;
            font-weight: 900;
        }

        .login-form-group {
            margin-bottom: 18px;
        }

        .login-form-label {
            display: block;
            margin-bottom: 7px;
            color: #334155;
            font-size: .78rem;
            font-weight: 750;
        }

        .login-input {
            width: 100%;
            min-height: 49px;
            padding: 11px 14px;
            border:
                1px solid
                #dbe1ea;
            border-radius: 12px;
            outline: none;
            background: #f8fafc;
            color: #111827;
            font-family: inherit;
            font-size: .9rem;
            transition:
                border-color .25s ease,
                *background* .25s ease,
                box-shadow .25s ease,
                transform .2s ease;
        }

        .login-input::placeholder {
            color: #94a3b8;
        }

        .login-input:hover {
            border-color: #cbd5e1;
        }

        .login-input:focus {
            border-color: #6366f1;
            background: #ffffff;
            box-shadow:
                0 0 0 4px
                rgba(99,102,241,.10);
        }

        .login-password-wrap {
            position: relative;
        }

        .login-password-wrap .login-input {
            padding-right: 70px;
        }

        .login-toggle-password {
            position: absolute;
            right: 9px;
            top: 50%;
            transform: translateY(-50%);
            min-width: 45px;
            height: 30px;
            padding: 0 7px;
            border: 0;
            border-radius: 7px;
            background: transparent;
            color: #4f46e5;
            font-family: inherit;
            font-size: .7rem;
            font-weight: 800;
            cursor: pointer;
            transition:
                *background* .2s ease,
                color .2s ease;
        }

        .login-toggle-password:hover {
            background: #eef2ff;
            color: #3730a3;
        }

        .login-options {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-top: -2px;
            margin-bottom: 21px;
        }

        .login-remember {
            display: flex;
            align-items: center;
            gap: 7px;
            color: #64748b;
            font-size: .75rem;
            cursor: pointer;
        }

        .login-remember input {
            width: 15px;
            height: 15px;
            accent-color: #4f46e5;
            cursor: pointer;
        }

        .login-forgot {
            color: #4f46e5;
            font-size: .75rem;
            font-weight: 750;
            text-decoration: none;
        }

        .login-forgot:hover {
            color: #3730a3;
            text-decoration: underline;
        }

        .login-button {
            width: 100%;
            min-height: 51px;
            border: 0;
            border-radius: 13px;
            color: #ffffff;
            background:
                linear-gradient(
                    135deg,
                    #6366f1,
                    #4f46e5
                );
            font-family: inherit;
            font-size: .9rem;
            font-weight: 800;
            cursor: pointer;
            box-shadow:
                0 12px 30px
                rgba(79,70,229,.22);
            transition:
                transform .25s ease,
                box-shadow .25s ease,
                filter .25s ease;
        }

        .login-button:hover {
            transform: translateY(-2px);
            filter: brightness(1.02);
            box-shadow:
                0 18px 40px
                rgba(79,70,229,.30);
        }

        .login-button:active {
            transform: translateY(0);
            box-shadow:
                0 8px 20px
                rgba(79,70,229,.20);
        }

        .login-security-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            margin-top: 17px;
            padding: 11px 13px;
            border:
                1px solid
                #edf1f5;
            border-radius: 10px;
            background: #f8fafc;
            color: #94a3b8;
            font-size: .69rem;
            line-height: 1.5;
            text-align: center;
        }

        .register-note {
            margin-top: 23px;
            text-align: center;
            color: #64748b;
            font-size: .84rem;
        }

        .register-note a {
            color: #4f46e5;
            font-weight: 750;
            text-decoration: none;
        }

        .register-note a:hover {
            color: #3730a3;
            text-decoration: underline;
        }

        @media (max-width: 991px) {
            .login-wrapper {
                grid-template-columns: 1fr;
            }

            .login-info {
                min-height: auto;
                padding: 42px 35px;
            }

            .login-form-area {
                padding: 42px 35px;
            }

            .login-benefits {
                grid-template-columns:
                    repeat(3, 1fr);
            }

            .login-heading {
                font-size: 3rem;
            }
        }

        @media (max-width: 767px) {
            .login-page {
                padding: 20px 14px;
            }

            .login-wrapper {
                border-radius: 21px;
            }

            .login-info {
                padding: 34px 24px;
            }

            .login-form-area {
                padding: 34px 24px;
            }

            .login-brand {
                margin-bottom: 30px;
            }

            .login-heading {
                font-size: 2.55rem;
            }

            .login-benefits {
                grid-template-columns: 1fr;
            }

            .login-form-heading h2 {
                font-size: 1.75rem;
            }
        }

        @media (max-width: 400px) {
            .login-page {
                padding: 12px;
            }

            .login-info {
                padding: 30px 20px;
            }

            .login-form-area {
                padding: 30px 20px;
            }

            .login-heading {
                font-size: 2.25rem;
            }

            .login-options {
                align-items: flex-start;
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>

<body>

<div class="login-page">

    <div class="login-wrapper">

        <section class="login-info">

            <div class="login-info-content">

                <div class="login-brand">
                    <div class="login-brand-icon">
                        ES
                    </div>

                    <div class="login-brand-text">
                        <strong>EventSphere</strong>

                        <span>
                            Campus Events Management Platform
                        </span>
                    </div>
                </div>

                <div class="login-label">
                    Secure Student Access
                </div>

                <h1 class="login-heading">
                    Welcome back to
                    <span>EventSphere.</span>
                </h1>

                <p class="login-description">
                    Sign in to manage your event registrations,
                    view personalized updates, track your
                    participation and stay connected with
                    campus activities.
                </p>

                <div class="login-benefits">

                    <div class="login-benefit">
                        <div class="login-benefit-icon">
                            01
                        </div>

                        <div>
                            <strong>Discover Events</strong>

                            <small>
                                Explore upcoming campus activities.
                            </small>
                        </div>
                    </div>

                    <div class="login-benefit">
                        <div class="login-benefit-icon">
                            02
                        </div>

                        <div>
                            <strong>Manage Registrations</strong>

                            <small>
                                Keep your event participation organized.
                            </small>
                        </div>
                    </div>

                    <div class="login-benefit">
                        <div class="login-benefit-icon">
                            03
                        </div>

                        <div>
                            <strong>Stay Updated</strong>

                            <small>
                                Receive important event announcements.
                            </small>
                        </div>
                    </div>

                </div>

            </div>

        </section>

        <section class="login-form-area">

            <div class="login-form-inner">

                <div class="login-form-heading">
                    <h2>Welcome back</h2>

                    <p>
                        Sign in to continue to your EventSphere account.
                    </p>
                </div>

                <?php if ($error !== ''): ?>

                    <div class="login-alert">
                        <span class="login-alert-icon">!</span>

                        <span>
                            <?= htmlspecialchars(
                                $error,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>
                    </div>

                <?php endif; ?>

                <form
                    method="POST"
                    action=""
                    autocomplete="on"
                >

                    <div class="login-form-group">

                        <label
                            for="email"
                            class="login-form-label"
                        >
                            Email Address
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            class="login-input"
                            placeholder="Enter your email address"
                            value="<?= htmlspecialchars(
                                $email,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            autocomplete="email"
                            required
                        >

                    </div>

                    <div class="login-form-group">

                        <label
                            for="password"
                            class="login-form-label"
                        >
                            Password
                        </label>

                        <div class="login-password-wrap">

                            <input
                                type="password"
                                id="password"
                                name="password"
                                class="login-input"
                                placeholder="Enter your password"
                                autocomplete="current-password"
                                required
                            >

                            <button
                                type="button"
                                class="login-toggle-password"
                                id="togglePassword"
                            >
                                Show
                            </button>

                        </div>

                    </div>

                    <div class="login-options">

                        <label class="login-remember">

                            <input
                                type="checkbox"
                                name="remember"
                                value="1"
                            >

                            Remember me

                        </label>

                        <a
                            href="#"
                            class="login-forgot"
                            onclick="return false;"
                        >
                            Forgot password?
                        </a>

                    </div>

                    <button
                        type="submit"
                        class="login-button"
                    >
                        Sign In
                    </button>

                </form>

                <div class="login-security-note">
                    <span>🔒</span>

                    <span>
                        Your account role determines the dashboard
                        you access after signing in.
                    </span>
                </div>

                <div class="register-note">
                    Don't have an account?

                    <a href="register.php">
                        Create account
                    </a>
                </div>

            </div>

        </section>

    </div>

</div>

<script>
    const password = document.getElementById('password');
    const togglePassword = document.getElementById('togglePassword');

    if (password && togglePassword) {
        togglePassword.addEventListener('click', function () {
            const isPassword = password.type === 'password';

            password.type = isPassword ? 'text' : 'password';
            togglePassword.textContent = isPassword ? 'Hide' : 'Show';
        });
    }
</script>

</body>
</html>