<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| EventSphere - Organizer Gallery
|--------------------------------------------------------------------------
| Only authenticated organizers can access this page.
| Students are redirected to student-dashboard.php.
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

if (!function_exists('gallery_h')) {
    function gallery_h(mixed $value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Check Session
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user']) ||
    !is_array($_SESSION['user'])
) {
    header('Location: organizer-login.php');
    exit;
}

$user = $_SESSION['user'];

$userId = (int)(
    $user['user_id'] ?? 0
);

$sessionRole = strtolower(
    trim(
        (string)(
            $user['role'] ?? ''
        )
    )
);

if ($userId <= 0) {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    header('Location: organizer-login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Get Current User From Database
|--------------------------------------------------------------------------
| Do not trust only the session role.
|--------------------------------------------------------------------------
*/

$userStmt = mysqli_prepare(
    $conn,
    "
    SELECT
        user_id,
        role,
        account_status
    FROM users
    WHERE user_id = ?
    LIMIT 1
    "
);

if (!$userStmt) {

    die(
        'Unable to verify account: ' .
        gallery_h(mysqli_error($conn))
    );
}

mysqli_stmt_bind_param(
    $userStmt,
    'i',
    $userId
);

if (!mysqli_stmt_execute($userStmt)) {

    mysqli_stmt_close($userStmt);

    die(
        'Unable to verify account: ' .
        gallery_h(mysqli_error($conn))
    );
}

mysqli_stmt_bind_result(
    $userStmt,
    $dbUserId,
    $dbRole,
    $accountStatus
);

$foundUser = mysqli_stmt_fetch($userStmt);

mysqli_stmt_close($userStmt);

/*
|--------------------------------------------------------------------------
| Account Not Found
|--------------------------------------------------------------------------
*/

if (!$foundUser) {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    header('Location: organizer-login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Normalize Database Values
|--------------------------------------------------------------------------
*/

$dbRole = strtolower(
    trim(
        (string)$dbRole
    )
);

$accountStatus = strtolower(
    trim(
        (string)$accountStatus
    )
);

/*
|--------------------------------------------------------------------------
| STUDENT
|--------------------------------------------------------------------------
| Student should NOT access organizer gallery.
|--------------------------------------------------------------------------
*/

if ($dbRole === 'student') {

    header('Location: student-dashboard.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| ORGANIZER
|--------------------------------------------------------------------------
*/

if ($dbRole !== 'organizer') {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    header('Location: organizer-login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Account Status
|--------------------------------------------------------------------------
*/

if ($accountStatus !== 'active') {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    header('Location: organizer-login.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Keep Session Data Consistent
|--------------------------------------------------------------------------
*/

$_SESSION['user']['user_id'] = (int)$dbUserId;
$_SESSION['user']['role'] = 'organizer';

/*
|--------------------------------------------------------------------------
| Gallery Data
|--------------------------------------------------------------------------
*/

$galleryItems = [];

$gallerySql = "
    SELECT
        e.event_id,
        e.title,
        e.slug,
        e.short_description,
        e.description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.event_status,
        e.featured_image,
        e.max_capacity,

        c.category_id,
        c.category_name,
        c.icon,

        d.department_id,
        d.department_name,
        d.department_code,

        v.venue_id,
        v.venue_name,
        v.building_name,
        v.floor_no

    FROM events e

    LEFT JOIN event_categories c
        ON c.category_id = e.category_id

    LEFT JOIN departments d
        ON d.department_id = e.department_id

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    WHERE e.organizer_id = ?
      AND e.featured_image IS NOT NULL
      AND e.featured_image <> ''

    ORDER BY
        e.event_date DESC,
        e.event_id DESC
";

$galleryStmt = mysqli_prepare(
    $conn,
    $gallerySql
);

if (!$galleryStmt) {

    die(
        'Unable to load gallery: ' .
        gallery_h(mysqli_error($conn))
    );
}

mysqli_stmt_bind_param(
    $galleryStmt,
    'i',
    $userId
);

if (!mysqli_stmt_execute($galleryStmt)) {

    $error = mysqli_stmt_error($galleryStmt);

    mysqli_stmt_close($galleryStmt);

    die(
        'Unable to load gallery: ' .
        gallery_h($error)
    );
}

/*
|--------------------------------------------------------------------------
| Bind Result
|--------------------------------------------------------------------------
*/

mysqli_stmt_bind_result(
    $galleryStmt,

    $eventId,
    $title,
    $slug,
    $shortDescription,
    $description,
    $eventDate,
    $startTime,
    $endTime,
    $eventStatus,
    $featuredImage,
    $maxCapacity,

    $categoryId,
    $categoryName,
    $categoryIcon,

    $departmentId,
    $departmentName,
    $departmentCode,

    $venueId,
    $venueName,
    $buildingName,
    $floorNo
);

while (mysqli_stmt_fetch($galleryStmt)) {

    $galleryItems[] = [

        'event_id' => $eventId,

        'title' => $title,

        'slug' => $slug,

        'short_description' => $shortDescription,

        'description' => $description,

        'event_date' => $eventDate,

        'start_time' => $startTime,

        'end_time' => $endTime,

        'event_status' => $eventStatus,

        'featured_image' => $featuredImage,

        'max_capacity' => $maxCapacity,

        'category_id' => $categoryId,

        'category_name' => $categoryName,

        'icon' => $categoryIcon,

        'department_id' => $departmentId,

        'department_name' => $departmentName,

        'department_code' => $departmentCode,

        'venue_id' => $venueId,

        'venue_name' => $venueName,

        'building_name' => $buildingName,

        'floor_no' => $floorNo
    ];
}

mysqli_stmt_close($galleryStmt);

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$totalImages = count($galleryItems);

$publishedImages = 0;

$draftImages = 0;

$categoryCounts = [];

foreach ($galleryItems as $item) {

    $status = strtolower(
        trim(
            (string)(
                $item['event_status'] ?? ''
            )
        )
    );

    if ($status === 'published') {
        $publishedImages++;
    }

    if ($status === 'draft') {
        $draftImages++;
    }

    $categoryName = trim(
        (string)(
            $item['category_name'] ?? 'Other'
        )
    );

    if ($categoryName === '') {
        $categoryName = 'Other';
    }

    if (!isset($categoryCounts[$categoryName])) {
        $categoryCounts[$categoryName] = 0;
    }

    $categoryCounts[$categoryName]++;
}

ksort($categoryCounts);

/*
|--------------------------------------------------------------------------
| Image Path Helper
|--------------------------------------------------------------------------
| Database examples:
| uploads/codesprint.jpg
| uploads/cricket-cup.jpg
| uploads/ai-seminar.jpg
|--------------------------------------------------------------------------
*/

function gallery_image_url(string $path): string
{
    $path = trim($path);

    if ($path === '') {
        return '';
    }

    /*
    | If already absolute URL
    */
    if (
        preg_match(
            '#^(https?:)?//#i',
            $path
        )
    ) {
        return $path;
    }

    /*
    | Remove leading slash
    */
    $path = ltrim(
        str_replace(
            '\\',
            '/',
            $path
        ),
        '/'
    );

    /*
    | uploads/xxx.jpg
    | becomes /eventsphere/uploads/xxx.jpg
    |
    | Assumes this file is inside:
    | C:\xampp\htdocs\eventsphere\
    */

    return '/' .
        trim(
            basename(
                dirname(
                    __FILE__
                )
            ),
            '/'
        ) .
        '/' .
        $path;
}

/*
|--------------------------------------------------------------------------
| Page
|--------------------------------------------------------------------------
*/

$pageTitle = 'Organizer Gallery | EventSphere';

require __DIR__ . '/header.php';

?>

<style>

/* =========================================================
   EVENTSPHERE ORGANIZER GALLERY
   ========================================================= */

.gallery-page {
    padding: 42px 0 85px;
}

/* =========================================================
   HERO
   ========================================================= */

.gallery-hero {
    position: relative;
    overflow: hidden;
    padding: 42px;
    border-radius: 28px;
    color: #fff;

    background:
        radial-gradient(
            circle at 88% 10%,
            rgba(99, 102, 241, .42),
            transparent 30%
        ),
        radial-gradient(
            circle at 8% 92%,
            rgba(34, 211, 238, .18),
            transparent 32%
        ),
        linear-gradient(
            135deg,
            #0f172a 0%,
            #172554 52%,
            #312e81 100%
        );

    box-shadow:
        0 25px 70px rgba(15, 23, 42, .18);
}

.gallery-hero::before {
    content: "";
    position: absolute;

    width: 260px;
    height: 260px;

    right: -100px;
    top: -100px;

    border-radius: 50%;

    border: 1px solid rgba(255, 255, 255, .12);

    animation:
        heroFloat 7s ease-in-out infinite;
}

.gallery-hero::after {
    content: "";

    position: absolute;

    width: 120px;
    height: 120px;

    left: -55px;
    bottom: -55px;

    border-radius: 50%;

    background:
        rgba(255, 255, 255, .035);

    animation:
        heroFloat 9s ease-in-out infinite reverse;
}

@keyframes heroFloat {

    0%,
    100% {
        transform:
            translateY(0)
            rotate(0deg);
    }

    50% {
        transform:
            translateY(-12px)
            rotate(5deg);
    }
}

.gallery-hero-content {
    position: relative;
    z-index: 2;
}

.gallery-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 7px;

    color: #a5b4fc;

    font-size: 11px;
    font-weight: 850;

    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.gallery-eyebrow::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #818cf8;

    box-shadow:
        0 0 0 5px
        rgba(129, 140, 248, .12);
}

.gallery-hero h1 {
    margin: 10px 0 8px;

    font-size: 37px;
    line-height: 1.1;

    font-weight: 850;

    letter-spacing: -.8px;
}

.gallery-hero p {
    max-width: 680px;

    margin: 0;

    color: #cbd5e1;

    font-size: 14px;
    line-height: 1.7;
}

/* =========================================================
   STATS
   ========================================================= */

.gallery-stats {
    margin-top: 25px;
}

.gallery-stat {
    position: relative;
    overflow: hidden;

    height: 100%;

    padding: 22px;

    border: 1px solid #e8edf3;

    border-radius: 19px;

    background: #fff;

    box-shadow:
        0 9px 30px
        rgba(15, 23, 42, .045);

    transition:
        transform .25s ease,
        box-shadow .25s ease;
}

.gallery-stat:hover {
    transform: translateY(-4px);

    box-shadow:
        0 18px 42px
        rgba(15, 23, 42, .09);
}

.gallery-stat::after {
    content: "";

    position: absolute;

    right: -35px;
    bottom: -55px;

    width: 120px;
    height: 120px;

    border-radius: 50%;

    background:
        rgba(99, 102, 241, .06);
}

.gallery-stat-label {
    position: relative;
    z-index: 2;

    color: #94a3b8;

    font-size: 10px;
    font-weight: 850;

    letter-spacing: .7px;

    text-transform: uppercase;
}

.gallery-stat-number {
    position: relative;
    z-index: 2;

    margin-top: 7px;

    color: #0f172a;

    font-size: 30px;
    line-height: 1;

    font-weight: 850;
}

/* =========================================================
   MAIN GALLERY BOX
   ========================================================= */

.gallery-box {
    margin-top: 28px;

    padding: 29px;

    border: 1px solid #e8edf3;

    border-radius: 22px;

    background: #fff;

    box-shadow:
        0 10px 35px
        rgba(15, 23, 42, .045);
}

.gallery-header {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 20px;

    margin-bottom: 23px;
}

.gallery-header h2 {
    margin: 0;

    color: #0f172a;

    font-size: 21px;

    font-weight: 850;
}

.gallery-header p {
    margin: 5px 0 0;

    color: #94a3b8;

    font-size: 12px;
}

/* =========================================================
   FILTERS
   ========================================================= */

.gallery-filters {
    display: flex;

    flex-wrap: wrap;

    gap: 10px;

    margin-bottom: 25px;
}

.gallery-filter {
    min-height: 38px;

    padding: 0 14px;

    border: 1px solid #e2e8f0;

    border-radius: 999px;

    background: #fff;

    color: #64748b;

    font-size: 10px;
    font-weight: 800;

    cursor: pointer;

    transition:
        color .2s ease,
        background .2s ease,
        border-color .2s ease,
        transform .2s ease;
}

.gallery-filter:hover {
    color: #4f46e5;

    border-color: #c7d2fe;

    background: #eef2ff;

    transform: translateY(-1px);
}

.gallery-filter.active {
    color: #fff;

    border-color: #4f46e5;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    box-shadow:
        0 7px 18px
        rgba(79, 70, 229, .20);
}

/* =========================================================
   SEARCH
   ========================================================= */

.gallery-search {
    position: relative;

    margin-bottom: 22px;
}

.gallery-search input {
    width: 100%;

    min-height: 46px;

    padding:
        0 16px 0 42px;

    border: 1px solid #dfe5ec;

    border-radius: 12px;

    outline: none;

    color: #334155;

    font-size: 12px;

    transition:
        border-color .2s ease,
        box-shadow .2s ease;
}

.gallery-search input:focus {
    border-color: #818cf8;

    box-shadow:
        0 0 0 3px
        rgba(99, 102, 241, .12);
}

.gallery-search-icon {
    position: absolute;

    left: 15px;
    top: 50%;

    transform:
        translateY(-50%);

    color: #94a3b8;

    font-size: 15px;
}

/* =========================================================
   GALLERY CARD
   ========================================================= */

.gallery-item {
    position: relative;
    overflow: hidden;

    height: 100%;

    border: 1px solid #e8edf3;

    border-radius: 18px;

    background: #fff;

    box-shadow:
        0 8px 25px
        rgba(15, 23, 42, .045);

    transition:
        transform .3s ease,
        box-shadow .3s ease,
        border-color .3s ease;

    animation:
        galleryAppear .5s ease both;
}

.gallery-item:hover {
    transform:
        translateY(-6px);

    border-color:
        #d9defa;

    box-shadow:
        0 20px 45px
        rgba(15, 23, 42, .11);
}

@keyframes galleryAppear {

    from {
        opacity: 0;

        transform:
            translateY(15px);
    }

    to {
        opacity: 1;

        transform:
            translateY(0);
    }
}

/* =========================================================
   IMAGE
   ========================================================= */

.gallery-image-wrap {
    position: relative;
    overflow: hidden;

    height: 230px;

    background:
        linear-gradient(
            135deg,
            #eef2ff,
            #f8fafc
        );
}

.gallery-image {
    width: 100%;
    height: 100%;

    display: block;

    object-fit: cover;

    transition:
        transform .55s ease,
        filter .4s ease;
}

.gallery-item:hover .gallery-image {
    transform:
        scale(1.07);

    filter:
        brightness(.82);
}

.gallery-overlay {
    position: absolute;

    inset: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    opacity: 0;

    background:
        linear-gradient(
            180deg,
            rgba(15, 23, 42, .08),
            rgba(15, 23, 42, .58)
        );

    transition:
        opacity .3s ease;
}

.gallery-item:hover .gallery-overlay {
    opacity: 1;
}

.view-image-btn {
    width: 50px;
    height: 50px;

    display: flex;

    align-items: center;
    justify-content: center;

    border:
        1px solid
        rgba(255, 255, 255, .35);

    border-radius: 50%;

    color: #fff;

    background:
        rgba(15, 23, 42, .48);

    backdrop-filter:
        blur(8px);

    cursor: pointer;

    font-size: 19px;

    transform:
        scale(.8);

    transition:
        transform .25s ease,
        background .25s ease;
}

.gallery-item:hover .view-image-btn {
    transform:
        scale(1);
}

.view-image-btn:hover {
    background:
        rgba(99, 102, 241, .9);
}

/* =========================================================
   CARD CONTENT
   ========================================================= */

.gallery-content {
    padding: 20px;
}

.gallery-category {
    display: inline-flex;

    padding:
        6px 10px;

    border-radius: 999px;

    color: #4f46e5;

    background: #eef2ff;

    font-size: 9px;
    font-weight: 850;

    letter-spacing: .4px;

    text-transform: uppercase;
}

.gallery-title {
    margin:
        12px 0 7px;

    color: #172033;

    font-size: 17px;
    line-height: 1.35;

    font-weight: 850;
}

.gallery-description {
    min-height: 42px;

    color: #64748b;

    font-size: 11px;
    line-height: 1.65;
}

.gallery-meta {
    margin-top: 17px;

    padding-top: 15px;

    border-top:
        1px solid
        #e8edf3;
}

.gallery-meta-row {
    display: flex;

    align-items: flex-start;

    gap: 7px;

    margin-bottom: 8px;

    color: #64748b;

    font-size: 10px;
    line-height: 1.5;
}

.gallery-meta-row:last-child {
    margin-bottom: 0;
}

.gallery-meta-row strong {
    color: #334155;
}

/* =========================================================
   STATUS
   ========================================================= */

.gallery-status {
    position: absolute;

    top: 13px;
    right: 13px;

    z-index: 5;

    display: inline-flex;

    padding:
        6px 9px;

    border-radius: 999px;

    font-size: 8px;
    font-weight: 850;

    letter-spacing: .5px;

    text-transform: uppercase;

    backdrop-filter:
        blur(8px);
}

.gallery-status.published {
    color: #047857;

    background:
        rgba(236, 253, 245, .95);
}

.gallery-status.draft {
    color: #92400e;

    background:
        rgba(255, 251, 235, .95);
}

/* =========================================================
   ACTION
   ========================================================= */

.gallery-action {
    width: 100%;

    min-height: 39px;

    margin-top: 17px;

    display: flex;

    align-items: center;
    justify-content: center;

    border:
        1px solid
        #dfe5ec;

    border-radius: 9px;

    color: #334155;

    background: #fff;

    text-decoration: none;

    font-size: 10px;
    font-weight: 800;

    transition: .2s ease;
}

.gallery-action:hover {
    color: #4f46e5;

    border-color:
        #c7d2fe;

    background:
        #eef2ff;
}

/* =========================================================
   EMPTY STATE
   ========================================================= */

.gallery-empty {
    padding:
        70px 20px;

    text-align: center;

    border:
        1px dashed
        #dbe2ea;

    border-radius: 17px;

    background:
        #fafbfc;
}

.gallery-empty-icon {
    width: 64px;
    height: 64px;

    margin:
        0 auto 16px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 18px;

    color: #4f46e5;

    background:
        #eef2ff;

    font-size: 25px;
}

.gallery-empty h3 {
    margin-bottom: 7px;

    color: #172033;

    font-size: 18px;

    font-weight: 850;
}

.gallery-empty p {
    max-width: 480px;

    margin:
        0 auto;

    color: #94a3b8;

    font-size: 12px;

    line-height: 1.6;
}

/* =========================================================
   LIGHTBOX
   ========================================================= */

.gallery-lightbox {
    position: fixed;

    inset: 0;

    z-index: 99999;

    display: none;

    align-items: center;
    justify-content: center;

    padding: 25px;

    background:
        rgba(2, 6, 23, .88);

    backdrop-filter:
        blur(10px);
}

.gallery-lightbox.show {
    display: flex;

    animation:
        lightboxFade .25s ease;
}

@keyframes lightboxFade {

    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
}

.lightbox-inner {
    position: relative;

    max-width: 1100px;

    width: 100%;

    animation:
        lightboxZoom .3s ease;
}

@keyframes lightboxZoom {

    from {
        transform:
            scale(.92);
    }

    to {
        transform:
            scale(1);
    }
}

.lightbox-image {
    width: 100%;

    max-height: 80vh;

    display: block;

    object-fit: contain;

    border-radius: 16px;

    box-shadow:
        0 30px 100px
        rgba(0, 0, 0, .45);
}

.lightbox-close {
    position: absolute;

    right: -8px;
    top: -48px;

    width: 40px;
    height: 40px;

    border: 0;

    border-radius: 50%;

    color: #fff;

    background:
        rgba(255, 255, 255, .12);

    cursor: pointer;

    font-size: 20px;
}

.lightbox-title {
    margin-top: 13px;

    color: #fff;

    text-align: center;

    font-size: 13px;

    font-weight: 750;
}

/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 767px) {

    .gallery-page {
        padding:
            25px 0 55px;
    }

    .gallery-hero {
        padding:
            29px 22px;

        border-radius:
            21px;
    }

    .gallery-hero h1 {
        font-size: 28px;
    }

    .gallery-box {
        padding: 20px;
    }

    .gallery-header {
        align-items: flex-start;

        flex-direction: column;
    }

    .gallery-image-wrap {
        height: 205px;
    }

    .lightbox-close {
        right: 0;
        top: -48px;
    }
}

</style>


<div class="container gallery-page">

    <!-- =====================================================
         HERO
    ====================================================== -->

    <section class="gallery-hero">

        <div class="gallery-hero-content">

            <div class="gallery-eyebrow">
                EventSphere Organizer Portal
            </div>

            <h1>
                Event Gallery
            </h1>

            <p>
                Explore and manage the visual presentation of
                events created through your organizer account.
                Every image shown here belongs to your events.
            </p>

        </div>

    </section>


    <!-- =====================================================
         STATS
    ====================================================== -->

    <div class="row g-3 gallery-stats">

        <div class="col-6 col-lg-3">

            <div class="gallery-stat">

                <div class="gallery-stat-label">
                    Total Images
                </div>

                <div class="gallery-stat-number">
                    <?= (int)$totalImages ?>
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="gallery-stat">

                <div class="gallery-stat-label">
                    Published
                </div>

                <div class="gallery-stat-number">
                    <?= (int)$publishedImages ?>
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="gallery-stat">

                <div class="gallery-stat-label">
                    Draft
                </div>

                <div class="gallery-stat-number">
                    <?= (int)$draftImages ?>
                </div>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="gallery-stat">

                <div class="gallery-stat-label">
                    Categories
                </div>

                <div class="gallery-stat-number">
                    <?= count($categoryCounts) ?>
                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         GALLERY
    ====================================================== -->

    <section class="gallery-box">

        <div class="gallery-header">

            <div>

                <h2>
                    Your Event Gallery
                </h2>

                <p>
                    Images uploaded with your organizer events.
                </p>

            </div>

        </div>


        <?php if (!empty($galleryItems)): ?>

            <!-- SEARCH -->

            <div class="gallery-search">

                <span class="gallery-search-icon">
                    🔎
                </span>

                <input
                    type="search"
                    id="gallerySearch"
                    placeholder="Search events, categories, departments..."
                    autocomplete="off"
                >

            </div>


            <!-- FILTERS -->

            <div class="gallery-filters">

                <button
                    type="button"
                    class="gallery-filter active"
                    data-filter="all"
                >
                    All
                </button>


                <?php foreach ($categoryCounts as $categoryName => $count): ?>

                    <button
                        type="button"
                        class="gallery-filter"
                        data-filter="<?= gallery_h(strtolower($categoryName)) ?>"
                    >

                        <?= gallery_h($categoryName) ?>

                        <span>
                            (<?= (int)$count ?>)
                        </span>

                    </button>

                <?php endforeach; ?>

            </div>


            <!-- CARDS -->

            <div
                class="row g-4"
                id="galleryGrid"
            >

                <?php foreach ($galleryItems as $item): ?>

                    <?php

                    $categoryName = trim(
                        (string)(
                            $item['category_name']
                            ?? 'Other'
                        )
                    );

                    if ($categoryName === '') {
                        $categoryName = 'Other';
                    }


                    $status = strtolower(
                        trim(
                            (string)(
                                $item['event_status']
                                ?? 'draft'
                            )
                        )
                    );


                    if ($status === '') {
                        $status = 'draft';
                    }


                    $description =
                        trim(
                            (string)(
                                $item['short_description']
                                ?? ''
                            )
                        );


                    if ($description === '') {

                        $description =
                            trim(
                                (string)(
                                    $item['description']
                                    ?? ''
                                )
                            );
                    }


                    if ($description === '') {
                        $description =
                            'No description available.';
                    }


                    /*
                    | Image URL
                    */

                    $imagePath = trim(
                        (string)(
                            $item['featured_image']
                            ?? ''
                        )
                    );

                    $imageUrl =
                        gallery_image_url(
                            $imagePath
                        );


                    /*
                    | Date
                    */

                    $formattedDate = 'Not scheduled';

                    if (
                        !empty(
                            $item['event_date']
                        )
                    ) {

                        $timestamp =
                            strtotime(
                                (string)$item['event_date']
                            );

                        if ($timestamp !== false) {

                            $formattedDate =
                                date(
                                    'd M Y',
                                    $timestamp
                                );
                        }
                    }


                    /*
                    | Time
                    */

                    $formattedTime = 'Not scheduled';

                    $startTime =
                        trim(
                            (string)(
                                $item['start_time']
                                ?? ''
                            )
                        );

                    $endTime =
                        trim(
                            (string)(
                                $item['end_time']
                                ?? ''
                            )
                        );


                    if ($startTime !== '') {

                        $startTimestamp =
                            strtotime(
                                $startTime
                            );

                        if ($startTimestamp !== false) {

                            $formattedTime =
                                date(
                                    'h:i A',
                                    $startTimestamp
                                );

                            if ($endTime !== '') {

                                $endTimestamp =
                                    strtotime(
                                        $endTime
                                    );

                                if (
                                    $endTimestamp !== false
                                ) {

                                    $formattedTime .=
                                        ' - ' .
                                        date(
                                            'h:i A',
                                            $endTimestamp
                                        );
                                }
                            }
                        }
                    }


                    /*
                    | Search text
                    */

                    $searchText = strtolower(
                        implode(
                            ' ',
                            [
                                (string)(
                                    $item['title']
                                    ?? ''
                                ),

                                $categoryName,

                                (string)(
                                    $item['department_name']
                                    ?? ''
                                ),

                                (string)(
                                    $item['department_code']
                                    ?? ''
                                ),

                                (string)(
                                    $item['venue_name']
                                    ?? ''
                                ),

                                (string)(
                                    $item['building_name']
                                    ?? ''
                                )
                            ]
                        )
                    );

                    ?>

                    <div
                        class="col-xl-4 col-md-6 gallery-column"
                        data-category="<?= gallery_h(strtolower($categoryName)) ?>"
                        data-search="<?= gallery_h($searchText) ?>"
                    >

                        <article class="gallery-item">

                            <!-- STATUS -->

                            <span
                                class="gallery-status <?= $status === 'published' ? 'published' : 'draft' ?>"
                            >
                                <?= gallery_h($status) ?>
                            </span>


                            <!-- IMAGE -->

                            <div class="gallery-image-wrap">

                                <?php if ($imageUrl !== ''): ?>

                                    <img
                                        src="<?= gallery_h($imageUrl) ?>"
                                        alt="<?= gallery_h($item['title'] ?? 'Event Image') ?>"
                                        class="gallery-image"
                                        loading="lazy"
                                        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                                    >

                                    <div
                                        class="gallery-image-fallback"
                                        style="
                                            display:none;
                                            position:absolute;
                                            inset:0;
                                            align-items:center;
                                            justify-content:center;
                                            flex-direction:column;
                                            gap:8px;
                                            color:#64748b;
                                            background:#f8fafc;
                                            font-size:12px;
                                        "
                                    >
                                        <span style="font-size:30px;">
                                            🖼
                                        </span>

                                        <span>
                                            Image unavailable
                                        </span>
                                    </div>

                                <?php else: ?>

                                    <div
                                        style="
                                            position:absolute;
                                            inset:0;
                                            display:flex;
                                            align-items:center;
                                            justify-content:center;
                                            flex-direction:column;
                                            gap:8px;
                                            color:#64748b;
                                            background:#f8fafc;
                                            font-size:12px;
                                        "
                                    >

                                        <span style="font-size:30px;">
                                            🖼
                                        </span>

                                        <span>
                                            No image
                                        </span>

                                    </div>

                                <?php endif; ?>


                                <?php if ($imageUrl !== ''): ?>

                                    <div class="gallery-overlay">

                                        <button
                                            type="button"
                                            class="view-image-btn"
                                            data-image="<?= gallery_h($imageUrl) ?>"
                                            data-title="<?= gallery_h($item['title'] ?? 'Event Image') ?>"
                                            aria-label="View image"
                                        >
                                            ⛶
                                        </button>

                                    </div>

                                <?php endif; ?>

                            </div>


                            <!-- CONTENT -->

                            <div class="gallery-content">

                                <span class="gallery-category">

                                    <?= gallery_h($categoryName) ?>

                                </span>


                                <div class="gallery-title">

                                    <?= gallery_h(
                                        $item['title']
                                        ?? 'Untitled Event'
                                    ) ?>

                                </div>


                                <div class="gallery-description">

                                    <?= gallery_h(
                                        mb_strimwidth(
                                            $description,
                                            0,
                                            125,
                                            '...'
                                        )
                                    ) ?>

                                </div>


                                <div class="gallery-meta">

                                    <!-- Department -->

                                    <div class="gallery-meta-row">

                                        <strong>
                                            Department:
                                        </strong>

                                        <span>

                                            <?= gallery_h(
                                                $item['department_name']
                                                ?? 'Not assigned'
                                            ) ?>

                                        </span>

                                    </div>


                                    <!-- Venue -->

                                    <div class="gallery-meta-row">

                                        <strong>
                                            Venue:
                                        </strong>

                                        <span>

                                            <?= gallery_h(
                                                $item['venue_name']
                                                ?? 'Not assigned'
                                            ) ?>

                                        </span>

                                    </div>


                                    <!-- Date -->

                                    <div class="gallery-meta-row">

                                        <strong>
                                            Date:
                                        </strong>

                                        <span>
                                            <?= gallery_h($formattedDate) ?>
                                        </span>

                                    </div>


                                    <!-- Time -->

                                    <div class="gallery-meta-row">

                                        <strong>
                                            Time:
                                        </strong>

                                        <span>
                                            <?= gallery_h($formattedTime) ?>
                                        </span>

                                    </div>

                                </div>


                                <!-- ACTION -->

                                <a
                                    href="event_details.php?id=<?= (int)$item['event_id'] ?>"
                                    class="gallery-action"
                                >
                                    View Event Details
                                </a>

                            </div>

                        </article>

                    </div>

                <?php endforeach; ?>

            </div>


            <!-- NO SEARCH RESULT -->

            <div
                id="noSearchResults"
                class="gallery-empty"
                style="display:none;"
            >

                <div class="gallery-empty-icon">
                    🔎
                </div>

                <h3>
                    No matching events
                </h3>

                <p>
                    Try another search term or select a different
                    gallery category.
                </p>

            </div>


        <?php else: ?>

            <!-- EMPTY -->

            <div class="gallery-empty">

                <div class="gallery-empty-icon">
                    🖼
                </div>

                <h3>
                    No gallery images yet
                </h3>

                <p>
                    Your event images will appear here automatically
                    when you create events with a featured image.
                </p>

                <a
                    href="organizer-events.php"
                    class="gallery-action"
                    style="max-width:210px;margin:20px auto 0;"
                >
                    Create an Event
                </a>

            </div>

        <?php endif; ?>

    </section>

</div>


<!-- =========================================================
     LIGHTBOX
========================================================= -->

<div
    class="gallery-lightbox"
    id="galleryLightbox"
>

    <div class="lightbox-inner">

        <button
            type="button"
            class="lightbox-close"
            id="lightboxClose"
            aria-label="Close"
        >
            ×
        </button>


        <img
            src=""
            alt=""
            class="lightbox-image"
            id="lightboxImage"
        >


        <div
            class="lightbox-title"
            id="lightboxTitle"
        ></div>

    </div>

</div>


<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {

        /*
        |--------------------------------------------------------------------------
        | Elements
        |--------------------------------------------------------------------------
        */

        const filters =
            document.querySelectorAll(
                ".gallery-filter"
            );

        const columns =
            document.querySelectorAll(
                ".gallery-column"
            );

        const search =
            document.querySelector(
                "#gallerySearch"
            );

        const noResults =
            document.querySelector(
                "#noSearchResults"
            );


        /*
        |--------------------------------------------------------------------------
        | State
        |--------------------------------------------------------------------------
        */

        let activeFilter = "all";


        /*
        |--------------------------------------------------------------------------
        | FILTER FUNCTION
        |--------------------------------------------------------------------------
        */

        function filterGallery() {

            const searchValue =
                search
                    ? search.value
                        .toLowerCase()
                        .trim()
                    : "";

            let visibleCount = 0;


            columns.forEach(
                function (column) {

                    const category =
                        (
                            column.dataset.category
                            || ""
                        ).toLowerCase();


                    const searchableText =
                        (
                            column.dataset.search
                            || ""
                        ).toLowerCase();


                    const categoryMatch =
                        activeFilter === "all"
                        ||
                        category === activeFilter;


                    const searchMatch =
                        searchValue === ""
                        ||
                        searchableText.includes(
                            searchValue
                        );


                    if (
                        categoryMatch &&
                        searchMatch
                    ) {

                        column.style.display = "";

                        visibleCount++;

                    } else {

                        column.style.display = "none";
                    }
                }
            );


            if (noResults) {

                noResults.style.display =
                    visibleCount === 0
                        ? "block"
                        : "none";
            }
        }


        /*
        |--------------------------------------------------------------------------
        | FILTER BUTTONS
        |--------------------------------------------------------------------------
        */

        filters.forEach(
            function (filterButton) {

                filterButton.addEventListener(
                    "click",
                    function () {

                        filters.forEach(
                            function (button) {

                                button.classList.remove(
                                    "active"
                                );
                            }
                        );


                        this.classList.add(
                            "active"
                        );


                        activeFilter =
                            (
                                this.dataset.filter
                                || "all"
                            ).toLowerCase();


                        filterGallery();
                    }
                );
            }
        );


        /*
        |--------------------------------------------------------------------------
        | SEARCH
        |--------------------------------------------------------------------------
        */

        if (search) {

            search.addEventListener(
                "input",
                filterGallery
            );
        }


        /*
        |--------------------------------------------------------------------------
        | LIGHTBOX
        |--------------------------------------------------------------------------
        */

        const lightbox =
            document.querySelector(
                "#galleryLightbox"
            );

        const lightboxImage =
            document.querySelector(
                "#lightboxImage"
            );

        const lightboxTitle =
            document.querySelector(
                "#lightboxTitle"
            );

        const lightboxClose =
            document.querySelector(
                "#lightboxClose"
            );


        const imageButtons =
            document.querySelectorAll(
                ".view-image-btn"
            );


        /*
        |--------------------------------------------------------------------------
        | OPEN LIGHTBOX
        |--------------------------------------------------------------------------
        */

        function openLightbox(
            image,
            title
        ) {

            if (
                !lightbox ||
                !lightboxImage ||
                !image
            ) {
                return;
            }


            lightboxImage.src = image;

            lightboxImage.alt =
                title;


            if (lightboxTitle) {

                lightboxTitle.textContent =
                    title;
            }


            lightbox.classList.add(
                "show"
            );


            document.body.style.overflow =
                "hidden";
        }


        /*
        |--------------------------------------------------------------------------
        | CLOSE LIGHTBOX
        |--------------------------------------------------------------------------
        */

        function closeLightbox() {

            if (!lightbox) {
                return;
            }


            lightbox.classList.remove(
                "show"
            );


            document.body.style.overflow =
                "";


            setTimeout(
                function () {

                    if (lightboxImage) {

                        lightboxImage.src = "";
                    }

                },
                250
            );
        }


        /*
        |--------------------------------------------------------------------------
        | IMAGE BUTTONS
        |--------------------------------------------------------------------------
        */

        imageButtons.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();

                        event.stopPropagation();


                        openLightbox(
                            this.dataset.image
                                || "",

                            this.dataset.title
                                || "Event Image"
                        );
                    }
                );
            }
        );


        /*
        |--------------------------------------------------------------------------
        | CLOSE BUTTON
        |--------------------------------------------------------------------------
        */

        if (lightboxClose) {

            lightboxClose.addEventListener(
                "click",
                closeLightbox
            );
        }


        /*
        |--------------------------------------------------------------------------
        | CLICK OUTSIDE
        |--------------------------------------------------------------------------
        */

        if (lightbox) {

            lightbox.addEventListener(
                "click",
                function (event) {

                    if (
                        event.target ===
                        lightbox
                    ) {

                        closeLightbox();
                    }
                }
            );
        }


        /*
        |--------------------------------------------------------------------------
        | ESCAPE KEY
        |--------------------------------------------------------------------------
        */

        document.addEventListener(
            "keydown",
            function (event) {

                if (
                    event.key === "Escape"
                ) {

                    closeLightbox();
                }
            }
        );

    }
);

</script>


<?php

require __DIR__ . '/footer.php';

?>