<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| STUDENT AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['user']['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user']['user_id'];

$userRole = strtolower(
    trim((string) ($_SESSION['user']['role'] ?? ''))
);

if ($userId <= 0) {
    http_response_code(403);
    exit('Access denied.');
}

if ($userRole !== 'student') {
    http_response_code(403);
    exit('Only students can download certificates.');
}

/*
|--------------------------------------------------------------------------
| GET CERTIFICATE ID
|--------------------------------------------------------------------------
*/

$certificateId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if ($certificateId === false || $certificateId === null || $certificateId <= 0) {
    http_response_code(400);
    exit('Invalid certificate ID.');
}

/*
|--------------------------------------------------------------------------
| GET CERTIFICATE
|--------------------------------------------------------------------------
| IMPORTANT:
| We check BOTH certificate_id and student_id.
| This prevents students from downloading someone else's certificate.
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        certificate_id,
        certificate_number,
        certificate_url
    FROM certificates
    WHERE certificate_id = ?
      AND student_id = ?
    LIMIT 1
";

$stmt = mysqli_prepare($conn, $sql);

if ($stmt === false) {
    http_response_code(500);
    exit('Unable to prepare certificate query.');
}

mysqli_stmt_bind_param(
    $stmt,
    'ii',
    $certificateId,
    $userId
);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);

    http_response_code(500);
    exit('Unable to load certificate.');
}

$result = mysqli_stmt_get_result($stmt);

if ($result === false) {
    mysqli_stmt_close($stmt);

    http_response_code(500);
    exit('Unable to read certificate data.');
}

if (mysqli_num_rows($result) !== 1) {
    mysqli_free_result($result);
    mysqli_stmt_close($stmt);

    http_response_code(404);
    exit('Certificate not found.');
}

$certificate = mysqli_fetch_assoc($result);

mysqli_free_result($result);
mysqli_stmt_close($stmt);

/*
|--------------------------------------------------------------------------
| GET CERTIFICATE PATH
|--------------------------------------------------------------------------
*/

$certificateUrl = trim(
    (string) ($certificate['certificate_url'] ?? '')
);

if ($certificateUrl === '') {
    http_response_code(404);
    exit('Certificate file is not available.');
}

/*
|--------------------------------------------------------------------------
| SECURITY CHECK
|--------------------------------------------------------------------------
| Only local files are allowed.
| External URLs such as http:// or https:// are rejected.
|--------------------------------------------------------------------------
*/

$parsedScheme = parse_url(
    $certificateUrl,
    PHP_URL_SCHEME
);

$parsedHost = parse_url(
    $certificateUrl,
    PHP_URL_HOST
);

if (
    ($parsedScheme !== null && $parsedScheme !== '') ||
    ($parsedHost !== null && $parsedHost !== '')
) {
    http_response_code(403);
    exit('Invalid certificate file.');
}

/*
|--------------------------------------------------------------------------
| NORMALIZE PATH
|--------------------------------------------------------------------------
*/

$relativePath = str_replace(
    '\\',
    '/',
    $certificateUrl
);

$relativePath = ltrim(
    $relativePath,
    '/'
);

/*
|--------------------------------------------------------------------------
| PREVENT PATH TRAVERSAL
|--------------------------------------------------------------------------
*/

if (
    strpos($relativePath, '../') !== false ||
    strpos($relativePath, '..\\') !== false
) {
    http_response_code(403);
    exit('Invalid certificate path.');
}

/*
|--------------------------------------------------------------------------
| FIND CERTIFICATE FILE
|--------------------------------------------------------------------------
*/

$possibleFiles = [
    __DIR__ . '/' . $relativePath,

    __DIR__ . '/uploads/' .
        basename($relativePath),

    __DIR__ . '/certificates/' .
        basename($relativePath),

    __DIR__ . '/uploads/certificates/' .
        basename($relativePath),
];

$filePath = '';

foreach ($possibleFiles as $possibleFile) {

    if (!is_file($possibleFile)) {
        continue;
    }

    if (!is_readable($possibleFile)) {
        continue;
    }

    $realFile = realpath($possibleFile);

    if ($realFile === false) {
        continue;
    }

    $filePath = $realFile;
    break;
}

/*
|--------------------------------------------------------------------------
| FILE NOT FOUND
|--------------------------------------------------------------------------
*/

if ($filePath === '') {
    http_response_code(404);
    exit('Certificate file not found on server.');
}

/*
|--------------------------------------------------------------------------
| FILE EXTENSION
|--------------------------------------------------------------------------
*/

$extension = strtolower(
    pathinfo($filePath, PATHINFO_EXTENSION)
);

/*
|--------------------------------------------------------------------------
| ALLOWED FILE TYPES
|--------------------------------------------------------------------------
*/

$mimeTypes = [
    'pdf'  => 'application/pdf',
    'png'  => 'image/png',
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'webp' => 'image/webp'
];

if (!isset($mimeTypes[$extension])) {
    http_response_code(403);
    exit('Unsupported certificate file type.');
}

$contentType = $mimeTypes[$extension];

/*
|--------------------------------------------------------------------------
| CERTIFICATE FILE NAME
|--------------------------------------------------------------------------
*/

$certificateNumber = trim(
    (string) (
        $certificate['certificate_number']
        ?? ''
    )
);

if ($certificateNumber === '') {
    $certificateNumber = 'certificate-' . $certificateId;
}

/*
|--------------------------------------------------------------------------
| CLEAN FILE NAME
|--------------------------------------------------------------------------
*/

$certificateNumber = preg_replace(
    '/[^A-Za-z0-9_-]/',
    '_',
    $certificateNumber
);

if ($certificateNumber === '' || $certificateNumber === null) {
    $certificateNumber = 'certificate-' . $certificateId;
}

$fileName =
    'EventSphere_' .
    $certificateNumber .
    '.' .
    $extension;

/*
|--------------------------------------------------------------------------
| FILE SIZE
|--------------------------------------------------------------------------
*/

$fileSize = filesize($filePath);

if ($fileSize === false) {
    http_response_code(500);
    exit('Unable to read certificate file.');
}

/*
|--------------------------------------------------------------------------
| CLEAR OUTPUT BUFFER
|--------------------------------------------------------------------------
*/

while (ob_get_level() > 0) {
    ob_end_clean();
}

/*
|--------------------------------------------------------------------------
| DOWNLOAD HEADERS
|--------------------------------------------------------------------------
*/

header('Content-Type: ' . $contentType);

header(
    'Content-Disposition: attachment; filename="' .
    $fileName .
    '"'
);

header(
    'Content-Length: ' .
    (string) $fileSize
);

header('Content-Transfer-Encoding: binary');

header(
    'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0'
);

header('Pragma: no-cache');

header('Expires: 0');

/*
|--------------------------------------------------------------------------
| DOWNLOAD CERTIFICATE
|--------------------------------------------------------------------------
*/

$handle = fopen($filePath, 'rb');

if ($handle === false) {
    http_response_code(500);
    exit('Unable to open certificate file.');
}

while (!feof($handle)) {

    $buffer = fread($handle, 8192);

    if ($buffer === false) {
        break;
    }

    echo $buffer;

    flush();
}

fclose($handle);

exit;