<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$title = 'Events | EventSphere';

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

if (!function_exists('h')) {
    function h(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

function cleanQuery(string $value, int $maxLength = 150): string
{
    $value = trim($value);

    if ($value === '') {
        return '';
    }

    return mb_substr($value, 0, $maxLength);
}

function validDate(string $date): bool
{
    if ($date === '') {
        return false;
    }

    $parsed = DateTime::createFromFormat('Y-m-d', $date);

    return $parsed !== false
        && $parsed->format('Y-m-d') === $date;
}

function formatEventDate(?string $date): string
{
    if (!$date || !validDate($date)) {
        return 'Date TBA';
    }

    return date('d M Y', strtotime($date));
}

function formatEventTime(?string $time): string
{
    if (!$time) {
        return 'Time TBA';
    }

    $timestamp = strtotime($time);

    return $timestamp
        ? date('h:i A', $timestamp)
        : 'Time TBA';
}

function getEventState(
    string $date,
    ?string $start = null,
    ?string $end = null
): array {
    $today = date('Y-m-d');

    if ($date < $today) {
        return [
            'label' => 'Past',
            'class' => 'is-past'
        ];
    }

    if ($date > $today) {
        return [
            'label' => 'Upcoming',
            'class' => 'is-upcoming'
        ];
    }

    $now = date('H:i:s');

    if ($start && $end && $now >= $start && $now <= $end) {
        return [
            'label' => 'Live Now',
            'class' => 'is-live'
        ];
    }

    if ($start && $now < $start) {
        return [
            'label' => 'Today',
            'class' => 'is-today'
        ];
    }

    if ($end && $now > $end) {
        return [
            'label' => 'Completed',
            'class' => 'is-past'
        ];
    }

    return [
        'label' => 'Today',
        'class' => 'is-today'
    ];
}

function registrationStatus(
    ?string $open,
    ?string $close,
    string $eventDate,
    string $eventState
): array {
    $now = date('Y-m-d H:i:s');

    if ($eventState === 'is-past') {
        return [
            'allowed' => false,
            'label' => 'Event Ended',
            'class' => 'is-disabled'
        ];
    }

    if ($open && $now < $open) {
        return [
            'allowed' => false,
            'label' => 'Registration Opens Soon',
            'class' => 'is-disabled'
        ];
    }

    if ($close && $now > $close) {
        return [
            'allowed' => false,
            'label' => 'Registration Closed',
            'class' => 'is-disabled'
        ];
    }

    return [
        'allowed' => true,
        'label' => 'Register Now',
        'class' => 'is-register'
    ];
}

function buildQuery(array $values = []): string
{
    $filtered = [];

    foreach ($values as $key => $value) {
        if (
            $value !== ''
            && $value !== null
            && $value !== '0'
            && $value !== 'all'
        ) {
            $filtered[$key] = $value;
        }
    }

    return http_build_query($filtered);
}

/*
|--------------------------------------------------------------------------
| Session / User
|--------------------------------------------------------------------------
*/

$isLoggedIn = isset($_SESSION['user']['user_id']);

$userId = (int) (
    $_SESSION['user']['user_id'] ?? 0
);

$userRole = strtolower(
    trim((string) ($_SESSION['user']['role'] ?? ''))
);

$isStudent = $isLoggedIn && $userRole === 'student';
$isOrganizer = $isLoggedIn && $userRole === 'organizer';

$organizerEventPage = 'organizer-event.php';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$search = cleanQuery(
    (string) ($_GET['search'] ?? ''),
    120
);

$categoryId = max(
    0,
    (int) ($_GET['category'] ?? 0)
);

$departmentId = max(
    0,
    (int) ($_GET['department'] ?? 0)
);

$dateFrom = cleanQuery(
    (string) ($_GET['date_from'] ?? ''),
    10
);

$dateTo = cleanQuery(
    (string) ($_GET['date_to'] ?? ''),
    10
);

$status = strtolower(
    cleanQuery(
        (string) ($_GET['status'] ?? 'all'),
        20
    )
);

$allowedStatuses = [
    'all',
    'upcoming',
    'today',
    'past'
];

if (!in_array($status, $allowedStatuses, true)) {
    $status = 'all';
}

if ($dateFrom !== '' && !validDate($dateFrom)) {
    $dateFrom = '';
}

if ($dateTo !== '' && !validDate($dateTo)) {
    $dateTo = '';
}

if (
    $dateFrom !== ''
    && $dateTo !== ''
    && $dateFrom > $dateTo
) {
    [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
}

/*
|--------------------------------------------------------------------------
| Events Query
|--------------------------------------------------------------------------
*/

$where = [
    "e.event_status = 'published'"
];

$params = [];
$types = '';

if ($search !== '') {

    $where[] = "(
        e.title LIKE ?
        OR e.short_description LIKE ?
        OR e.description LIKE ?
    )";

    $searchValue = '%' . $search . '%';

    $params[] = $searchValue;
    $params[] = $searchValue;
    $params[] = $searchValue;

    $types .= 'sss';
}

if ($categoryId > 0) {

    $where[] = "e.category_id = ?";

    $params[] = $categoryId;

    $types .= 'i';
}

if ($departmentId > 0) {

    $where[] = "e.department_id = ?";

    $params[] = $departmentId;

    $types .= 'i';
}

if ($dateFrom !== '') {

    $where[] = "e.event_date >= ?";

    $params[] = $dateFrom;

    $types .= 's';
}

if ($dateTo !== '') {

    $where[] = "e.event_date <= ?";

    $params[] = $dateTo;

    $types .= 's';
}

$today = date('Y-m-d');

if ($status === 'upcoming') {

    $where[] = "e.event_date > ?";

    $params[] = $today;

    $types .= 's';
}

if ($status === 'today') {

    $where[] = "e.event_date = ?";

    $params[] = $today;

    $types .= 's';
}

if ($status === 'past') {

    $where[] = "e.event_date < ?";

    $params[] = $today;

    $types .= 's';
}

$whereSql = implode(' AND ', $where);

$sql = "
    SELECT
        e.event_id,
        e.title,
        e.slug,
        e.short_description,
        e.description,
        e.category_id,
        e.department_id,
        e.organizer_id,
        e.venue_id,
        e.event_date,
        e.start_time,
        e.end_time,
        e.registration_open,
        e.registration_close,
        e.event_status,
        e.featured_image,
        e.max_capacity,
        e.waitlist_enabled,

        c.category_name,

        d.department_name,

        v.venue_name,

        u.email AS organizer_email

    FROM events e

    LEFT JOIN event_categories c
        ON c.category_id = e.category_id

    LEFT JOIN departments d
        ON d.department_id = e.department_id

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    LEFT JOIN users u
        ON u.user_id = e.organizer_id

    WHERE {$whereSql}

    ORDER BY
        e.event_date ASC,
        e.start_time ASC,
        e.event_id DESC
";

$events = [];

$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {

    if (!empty($params)) {

        mysqli_stmt_bind_param(
            $stmt,
            $types,
            ...$params
        );
    }

    if (mysqli_stmt_execute($stmt)) {

        $result = mysqli_stmt_get_result($stmt);

        if ($result) {

            while ($row = mysqli_fetch_assoc($result)) {
                $events[] = $row;
            }
        }
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Categories
|--------------------------------------------------------------------------
*/

$categories = [];

$categoryResult = mysqli_query(
    $conn,
    "
        SELECT
            category_id,
            category_name
        FROM event_categories
        ORDER BY category_name ASC
    "
);

if ($categoryResult) {

    while ($row = mysqli_fetch_assoc($categoryResult)) {
        $categories[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| Departments
|--------------------------------------------------------------------------
*/

$departments = [];

$departmentResult = mysqli_query(
    $conn,
    "
        SELECT
            department_id,
            department_name
        FROM departments
        ORDER BY department_name ASC
    "
);

if ($departmentResult) {

    while ($row = mysqli_fetch_assoc($departmentResult)) {
        $departments[] = $row;
    }
}

/*
|--------------------------------------------------------------------------
| Current Filters
|--------------------------------------------------------------------------
*/

$currentFilters = [
    'search' => $search,
    'category' => $categoryId,
    'department' => $departmentId,
    'date_from' => $dateFrom,
    'date_to' => $dateTo,
    'status' => $status
];

require_once __DIR__ . '/header.php';

?>

<style>

/* ==========================================================================
   EVENTS PAGE
   ========================================================================== */

.events-page {
    --primary: #4f46e5;
    --primary-dark: #3730a3;
    --primary-soft: #eef2ff;
    --text: #172033;
    --muted: #64748b;
    --subtle: #94a3b8;
    --border: #e5e7eb;
    --surface: #ffffff;
    --background: #f7f8fc;
    --success: #059669;
    --danger: #dc2626;
    --info: #0284c7;

    min-height: 100vh;

    background:
        radial-gradient(
            circle at 8% 8%,
            rgba(99, 102, 241, .07),
            transparent 24%
        ),
        var(--background);

    color: var(--text);
}

.events-container {
    width: min(1240px, calc(100% - 40px));
    margin-inline: auto;
}

/* ==========================================================================
   HERO
   ========================================================================== */

.events-hero {
    position: relative;
    overflow: hidden;

    padding: 82px 0 125px;

    background:
        radial-gradient(
            circle at 82% 20%,
            rgba(129, 140, 248, .24),
            transparent 29%
        ),
        radial-gradient(
            circle at 12% 90%,
            rgba(34, 211, 238, .13),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #0f172a 0%,
            #171936 50%,
            #241c54 100%
        );
}

.events-hero::before,
.events-hero::after {
    content: "";

    position: absolute;

    border: 1px solid rgba(255, 255, 255, .08);
    border-radius: 50%;

    pointer-events: none;
}

.events-hero::before {
    width: 500px;
    height: 500px;

    right: -230px;
    top: -300px;
}

.events-hero::after {
    width: 330px;
    height: 330px;

    left: -190px;
    bottom: -260px;
}

.hero-content {
    position: relative;
    z-index: 2;

    max-width: 790px;
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 9px;

    padding: 8px 13px;

    border: 1px solid rgba(255, 255, 255, .13);
    border-radius: 999px;

    background: rgba(255, 255, 255, .07);

    color: #c7d2fe;

    font-size: 11px;
    font-weight: 800;
    letter-spacing: .09em;
    text-transform: uppercase;

    backdrop-filter: blur(12px);
}

.hero-badge::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #34d399;

    box-shadow:
        0 0 0 5px rgba(52, 211, 153, .1);
}

.hero-title {
    margin: 21px 0 0;

    color: #fff;

    font-size: clamp(42px, 6vw, 72px);
    line-height: .98;
    letter-spacing: -.06em;
    font-weight: 850;
}

.hero-title span {
    background:
        linear-gradient(
            90deg,
            #a5b4fc,
            #67e8f9
        );

    -webkit-background-clip: text;
    background-clip: text;

    color: transparent;
}

.hero-text {
    max-width: 690px;

    margin: 22px 0 0;

    color: #cbd5e1;

    font-size: 15px;
    line-height: 1.8;
}

/* ==========================================================================
   FILTER
   ========================================================================== */

.events-filter-wrap {
    position: relative;
    z-index: 10;

    margin-top: -58px;
}

.events-filter {
    padding: 23px;

    border: 1px solid rgba(226, 232, 240, .9);
    border-radius: 22px;

    background: rgba(255, 255, 255, .97);

    box-shadow:
        0 24px 65px rgba(15, 23, 42, .12),
        0 2px 5px rgba(15, 23, 42, .03);

    backdrop-filter: blur(18px);
}

.filter-main {
    display: grid;

    grid-template-columns:
        minmax(220px, 2fr)
        repeat(4, minmax(120px, 1fr))
        auto;

    gap: 12px;

    align-items: end;
}

.field label {
    display: block;

    margin: 0 0 7px;

    color: #475569;

    font-size: 10px;
    font-weight: 850;
    letter-spacing: .05em;
    text-transform: uppercase;
}

.input,
.select {
    width: 100%;
    height: 46px;

    padding: 0 13px;

    border: 1px solid #dfe4ec;
    border-radius: 11px;

    outline: none;

    background: #f8fafc;
    color: #172033;

    font: inherit;
    font-size: 12px;

    transition:
        border-color .2s ease,
        background .2s ease,
        box-shadow .2s ease;
}

.input::placeholder {
    color: #9aa6b6;
}

.input:hover,
.select:hover {
    border-color: #cbd5e1;
}

.input:focus,
.select:focus {
    border-color: #6366f1;

    background: #fff;

    box-shadow:
        0 0 0 4px rgba(99, 102, 241, .09);
}

.search-button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    height: 46px;

    padding: 0 19px;

    border: 0;
    border-radius: 11px;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    color: #fff;

    font: inherit;
    font-size: 12px;
    font-weight: 800;

    cursor: pointer;

    white-space: nowrap;

    transition:
        transform .2s ease,
        box-shadow .2s ease;
}

.search-button:hover {
    transform: translateY(-1px);

    box-shadow:
        0 9px 24px rgba(79, 70, 229, .23);
}

.search-button:focus-visible,
.quick-filter:focus-visible,
.reset-link:focus-visible,
.event-button:focus-visible {
    outline: 3px solid rgba(99, 102, 241, .22);
    outline-offset: 2px;
}

.filter-bottom {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 15px;

    margin-top: 16px;
    padding-top: 15px;

    border-top: 1px solid #eef1f5;
}

.quick-filters {
    display: flex;

    flex-wrap: wrap;

    gap: 7px;
}

.quick-filter {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    min-height: 31px;

    padding: 0 12px;

    border: 1px solid #e2e8f0;
    border-radius: 999px;

    background: #fff;
    color: #64748b;

    font-size: 10px;
    font-weight: 800;

    text-decoration: none;

    transition:
        color .2s ease,
        background .2s ease,
        border-color .2s ease;
}

.quick-filter:hover,
.quick-filter.active {
    border-color: #c7d2fe;

    background: #eef2ff;
    color: #4f46e5;
}

.reset-link {
    color: #64748b;

    font-size: 11px;
    font-weight: 750;

    text-decoration: none;

    white-space: nowrap;
}

.reset-link:hover {
    color: #4f46e5;
}

/* ==========================================================================
   EVENTS SECTION
   ========================================================================== */

.events-section {
    padding: 63px 0 95px;
}

.events-heading {
    display: flex;

    align-items: flex-end;
    justify-content: space-between;

    gap: 25px;

    margin-bottom: 27px;
}

.heading-eyebrow {
    margin-bottom: 6px;

    color: #6366f1;

    font-size: 10px;
    font-weight: 850;
    letter-spacing: .12em;
    text-transform: uppercase;
}

.events-heading h2 {
    margin: 0;

    color: #111827;

    font-size: 30px;
    line-height: 1.1;
    letter-spacing: -.045em;
    font-weight: 850;
}

.events-heading p {
    margin: 8px 0 0;

    color: #64748b;

    font-size: 12px;
    line-height: 1.6;
}

.result-count {
    flex-shrink: 0;

    padding: 8px 13px;

    border: 1px solid #e0e7ff;
    border-radius: 999px;

    background: #eef2ff;
    color: #4f46e5;

    font-size: 11px;
    font-weight: 800;
}

/* ==========================================================================
   EVENT GRID
   ========================================================================== */

.events-grid {
    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 22px;
}

.event-card {
    display: flex;

    min-width: 0;

    flex-direction: column;

    overflow: hidden;

    border: 1px solid #e4e8ef;
    border-radius: 20px;

    background: #fff;

    box-shadow:
        0 8px 27px rgba(15, 23, 42, .052);

    transition:
        transform .25s ease,
        border-color .25s ease,
        box-shadow .25s ease;
}

.event-card:hover {
    transform: translateY(-5px);

    border-color: #d9def2;

    box-shadow:
        0 20px 48px rgba(15, 23, 42, .105);
}

/* ==========================================================================
   EVENT IMAGE
   ========================================================================== */

.event-media {
    position: relative;

    height: 215px;

    overflow: hidden;

    background:
        radial-gradient(
            circle at 25% 20%,
            #c7d2fe,
            transparent 34%
        ),
        linear-gradient(
            135deg,
            #eef2ff,
            #e0f2fe
        );
}

.event-media img {
    display: block;

    width: 100%;
    height: 100%;

    object-fit: cover;

    transition: transform .45s ease;
}

.event-card:hover .event-media img {
    transform: scale(1.055);
}

.event-fallback {
    display: grid;

    place-items: center;

    width: 100%;
    height: 100%;

    background:
        radial-gradient(
            circle at 50% 35%,
            rgba(99, 102, 241, .17),
            transparent 40%
        );

    color: #4f46e5;

    font-size: 43px;
    font-weight: 900;
    letter-spacing: -.09em;
}

/* ==========================================================================
   EVENT STATUS
   ========================================================================== */

.event-status {
    position: absolute;

    top: 13px;
    left: 13px;

    display: inline-flex;

    align-items: center;

    min-height: 27px;

    padding: 0 10px;

    border-radius: 999px;

    backdrop-filter: blur(12px);

    font-size: 9px;
    font-weight: 850;
    letter-spacing: .02em;
}

.is-upcoming {
    background: rgba(255, 255, 255, .94);
    color: #4f46e5;
}

.is-today {
    background: rgba(255, 255, 255, .94);
    color: #0284c7;
}

.is-live {
    background: rgba(5, 150, 105, .95);
    color: #fff;

    box-shadow:
        0 6px 20px rgba(5, 150, 105, .2);
}

.is-past {
    background: rgba(15, 23, 42, .86);
    color: #fff;
}

/* ==========================================================================
   EVENT CONTENT
   ========================================================================== */

.event-content {
    display: flex;

    flex: 1;

    flex-direction: column;

    padding: 20px;
}

.event-topline {
    display: flex;

    align-items: center;
    justify-content: space-between;

    gap: 10px;

    min-height: 22px;

    margin-bottom: 10px;
}

.event-category {
    min-width: 0;

    overflow: hidden;

    color: #6366f1;

    font-size: 9px;
    font-weight: 850;
    letter-spacing: .09em;

    text-overflow: ellipsis;

    text-transform: uppercase;

    white-space: nowrap;
}

.event-capacity-badge {
    flex-shrink: 0;

    padding: 5px 8px;

    border: 1px solid #eef0f4;
    border-radius: 7px;

    background: #f8fafc;
    color: #64748b;

    font-size: 8px;
    font-weight: 800;
}

.event-title {
    display: -webkit-box;

    min-height: 50px;

    margin: 0;

    overflow: hidden;

    color: #111827;

    font-size: 18px;
    line-height: 1.38;
    letter-spacing: -.025em;
    font-weight: 850;

    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}

.event-description {
    display: -webkit-box;

    min-height: 40px;

    margin: 9px 0 0;

    overflow: hidden;

    color: #64748b;

    font-size: 11.5px;
    line-height: 1.72;

    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}

/* ==========================================================================
   EVENT INFORMATION
   ========================================================================== */

.event-info {
    display: grid;

    gap: 9px;

    margin-top: 17px;
    padding-top: 16px;

    border-top: 1px solid #edf0f5;
}

.info-row {
    display: flex;

    align-items: flex-start;

    gap: 10px;

    min-width: 0;

    color: #64748b;

    font-size: 11px;
}

.info-icon {
    display: grid;

    place-items: center;

    width: 28px;
    height: 28px;

    flex: 0 0 28px;

    border: 1px solid #e4e8ff;
    border-radius: 8px;

    background: #f4f6ff;
    color: #4f46e5;

    font-size: 10px;
    font-weight: 850;
}

.info-content {
    min-width: 0;

    padding-top: 2px;
}

.info-label {
    display: block;

    margin-bottom: 2px;

    color: #94a3b8;

    font-size: 8px;
    font-weight: 800;
    letter-spacing: .05em;
    text-transform: uppercase;
}

.info-value {
    display: block;

    overflow: hidden;

    color: #334155;

    font-weight: 700;
    line-height: 1.45;

    overflow-wrap: anywhere;

    text-overflow: ellipsis;
}

/* ==========================================================================
   ACTIONS
   ========================================================================== */

.event-actions {
    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 8px;

    margin-top: auto;
    padding-top: 18px;
}

.event-button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    min-width: 0;
    min-height: 39px;

    padding: 0 11px;

    border-radius: 9px;

    font-size: 10px;
    font-weight: 800;

    line-height: 1.2;

    text-align: center;
    text-decoration: none;

    transition:
        transform .2s ease,
        background .2s ease,
        border-color .2s ease,
        color .2s ease,
        box-shadow .2s ease;
}

.details-button {
    border: 1px solid #e2e8f0;

    background: #fff;
    color: #475569;
}

.details-button:hover {
    border-color: #c7d2fe;

    background: #f8faff;
    color: #4f46e5;

    transform: translateY(-1px);
}

.register-button {
    border: 1px solid transparent;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    color: #fff;
}

.register-button:hover {
    transform: translateY(-1px);

    box-shadow:
        0 8px 20px rgba(79, 70, 229, .2);
}

.login-button {
    border: 1px solid transparent;

    background: #f1f5f9;
    color: #475569;
}

.login-button:hover {
    background: #e2e8f0;
    color: #334155;

    transform: translateY(-1px);
}

.organizer-button {
    border: 1px solid #ddd6fe;

    background: #f5f3ff;
    color: #6d28d9;
}

.organizer-button:hover {
    border-color: #c4b5fd;

    background: #ede9fe;
    color: #5b21b6;

    transform: translateY(-1px);
}

.disabled-button {
    border: 1px solid #edf0f3;

    background: #f8fafc;
    color: #9aa5b4;

    cursor: not-allowed;
}

.event-owner-note {
    display: flex;

    align-items: center;

    gap: 7px;

    margin-top: 9px;

    color: #8b5cf6;

    font-size: 9px;
    font-weight: 750;
}

.event-owner-note::before {
    content: "";

    width: 5px;
    height: 5px;

    flex: 0 0 5px;

    border-radius: 50%;

    background: #8b5cf6;
}

/* ==========================================================================
   EMPTY STATE
   ========================================================================== */

.empty-state {
    padding: 76px 25px;

    border: 1px solid #e2e8f0;
    border-radius: 22px;

    background: #fff;

    text-align: center;

    box-shadow:
        0 8px 28px rgba(15, 23, 42, .035);
}

.empty-symbol {
    display: grid;

    place-items: center;

    width: 66px;
    height: 66px;

    margin: 0 auto 17px;

    border: 1px solid #e0e7ff;
    border-radius: 18px;

    background: #eef2ff;
    color: #6366f1;

    font-size: 27px;
}

.empty-state h3 {
    margin: 0;

    color: #111827;

    font-size: 20px;
    font-weight: 850;
    letter-spacing: -.025em;
}

.empty-state p {
    max-width: 480px;

    margin: 8px auto 0;

    color: #64748b;

    font-size: 12px;
    line-height: 1.7;
}

.empty-state a {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    min-height: 39px;

    margin-top: 18px;

    padding: 0 15px;

    border-radius: 9px;

    background: #eef2ff;
    color: #4f46e5;

    font-size: 11px;
    font-weight: 800;

    text-decoration: none;

    transition: .2s ease;
}

.empty-state a:hover {
    background: #e0e7ff;

    transform: translateY(-1px);
}

/* ==========================================================================
   TABLET
   ========================================================================== */

@media (max-width: 1180px) {

    .filter-main {
        grid-template-columns:
            repeat(3, minmax(0, 1fr));
    }

    .events-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }
}

/* ==========================================================================
   MOBILE
   ========================================================================== */

@media (max-width: 760px) {

    .events-container {
        width: min(100% - 28px, 1240px);
    }

    .events-hero {
        padding: 58px 0 96px;
    }

    .hero-title {
        font-size: 44px;
    }

    .hero-text {
        font-size: 14px;
    }

    .events-filter-wrap {
        margin-top: -48px;
    }

    .events-filter {
        padding: 16px;
        border-radius: 17px;
    }

    .filter-main {
        grid-template-columns: 1fr;
    }

    .filter-bottom {
        align-items: flex-start;
        flex-direction: column;
    }

    .events-heading {
        align-items: flex-start;
        flex-direction: column;
        gap: 12px;
    }

    .events-heading h2 {
        font-size: 27px;
    }

    .events-grid {
        grid-template-columns: 1fr;
    }
}

/* ==========================================================================
   SMALL MOBILE
   ========================================================================== */

@media (max-width: 480px) {

    .events-section {
        padding-top: 45px;
    }

    .hero-title {
        font-size: 37px;
    }

    .hero-text {
        font-size: 13px;
    }

    .event-media {
        height: 205px;
    }

    .event-actions {
        grid-template-columns: 1fr;
    }

    .filter-bottom {
        gap: 12px;
    }
}

/* ==========================================================================
   REDUCED MOTION
   ========================================================================== */

@media (prefers-reduced-motion: reduce) {

    .event-card,
    .event-media img,
    .event-button,
    .search-button {
        transition: none;
    }
}

</style>

<div class="events-page">

    <!-- ================================================================
         HERO
         ================================================================ -->

    <section class="events-hero">

        <div class="events-container">

            <div class="hero-content">

                <span class="hero-badge">
                    EventSphere Campus
                </span>

                <h1 class="hero-title">
                    Find your next
                    <span>campus experience.</span>
                </h1>

                <p class="hero-text">
                    Discover competitions, workshops, seminars,
                    society activities and other events happening
                    across campus. Explore the details and find
                    something worth attending.
                </p>

            </div>

        </div>

    </section>

    <!-- ================================================================
         FILTER
         ================================================================ -->

    <section class="events-filter-wrap">

        <div class="events-container">

            <form
                method="GET"
                action="events.php"
                class="events-filter"
                autocomplete="off"
            >

                <div class="filter-main">

                    <!-- SEARCH -->

                    <div class="field">

                        <label for="search">
                            Search
                        </label>

                        <input
                            id="search"
                            type="search"
                            name="search"
                            class="input"
                            maxlength="120"
                            placeholder="Search events..."
                            value="<?= h($search) ?>"
                        >

                    </div>

                    <!-- CATEGORY -->

                    <div class="field">

                        <label for="category">
                            Category
                        </label>

                        <select
                            id="category"
                            name="category"
                            class="select"
                        >

                            <option value="0">
                                All Categories
                            </option>

                            <?php foreach ($categories as $category): ?>

                                <option
                                    value="<?= (int) $category['category_id'] ?>"
                                    <?= $categoryId === (int) $category['category_id'] ? 'selected' : '' ?>
                                >
                                    <?= h($category['category_name']) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <!-- DEPARTMENT -->

                    <div class="field">

                        <label for="department">
                            Department
                        </label>

                        <select
                            id="department"
                            name="department"
                            class="select"
                        >

                            <option value="0">
                                All Departments
                            </option>

                            <?php foreach ($departments as $department): ?>

                                <option
                                    value="<?= (int) $department['department_id'] ?>"
                                    <?= $departmentId === (int) $department['department_id'] ? 'selected' : '' ?>
                                >
                                    <?= h($department['department_name']) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <!-- DATE FROM -->

                    <div class="field">

                        <label for="date_from">
                            From
                        </label>

                        <input
                            id="date_from"
                            type="date"
                            name="date_from"
                            class="input"
                            value="<?= h($dateFrom) ?>"
                        >

                    </div>

                    <!-- DATE TO -->

                    <div class="field">

                        <label for="date_to">
                            Until
                        </label>

                        <input
                            id="date_to"
                            type="date"
                            name="date_to"
                            class="input"
                            value="<?= h($dateTo) ?>"
                        >

                    </div>

                    <!-- SEARCH BUTTON -->

                    <div>

                        <button
                            type="submit"
                            class="search-button"
                        >
                            Find Events
                        </button>

                    </div>

                </div>

                <!-- QUICK FILTERS -->

                <div class="filter-bottom">

                    <div class="quick-filters">

                        <?php

                        $allQuery = buildQuery([
                            'search' => $search,
                            'category' => $categoryId,
                            'department' => $departmentId,
                            'date_from' => $dateFrom,
                            'date_to' => $dateTo
                        ]);

                        ?>

                        <a
                            href="events.php<?= $allQuery ? '?' . h($allQuery) : '' ?>"
                            class="quick-filter <?= $status === 'all' ? 'active' : '' ?>"
                        >
                            All
                        </a>

                        <?php

                        $upcomingQuery = buildQuery([
                            'search' => $search,
                            'category' => $categoryId,
                            'department' => $departmentId,
                            'date_from' => $dateFrom,
                            'date_to' => $dateTo,
                            'status' => 'upcoming'
                        ]);

                        ?>

                        <a
                            href="events.php?<?= h($upcomingQuery) ?>"
                            class="quick-filter <?= $status === 'upcoming' ? 'active' : '' ?>"
                        >
                            Upcoming
                        </a>

                        <?php

                        $todayQuery = buildQuery([
                            'search' => $search,
                            'category' => $categoryId,
                            'department' => $departmentId,
                            'date_from' => $dateFrom,
                            'date_to' => $dateTo,
                            'status' => 'today'
                        ]);

                        ?>

                        <a
                            href="events.php?<?= h($todayQuery) ?>"
                            class="quick-filter <?= $status === 'today' ? 'active' : '' ?>"
                        >
                            Today
                        </a>

                        <?php

                        $pastQuery = buildQuery([
                            'search' => $search,
                            'category' => $categoryId,
                            'department' => $departmentId,
                            'date_from' => $dateFrom,
                            'date_to' => $dateTo,
                            'status' => 'past'
                        ]);

                        ?>

                        <a
                            href="events.php?<?= h($pastQuery) ?>"
                            class="quick-filter <?= $status === 'past' ? 'active' : '' ?>"
                        >
                            Past
                        </a>

                    </div>

                    <?php

                    $hasFilters =
                        $search !== ''
                        || $categoryId > 0
                        || $departmentId > 0
                        || $dateFrom !== ''
                        || $dateTo !== ''
                        || $status !== 'all';

                    ?>

                    <?php if ($hasFilters): ?>

                        <a
                            href="events.php"
                            class="reset-link"
                        >
                            Clear filters
                        </a>

                    <?php endif; ?>

                </div>

            </form>

        </div>

    </section>

    <!-- ================================================================
         EVENTS
         ================================================================ -->

    <section class="events-section">

        <div class="events-container">

            <div class="events-heading">

                <div>

                    <div class="heading-eyebrow">
                        What's happening
                    </div>

                    <h2>
                        Explore Events
                    </h2>

                    <p>
                        Browse published campus events and find something worth attending.
                    </p>

                </div>

                <div class="result-count">

                    <?= count($events) ?>

                    <?= count($events) === 1 ? 'Event' : 'Events' ?>

                </div>

            </div>

            <?php if (empty($events)): ?>

                <!-- EMPTY -->

                <div class="empty-state">

                    <div class="empty-symbol">
                        📅
                    </div>

                    <h3>
                        No events found
                    </h3>

                    <p>
                        There are no published events matching
                        your current search or filters.
                        Try another category or clear the filters.
                    </p>

                    <?php if ($hasFilters): ?>

                        <a href="events.php">
                            View all events
                        </a>

                    <?php endif; ?>

                </div>

            <?php else: ?>

                <!-- EVENT GRID -->

                <div class="events-grid">

                    <?php foreach ($events as $event): ?>

                        <?php

                        $eventId = (int) $event['event_id'];

                        $state = getEventState(
                            (string) $event['event_date'],
                            $event['start_time'] ?? null,
                            $event['end_time'] ?? null
                        );

                        $registration = registrationStatus(
                            $event['registration_open'] ?? null,
                            $event['registration_close'] ?? null,
                            (string) $event['event_date'],
                            $state['class']
                        );

                        $image = trim(
                            (string) (
                                $event['featured_image'] ?? ''
                            )
                        );

                        $description = trim(
                            (string) (
                                $event['short_description']
                                ?: $event['description']
                                ?: 'Event details will be available soon.'
                            )
                        );

                        $isOwner =
                            $isOrganizer
                            && $userId > 0
                            && (int) $event['organizer_id'] === $userId;

                        ?>

                        <article class="event-card">

                            <!-- EVENT IMAGE -->

                            <div class="event-media">

                                <?php if ($image !== ''): ?>

                                    <img
                                        src="<?= h($image) ?>"
                                        alt="<?= h($event['title']) ?>"
                                        loading="lazy"
                                        onerror="this.style.display='none';this.nextElementSibling.style.display='grid';"
                                    >

                                    <div
                                        class="event-fallback"
                                        style="display:none"
                                        aria-hidden="true"
                                    >
                                        ES
                                    </div>

                                <?php else: ?>

                                    <div
                                        class="event-fallback"
                                        aria-hidden="true"
                                    >
                                        ES
                                    </div>

                                <?php endif; ?>

                                <span
                                    class="event-status <?= h($state['class']) ?>"
                                >
                                    <?= h($state['label']) ?>
                                </span>

                            </div>

                            <!-- EVENT CONTENT -->

                            <div class="event-content">

                                <div class="event-topline">

                                    <span
                                        class="event-category"
                                        title="<?= h($event['category_name'] ?? 'General') ?>"
                                    >
                                        <?= h(
                                            $event['category_name']
                                            ?? 'General'
                                        ) ?>
                                    </span>

                                    <?php if (!empty($event['max_capacity'])): ?>

                                        <span class="event-capacity-badge">
                                            <?= (int) $event['max_capacity'] ?>
                                            seats
                                        </span>

                                    <?php endif; ?>

                                </div>

                                <!-- TITLE -->

                                <h3 class="event-title">
                                    <?= h($event['title']) ?>
                                </h3>

                                <!-- DESCRIPTION -->

                                <p class="event-description">
                                    <?= h($description) ?>
                                </p>

                                <!-- INFORMATION -->

                                <div class="event-info">

                                    <!-- DATE -->

                                    <div class="info-row">

                                        <div
                                            class="info-icon"
                                            aria-hidden="true"
                                        >
                                            D
                                        </div>

                                        <div class="info-content">

                                            <span class="info-label">
                                                Date
                                            </span>

                                            <span class="info-value">

                                                <?= h(
                                                    formatEventDate(
                                                        (string) $event['event_date']
                                                    )
                                                ) ?>

                                            </span>

                                        </div>

                                    </div>

                                    <!-- TIME -->

                                    <div class="info-row">

                                        <div
                                            class="info-icon"
                                            aria-hidden="true"
                                        >
                                            T
                                        </div>

                                        <div class="info-content">

                                            <span class="info-label">
                                                Time
                                            </span>

                                            <span class="info-value">

                                                <?= h(
                                                    formatEventTime(
                                                        $event['start_time'] ?? null
                                                    )
                                                ) ?>

                                                <?php if (!empty($event['end_time'])): ?>

                                                    —

                                                    <?= h(
                                                        formatEventTime(
                                                            $event['end_time']
                                                        )
                                                    ) ?>

                                                <?php endif; ?>

                                            </span>

                                        </div>

                                    </div>

                                    <!-- VENUE -->

                                    <div class="info-row">

                                        <div
                                            class="info-icon"
                                            aria-hidden="true"
                                        >
                                            V
                                        </div>

                                        <div class="info-content">

                                            <span class="info-label">
                                                Venue
                                            </span>

                                            <span class="info-value">
                                                <?= h(
                                                    $event['venue_name']
                                                    ?? 'Venue TBA'
                                                ) ?>
                                            </span>

                                        </div>

                                    </div>

                                    <!-- DEPARTMENT -->

                                    <div class="info-row">

                                        <div
                                            class="info-icon"
                                            aria-hidden="true"
                                        >
                                            A
                                        </div>

                                        <div class="info-content">

                                            <span class="info-label">
                                                Department
                                            </span>

                                            <span class="info-value">
                                                <?= h(
                                                    $event['department_name']
                                                    ?? 'General'
                                                ) ?>
                                            </span>

                                        </div>

                                    </div>

                                </div>

                                <!-- ACTIONS -->

                                <div class="event-actions">

                                    <!-- DETAILS -->

                                    <a
                                        href="event-details.php?id=<?= $eventId ?>"
                                        class="event-button details-button"
                                    >
                                        View Details
                                    </a>

                                    <?php if ($isOrganizer): ?>

                                        <!-- ORGANIZER -->

                                        <a
                                            href="<?= h($organizerEventPage) ?>?id=<?= $eventId ?>"
                                            class="event-button organizer-button"
                                        >
                                            <?= $isOwner
                                                ? 'Manage Event'
                                                : 'View Event'
                                            ?>
                                        </a>

                                    <?php elseif ($isStudent && $registration['allowed']): ?>

                                        <!-- STUDENT REGISTER -->

                                        <a
                                            href="event-details.php?id=<?= $eventId ?>#registration"
                                            class="event-button register-button"
                                        >
                                            Register Now
                                        </a>

                                    <?php elseif (!$isLoggedIn && $registration['allowed']): ?>

                                        <!-- LOGIN TO REGISTER -->

                                        <?php

                                        $redirectUrl =
                                            'event-details.php?id='
                                            . $eventId
                                            . '%23registration';

                                        ?>

                                        <a
                                            href="login.php?redirect=<?= h($redirectUrl) ?>"
                                            class="event-button login-button"
                                        >
                                            Login to Register
                                        </a>

                                    <?php else: ?>

                                        <!-- DISABLED -->

                                        <span
                                            class="event-button disabled-button"
                                            aria-disabled="true"
                                        >
                                            <?= h($registration['label']) ?>
                                        </span>

                                    <?php endif; ?>

                                </div>

                                <!-- OWNER NOTE -->

                                <?php if ($isOwner): ?>

                                    <div class="event-owner-note">
                                        This is your event
                                    </div>

                                <?php endif; ?>

                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </div>

    </section>

</div>

<?php require_once __DIR__ . '/footer.php'; ?>