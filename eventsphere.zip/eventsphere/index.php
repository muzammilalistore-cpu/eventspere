<?php
declare(strict_types=1);

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/functions.php";

$title = "EventSphere | College Events Platform";

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$is_logged_in = false;
$user_role = null;
$user_name = null;

if (isset($_SESSION["user"]) && is_array($_SESSION["user"]) && isset($_SESSION["user"]["user_id"])) {
    $is_logged_in = true;
    $user_role = $_SESSION["user"]["role"] ?? null;
    $user_name = $_SESSION["user"]["full_name"] ?? $_SESSION["user"]["name"] ?? $_SESSION["user"]["email"] ?? "User";
}

$dashboard_url = "login.php";

if ($is_logged_in) {
    if ($user_role === "student") {
        $dashboard_url = "student-dashboard.php";
    } elseif ($user_role === "organizer") {
        $dashboard_url = "organizer-dashboard.php";
    }
}

function safe_query($conn, $sql)
{
    $result = mysqli_query($conn, $sql);
    return $result ?: false;
}

function get_count($conn, $sql)
{
    $result = safe_query($conn, $sql);

    if (!$result) {
        return 0;
    }

    $row = mysqli_fetch_assoc($result);
    return (int)($row["total"] ?? 0);
}

$event_total = get_count(
    $conn,
    "SELECT COUNT(*) AS total
     FROM events
     WHERE event_status = 'published'"
);

$student_total = get_count(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE role = 'student'"
);

$department_total = get_count(
    $conn,
    "SELECT COUNT(*) AS total
     FROM departments"
);

$registration_total = get_count(
    $conn,
    "SELECT COUNT(*) AS total
     FROM event_registrations"
);

$events = safe_query(
    $conn,
    "SELECT
        e.event_id,
        e.title,
        e.short_description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.max_capacity,
        c.category_name,
        d.department_name,
        v.venue_name
     FROM events e
     INNER JOIN event_categories c ON c.category_id = e.category_id
     INNER JOIN departments d ON d.department_id = e.department_id
     INNER JOIN venues v ON v.venue_id = e.venue_id
     WHERE e.event_status = 'published'
     AND e.event_date >= CURDATE()
     ORDER BY e.event_date ASC, e.start_time ASC
     LIMIT 6"
);

$featured = false;

$featured_result = safe_query(
    $conn,
    "SELECT
        e.event_id,
        e.title,
        e.short_description,
        e.event_date,
        e.start_time,
        c.category_name,
        d.department_name,
        v.venue_name
     FROM events e
     INNER JOIN event_categories c ON c.category_id = e.category_id
     INNER JOIN departments d ON d.department_id = e.department_id
     INNER JOIN venues v ON v.venue_id = e.venue_id
     WHERE e.event_status = 'published'
     AND e.event_date >= CURDATE()
     ORDER BY e.event_date ASC, e.start_time ASC
     LIMIT 1"
);

if ($featured_result) {
    $featured = mysqli_fetch_assoc($featured_result);
}

$reviews_result = false;

$table_check = safe_query($conn, "SHOW TABLES LIKE 'event_reviews'");

if ($table_check && mysqli_num_rows($table_check) > 0) {
    $reviews_result = safe_query(
        $conn,
        "SELECT
            r.rating,
            r.comment,
            up.full_name
         FROM event_reviews r
         INNER JOIN user_profiles up ON up.user_id = r.student_id
         WHERE r.comment IS NOT NULL
         AND r.comment <> ''
         ORDER BY r.review_id DESC
         LIMIT 3"
    );
}

require "header.php";
?>

<style>
html,
body {
    max-width: 100%;
    overflow-x: hidden;
}

main.container {
    width: 100%;
    max-width: 100%;
    padding-left: 0;
    padding-right: 0;
}

.eventsphere-home {
    background: #f5f7fa;
    color: #1f2937;
}

.home-hero {
    background: #172554;
    color: #fff;
    padding: 88px 0 92px;
    position: relative;
}

.home-hero-inner {
    max-width: 1180px;
    margin: 0 auto;
    padding: 0 24px;
}

.home-hero-grid {
    display: grid;
    grid-template-columns: 1.35fr .65fr;
    gap: 70px;
    align-items: center;
}

.hero-small-title {
    display: inline-block;
    margin-bottom: 18px;
    color: #bfdbfe;
    font-size: .78rem;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.home-hero h1 {
    margin: 0;
    max-width: 760px;
    font-size: clamp(2.8rem, 6vw, 5.5rem);
    line-height: 1.02;
    font-weight: 800;
    letter-spacing: -.045em;
}

.home-hero h1 span {
    color: #93c5fd;
}

.home-hero-text {
    max-width: 650px;
    margin: 24px 0 0;
    color: #dbeafe;
    font-size: 1rem;
    line-height: 1.8;
}

.hero-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 30px;
}

.hero-main-btn,
.hero-outline-btn {
    min-height: 48px;
    padding: 0 20px;
    border-radius: 7px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    font-weight: 700;
    transition: .2s ease;
}

.hero-main-btn {
    background: #fff;
    color: #172554;
}

.hero-main-btn:hover {
    color: #172554;
    transform: translateY(-2px);
}

.hero-outline-btn {
    border: 1px solid rgba(255, 255, 255, .35);
    color: #fff;
}

.hero-outline-btn:hover {
    color: #fff;
    background: rgba(255, 255, 255, .08);
}

.hero-info-box {
    background: #fff;
    color: #1f2937;
    border-radius: 10px;
    padding: 28px;
    box-shadow: 0 18px 45px rgba(0, 0, 0, .16);
}

.hero-info-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 25px;
}

.hero-info-heading strong {
    font-size: 1rem;
}

.hero-status {
    padding: 5px 10px;
    border-radius: 20px;
    background: #dcfce7;
    color: #166534;
    font-size: .7rem;
    font-weight: 700;
}

.hero-info-row {
    padding: 15px 0;
    border-top: 1px solid #e5e7eb;
}

.hero-info-row:first-of-type {
    border-top: 0;
}

.hero-info-label {
    color: #6b7280;
    font-size: .75rem;
    margin-bottom: 5px;
}

.hero-info-value {
    color: #111827;
    font-size: 1rem;
    font-weight: 700;
}

.home-stats {
    margin-top: -32px;
    position: relative;
    z-index: 5;
}

.stats-box {
    max-width: 1120px;
    margin: 0 auto;
    padding: 0 24px;
}

.stats-inner {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 9px;
    box-shadow: 0 10px 30px rgba(15, 23, 42, .08);
}

.stat-column {
    padding: 24px 20px;
    text-align: center;
}

.stat-column + .stat-column {
    border-left: 1px solid #e5e7eb;
}

.stat-value {
    color: #172554;
    font-size: 1.9rem;
    font-weight: 800;
    line-height: 1;
}

.stat-caption {
    margin-top: 7px;
    color: #6b7280;
    font-size: .78rem;
}

.home-section {
    padding: 82px 0;
}

.home-section-inner {
    max-width: 1120px;
    margin: 0 auto;
    padding: 0 24px;
}

.section-heading {
    max-width: 700px;
    margin-bottom: 38px;
}

.section-label {
    display: block;
    margin-bottom: 8px;
    color: #2563eb;
    font-size: .73rem;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.section-heading h2 {
    margin: 0;
    color: #111827;
    font-size: clamp(2rem, 4vw, 3rem);
    line-height: 1.1;
    font-weight: 800;
    letter-spacing: -.035em;
}

.section-heading p {
    margin: 14px 0 0;
    color: #6b7280;
    line-height: 1.75;
}

.event-card {
    height: 100%;
    overflow: hidden;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 9px;
    transition: .2s ease;
}

.event-card:hover {
    transform: translateY(-4px);
    border-color: #cbd5e1;
    box-shadow: 0 14px 30px rgba(15, 23, 42, .08);
}

.event-card-header {
    height: 5px;
    background: #2563eb;
}

.event-card-body {
    padding: 23px;
}

.event-category {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 5px;
    background: #eff6ff;
    color: #1d4ed8;
    font-size: .67rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.event-card h3 {
    margin: 15px 0 9px;
    color: #111827;
    font-size: 1.17rem;
    font-weight: 750;
    line-height: 1.35;
}

.event-description {
    min-height: 48px;
    margin: 0;
    color: #6b7280;
    font-size: .88rem;
    line-height: 1.65;
}

.event-details {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin: 19px 0;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
}

.event-detail {
    display: flex;
    align-items: center;
    gap: 9px;
    color: #4b5563;
    font-size: .78rem;
}

.event-detail-label {
    min-width: 58px;
    color: #9ca3af;
    font-size: .7rem;
    font-weight: 700;
    text-transform: uppercase;
}

.event-view {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #1d4ed8;
    text-decoration: none;
    font-size: .82rem;
    font-weight: 750;
}

.event-view:hover {
    color: #1e40af;
}

.about-section {
    background: #fff;
}

.about-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 55px;
    align-items: center;
}

.about-heading h2 {
    margin: 0;
    color: #111827;
    font-size: clamp(2rem, 4vw, 3rem);
    line-height: 1.1;
    font-weight: 800;
    letter-spacing: -.035em;
}

.about-heading p {
    margin: 18px 0 0;
    color: #6b7280;
    line-height: 1.8;
}

.about-list {
    margin-top: 27px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}

.about-item {
    padding: 17px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #fafafa;
}

.about-item-number {
    color: #2563eb;
    font-size: .7rem;
    font-weight: 800;
}

.about-item strong {
    display: block;
    margin-top: 5px;
    color: #1f2937;
    font-size: .9rem;
}

.about-item span {
    display: block;
    margin-top: 5px;
    color: #6b7280;
    font-size: .78rem;
    line-height: 1.55;
}

.about-preview {
    padding: 25px;
    border: 1px solid #dbe3ef;
    border-radius: 10px;
    background: #f8fafc;
}

.preview-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 18px;
    border-bottom: 1px solid #e5e7eb;
}

.preview-top strong {
    color: #1f2937;
    font-size: .9rem;
}

.preview-top span {
    color: #16a34a;
    font-size: .72rem;
    font-weight: 700;
}

.preview-stat {
    padding: 18px 0;
    border-bottom: 1px solid #e5e7eb;
}

.preview-stat:last-child {
    border-bottom: 0;
    padding-bottom: 0;
}

.preview-stat-top {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 8px;
    color: #4b5563;
    font-size: .76rem;
}

.preview-bar {
    width: 100%;
    height: 7px;
    overflow: hidden;
    border-radius: 20px;
    background: #e5e7eb;
}

.preview-bar span {
    display: block;
    height: 100%;
    border-radius: inherit;
    background: #2563eb;
}

.featured-wrapper {
    background: #f5f7fa;
}

.featured-card {
    background: #172554;
    color: #fff;
    border-radius: 10px;
    padding: 38px;
}

.featured-grid {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 40px;
    align-items: center;
}

.featured-label {
    display: inline-block;
    margin-bottom: 12px;
    color: #bfdbfe;
    font-size: .72rem;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.featured-date {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 5px;
    background: rgba(255, 255, 255, .1);
    color: #dbeafe;
    font-size: .74rem;
}

.featured-card h2 {
    margin: 15px 0 10px;
    color: #fff;
    font-size: clamp(1.8rem, 4vw, 2.8rem);
    font-weight: 800;
    line-height: 1.15;
}

.featured-card p {
    max-width: 680px;
    margin: 0;
    color: #dbeafe;
    line-height: 1.7;
}

.featured-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 18px;
}

.featured-tag {
    padding: 6px 10px;
    border: 1px solid rgba(255, 255, 255, .16);
    border-radius: 5px;
    color: #e0e7ff;
    font-size: .7rem;
}

.featured-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 48px;
    padding: 0 20px;
    border-radius: 7px;
    background: #fff;
    color: #172554;
    text-decoration: none;
    font-weight: 750;
    white-space: nowrap;
}

.featured-button:hover {
    color: #172554;
    background: #eff6ff;
}

.feature-card {
    height: 100%;
    padding: 24px;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 9px;
}

.feature-number {
    color: #2563eb;
    font-size: .75rem;
    font-weight: 800;
}

.feature-card h3 {
    margin: 14px 0 8px;
    color: #1f2937;
    font-size: 1rem;
    font-weight: 750;
}

.feature-card p {
    margin: 0;
    color: #6b7280;
    font-size: .83rem;
    line-height: 1.65;
}

.review-card {
    height: 100%;
    padding: 24px;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 9px;
}

.review-stars {
    color: #f59e0b;
    font-size: .9rem;
    letter-spacing: 2px;
}

.review-text {
    margin: 17px 0;
    color: #4b5563;
    font-size: .88rem;
    line-height: 1.75;
}

.review-name {
    color: #1f2937;
    font-size: .85rem;
    font-weight: 750;
}

.review-role {
    display: block;
    margin-top: 3px;
    color: #9ca3af;
    font-size: .72rem;
}

.home-cta {
    padding: 0 0 82px;
}

.cta-box {
    padding: 55px 30px;
    border-radius: 10px;
    background: #eaf2ff;
    border: 1px solid #d7e6ff;
    text-align: center;
}

.cta-box h2 {
    margin: 0;
    color: #172554;
    font-size: clamp(1.9rem, 4vw, 3rem);
    font-weight: 800;
    letter-spacing: -.035em;
}

.cta-box p {
    max-width: 610px;
    margin: 14px auto 24px;
    color: #475569;
    line-height: 1.7;
}

.cta-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 48px;
    padding: 0 22px;
    border-radius: 7px;
    background: #172554;
    color: #fff;
    text-decoration: none;
    font-weight: 750;
}

.cta-button:hover {
    color: #fff;
    background: #1e3a8a;
}

.empty-events {
    padding: 55px 20px;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 9px;
    text-align: center;
}

.empty-events h4 {
    margin-bottom: 7px;
    color: #1f2937;
}

.empty-events p {
    margin: 0;
    color: #6b7280;
}

@media (max-width: 991px) {
    .home-hero-grid {
        grid-template-columns: 1fr;
        gap: 40px;
    }

    .hero-info-box {
        max-width: 600px;
    }

    .about-grid {
        grid-template-columns: 1fr;
        gap: 40px;
    }

    .featured-grid {
        grid-template-columns: 1fr;
    }

    .featured-button {
        width: fit-content;
    }
}

@media (max-width: 767px) {
    .home-hero {
        padding: 65px 0 75px;
    }

    .home-hero-inner,
    .home-section-inner {
        padding-left: 18px;
        padding-right: 18px;
    }

    .home-hero h1 {
        font-size: clamp(2.7rem, 13vw, 4rem);
    }

    .hero-buttons {
        flex-direction: column;
        align-items: stretch;
    }

    .hero-main-btn,
    .hero-outline-btn {
        width: 100%;
    }

    .home-stats {
        margin-top: -22px;
    }

    .stats-box {
        padding: 0 14px;
    }

    .stat-column {
        padding: 18px 8px;
    }

    .stat-column + .stat-column {
        border-left: 0;
    }

    .stat-value {
        font-size: 1.45rem;
    }

    .stat-caption {
        font-size: .67rem;
    }

    .home-section {
        padding: 65px 0;
    }

    .about-list {
        grid-template-columns: 1fr;
    }

    .featured-card {
        padding: 27px 22px;
    }

    .featured-button {
        width: 100%;
    }

    .home-cta {
        padding-bottom: 65px;
    }

    .cta-box {
        padding: 42px 20px;
    }
}
</style>

<div class="eventsphere-home">
    <section class="home-hero">
        <div class="home-hero-inner">
            <div class="home-hero-grid">
                <div>
                    <span class="hero-small-title">EventSphere · College Event Management</span>

                    <h1>
                        Stay connected with
                        <span>campus events.</span>
                    </h1>

                    <p class="home-hero-text">
                        Discover upcoming college activities, register for events and keep track of your participation through one simple platform.
                    </p>

                    <div class="hero-buttons">
                        <a href="events.php" class="hero-main-btn">Browse Events</a>

                        <?php if ($is_logged_in): ?>
                            <a href="<?= e($dashboard_url) ?>" class="hero-outline-btn">My Dashboard</a>
                        <?php else: ?>
                            <a href="register.php" class="hero-outline-btn">Create Account</a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="hero-info-box">
                    <div class="hero-info-heading">
                        <strong>Campus Event Portal</strong>
                        <span class="hero-status">Active</span>
                    </div>

                    <div class="hero-info-row">
                        <div class="hero-info-label">Published Events</div>
                        <div class="hero-info-value"><?= $event_total ?></div>
                    </div>

                    <div class="hero-info-row">
                        <div class="hero-info-label">Registered Students</div>
                        <div class="hero-info-value"><?= $student_total ?></div>
                    </div>

                    <div class="hero-info-row">
                        <div class="hero-info-label">Departments</div>
                        <div class="hero-info-value"><?= $department_total ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="home-stats">
        <div class="stats-box">
            <div class="stats-inner">
                <div class="row g-0">
                    <div class="col-6 col-md-3">
                        <div class="stat-column">
                            <div class="stat-value"><?= $event_total ?>+</div>
                            <div class="stat-caption">Published Events</div>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="stat-column">
                            <div class="stat-value"><?= $student_total ?>+</div>
                            <div class="stat-caption">Students</div>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="stat-column">
                            <div class="stat-value"><?= $department_total ?></div>
                            <div class="stat-caption">Departments</div>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="stat-column">
                            <div class="stat-value"><?= $registration_total ?>+</div>
                            <div class="stat-caption">Registrations</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="home-section">
        <div class="home-section-inner">
            <div class="section-heading">
                <span class="section-label">Upcoming Events</span>
                <h2>Find something happening on campus.</h2>
                <p>
                    Browse upcoming activities, academic events, student programs and other college activities.
                </p>
            </div>

            <div class="row g-4">
                <?php if ($events && mysqli_num_rows($events) > 0): ?>
                    <?php while ($event = mysqli_fetch_assoc($events)): ?>
                        <div class="col-md-6 col-lg-4">
                            <article class="event-card">
                                <div class="event-card-header"></div>

                                <div class="event-card-body">
                                    <span class="event-category">
                                        <?= e($event["category_name"]) ?>
                                    </span>

                                    <h3><?= e($event["title"]) ?></h3>

                                    <p class="event-description">
                                        <?= e($event["short_description"]) ?>
                                    </p>

                                    <div class="event-details">
                                        <div class="event-detail">
                                            <span class="event-detail-label">Date</span>
                                            <span><?= e($event["event_date"]) ?></span>
                                        </div>

                                        <div class="event-detail">
                                            <span class="event-detail-label">Time</span>
                                            <span><?= e($event["start_time"]) ?></span>
                                        </div>

                                        <div class="event-detail">
                                            <span class="event-detail-label">Venue</span>
                                            <span><?= e($event["venue_name"]) ?></span>
                                        </div>
                                    </div>

                                    <a href="event-details.php?id=<?= (int)$event["event_id"] ?>" class="event-view">
                                        View event details →
                                    </a>
                                </div>
                            </article>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12">
                        <div class="empty-events">
                            <h4>No upcoming events</h4>
                            <p>New published events will appear here.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="text-center mt-5">
                <a href="events.php" class="btn btn-dark px-4 py-2">View All Events</a>
            </div>
        </div>
    </section>

    <section class="home-section about-section">
        <div class="home-section-inner">
            <div class="about-grid">
                <div class="about-heading">
                    <span class="section-label">About EventSphere</span>

                    <h2>A simpler way to manage college events.</h2>

                    <p>
                        EventSphere provides students and college organizers with a central platform for discovering, publishing and managing campus events.
                    </p>

                    <div class="about-list">
                        <div class="about-item">
                            <span class="about-item-number">01</span>
                            <strong>Discover Events</strong>
                            <span>Search events by category, department, date and venue.</span>
                        </div>

                        <div class="about-item">
                            <span class="about-item-number">02</span>
                            <strong>Register Online</strong>
                            <span>Register for available events without unnecessary steps.</span>
                        </div>

                        <div class="about-item">
                            <span class="about-item-number">03</span>
                            <strong>Receive Updates</strong>
                            <span>Stay informed about announcements and event changes.</span>
                        </div>

                        <div class="about-item">
                            <span class="about-item-number">04</span>
                            <strong>Track Participation</strong>
                            <span>Keep registrations and participation records organized.</span>
                        </div>
                    </div>
                </div>

                <div class="about-preview">
                    <div class="preview-top">
                        <strong>Student Activity</strong>
                        <span>● Active</span>
                    </div>

                    <div class="preview-stat">
                        <div class="preview-stat-top">
                            <span>Event Discovery</span>
                            <span>91%</span>
                        </div>
                        <div class="preview-bar">
                            <span style="width:91%;"></span>
                        </div>
                    </div>

                    <div class="preview-stat">
                        <div class="preview-stat-top">
                            <span>Student Participation</span>
                            <span>82%</span>
                        </div>
                        <div class="preview-bar">
                            <span style="width:82%;"></span>
                        </div>
                    </div>

                    <div class="preview-stat">
                        <div class="preview-stat-top">
                            <span>Community Engagement</span>
                            <span>74%</span>
                        </div>
                        <div class="preview-bar">
                            <span style="width:74%;"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if ($featured): ?>
        <section class="home-section featured-wrapper">
            <div class="home-section-inner">
                <div class="featured-card">
                    <div class="featured-grid">
                        <div>
                            <span class="featured-label">Featured Event</span>

                            <div class="featured-date">
                                <?= e($featured["event_date"]) ?> &nbsp; · &nbsp; <?= e($featured["start_time"]) ?>
                            </div>

                            <h2><?= e($featured["title"]) ?></h2>

                            <p><?= e($featured["short_description"]) ?></p>

                            <div class="featured-tags">
                                <span class="featured-tag"><?= e($featured["category_name"]) ?></span>
                                <span class="featured-tag"><?= e($featured["department_name"]) ?></span>
                                <span class="featured-tag"><?= e($featured["venue_name"]) ?></span>
                            </div>
                        </div>

                        <div>
                            <a href="event-details.php?id=<?= (int)$featured["event_id"] ?>" class="featured-button">
                                View Event
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="home-section">
        <div class="home-section-inner">
            <div class="section-heading">
                <span class="section-label">Platform Features</span>
                <h2>Everything you need in one place.</h2>
                <p>EventSphere brings the important parts of campus event management together.</p>
            </div>

            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="feature-card">
                        <div class="feature-number">01</div>
                        <h3>Event Discovery</h3>
                        <p>Find relevant college events using categories, departments, dates and venues.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="feature-card">
                        <div class="feature-number">02</div>
                        <h3>Online Registration</h3>
                        <p>Register for available events and keep your upcoming activities organized.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="feature-card">
                        <div class="feature-number">03</div>
                        <h3>Participation Records</h3>
                        <p>View registrations, attendance and participation information through your account.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3">
                    <div class="feature-card">
                        <div class="feature-number">04</div>
                        <h3>Student Feedback</h3>
                        <p>Share event experiences through ratings and feedback after participating.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if ($reviews_result && mysqli_num_rows($reviews_result) > 0): ?>
        <section class="home-section about-section">
            <div class="home-section-inner">
                <div class="section-heading">
                    <span class="section-label">Student Feedback</span>
                    <h2>What participants are saying.</h2>
                    <p>Feedback submitted by students after participating in events.</p>
                </div>

                <div class="row g-4">
                    <?php while ($review = mysqli_fetch_assoc($reviews_result)): ?>
                        <div class="col-md-4">
                            <div class="review-card">
                                <div class="review-stars">
                                    <?php
                                    $rating = (int)$review["rating"];
                                    $rating = max(1, min(5, $rating));

                                    for ($i = 1; $i <= 5; $i++) {
                                        echo $i <= $rating ? "★" : "☆";
                                    }
                                    ?>
                                </div>

                                <p class="review-text">“<?= e($review["comment"]) ?>”</p>

                                <div class="review-name">
                                    <?= e($review["full_name"]) ?>
                                </div>

                                <span class="review-role">Event Participant</span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="home-cta">
        <div class="home-section-inner">
            <div class="cta-box">
                <h2>Ready to explore campus events?</h2>

                <p>
                    Find an event that interests you, check the details and register when seats are available.
                </p>

                <a href="events.php" class="cta-button">Explore Events</a>
            </div>
        </div>
    </section>
</div>

<?php require "footer.php"; ?>