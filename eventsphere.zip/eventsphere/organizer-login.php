<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require "db.php";
require_once "functions.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Already logged in organizer */
if (isset($_SESSION["user"])) {
    $loggedUser = $_SESSION["user"];

    if (($loggedUser["role"] ?? "") === "organizer") {
        header("Location: organizer-dashboard.php");
        exit;
    }
}

$error = "";
$email = "";

/* =========================================================
   ORGANIZER LOGIN
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($email === "" || $password === "") {

        $error = "Please enter your email and password.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } else {

        $sql = "
            SELECT
                user_id,
                email,
                password_hash,
                role,
                account_status,
                email_verified
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {

            $error = "Something went wrong. Please try again.";

        } else {

            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);

            mysqli_stmt_bind_result(
                $stmt,
                $userId,
                $dbEmail,
                $passwordHash,
                $role,
                $accountStatus,
                $emailVerified
            );

            if (mysqli_stmt_fetch($stmt)) {

                /* Check role */
                if ($role !== "organizer") {

                    $error = "This login is only for organizers.";

                /* Check account */
                } elseif ($accountStatus !== "active") {

                    $error = "Your organizer account is not active.";

                /* Check password */
                } elseif (!password_verify($password, $passwordHash)) {

                    $error = "Invalid email or password.";

                } else {

                    /* Regenerate session */
                    session_regenerate_id(true);

                    $_SESSION["user"] = [
                        "user_id" => (int)$userId,
                        "email" => $dbEmail,
                        "role" => $role,
                        "account_status" => $accountStatus,
                        "email_verified" => (int)$emailVerified
                    ];

                    /* Update last login */
                    mysqli_stmt_close($stmt);

                    $updateSql = "
                        UPDATE users
                        SET last_login_at = NOW()
                        WHERE user_id = ?
                    ";

                    $updateStmt = mysqli_prepare($conn, $updateSql);

                    if ($updateStmt) {
                        mysqli_stmt_bind_param(
                            $updateStmt,
                            "i",
                            $userId
                        );

                        mysqli_stmt_execute($updateStmt);
                        mysqli_stmt_close($updateStmt);
                    }

                    header("Location: organizer-dashboard.php");
                    exit;
                }

            } else {

                $error = "Invalid email or password.";
            }

            mysqli_stmt_close($stmt);
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Organizer Login | EventSphere</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;

            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background:
                radial-gradient(
                    circle at 10% 20%,
                    rgba(99,102,241,.14),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 90% 80%,
                    rgba(14,165,233,.12),
                    transparent 30%
                ),
                #f8fafc;

            display: flex;
            align-items: center;
            justify-content: center;

            padding: 25px;
        }

        .login-wrapper {
            width: 100%;
            max-width: 1050px;

            display: grid;
            grid-template-columns: 1fr 1fr;

            background: #fff;

            border: 1px solid #e5e7eb;

            border-radius: 28px;

            overflow: hidden;

            box-shadow:
                0 30px 80px rgba(15,23,42,.12);
        }

        /* LEFT */

        .login-info {
            position: relative;

            padding: 60px;

            color: #fff;

            background:
                radial-gradient(
                    circle at 80% 15%,
                    rgba(129,140,248,.35),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 10% 90%,
                    rgba(34,211,238,.15),
                    transparent 30%
                ),
                linear-gradient(
                    145deg,
                    #0f172a,
                    #1e293b 55%,
                    #312e81
                );

            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;

            font-size: 14px;
            font-weight: 800;

            letter-spacing: .5px;

            margin-bottom: 45px;
        }

        .brand-icon {
            width: 38px;
            height: 38px;

            border-radius: 12px;

            display: flex;
            align-items: center;
            justify-content: center;

            background: rgba(255,255,255,.12);

            border: 1px solid rgba(255,255,255,.15);
        }

        .login-info h1 {
            margin: 0 0 15px;

            font-size: 42px;
            line-height: 1.1;
            font-weight: 850;
            letter-spacing: -1.5px;
        }

        .login-info p {
            margin: 0;

            max-width: 430px;

            color: #cbd5e1;

            font-size: 14px;
            line-height: 1.8;
        }

        .features {
            margin-top: 35px;

            display: grid;
            gap: 13px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 12px;

            color: #e2e8f0;

            font-size: 12px;
            font-weight: 600;
        }

        .feature span {
            width: 28px;
            height: 28px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 9px;

            background: rgba(255,255,255,.09);

            color: #a5b4fc;
        }

        /* RIGHT */

        .login-form-area {
            padding: 60px;

            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-heading {
            margin-bottom: 30px;
        }

        .form-heading small {
            display: block;

            color: #6366f1;

            font-size: 10px;
            font-weight: 850;

            letter-spacing: 1.5px;
            text-transform: uppercase;

            margin-bottom: 9px;
        }

        .form-heading h2 {
            margin: 0 0 8px;

            color: #0f172a;

            font-size: 28px;
            font-weight: 850;
        }

        .form-heading p {
            margin: 0;

            color: #94a3b8;

            font-size: 12px;
        }

        .alert {
            padding: 13px 15px;

            margin-bottom: 20px;

            border-radius: 11px;

            font-size: 12px;
            font-weight: 650;

            background: #fef2f2;

            border: 1px solid #fecaca;

            color: #b91c1c;
        }

        .form-group {
            margin-bottom: 19px;
        }

        .form-group label {
            display: block;

            margin-bottom: 8px;

            color: #334155;

            font-size: 11px;
            font-weight: 800;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper input {
            width: 100%;

            height: 52px;

            padding: 0 15px;

            border: 1px solid #dbe2ea;

            border-radius: 12px;

            outline: none;

            color: #0f172a;

            background: #fff;

            font-size: 13px;

            transition: .2s ease;
        }

        .input-wrapper input:focus {
            border-color: #818cf8;

            box-shadow:
                0 0 0 4px rgba(99,102,241,.10);
        }

        .login-btn {
            width: 100%;

            height: 52px;

            border: 0;

            border-radius: 12px;

            cursor: pointer;

            color: #fff;

            background:
                linear-gradient(
                    135deg,
                    #6366f1,
                    #4f46e5
                );

            font-size: 12px;
            font-weight: 850;

            box-shadow:
                0 12px 25px rgba(79,70,229,.22);

            transition: .25s ease;
        }

        .login-btn:hover {
            transform: translateY(-2px);

            box-shadow:
                0 16px 30px rgba(79,70,229,.28);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        .bottom-links {
            margin-top: 25px;

            text-align: center;

            font-size: 12px;

            color: #94a3b8;
        }

        .bottom-links a {
            color: #4f46e5;

            font-weight: 750;

            text-decoration: none;
        }

        .bottom-links a:hover {
            text-decoration: underline;
        }

        .student-link {
            margin-top: 10px;

            text-align: center;
        }

        .student-link a {
            color: #64748b;

            text-decoration: none;

            font-size: 11px;
            font-weight: 700;
        }

        .student-link a:hover {
            color: #4f46e5;
        }

        /* MOBILE */

        @media (max-width: 800px) {

            body {
                padding: 15px;
            }

            .login-wrapper {
                grid-template-columns: 1fr;

                max-width: 520px;
            }

            .login-info {
                padding: 35px;
            }

            .login-info h1 {
                font-size: 32px;
            }

            .features {
                margin-top: 25px;
            }

            .login-form-area {
                padding: 35px;
            }
        }

        @media (max-width: 480px) {

            .login-info,
            .login-form-area {
                padding: 28px 22px;
            }

            .login-info h1 {
                font-size: 28px;
            }

        }

    </style>

</head>

<body>

<div class="login-wrapper">

    <!-- LEFT SIDE -->

    <div class="login-info">

        <div class="brand">

            <div class="brand-icon">
                ES
            </div>

            EventSphere

        </div>

        <h1>
            Manage events.<br>
            Lead experiences.
        </h1>

        <p>
            Access your organizer workspace to create,
            manage and monitor college events from one
            centralized portal.
        </p>

        <div class="features">

            <div class="feature">
                <span>✓</span>
                Create and manage events
            </div>

            <div class="feature">
                <span>✓</span>
                Manage registrations
            </div>

            <div class="feature">
                <span>✓</span>
                Monitor event activity
            </div>

            <div class="feature">
                <span>✓</span>
                Organizer-only workspace
            </div>

        </div>

    </div>


    <!-- RIGHT SIDE -->

    <div class="login-form-area">

        <div class="form-heading">

            <small>
                Organizer Portal
            </small>

            <h2>
                Welcome back
            </h2>

            <p>
                Sign in with your organizer account.
            </p>

        </div>


        <?php if ($error !== ""): ?>

            <div class="alert">
                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    "UTF-8"
                ) ?>
            </div>

        <?php endif; ?>


        <form method="POST" autocomplete="on">

            <div class="form-group">

                <label for="email">
                    Organizer Email
                </label>

                <div class="input-wrapper">

                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="<?= htmlspecialchars(
                            $email,
                            ENT_QUOTES,
                            "UTF-8"
                        ) ?>"
                        placeholder="organizer@example.com"
                        autocomplete="username"
                        required
                    >

                </div>

            </div>


            <div class="form-group">

                <label for="password">
                    Password
                </label>

                <div class="input-wrapper">

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                        required
                    >

                </div>

            </div>


            <button
                type="submit"
                class="login-btn"
            >
                Sign In to Organizer Portal
            </button>

        </form>


        <div class="bottom-links">

            Need an organizer account?
            <a href="organizer-register.php">
                Register
            </a>

        </div>

        <div class="student-link">

            <a href="login.php">
                Student Login →
            </a>

        </div>

    </div>

</div>

</body>

</html>