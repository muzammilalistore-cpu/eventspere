<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| EventSphere - Common Functions
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Escape Output
|--------------------------------------------------------------------------
*/

function e(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}


/*
|--------------------------------------------------------------------------
| Backward-Compatible Redirect Helper
|--------------------------------------------------------------------------
*/

function go(string $url): never
{
    redirect($url);
}


/*
|--------------------------------------------------------------------------
| Database Query Helper
|--------------------------------------------------------------------------
|
| Used by register.php and other pages:
|
| q($conn, $sql)
| q($conn, $sql, "i", $id)
| q($conn, $sql, "s", $email)
|
|--------------------------------------------------------------------------
*/

function q(
    mysqli $conn,
    string $sql,
    string $types = '',
    mixed ...$params
): mysqli_result {

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        throw new RuntimeException(
            'Database query preparation failed: ' . mysqli_error($conn)
        );
    }

    if ($types !== '') {

        if (count($params) !== strlen($types)) {
            throw new InvalidArgumentException(
                'Number of parameters does not match parameter types.'
            );
        }

        mysqli_stmt_bind_param(
            $stmt,
            $types,
            ...$params
        );
    }

    if (!mysqli_stmt_execute($stmt)) {
        throw new RuntimeException(
            'Database query execution failed: ' .
            mysqli_stmt_error($stmt)
        );
    }

    $result = mysqli_stmt_get_result($stmt);

    if ($result === false) {
        throw new RuntimeException(
            'Unable to retrieve database result: ' .
            mysqli_stmt_error($stmt)
        );
    }

    return $result;
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

function is_logged_in(): bool
{
    return isset($_SESSION['user']['user_id'])
        && is_numeric($_SESSION['user']['user_id']);
}


/*
|--------------------------------------------------------------------------
| Auth Alias
|--------------------------------------------------------------------------
|
| Kept for compatibility with older EventSphere pages.
|
|--------------------------------------------------------------------------
*/

function auth(): bool
{
    return is_logged_in();
}


/*
|--------------------------------------------------------------------------
| Require Login
|--------------------------------------------------------------------------
*/

function require_auth(): void
{
    if (!is_logged_in()) {
        redirect('login.php?error=unauthorized');
    }
}


/*
|--------------------------------------------------------------------------
| Current User ID
|--------------------------------------------------------------------------
*/

function current_user_id(): int
{
    if (
        isset($_SESSION['user']['user_id'])
        && is_numeric($_SESSION['user']['user_id'])
    ) {
        return (int) $_SESSION['user']['user_id'];
    }

    return 0;
}


/*
|--------------------------------------------------------------------------
| Roles
|--------------------------------------------------------------------------
*/

function is_student(): bool
{
    return is_logged_in()
        && ($_SESSION['user']['role'] ?? '') === 'student';
}


function is_organizer(): bool
{
    return is_logged_in()
        && ($_SESSION['user']['role'] ?? '') === 'organizer';
}


/*
|--------------------------------------------------------------------------
| Require Student
|--------------------------------------------------------------------------
*/

function require_student(): void
{
    require_auth();

    if (!is_student()) {
        redirect('dashboard.php?error=unauthorized');
    }
}


/*
|--------------------------------------------------------------------------
| Require Organizer
|--------------------------------------------------------------------------
*/

function require_organizer(): void
{
    require_auth();

    if (!is_organizer()) {
        redirect('dashboard.php?error=unauthorized');
    }
}


/*
|--------------------------------------------------------------------------
| Session User
|--------------------------------------------------------------------------
*/

function session_user(): array
{
    return $_SESSION['user'] ?? [];
}


function session_user_name(): string
{
    $user = session_user();

    return trim(
        (string) ($user['full_name'] ?? 'User')
    ) ?: 'User';
}


function session_user_email(): string
{
    $user = session_user();

    return trim(
        (string) ($user['email'] ?? '')
    );
}


function session_user_role(): string
{
    return (string) (
        $_SESSION['user']['role'] ?? ''
    );
}
function flash(string $message, string $type = "info"): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (!isset($_SESSION["flash"]) || !is_array($_SESSION["flash"])) {
        $_SESSION["flash"] = [];
    }

    $_SESSION["flash"][] = [
        "message" => $message,
        "type" => $type
    ];
}

function get_flash_messages(): array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $messages = $_SESSION["flash"] ?? [];

    unset($_SESSION["flash"]);

    return is_array($messages) ? $messages : [];
}