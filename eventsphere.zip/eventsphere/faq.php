<?php

require "db.php";

$title = "FAQs | EventSphere";

require "header.php";
?>

<div class="container py-5">

    <div class="text-center mb-5">
        <span class="text-uppercase small fw-semibold text-primary">
            EventSphere
        </span>

        <h1 class="display-5 fw-bold mt-2">
            Frequently Asked Questions
        </h1>

        <p class="text-muted mx-auto" style="max-width: 650px;">
            Find answers to common questions about events, registrations,
            gallery, certificates, reviews, and your EventSphere account.
        </p>
    </div>

    <div class="accordion shadow-sm rounded-4 overflow-hidden" id="faqAccordion">

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button fw-semibold" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq1">
                    What is EventSphere?
                </button>
            </h2>

            <div id="faq1" class="accordion-collapse collapse show"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    EventSphere is a college event management platform that
                    allows students to discover upcoming events, register for
                    events, manage registrations, explore event media, submit
                    feedback, and access their event-related information.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq2">
                    Do I need an account to register for an event?
                </button>
            </h2>

            <div id="faq2" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. Students need to log in to their EventSphere account
                    before registering for events and accessing personalized
                    dashboard features.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq3">
                    How can I register for an event?
                </button>
            </h2>

            <div id="faq3" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Open the event details page, check the available slots,
                    and select the registration option. Once your registration
                    is confirmed, the event will appear in your dashboard.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq4">
                    What happens when an event is full?
                </button>
            </h2>

            <div id="faq4" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    When all available seats are booked, students may be
                    placed on the event waitlist if waitlist functionality
                    is enabled for that event.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq5">
                    Can I cancel my event registration?
                </button>
            </h2>

            <div id="faq5" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. Registered students can manage their upcoming event
                    registrations through their dashboard and cancel a
                    registration when cancellation is available.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq6">
                    How can I check available seats?
                </button>
            </h2>

            <div id="faq6" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    EventSphere displays the current availability of event
                    slots on event listings and event detail pages whenever
                    seating information is available.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq7">
                    Can I add an event to my calendar?
                </button>
            </h2>

            <div id="faq7" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. EventSphere can provide calendar information that can
                    be added to compatible calendar applications such as
                    Google Calendar, Outlook, and Apple Calendar.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq8">
                    Can I share an event with other students?
                </button>
            </h2>

            <div id="faq8" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. Event pages can provide sharing options for platforms
                    such as WhatsApp, Facebook, X, LinkedIn, and email.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq9">
                    Where can I view event photos and videos?
                </button>
            </h2>

            <div id="faq9" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Event photos and videos are available in the Event Gallery.
                    Media can be explored according to the events and available
                    gallery information.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq10">
                    Can I save my favorite media?
                </button>
            </h2>

            <div id="faq10" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    If the saved-media feature is enabled, logged-in students
                    can save selected event photos or videos for easier access
                    later.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq11">
                    Can I submit feedback after attending an event?
                </button>
            </h2>

            <div id="faq11" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. Students who attended an event can submit feedback
                    about their overall experience and provide comments or
                    suggestions.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq12">
                    Can I rate different parts of an event?
                </button>
            </h2>

            <div id="faq12" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. The feedback system can allow students to rate
                    different event components such as venue, coordination,
                    technical arrangements, and hospitality.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq13">
                    Where can I see my event activity?
                </button>
            </h2>

            <div id="faq13" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Your dashboard provides an overview of your recent
                    registrations, participation history, notifications, and
                    other event-related activities.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq14">
                    Where can I find my certificates?
                </button>
            </h2>

            <div id="faq14" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Certificates issued for eligible events can be accessed
                    through the student's account when they have been uploaded
                    or made available by the system.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq15">
                    Can I update my profile information?
                </button>
            </h2>

            <div id="faq15" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    Yes. Registered students can update their available
                    personal profile information from the Profile section
                    of their account.
                </div>
            </div>
        </div>

        <div class="accordion-item">
            <h2 class="accordion-header">
                <button class="accordion-button collapsed fw-semibold"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faq16">
                    What type of events can I find on EventSphere?
                </button>
            </h2>

            <div id="faq16" class="accordion-collapse collapse"
                 data-bs-parent="#faqAccordion">
                <div class="accordion-body text-muted">
                    EventSphere can include cultural events, technical fests,
                    sports meets, annual day functions, workshops, seminars,
                    and intercollegiate competitions.
                </div>
            </div>
        </div>

    </div>

</div>

<style>
body {
    background: #f8fafc;
}

.accordion {
    border: 1px solid #e5e7eb;
}

.accordion-item {
    border: 0;
    border-bottom: 1px solid #e5e7eb;
}

.accordion-item:last-child {
    border-bottom: 0;
}

.accordion-button {
    padding: 20px 22px;
    color: #172033;
    background: #fff;
    box-shadow: none !important;
}

.accordion-button:not(.collapsed) {
    color: #4f46e5;
    background: #f8faff;
}

.accordion-body {
    padding: 0 22px 22px;
    background: #f8faff;
    line-height: 1.7;
    font-size: 14px;
}
</style>

<?php require "footer.php"; ?>