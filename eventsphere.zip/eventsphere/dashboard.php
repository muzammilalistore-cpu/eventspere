<?php

require "db.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* =========================================================
   AUTHENTICATION
   ========================================================= */

if (!isset($_SESSION["user"]["user_id"])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION["user"];
$userId = (int) $user["user_id"];

/* Student dashboard only */
if (($user["role"] ?? "") !== "student") {
    header("Location: index.php");
    exit;
}

$title = "Student Dashboard";

/* =========================================================
   HELPER
   ========================================================= */

function h($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

/* =========================================================
   STUDENT PROFILE
   ========================================================= */

$name = $user["email"];
$departmentName = "Student";
$enrollmentNo = "";

$profileStmt = mysqli_prepare(
    $conn,
    "SELECT
        up.full_name,
        up.enrollment_no,
        d.department_name
     FROM user_profiles up
     LEFT JOIN departments d
        ON d.department_id = up.department_id
     WHERE up.user_id = ?
     LIMIT 1"
);

if ($profileStmt) {

    mysqli_stmt_bind_param(
        $profileStmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($profileStmt);

    $profileResult = mysqli_stmt_get_result($profileStmt);

    $profile = mysqli_fetch_assoc($profileResult);

    if ($profile) {

        if (!empty($profile["full_name"])) {
            $name = $profile["full_name"];
        }

        if (!empty($profile["department_name"])) {
            $departmentName = $profile["department_name"];
        }

        if (!empty($profile["enrollment_no"])) {
            $enrollmentNo = $profile["enrollment_no"];
        }
    }

    mysqli_stmt_close($profileStmt);
}

/* =========================================================
   INITIAL COUNTERS
   ========================================================= */

$registrationCount = 0;
$upcomingCount = 0;
$attendanceCount = 0;
$certificateCount = 0;

/* =========================================================
   TOTAL REGISTRATIONS
   ========================================================= */

$stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS total
     FROM event_registrations
     WHERE student_id = ?"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    $registrationCount = (int) ($row["total"] ?? 0);

    mysqli_stmt_close($stmt);
}

/* =========================================================
   UPCOMING REGISTERED EVENTS
   ========================================================= */

$stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS total
     FROM event_registrations r
     INNER JOIN events e
        ON e.event_id = r.event_id
     WHERE r.student_id = ?
       AND r.status IN ('confirmed', 'attended')
       AND e.event_date >= CURDATE()
       AND e.event_status NOT IN ('cancelled', 'completed')"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    $upcomingCount = (int) ($row["total"] ?? 0);

    mysqli_stmt_close($stmt);
}

/* =========================================================
   ATTENDANCE
   ========================================================= */

$stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS total
     FROM attendance
     WHERE student_id = ?
       AND attendance_status = 'present'"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    $attendanceCount = (int) ($row["total"] ?? 0);

    mysqli_stmt_close($stmt);
}

/* =========================================================
   CERTIFICATES
   ========================================================= */

$stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS total
     FROM certificates
     WHERE student_id = ?"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    $certificateCount = (int) ($row["total"] ?? 0);

    mysqli_stmt_close($stmt);
}

/* =========================================================
   UPCOMING EVENTS
   These are campus events, not only registered events.
   ========================================================= */

$upcomingEvents = [];

$stmt = mysqli_prepare(
    $conn,
    "SELECT
        e.event_id,
        e.title,
        e.event_date,
        e.start_time,
        e.event_status,
        c.category_name
     FROM events e
     LEFT JOIN event_categories c
        ON c.category_id = e.category_id
     WHERE e.event_date >= CURDATE()
       AND e.event_status NOT IN ('cancelled', 'completed')
     ORDER BY e.event_date ASC, e.start_time ASC
     LIMIT 6"
);

if ($stmt) {

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $upcomingEvents[] = $row;
    }

    mysqli_stmt_close($stmt);
}

/* =========================================================
   CHECK WHICH UPCOMING EVENTS ARE ALREADY REGISTERED
   ========================================================= */

$registeredEventIds = [];

$stmt = mysqli_prepare(
    $conn,
    "SELECT event_id
     FROM event_registrations
     WHERE student_id = ?"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $registeredEventIds[] = (int) $row["event_id"];
    }

    mysqli_stmt_close($stmt);
}

/* =========================================================
   RECENT REGISTERED EVENTS
   ========================================================= */

$recentEvents = [];

$stmt = mysqli_prepare(
    $conn,
    "SELECT
        r.registration_id,
        r.registration_code,
        r.status AS registration_status,

        e.event_id,
        e.title,
        e.event_date,
        e.start_time,
        e.event_status,

        c.category_name

     FROM event_registrations r

     INNER JOIN events e
        ON e.event_id = r.event_id

     LEFT JOIN event_categories c
        ON c.category_id = e.category_id

     WHERE r.student_id = ?

     ORDER BY
        e.event_date DESC,
        e.start_time DESC

     LIMIT 6"
);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $recentEvents[] = $row;
    }

    mysqli_stmt_close($stmt);
}

/* =========================================================
   AVATAR INITIAL
   ========================================================= */

$avatarInitial = strtoupper(
    substr(trim($name), 0, 1)
);

require "header.php";

?>

<style>

/* =========================================================
   DASHBOARD
   ========================================================= */

.student-dashboard {
    padding: 42px 0 85px;
}

/* =========================================================
   HERO
   ========================================================= */

.dashboard-hero {
    position: relative;
    overflow: hidden;
    padding: 42px;
    border-radius: 28px;

    background:
        radial-gradient(
            circle at 88% 12%,
            rgba(99,102,241,.30),
            transparent 30%
        ),
        radial-gradient(
            circle at 10% 90%,
            rgba(34,211,238,.15),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #172554 58%,
            #312e81
        );

    color: #fff;

    box-shadow:
        0 25px 70px rgba(15,23,42,.18);

    animation: dashboardHero .7s ease both;
}

.dashboard-hero::before {
    content: "";
    position: absolute;
    width: 330px;
    height: 330px;
    right: -150px;
    top: -150px;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,.12);
    box-shadow:
        0 0 0 35px rgba(255,255,255,.025),
        0 0 0 70px rgba(255,255,255,.018);
    animation: heroOrb 8s ease-in-out infinite;
}

.dashboard-hero-content {
    position: relative;
    z-index: 2;
}

.dashboard-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    color: #c7d2fe;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.dashboard-label::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #34d399;
    box-shadow: 0 0 15px #34d399;
}

.dashboard-hero h1 {
    margin: 13px 0 9px;
    font-size: clamp(2rem, 4vw, 3.2rem);
    line-height: 1.05;
    font-weight: 850;
    letter-spacing: -.045em;
}

.dashboard-hero p {
    max-width: 680px;
    margin: 0;
    color: #cbd5e1;
    line-height: 1.7;
    font-size: .92rem;
}

.dashboard-user {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-top: 26px;
}

.dashboard-avatar {
    width: 52px;
    height: 52px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: rgba(255,255,255,.12);
    border: 1px solid rgba(255,255,255,.20);

    color: #fff;
    font-size: 18px;
    font-weight: 850;

    backdrop-filter: blur(10px);
}

.dashboard-user strong {
    font-size: .9rem;
}

.dashboard-user small {
    color: #cbd5e1;
    font-size: .74rem;
}

/* =========================================================
   STATISTICS
   ========================================================= */

.dashboard-stats {
    margin-top: 24px;
}

.stat-card {
    height: 100%;
    padding: 23px;

    border: 1px solid #e9edf3;
    border-radius: 20px;

    background: #fff;

    box-shadow:
        0 10px 35px rgba(15,23,42,.055);

    transition:
        transform .3s ease,
        box-shadow .3s ease;
}

.stat-card:hover {
    transform: translateY(-6px);

    box-shadow:
        0 22px 50px rgba(15,23,42,.11);
}

.stat-icon {
    width: 45px;
    height: 45px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 17px;

    border-radius: 13px;

    background: #eef2ff;

    color: #4f46e5;

    font-size: 18px;
}

.stat-card h2 {
    margin: 0;
    color: #0f172a;
    font-size: 29px;
    font-weight: 850;
    letter-spacing: -.03em;
}

.stat-card p {
    margin: 4px 0 0;
    color: #64748b;
    font-size: 12px;
}

/* =========================================================
   SECTIONS
   ========================================================= */

.dashboard-section {
    margin-top: 38px;
}

.section-heading {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 15px;

    margin-bottom: 17px;
}

.section-heading h3 {
    margin: 0;
    color: #0f172a;
    font-size: 21px;
    font-weight: 850;
    letter-spacing: -.025em;
}

.section-heading p {
    margin: 4px 0 0;
    color: #94a3b8;
    font-size: .78rem;
}

.section-link {
    color: #4f46e5;
    text-decoration: none;
    font-size: .78rem;
    font-weight: 800;
}

.section-link:hover {
    color: #3730a3;
}

/* =========================================================
   QUICK ACTIONS
   ========================================================= */

.quick-card {
    display: block;
    height: 100%;

    padding: 21px;

    color: #111827;
    text-decoration: none;

    background: #fff;

    border: 1px solid #e9edf3;
    border-radius: 18px;

    box-shadow:
        0 8px 28px rgba(15,23,42,.04);

    transition: .3s ease;
}

.quick-card:hover {
    color: #111827;
    transform: translateY(-5px);

    box-shadow:
        0 18px 42px rgba(15,23,42,.09);
}

.quick-icon {
    width: 44px;
    height: 44px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 15px;

    border-radius: 12px;

    background: #eef2ff;
    color: #4f46e5;

    font-size: 17px;
}

.quick-card strong {
    display: block;
    margin-bottom: 5px;
    font-size: .87rem;
}

.quick-card small {
    color: #94a3b8;
    font-size: .72rem;
}

/* =========================================================
   UPCOMING EVENT CARDS
   ========================================================= */

.upcoming-event {
    position: relative;
    overflow: hidden;

    height: 100%;

    padding: 22px;

    background: #fff;

    border: 1px solid #e8ecf2;
    border-radius: 20px;

    box-shadow:
        0 8px 30px rgba(15,23,42,.045);

    transition: .3s ease;
}

.upcoming-event:hover {
    transform: translateY(-6px);

    box-shadow:
        0 20px 45px rgba(15,23,42,.10);
}

.event-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
}

.event-calendar {
    width: 50px;
    min-width: 50px;
    height: 54px;

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background: #eef2ff;
    color: #4f46e5;
}

.event-calendar strong {
    font-size: 18px;
    line-height: 1;
}

.event-calendar span {
    margin-top: 4px;

    font-size: 9px;
    font-weight: 850;

    text-transform: uppercase;
}

.event-category {
    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    background: #f1f5f9;
    color: #64748b;

    font-size: 9px;
    font-weight: 800;
}

.upcoming-event h4 {
    margin: 18px 0 7px;

    color: #0f172a;

    font-size: 15px;
    font-weight: 800;
    line-height: 1.4;
}

.event-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 7px 13px;

    margin-bottom: 18px;

    color: #94a3b8;
    font-size: 10px;
}

.event-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    width: 100%;
    min-height: 38px;

    border-radius: 10px;

    background: #f8fafc;
    color: #4f46e5;

    text-decoration: none;

    font-size: .72rem;
    font-weight: 800;

    transition: .25s ease;
}

.event-action:hover {
    background: #4f46e5;
    color: #fff;
}

.event-registered {
    background: #ecfdf5;
    color: #15803d;
}

.event-registered:hover {
    background: #dcfce7;
    color: #15803d;
}

/* =========================================================
   RECENT EVENTS
   ========================================================= */

.event-list {
    overflow: hidden;

    background: #fff;

    border: 1px solid #e9edf3;
    border-radius: 20px;

    box-shadow:
        0 8px 30px rgba(15,23,42,.045);
}

.event-row {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 20px;

    padding: 18px 21px;

    border-bottom: 1px solid #f1f5f9;

    transition: background .2s ease;
}

.event-row:hover {
    background: #fafbff;
}

.event-row:last-child {
    border-bottom: 0;
}

.event-info {
    display: flex;
    align-items: center;
    gap: 13px;

    min-width: 0;
}

.event-date {
    width: 49px;
    min-width: 49px;
    height: 49px;

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: #eef2ff;
    color: #4f46e5;
}

.event-date strong {
    font-size: 16px;
    line-height: 1;
}

.event-date span {
    margin-top: 3px;

    font-size: 9px;
    font-weight: 850;

    text-transform: uppercase;
}

.event-details {
    min-width: 0;
}

.event-details h4 {
    overflow: hidden;

    margin: 0 0 4px;

    color: #0f172a;

    font-size: 13px;
    font-weight: 800;

    white-space: nowrap;
    text-overflow: ellipsis;
}

.event-details p {
    margin: 0;

    color: #94a3b8;

    font-size: 10px;
}

.status {
    flex-shrink: 0;

    padding: 6px 11px;

    border-radius: 30px;

    font-size: 9px;
    font-weight: 850;
}

.status-confirmed {
    background: #ecfdf5;
    color: #15803d;
}

.status-attended {
    background: #eff6ff;
    color: #2563eb;
}

.status-pending {
    background: #fffbeb;
    color: #b45309;
}

.status-cancelled {
    background: #fef2f2;
    color: #b91c1c;
}

/* =========================================================
   EMPTY STATE
   ========================================================= */

.empty-state {
    padding: 45px 25px;

    text-align: center;
}

.empty-icon {
    width: 55px;
    height: 55px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin: 0 auto 13px;

    border-radius: 16px;

    background: #f1f5f9;

    font-size: 21px;
}

.empty-state strong {
    display: block;
    margin-bottom: 6px;

    color: #334155;

    font-size: .9rem;
}

.empty-state p {
    max-width: 430px;
    margin: 0 auto 17px;

    color: #94a3b8;

    font-size: .76rem;
    line-height: 1.6;
}

.empty-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 10px 17px;

    border-radius: 10px;

    background: #4f46e5;
    color: #fff;

    text-decoration: none;

    font-size: .73rem;
    font-weight: 800;
}

.empty-button:hover {
    color: #fff;
    background: #3730a3;
}

/* =========================================================
   ANIMATIONS
   ========================================================= */

@keyframes dashboardHero {

    from {
        opacity: 0;
        transform: translateY(18px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}

@keyframes heroOrb {

    0%,
    100% {
        transform: translateY(0) rotate(0deg);
    }

    50% {
        transform: translateY(18px) rotate(8deg);
    }

}

/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 767px) {

    .student-dashboard {
        padding: 25px 0 55px;
    }

    .dashboard-hero {
        padding: 29px 22px;
        border-radius: 22px;
    }

    .dashboard-hero h1 {
        font-size: 29px;
    }

    .dashboard-hero p {
        font-size: .82rem;
    }

    .section-heading {
        align-items: flex-start;
        flex-direction: column;
    }

    .event-row {
        align-items: flex-start;
        flex-direction: column;
    }

    .status {
        margin-left: 62px;
    }

}

</style>


<div class="container student-dashboard">


    <!-- =====================================================
         HERO
         ===================================================== -->

    <section class="dashboard-hero">

        <div class="dashboard-hero-content">

            <span class="dashboard-label">
                EventSphere Student Portal
            </span>

            <h1>
                Welcome back, <?= h($name) ?>
            </h1>

            <p>
                Discover campus events, manage your registrations,
                track attendance and access your certificates
                from one place.
            </p>


            <div class="dashboard-user">

                <div class="dashboard-avatar">
                    <?= h($avatarInitial) ?>
                </div>

                <div>

                    <strong>
                        <?= h($name) ?>
                    </strong>

                    <br>

                    <small>
                        <?= h($departmentName) ?>

                        <?php if ($enrollmentNo !== ""): ?>
                            · <?= h($enrollmentNo) ?>
                        <?php endif; ?>

                    </small>

                </div>

            </div>

        </div>

    </section>


    <!-- =====================================================
         STATISTICS
         ===================================================== -->

    <div class="row g-4 dashboard-stats">


        <div class="col-6 col-lg-3">

            <div class="stat-card">

                <div class="stat-icon">
                    📋
                </div>

                <h2>
                    <?= $registrationCount ?>
                </h2>

                <p>
                    Total Registrations
                </p>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="stat-card">

                <div class="stat-icon">
                    📅
                </div>

                <h2>
                    <?= $upcomingCount ?>
                </h2>

                <p>
                    Upcoming Events
                </p>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="stat-card">

                <div class="stat-icon">
                    ✓
                </div>

                <h2>
                    <?= $attendanceCount ?>
                </h2>

                <p>
                    Events Attended
                </p>

            </div>

        </div>


        <div class="col-6 col-lg-3">

            <div class="stat-card">

                <div class="stat-icon">
                    🎓
                </div>

                <h2>
                    <?= $certificateCount ?>
                </h2>

                <p>
                    Certificates
                </p>

            </div>

        </div>

    </div>


    <!-- =====================================================
         QUICK ACTIONS
         ===================================================== -->

    <section class="dashboard-section">

        <div class="section-heading">

            <div>

                <h3>
                    Quick Actions
                </h3>

                <p>
                    Manage your EventSphere activity
                </p>

            </div>

        </div>


        <div class="row g-3">


            <div class="col-6 col-lg-4">

                <a
                    href="events.php"
                    class="quick-card"
                >

                    <div class="quick-icon">
                        🔎
                    </div>

                    <strong>
                        Browse Events
                    </strong>

                    <small>
                        Discover and register for upcoming events
                    </small>

                </a>

            </div>


            <div class="col-6 col-lg-4">

                <a
                    href="my-events.php"
                    class="quick-card"
                >

                    <div class="quick-icon">
                        📋
                    </div>

                    <strong>
                        My Events
                    </strong>

                    <small>
                        View all your event registrations
                    </small>

                </a>

            </div>


            <div class="col-6 col-lg-4">

                <a
                    href="certificate.php"
                    class="quick-card"
                >

                    <div class="quick-icon">
                        🎓
                    </div>

                    <strong>
                        My Certificates
                    </strong>

                    <small>
                        Access your earned certificates
                    </small>

                </a>

            </div>


            <div class="col-6 col-lg-4">

                <a
                    href="attendance.php"
                    class="quick-card"
                >

                    <div class="quick-icon">
                        ✓
                    </div>

                    <strong>
                        Attendance
                    </strong>

                    <small>
                        Check your participation history
                    </small>

                </a>

            </div>


            <div class="col-6 col-lg-4">

                <a
                    href="feedback.php"
                    class="quick-card"
                >

                    <div class="quick-icon">
                        💬
                    </div>

                    <strong>
                        Event Feedback
                    </strong>

                    <small>
                        Share your event experience
                    </small>

                </a>

            </div>


            <div class="col-6 col-lg-4">

                <a
                    href="profile.php"
                    class="quick-card"
                >

                    <div class="quick-icon">
                        ⚙
                    </div>

                    <strong>
                        My Profile
                    </strong>

                    <small>
                        Update your student information
                    </small>

                </a>

            </div>

        </div>

    </section>


    <!-- =====================================================
         UPCOMING CAMPUS EVENTS
         ===================================================== -->

    <section class="dashboard-section">

        <div class="section-heading">

            <div>

                <h3>
                    Upcoming Events
                </h3>

                <p>
                    Explore what's happening on campus
                </p>

            </div>

            <a
                href="events.php"
                class="section-link"
            >
                View All Events →
            </a>

        </div>


        <div class="row g-4">


            <?php if (empty($upcomingEvents)): ?>

                <div class="col-12">

                    <div class="event-list">

                        <div class="empty-state">

                            <div class="empty-icon">
                                📅
                            </div>

                            <strong>
                                No upcoming events
                            </strong>

                            <p>
                                There are currently no upcoming
                                campus events available.
                            </p>

                        </div>

                    </div>

                </div>

            <?php else: ?>


                <?php foreach ($upcomingEvents as $event): ?>

                    <?php

                    $eventDate = strtotime(
                        $event["event_date"]
                    );

                    $eventId = (int) $event["event_id"];

                    $isRegistered =
                        in_array(
                            $eventId,
                            $registeredEventIds,
                            true
                        );

                    ?>

                    <div class="col-md-6 col-lg-4">

                        <div class="upcoming-event">


                            <div class="event-top">

                                <div class="event-calendar">

                                    <strong>
                                        <?= date("d", $eventDate) ?>
                                    </strong>

                                    <span>
                                        <?= date("M", $eventDate) ?>
                                    </span>

                                </div>


                                <span class="event-category">

                                    <?= h(
                                        $event["category_name"]
                                        ?? "Event"
                                    ) ?>

                                </span>

                            </div>


                            <h4>
                                <?= h($event["title"]) ?>
                            </h4>


                            <div class="event-meta">

                                <span>
                                    🗓
                                    <?= date(
                                        "d M Y",
                                        $eventDate
                                    ) ?>
                                </span>

                                <?php if (!empty($event["start_time"])): ?>

                                    <span>
                                        🕒
                                        <?= date(
                                            "h:i A",
                                            strtotime(
                                                $event["start_time"]
                                            )
                                        ) ?>
                                    </span>

                                <?php endif; ?>

                            </div>


                            <?php if ($isRegistered): ?>

                                <a
                                    href="my-events.php"
                                    class="event-action event-registered"
                                >
                                    ✓ Already Registered
                                </a>

                            <?php else: ?>

                                <a
                                    href="event-details.php?id=<?= $eventId ?>"
                                    class="event-action"
                                >
                                    View Event →
                                </a>

                            <?php endif; ?>


                        </div>

                    </div>

                <?php endforeach; ?>


            <?php endif; ?>

        </div>

    </section>


    <!-- =====================================================
         RECENT REGISTRATIONS
         ===================================================== -->

    <section class="dashboard-section">

        <div class="section-heading">

            <div>

                <h3>
                    My Recent Events
                </h3>

                <p>
                    Your latest event activity
                </p>

            </div>

            <a
                href="my-events.php"
                class="section-link"
            >
                View My Events →
            </a>

        </div>


        <div class="event-list">


            <?php if (empty($recentEvents)): ?>

                <div class="empty-state">

                    <div class="empty-icon">
                        📋
                    </div>

                    <strong>
                        No registrations yet
                    </strong>

                    <p>
                        You have not registered for any event yet.
                        Browse upcoming events and reserve your place.
                    </p>

                    <a
                        href="events.php"
                        class="empty-button"
                    >
                        Browse Events
                    </a>

                </div>


            <?php else: ?>


                <?php foreach ($recentEvents as $event): ?>

                    <?php

                    $date = strtotime(
                        $event["event_date"]
                    );

                    $registrationStatus =
                        strtolower(
                            $event["registration_status"]
                            ?? "pending"
                        );

                    $statusClass =
                        "status-" .
                        preg_replace(
                            "/[^a-z0-9_-]/",
                            "",
                            $registrationStatus
                        );

                    ?>

                    <div class="event-row">


                        <div class="event-info">


                            <div class="event-date">

                                <strong>
                                    <?= date("d", $date) ?>
                                </strong>

                                <span>
                                    <?= date("M", $date) ?>
                                </span>

                            </div>


                            <div class="event-details">

                                <h4>
                                    <?= h(
                                        $event["title"]
                                    ) ?>
                                </h4>

                                <p>

                                    <?= h(
                                        $event["category_name"]
                                        ?? "Event"
                                    ) ?>

                                    ·

                                    <?= date(
                                        "d M Y",
                                        $date
                                    ) ?>

                                    <?php if (
                                        !empty(
                                            $event["registration_code"]
                                        )
                                    ): ?>

                                        ·

                                        <?= h(
                                            $event[
                                                "registration_code"
                                            ]
                                        ) ?>

                                    <?php endif; ?>

                                </p>

                            </div>


                        </div>


                        <span
                            class="status <?= h($statusClass) ?>"
                        >
                            <?= h(
                                ucfirst(
                                    $registrationStatus
                                )
                            ) ?>
                        </span>


                    </div>

                <?php endforeach; ?>


            <?php endif; ?>


        </div>

    </section>


</div>


<?php require "footer.php"; ?>