<?php

require "db.php";
require_once "functions.php";

$title = "Contact Us";

$name = "";
$email = "";
$subject = "";
$message = "";

$success = "";
$error = "";

if (empty($_SESSION["contact_token"])) {
    $_SESSION["contact_token"] = bin2hex(random_bytes(32));
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $subject = trim($_POST["subject"] ?? "");
    $message = trim($_POST["message"] ?? "");
    $token = $_POST["contact_token"] ?? "";

    if (
        empty($token) ||
        empty($_SESSION["contact_token"]) ||
        !hash_equals($_SESSION["contact_token"], $token)
    ) {

        $error = "Your request could not be verified. Please try again.";

    } elseif ($name === "") {

        $error = "Please enter your full name.";

    } elseif (strlen($name) < 2) {

        $error = "Please enter your full name correctly.";

    } elseif (strlen($name) > 100) {

        $error = "Your name is too long.";

    } elseif (!preg_match("/^[a-zA-ZÀ-ÿ\s.'-]+$/", $name)) {

        $error = "Please use letters only in your name.";

    } elseif ($email === "") {

        $error = "Please enter your email address.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } elseif (strlen($email) > 150) {

        $error = "Your email address is too long.";

    } elseif ($subject === "") {

        $error = "Please enter a subject.";

    } elseif (strlen($subject) < 3) {

        $error = "Please enter a little more detail in the subject.";

    } elseif (strlen($subject) > 200) {

        $error = "Your subject is too long.";

    } elseif ($message === "") {

        $error = "Please write your message.";

    } elseif (strlen($message) < 10) {

        $error = "Please write a little more about your message.";

    } elseif (strlen($message) > 2000) {

        $error = "Your message is too long.";

    } else {

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO contact_messages
            (name, email, subject, message)
            VALUES (?, ?, ?, ?)"
        );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "ssss",
                $name,
                $email,
                $subject,
                $message
            );

            if (mysqli_stmt_execute($stmt)) {

                $success = "Thanks! Your message has been sent successfully.";

                $name = "";
                $email = "";
                $subject = "";
                $message = "";

                $_SESSION["contact_token"] = bin2hex(random_bytes(32));

            } else {

                $error = "Sorry, we couldn't send your message right now. Please try again later.";
            }

            mysqli_stmt_close($stmt);

        } else {

            $error = "Sorry, we couldn't send your message right now. Please try again later.";
        }
    }
}

require "header.php";
?>

<style>

.contact-page {
    padding: 15px 0 70px;
    overflow: hidden;
}

.contact-hero {
    position: relative;
    overflow: hidden;
    padding: 80px 50px 125px;
    border-radius: 28px;
    color: #fff;
    background:
        radial-gradient(
            circle at 85% 18%,
            rgba(99, 102, 241, .34),
            transparent 28%
        ),
        radial-gradient(
            circle at 12% 90%,
            rgba(34, 211, 238, .16),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #070b16,
            #111827 52%,
            #1e1b4b
        );
}

.contact-hero::before {
    content: "";
    position: absolute;
    width: 430px;
    height: 430px;
    right: -150px;
    top: -190px;
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 50%;
    animation: contactRotate 18s linear infinite;
}

.contact-hero::after {
    content: "";
    position: absolute;
    width: 220px;
    height: 220px;
    right: 70px;
    bottom: -160px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 50%;
    animation: contactRotate 12s linear infinite reverse;
}

.contact-hero-content {
    position: relative;
    z-index: 2;
    max-width: 760px;
}

.contact-label {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    padding: 8px 14px;
    border: 1px solid rgba(255,255,255,.15);
    border-radius: 999px;
    background: rgba(255,255,255,.06);
    color: #c7d2fe;
    font-size: .75rem;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
    backdrop-filter: blur(10px);
}

.contact-label span {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #34d399;
    box-shadow: 0 0 16px #34d399;
    animation: contactPulse 1.8s infinite;
}

.contact-title {
    margin: 22px 0 17px;
    font-size: clamp(2.8rem, 6vw, 5.4rem);
    line-height: .96;
    font-weight: 850;
    letter-spacing: -.065em;
}

.contact-title span {
    background: linear-gradient(
        100deg,
        #ffffff,
        #a5b4fc 45%,
        #67e8f9
    );
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

.contact-description {
    max-width: 670px;
    margin: 0;
    color: #cbd5e1;
    font-size: 1.04rem;
    line-height: 1.8;
}

.contact-wrapper {
    position: relative;
    z-index: 5;
    margin-top: -55px;
}

.contact-form-card {
    padding: 34px;
    border: 1px solid #e5e7eb;
    border-radius: 24px;
    background: #ffffff;
    box-shadow: 0 25px 70px rgba(15,23,42,.11);
}

.contact-form-card h2 {
    margin: 0 0 8px;
    color: #111827;
    font-size: 1.55rem;
    font-weight: 800;
}

.form-intro {
    margin-bottom: 25px;
    color: #64748b;
    line-height: 1.7;
}

.contact-info-card {
    height: 100%;
    padding: 34px;
    border-radius: 24px;
    color: #fff;
    background:
        radial-gradient(
            circle at 90% 10%,
            rgba(99,102,241,.28),
            transparent 30%
        ),
        linear-gradient(
            145deg,
            #0f172a,
            #111827
        );
    box-shadow: 0 25px 70px rgba(15,23,42,.16);
}

.contact-info-card h2 {
    margin: 24px 0 10px;
    font-size: 1.55rem;
    font-weight: 800;
}

.contact-info-card > p {
    color: #94a3b8;
    line-height: 1.7;
}

.contact-info-item {
    display: flex;
    gap: 14px;
    padding: 19px 0;
    border-bottom: 1px solid rgba(255,255,255,.08);
}

.contact-info-item:last-child {
    border-bottom: 0;
}

.contact-info-icon {
    display: grid;
    place-items: center;
    flex: 0 0 44px;
    width: 44px;
    height: 44px;
    border: 1px solid rgba(129,140,248,.18);
    border-radius: 13px;
    background: rgba(99,102,241,.12);
    color: #a5b4fc;
    font-size: .75rem;
    font-weight: 800;
}

.contact-info-item strong {
    display: block;
    margin-bottom: 4px;
    font-size: .95rem;
}

.contact-info-item span {
    color: #94a3b8;
    font-size: .83rem;
    line-height: 1.5;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.form-group {
    margin-bottom: 18px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: #334155;
    font-size: .84rem;
    font-weight: 750;
}

.form-control-modern {
    display: block;
    width: 100%;
    padding: 13px 15px;
    border: 1px solid #dbe2ea;
    border-radius: 12px;
    outline: none;
    color: #111827;
    background: #f8fafc;
    font-size: .92rem;
    transition:
        border-color .25s ease,
        background .25s ease,
        box-shadow .25s ease,
        transform .25s ease;
}

.form-control-modern::placeholder {
    color: #94a3b8;
}

.form-control-modern:hover {
    border-color: #cbd5e1;
}

.form-control-modern:focus {
    border-color: #6366f1;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(99,102,241,.10);
}

textarea.form-control-modern {
    min-height: 145px;
    resize: vertical;
}

.contact-submit {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    padding: 14px 20px;
    border: 0;
    border-radius: 12px;
    color: #fff;
    background: linear-gradient(
        135deg,
        #6366f1,
        #4f46e5
    );
    font-weight: 750;
    box-shadow: 0 12px 30px rgba(79,70,229,.25);
    transition: .3s ease;
}

.contact-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 18px 40px rgba(79,70,229,.35);
}

.contact-submit:active {
    transform: translateY(0);
}

.alert-modern {
    margin-bottom: 20px;
    padding: 13px 16px;
    border-radius: 12px;
    font-size: .88rem;
    line-height: 1.5;
}

.alert-success-modern {
    color: #166534;
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
}

.alert-error-modern {
    color: #991b1b;
    border: 1px solid #fecaca;
    background: #fef2f2;
}

@keyframes contactPulse {

    0%,
    100% {
        transform: scale(1);
        opacity: 1;
    }

    50% {
        transform: scale(1.65);
        opacity: .55;
    }
}

@keyframes contactRotate {

    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(360deg);
    }
}

@media (max-width: 767px) {

    .contact-page {
        padding-top: 5px;
    }

    .contact-hero {
        padding: 55px 24px 95px;
        border-radius: 22px;
    }

    .contact-title {
        font-size: 3rem;
    }

    .contact-description {
        font-size: .94rem;
    }

    .contact-wrapper {
        margin-top: -40px;
        padding: 0 10px;
    }

    .contact-form-card,
    .contact-info-card {
        padding: 24px;
    }

    .form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }

}

</style>

<div class="contact-page">

    <section class="contact-hero">

        <div class="contact-hero-content">

            <div class="contact-label">
                <span></span>
                EventSphere Support
            </div>

            <h1 class="contact-title">
                Let's start a
                <span>conversation.</span>
            </h1>

            <p class="contact-description">
                Have a question about an event, registration or your
                account? Send us a message and we'll help you find
                the right answer.
            </p>

        </div>

    </section>

    <div class="contact-wrapper">

        <div class="row g-4">

            <div class="col-lg-7">

                <div class="contact-form-card">

                    <h2>Send us a message</h2>

                    <p class="form-intro">
                        Fill out the form below and we'll receive your
                        message directly.
                    </p>

                    <?php if ($success !== ""): ?>

                        <div class="alert-modern alert-success-modern">
                            <?= e($success) ?>
                        </div>

                    <?php endif; ?>

                    <?php if ($error !== ""): ?>

                        <div class="alert-modern alert-error-modern">
                            <?= e($error) ?>
                        </div>

                    <?php endif; ?>

                    <form method="post" action="contact-us.php">

                        <input
                            type="hidden"
                            name="contact_token"
                            value="<?= e($_SESSION["contact_token"]) ?>"
                        >

                        <div class="form-row">

                            <div class="form-group">

                                <label
                                    class="form-label"
                                    for="name"
                                >
                                    Full Name
                                </label>

                                <input
                                    id="name"
                                    type="text"
                                    name="name"
                                    class="form-control-modern"
                                    value="<?= e($name) ?>"
                                    placeholder="Enter your full name"
                                    maxlength="100"
                                    autocomplete="name"
                                    required
                                >

                            </div>

                            <div class="form-group">

                                <label
                                    class="form-label"
                                    for="email"
                                >
                                    Email Address
                                </label>

                                <input
                                    id="email"
                                    type="email"
                                    name="email"
                                    class="form-control-modern"
                                    value="<?= e($email) ?>"
                                    placeholder="you@example.com"
                                    maxlength="150"
                                    autocomplete="email"
                                    required
                                >

                            </div>

                        </div>

                        <div class="form-group">

                            <label
                                class="form-label"
                                for="subject"
                            >
                                Subject
                            </label>

                            <input
                                id="subject"
                                type="text"
                                name="subject"
                                class="form-control-modern"
                                value="<?= e($subject) ?>"
                                placeholder="What can we help you with?"
                                maxlength="200"
                                required
                            >

                        </div>

                        <div class="form-group">

                            <label
                                class="form-label"
                                for="message"
                            >
                                Message
                            </label>

                            <textarea
                                id="message"
                                name="message"
                                class="form-control-modern"
                                placeholder="Write your message here..."
                                maxlength="2000"
                                required
                            ><?= e($message) ?></textarea>

                        </div>

                        <button
                            type="submit"
                            class="contact-submit"
                        >
                            Send Message
                        </button>

                    </form>

                </div>

            </div>

            <div class="col-lg-5">

                <div class="contact-info-card">

                    <div class="contact-label">
                        <span></span>
                        We're here to help
                    </div>

                    <h2>
                        How can we help?
                    </h2>

                    <p>
                        Whether you're a student looking for an event
                        or an organizer managing campus activities,
                        EventSphere keeps things simple.
                    </p>

                    <div class="contact-info-item">

                        <div class="contact-info-icon">
                            01
                        </div>

                        <div>
                            <strong>Event Support</strong>
                            <span>
                                Questions about events, registrations
                                and participation.
                            </span>
                        </div>

                    </div>

                    <div class="contact-info-item">

                        <div class="contact-info-icon">
                            02
                        </div>

                        <div>
                            <strong>Student Help</strong>
                            <span>
                                Need help with your account,
                                registrations or certificates?
                            </span>
                        </div>

                    </div>

                    <div class="contact-info-item">

                        <div class="contact-info-icon">
                            03
                        </div>

                        <div>
                            <strong>Organizer Support</strong>
                            <span>
                                Get help managing college events
                                and participants.
                            </span>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php require "footer.php"; ?>