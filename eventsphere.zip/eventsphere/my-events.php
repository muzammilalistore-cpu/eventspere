<?php

require "db.php";
require_once "functions.php";

require_auth();

$title = "My Events";

$student_id = (int)$_SESSION["user"]["user_id"];

$sql = "
    SELECT
        r.registration_id,
        r.registration_code,
        r.status AS registration_status,
        e.event_id,
        e.title,
        e.short_description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.event_status,
        c.category_name,
        v.venue_name
    FROM event_registrations r
    INNER JOIN events e
        ON e.event_id = r.event_id
    LEFT JOIN event_categories c
        ON c.category_id = e.category_id
    LEFT JOIN venues v
        ON v.venue_id = e.venue_id
    WHERE r.student_id = ?
    ORDER BY e.event_date DESC, e.start_time DESC
";

$result = q(
    $conn,
    $sql,
    "i",
    $student_id
);

require "header.php";
?>

<style>
.my-events-page {
    padding: 20px 0 70px;
}

.events-heading {
    margin-bottom: 30px;
}

.events-heading h1 {
    margin: 0;
    color: #111827;
    font-size: clamp(2rem, 4vw, 3rem);
    font-weight: 850;
    letter-spacing: -.05em;
}

.events-heading p {
    margin: 10px 0 0;
    color: #64748b;
}

.event-list-card {
    overflow: hidden;
    border: 1px solid #e5e7eb;
    border-radius: 22px;
    background: #fff;
    box-shadow: 0 10px 35px rgba(15, 23, 42, .06);
    transition: .3s ease;
}

.event-list-card:hover {
    transform: translateY(-5px);
    border-color: #c7d2fe;
    box-shadow: 0 20px 50px rgba(79, 70, 229, .12);
}

.event-card-top {
    height: 6px;
    background: linear-gradient(90deg, #4f46e5, #06b6d4);
}

.event-card-body {
    padding: 25px;
}

.event-category {
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 8px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: .72rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .05em;
}

.event-card-title {
    margin: 15px 0 8px;
    color: #111827;
    font-size: 1.3rem;
    font-weight: 800;
}

.event-description {
    margin: 0;
    color: #64748b;
    line-height: 1.65;
    font-size: .9rem;
}

.event-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin: 20px 0;
}

.event-meta span {
    padding: 8px 11px;
    border-radius: 9px;
    background: #f8fafc;
    color: #475569;
    font-size: .76rem;
}

.registration-box {
    padding: 15px;
    border: 1px dashed #cbd5e1;
    border-radius: 13px;
    background: #f8fafc;
}

.registration-label {
    display: block;
    margin-bottom: 4px;
    color: #64748b;
    font-size: .72rem;
    font-weight: 700;
    text-transform: uppercase;
}

.registration-code {
    color: #111827;
    font-weight: 850;
    letter-spacing: .04em;
}

.status-badge {
    display: inline-flex;
    padding: 7px 11px;
    border-radius: 999px;
    font-size: .72rem;
    font-weight: 800;
    text-transform: capitalize;
}

.status-confirmed {
    background: #dcfce7;
    color: #166534;
}

.status-attended {
    background: #dbeafe;
    color: #1d4ed8;
}

.status-cancelled {
    background: #fee2e2;
    color: #b91c1c;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
}

.empty-events {
    padding: 70px 25px;
    text-align: center;
    border: 1px solid #e5e7eb;
    border-radius: 24px;
    background: #fff;
    box-shadow: 0 10px 35px rgba(15, 23, 42, .05);
}

.empty-icon {
    width: 64px;
    height: 64px;
    margin: 0 auto 20px;
    display: grid;
    place-items: center;
    border-radius: 18px;
    background: #eef2ff;
    color: #4f46e5;
    font-size: 1.4rem;
    font-weight: 900;
}

.empty-events h3 {
    margin-bottom: 10px;
    color: #111827;
    font-weight: 800;
}

.empty-events p {
    margin-bottom: 24px;
    color: #64748b;
}

.event-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin-top: 18px;
}

.event-actions a {
    border-radius: 10px;
    font-weight: 700;
}

@media (max-width: 576px) {

    .my-events-page {
        padding-top: 5px;
    }

    .event-card-body {
        padding: 20px;
    }

    .event-actions {
        flex-direction: column;
    }

    .event-actions a {
        width: 100%;
    }
}
</style>

<div class="my-events-page">

    <div class="events-heading">

        <h1>My Events</h1>

        <p>
            Keep track of the events you have registered for
            and your participation status.
        </p>

    </div>

    <div class="row g-4">

        <?php if ($result && mysqli_num_rows($result) > 0): ?>

            <?php while ($event = mysqli_fetch_assoc($result)): ?>

                <?php
                $status = strtolower(
                    trim($event["registration_status"] ?? "")
                );

                $status_class = "status-pending";

                if ($status === "confirmed") {
                    $status_class = "status-confirmed";
                } elseif ($status === "attended") {
                    $status_class = "status-attended";
                } elseif ($status === "cancelled") {
                    $status_class = "status-cancelled";
                }
                ?>

                <div class="col-12 col-lg-6">

                    <article class="event-list-card">

                        <div class="event-card-top"></div>

                        <div class="event-card-body">

                            <span class="event-category">
                                <?= e($event["category_name"] ?? "Event") ?>
                            </span>

                            <h2 class="event-card-title">
                                <?= e($event["title"]) ?>
                            </h2>

                            <?php if (!empty($event["short_description"])): ?>

                                <p class="event-description">
                                    <?= e($event["short_description"]) ?>
                                </p>

                            <?php endif; ?>

                            <div class="event-meta">

                                <span>
                                    <?= e($event["event_date"]) ?>
                                </span>

                                <span>
                                    <?= e($event["start_time"]) ?>
                                    -
                                    <?= e($event["end_time"]) ?>
                                </span>

                                <span>
                                    <?= e($event["venue_name"] ?? "Venue") ?>
                                </span>

                            </div>

                            <div class="registration-box">

                                <span class="registration-label">
                                    Registration Code
                                </span>

                                <div class="d-flex justify-content-between align-items-center gap-3">

                                    <span class="registration-code">
                                        <?= e($event["registration_code"]) ?>
                                    </span>

                                    <span class="status-badge <?= e($status_class) ?>">
                                        <?= e($status ?: "pending") ?>
                                    </span>

                                </div>

                            </div>

                            <div class="event-actions">

                                <a
                                    href="event-details.php?id=<?= (int)$event["event_id"] ?>"
                                    class="btn btn-dark"
                                >
                                    View Event
                                </a>

                                <?php if ($status === "attended"): ?>

                                    <a
                                        href="certificate.php?registration_id=<?= (int)$event["registration_id"] ?>"
                                        class="btn btn-outline-primary"
                                    >
                                        Certificate
                                    </a>

                                    <a
                                        href="feedback.php?event_id=<?= (int)$event["event_id"] ?>"
                                        class="btn btn-outline-secondary"
                                    >
                                        Give Feedback
                                    </a>

                                <?php endif; ?>

                            </div>

                        </div>

                    </article>

                </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="col-12">

                <div class="empty-events">

                    <div class="empty-icon">
                        E
                    </div>

                    <h3>No events registered yet</h3>

                    <p>
                        You have not registered for any event.
                        Explore upcoming events and join something interesting.
                    </p>

                    <a
                        href="events.php"
                        class="btn btn-primary px-4 py-2"
                    >
                        Explore Events
                    </a>

                </div>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php require "footer.php"; ?>