<?php

declare(strict_types=1);

require "db.php";
require_once "functions.php";

$title = "Event Details";

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| EVENT ID
|--------------------------------------------------------------------------
*/

$event_id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;

if ($event_id <= 0) {
    header("Location: events.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
*/

if (
    empty($_SESSION["event_csrf_token"]) ||
    !is_string($_SESSION["event_csrf_token"])
) {
    $_SESSION["event_csrf_token"] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION["event_csrf_token"];

/*
|--------------------------------------------------------------------------
| GET EVENT
|--------------------------------------------------------------------------
*/

$stmt = mysqli_prepare(
    $conn,
    "SELECT
        e.event_id,
        e.title,
        e.short_description,
        e.description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.max_capacity,
        e.waitlist_enabled,
        e.event_status,
        c.category_name,
        d.department_name,
        v.venue_name,
        v.location_description
     FROM events e

     INNER JOIN event_categories c
        ON c.category_id = e.category_id

     INNER JOIN departments d
        ON d.department_id = e.department_id

     INNER JOIN venues v
        ON v.venue_id = e.venue_id

     WHERE e.event_id = ?
       AND e.event_status = 'published'

     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $event_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$event = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$event) {
    header("Location: events.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| LOGIN / USER
|--------------------------------------------------------------------------
*/

$user_logged_in = function_exists("auth") && auth();

$user_is_student = false;

$user_id = 0;

if (
    $user_logged_in &&
    isset($_SESSION["user"]) &&
    is_array($_SESSION["user"])
) {

    $user_id = (int)(
        $_SESSION["user"]["user_id"] ?? 0
    );

    $user_role = (string)(
        $_SESSION["user"]["role"] ?? ""
    );

    if ($user_role === "student") {
        $user_is_student = true;
    }
}

/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    /*
    |--------------------------------------------------------------------------
    | CHECK CSRF
    |--------------------------------------------------------------------------
    */

    $posted_token = (string)(
        $_POST["csrf_token"] ?? ""
    );

    if (
        $posted_token === "" ||
        !hash_equals(
            $csrf_token,
            $posted_token
        )
    ) {

        flash(
            "Invalid security token. Please refresh the page and try again.",
            "danger"
        );

        header(
            "Location: event-details.php?id=" . $event_id
        );

        exit;
    }

    $action = (string)(
        $_POST["action"] ?? ""
    );

    /*
    |--------------------------------------------------------------------------
    | CANCEL REGISTRATION
    |--------------------------------------------------------------------------
    */

    if ($action === "cancel_registration") {

        /*
        |----------------------------------------------------------------------
        | LOGIN CHECK
        |----------------------------------------------------------------------
        */

        if (!$user_logged_in) {

            header("Location: login.php");

            exit;
        }

        /*
        |----------------------------------------------------------------------
        | STUDENT CHECK
        |----------------------------------------------------------------------
        */

        if (
            !$user_is_student ||
            $user_id <= 0
        ) {

            flash(
                "Only students can cancel event registrations.",
                "danger"
            );

            header(
                "Location: event-details.php?id=" . $event_id
            );

            exit;
        }

        /*
        |----------------------------------------------------------------------
        | REGISTRATION ID
        |----------------------------------------------------------------------
        */

        $registration_id = isset(
            $_POST["registration_id"]
        )
            ? (int)$_POST["registration_id"]
            : 0;

        if ($registration_id <= 0) {

            flash(
                "Invalid registration selected.",
                "danger"
            );

            header(
                "Location: event-details.php?id=" . $event_id
            );

            exit;
        }

        /*
        |----------------------------------------------------------------------
        | CHECK EVENT DATE
        |----------------------------------------------------------------------
        */

        $event_date_check = strtotime(
            (string)$event["event_date"]
        );

        $today = strtotime(
            date("Y-m-d")
        );

        if (
            $event_date_check === false ||
            $event_date_check < $today
        ) {

            flash(
                "This registration can no longer be cancelled because the event date has passed.",
                "warning"
            );

            header(
                "Location: event-details.php?id=" . $event_id
            );

            exit;
        }

        /*
        |----------------------------------------------------------------------
        | CANCEL ONLY OWN REGISTRATION
        |----------------------------------------------------------------------
        */

        $cancel_stmt = mysqli_prepare(
            $conn,
            "UPDATE event_registrations er

             INNER JOIN events e
                ON e.event_id = er.event_id

             SET er.status = 'cancelled'

             WHERE er.registration_id = ?
               AND er.event_id = ?
               AND er.student_id = ?
               AND er.status = 'confirmed'
               AND e.event_date >= CURDATE()"
        );

        mysqli_stmt_bind_param(
            $cancel_stmt,
            "iii",
            $registration_id,
            $event_id,
            $user_id
        );

        if (
            mysqli_stmt_execute(
                $cancel_stmt
            )
        ) {

            if (
                mysqli_stmt_affected_rows(
                    $cancel_stmt
                ) > 0
            ) {

                flash(
                    "Your registration has been cancelled successfully.",
                    "success"
                );

            } else {

                flash(
                    "This registration cannot be cancelled. It may already be cancelled or the event may have started.",
                    "warning"
                );
            }

        } else {

            flash(
                "Unable to cancel registration. Please try again.",
                "danger"
            );
        }

        mysqli_stmt_close(
            $cancel_stmt
        );

        /*
        |--------------------------------------------------------------------------
        | RETURN TO EVENT PAGE
        |--------------------------------------------------------------------------
        */

        header(
            "Location: event-details.php?id=" . $event_id
        );

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTER
    |--------------------------------------------------------------------------
    */

    if ($action === "register") {

        if (!$user_logged_in) {

            header("Location: login.php");

            exit;
        }

        if (
            !$user_is_student ||
            $user_id <= 0
        ) {

            flash(
                "Only students can register for events.",
                "danger"
            );

            header(
                "Location: event-details.php?id=" . $event_id
            );

            exit;
        }

        /*
        |--------------------------------------------------------------------------
        | FORM DATA
        |--------------------------------------------------------------------------
        */

        $full_name = trim(
            (string)($_POST["full_name"] ?? "")
        );

        $email = trim(
            (string)($_POST["email"] ?? "")
        );

        $phone = trim(
            (string)($_POST["phone"] ?? "")
        );

        $enrollment_no = trim(
            (string)($_POST["enrollment_no"] ?? "")
        );

        $errors = [];

        if ($full_name === "") {
            $errors[] = "Full name is required.";
        }

        if (strlen($full_name) < 3) {
            $errors[] = "Full name must contain at least 3 characters.";
        }

        if (
            !filter_var(
                $email,
                FILTER_VALIDATE_EMAIL
            )
        ) {
            $errors[] = "Please enter a valid email address.";
        }

        if ($phone === "") {
            $errors[] = "Phone number is required.";
        }

        if (strlen($phone) < 7) {
            $errors[] = "Please enter a valid phone number.";
        }

        if ($enrollment_no === "") {
            $errors[] = "Enrollment number is required.";
        }

        /*
        |--------------------------------------------------------------------------
        | VALIDATION ERRORS
        |--------------------------------------------------------------------------
        */

        if (!empty($errors)) {

            foreach ($errors as $error) {

                flash(
                    $error,
                    "danger"
                );
            }

            header(
                "Location: event-details.php?id=" . $event_id
            );

            exit;
        }

        /*
        |--------------------------------------------------------------------------
        | CHECK EXISTING REGISTRATION
        |--------------------------------------------------------------------------
        */

        $duplicate_stmt = mysqli_prepare(
            $conn,
            "SELECT
                registration_id,
                registration_code,
                status

             FROM event_registrations

             WHERE event_id = ?
               AND student_id = ?

             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $duplicate_stmt,
            "ii",
            $event_id,
            $user_id
        );

        mysqli_stmt_execute(
            $duplicate_stmt
        );

        $duplicate_result =
            mysqli_stmt_get_result(
                $duplicate_stmt
            );

        $duplicate =
            mysqli_fetch_assoc(
                $duplicate_result
            );

        mysqli_stmt_close(
            $duplicate_stmt
        );

        /*
        |--------------------------------------------------------------------------
        | EXISTING RECORD
        |--------------------------------------------------------------------------
        */

        if ($duplicate) {

            $existing_status = strtolower(
                trim(
                    (string)(
                        $duplicate["status"] ?? ""
                    )
                )
            );

            /*
            |--------------------------------------------------------------------------
            | ALREADY CONFIRMED
            |--------------------------------------------------------------------------
            */

            if (
                in_array(
                    $existing_status,
                    [
                        "confirmed",
                        "attended"
                    ],
                    true
                )
            ) {

                flash(
                    "You are already registered for this event.",
                    "warning"
                );
            }

            /*
            |--------------------------------------------------------------------------
            | CANCELLED -> REGISTER AGAIN
            |--------------------------------------------------------------------------
            */

            elseif (
                $existing_status === "cancelled"
            ) {

                /*
                | Check seats again
                */

                $count_stmt = mysqli_prepare(
                    $conn,
                    "SELECT COUNT(*) AS total

                     FROM event_registrations

                     WHERE event_id = ?

                       AND status IN
                       ('confirmed','attended')"
                );

                mysqli_stmt_bind_param(
                    $count_stmt,
                    "i",
                    $event_id
                );

                mysqli_stmt_execute(
                    $count_stmt
                );

                $count_result =
                    mysqli_stmt_get_result(
                        $count_stmt
                    );

                $count_row =
                    mysqli_fetch_assoc(
                        $count_result
                    );

                mysqli_stmt_close(
                    $count_stmt
                );

                $registered_count =
                    (int)(
                        $count_row["total"] ?? 0
                    );

                $available_seats = max(
                    0,
                    (int)$event["max_capacity"]
                    - $registered_count
                );

                if ($available_seats <= 0) {

                    flash(
                        "This event is currently full.",
                        "danger"
                    );

                    header(
                        "Location: event-details.php?id=" . $event_id
                    );

                    exit;
                }

                /*
                | New registration code
                */

                $new_registration_code =
                    "EVS-" .
                    strtoupper(
                        substr(
                            bin2hex(
                                random_bytes(6)
                            ),
                            0,
                            10
                        )
                    );

                $duplicate_id =
                    (int)(
                        $duplicate["registration_id"]
                    );

                $restore_stmt = mysqli_prepare(
                    $conn,
                    "UPDATE event_registrations

                     SET
                        status = 'confirmed',
                        registration_code = ?

                     WHERE registration_id = ?
                       AND event_id = ?
                       AND student_id = ?
                       AND status = 'cancelled'"
                );

                mysqli_stmt_bind_param(
                    $restore_stmt,
                    "siii",
                    $new_registration_code,
                    $duplicate_id,
                    $event_id,
                    $user_id
                );

                if (
                    mysqli_stmt_execute(
                        $restore_stmt
                    )
                ) {

                    if (
                        mysqli_stmt_affected_rows(
                            $restore_stmt
                        ) > 0
                    ) {

                        flash(
                            "Registration successful. Your new registration code is " .
                            $new_registration_code,
                            "success"
                        );

                    } else {

                        flash(
                            "Unable to restore your registration.",
                            "danger"
                        );
                    }

                } else {

                    flash(
                        "Unable to complete registration. Please try again.",
                        "danger"
                    );
                }

                mysqli_stmt_close(
                    $restore_stmt
                );
            }

            /*
            |--------------------------------------------------------------------------
            | OTHER STATUS
            |--------------------------------------------------------------------------
            */

            else {

                flash(
                    "You already have a registration record for this event.",
                    "warning"
                );
            }

            header(
                "Location: event-details.php?id=" . $event_id
            );

            exit;
        }

        /*
        |--------------------------------------------------------------------------
        | COUNT CONFIRMED REGISTRATIONS
        |--------------------------------------------------------------------------
        */

        $count_stmt = mysqli_prepare(
            $conn,
            "SELECT COUNT(*) AS total

             FROM event_registrations

             WHERE event_id = ?

               AND status IN
               ('confirmed','attended')"
        );

        mysqli_stmt_bind_param(
            $count_stmt,
            "i",
            $event_id
        );

        mysqli_stmt_execute(
            $count_stmt
        );

        $count_result =
            mysqli_stmt_get_result(
                $count_stmt
            );

        $count_row =
            mysqli_fetch_assoc(
                $count_result
            );

        mysqli_stmt_close(
            $count_stmt
        );

        $registered_count =
            (int)(
                $count_row["total"] ?? 0
            );

        $available_seats = max(
            0,
            (int)$event["max_capacity"]
            - $registered_count
        );

        /*
        |--------------------------------------------------------------------------
        | AVAILABLE SEAT
        |--------------------------------------------------------------------------
        */

        if ($available_seats > 0) {

            $registration_code =
                "EVS-" .
                strtoupper(
                    substr(
                        bin2hex(
                            random_bytes(6)
                        ),
                        0,
                        10
                    )
                );

            $insert_stmt = mysqli_prepare(
                $conn,
                "INSERT INTO event_registrations
                (
                    event_id,
                    student_id,
                    registration_code,
                    status
                )

                VALUES
                (
                    ?,
                    ?,
                    ?,
                    'confirmed'
                )"
            );

            mysqli_stmt_bind_param(
                $insert_stmt,
                "iis",
                $event_id,
                $user_id,
                $registration_code
            );

            if (
                mysqli_stmt_execute(
                    $insert_stmt
                )
            ) {

                flash(
                    "Registration successful. Your registration code is " .
                    $registration_code,
                    "success"
                );

            } else {

                flash(
                    "Unable to complete registration. Please try again.",
                    "danger"
                );
            }

            mysqli_stmt_close(
                $insert_stmt
            );
        }

        /*
        |--------------------------------------------------------------------------
        | WAITLIST
        |--------------------------------------------------------------------------
        */

        elseif (
            (int)$event["waitlist_enabled"] === 1
        ) {

            $position_stmt = mysqli_prepare(
                $conn,
                "SELECT
                    COALESCE(
                        MAX(queue_position),
                        0
                    ) + 1 AS next_position

                 FROM event_waitlist

                 WHERE event_id = ?

                   AND status = 'waiting'"
            );

            mysqli_stmt_bind_param(
                $position_stmt,
                "i",
                $event_id
            );

            mysqli_stmt_execute(
                $position_stmt
            );

            $position_result =
                mysqli_stmt_get_result(
                    $position_stmt
                );

            $position_row =
                mysqli_fetch_assoc(
                    $position_result
                );

            mysqli_stmt_close(
                $position_stmt
            );

            $queue_position =
                (int)(
                    $position_row["next_position"] ?? 1
                );

            $wait_stmt = mysqli_prepare(
                $conn,
                "INSERT INTO event_waitlist
                (
                    event_id,
                    student_id,
                    queue_position,
                    status
                )

                VALUES
                (
                    ?,
                    ?,
                    ?,
                    'waiting'
                )"
            );

            mysqli_stmt_bind_param(
                $wait_stmt,
                "iii",
                $event_id,
                $user_id,
                $queue_position
            );

            if (
                mysqli_stmt_execute(
                    $wait_stmt
                )
            ) {

                flash(
                    "The event is full. You have been added to the waitlist.",
                    "warning"
                );

            } else {

                flash(
                    "Unable to join the waitlist.",
                    "danger"
                );
            }

            mysqli_stmt_close(
                $wait_stmt
            );
        }

        /*
        |--------------------------------------------------------------------------
        | FULL
        |--------------------------------------------------------------------------
        */

        else {

            flash(
                "This event is currently full.",
                "danger"
            );
        }

        header(
            "Location: event-details.php?id=" . $event_id
        );

        exit;
    }
}

/*
|--------------------------------------------------------------------------
| CURRENT REGISTRATION COUNT
|--------------------------------------------------------------------------
*/

$count_stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS total

     FROM event_registrations

     WHERE event_id = ?

       AND status IN
       ('confirmed','attended')"
);

mysqli_stmt_bind_param(
    $count_stmt,
    "i",
    $event_id
);

mysqli_stmt_execute(
    $count_stmt
);

$count_result =
    mysqli_stmt_get_result(
        $count_stmt
    );

$count_row =
    mysqli_fetch_assoc(
        $count_result
    );

mysqli_stmt_close(
    $count_stmt
);

$registered_count =
    (int)(
        $count_row["total"] ?? 0
    );

$available_seats = max(
    0,
    (int)$event["max_capacity"]
    - $registered_count
);

/*
|--------------------------------------------------------------------------
| CHECK CURRENT STUDENT REGISTRATION
|--------------------------------------------------------------------------
*/

$already_registered = false;

$registration_code = "";

$registration_id = 0;

$registration_status = "";

if (
    $user_is_student &&
    $user_id > 0
) {

    $check_stmt = mysqli_prepare(
        $conn,
        "SELECT
            registration_id,
            registration_code,
            status

         FROM event_registrations

         WHERE event_id = ?
           AND student_id = ?
           AND status IN
           ('confirmed','attended')

         LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $check_stmt,
        "ii",
        $event_id,
        $user_id
    );

    mysqli_stmt_execute(
        $check_stmt
    );

    $check_result =
        mysqli_stmt_get_result(
            $check_stmt
        );

    $registration =
        mysqli_fetch_assoc(
            $check_result
        );

    mysqli_stmt_close(
        $check_stmt
    );

    if ($registration) {

        $already_registered = true;

        $registration_id =
            (int)(
                $registration["registration_id"]
            );

        $registration_code =
            (string)(
                $registration["registration_code"]
            );

        $registration_status =
            strtolower(
                trim(
                    (string)(
                        $registration["status"]
                    )
                )
            );
    }
}

$title = $event["title"];

require "header.php";

?>

<style>

.event-page {
    padding: 20px 0 70px;
}

.event-hero {
    position: relative;
    overflow: hidden;
    min-height: 410px;
    display: flex;
    align-items: center;
    border-radius: 28px;
    padding: 55px;
    color: #fff;

    background:
        radial-gradient(
            circle at 85% 20%,
            rgba(99,102,241,.34),
            transparent 28%
        ),
        radial-gradient(
            circle at 10% 90%,
            rgba(34,211,238,.16),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #080d1b,
            #151b32,
            #1e1b4b
        );

    box-shadow:
        0 25px 70px
        rgba(15,23,42,.18);
}

.event-hero::before {
    content: "";
    position: absolute;
    width: 420px;
    height: 420px;
    right: -130px;
    top: -180px;
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 50%;
    animation: rotateCircle 18s linear infinite;
}

.event-hero::after {
    content: "";
    position: absolute;
    width: 250px;
    height: 250px;
    right: 50px;
    bottom: -160px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 50%;
    animation: rotateCircle 14s linear infinite reverse;
}

.event-hero-content {
    position: relative;
    z-index: 2;
    max-width: 850px;
    animation: eventReveal .8s ease both;
}

.event-category {
    display: inline-flex;
    padding: 8px 13px;
    border-radius: 999px;
    background: rgba(255,255,255,.09);
    border: 1px solid rgba(255,255,255,.12);
    color: #c7d2fe;
    font-size: .75rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .07em;
}

.event-hero h1 {
    margin: 20px 0 15px;
    font-size: clamp(2.5rem,5vw,4.8rem);
    line-height: 1;
    font-weight: 850;
    letter-spacing: -.055em;
}

.event-hero p {
    max-width: 720px;
    margin: 0;
    color: #cbd5e1;
    font-size: 1.05rem;
    line-height: 1.8;
}

.event-info-grid {
    position: relative;
    z-index: 5;
    margin-top: -45px;
}

.info-card {
    height: 100%;
    padding: 22px;
    border: 1px solid #e5e7eb;
    border-radius: 20px;
    background: rgba(255,255,255,.96);
    box-shadow: 0 18px 50px rgba(15,23,42,.09);
    transition: .3s ease;
}

.info-card:hover {
    transform: translateY(-5px);
    box-shadow:
        0 25px 55px
        rgba(79,70,229,.13);
}

.info-label {
    display: block;
    margin-bottom: 6px;
    color: #64748b;
    font-size: .75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .06em;
}

.info-value {
    color: #111827;
    font-size: .95rem;
    font-weight: 800;
}

.content-section {
    margin-top: 70px;
}

.content-card {
    padding: 35px;
    border: 1px solid #e8edf3;
    border-radius: 25px;
    background: #fff;
    box-shadow:
        0 15px 45px
        rgba(15,23,42,.055);
}

.content-card h2 {
    margin-bottom: 18px;
    color: #111827;
    font-weight: 850;
    letter-spacing: -.035em;
}

.description {
    color: #64748b;
    line-height: 1.9;
    white-space: pre-line;
}

.registration-card {
    position: sticky;
    top: 25px;
    padding: 30px;
    border: 1px solid #e2e8f0;
    border-radius: 25px;
    background: #fff;
    box-shadow:
        0 20px 55px
        rgba(15,23,42,.09);
}

.registration-card h2 {
    margin-bottom: 7px;
    color: #111827;
    font-weight: 850;
    letter-spacing: -.035em;
}

.registration-subtitle {
    margin-bottom: 25px;
    color: #64748b;
    font-size: .9rem;
}

.form-label-modern {
    margin-bottom: 7px;
    color: #334155;
    font-size: .82rem;
    font-weight: 750;
}

.form-control-modern {
    min-height: 50px;
    border: 1px solid #dbe2ea;
    border-radius: 12px;
    padding: 12px 14px;
    transition: .25s ease;
}

.form-control-modern:focus {
    border-color: #6366f1;
    box-shadow:
        0 0 0 4px
        rgba(99,102,241,.1);
}

.register-button {
    width: 100%;
    min-height: 54px;
    border: 0;
    border-radius: 13px;
    color: #fff;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    font-weight: 800;

    box-shadow:
        0 12px 30px
        rgba(79,70,229,.25);

    transition: .3s ease;
}

.register-button:hover {
    transform: translateY(-3px);

    box-shadow:
        0 18px 38px
        rgba(79,70,229,.35);
}

/*
|--------------------------------------------------------------------------
| CANCEL BUTTON
|--------------------------------------------------------------------------
*/

.cancel-button {
    width: 100%;
    min-height: 52px;
    margin-top: 14px;

    border: 1px solid #fecaca;
    border-radius: 13px;

    color: #b91c1c;
    background: #fff;

    font-weight: 800;

    cursor: pointer;

    transition:
        background .25s ease,
        border-color .25s ease,
        transform .25s ease,
        box-shadow .25s ease;
}

.cancel-button:hover {
    background: #fef2f2;
    border-color: #fca5a5;

    transform: translateY(-2px);

    box-shadow:
        0 10px 25px
        rgba(185,28,28,.10);
}

.cancel-button:active {
    transform: translateY(0);
}

/*
|--------------------------------------------------------------------------
| REGISTERED BOX
|--------------------------------------------------------------------------
*/

.success-registration {
    padding: 24px;
    border-radius: 18px;
    background: #ecfdf5;
    border: 1px solid #a7f3d0;
}

.success-registration strong {
    display: block;
    color: #047857;
    margin-bottom: 8px;
}

.registration-code {
    display: inline-block;
    margin-top: 8px;
    padding: 10px 13px;
    border-radius: 10px;
    background: #fff;
    color: #065f46;
    font-weight: 850;
    letter-spacing: .08em;
}

.registration-status {
    margin-top: 12px;
    color: #047857;
    font-size: .8rem;
    font-weight: 700;
}

.cancel-note {
    margin-top: 14px;
    color: #64748b;
    font-size: .75rem;
    line-height: 1.6;
}

/*
|--------------------------------------------------------------------------
| SEATS
|--------------------------------------------------------------------------
*/

.seat-box {
    display: flex;
    justify-content: space-between;
    align-items: center;

    margin-bottom: 22px;
    padding: 15px 17px;

    border-radius: 15px;
    background: #f8fafc;
}

.seat-number {
    color: #4f46e5;
    font-size: 1.3rem;
    font-weight: 850;
}

.login-box {
    padding: 22px;
    border-radius: 17px;
    background: #f8fafc;
    border: 1px solid #e5e7eb;
}

.full-event {
    padding: 20px;
    border-radius: 17px;
    background: #fff7ed;
    border: 1px solid #fed7aa;
    color: #9a3412;
}

@keyframes eventReveal {

    from {
        opacity: 0;
        transform: translateY(25px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}

@keyframes rotateCircle {

    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(360deg);
    }

}

@media(max-width:991px) {

    .event-hero {
        padding: 40px 28px;
    }

    .event-info-grid {
        margin-top: 25px;
    }

    .registration-card {
        position: relative;
        top: auto;
    }

}

@media(max-width:575px) {

    .event-page {
        padding-top: 5px;
    }

    .event-hero {
        min-height: 430px;
        padding: 35px 22px;
        border-radius: 22px;
    }

    .event-hero h1 {
        font-size: 2.7rem;
    }

    .content-card,
    .registration-card {
        padding: 23px;
        border-radius: 20px;
    }

}

</style>


<div class="event-page">

    <!-- HERO -->

    <section class="event-hero">

        <div class="event-hero-content">

            <span class="event-category">
                <?= e($event["category_name"]) ?>
            </span>

            <h1>
                <?= e($event["title"]) ?>
            </h1>

            <p>
                <?= e($event["short_description"]) ?>
            </p>

        </div>

    </section>


    <!-- EVENT INFO -->

    <div class="event-info-grid">

        <div class="row g-3">

            <div class="col-6 col-lg-3">

                <div class="info-card">

                    <span class="info-label">
                        Date
                    </span>

                    <span class="info-value">
                        <?= e($event["event_date"]) ?>
                    </span>

                </div>

            </div>


            <div class="col-6 col-lg-3">

                <div class="info-card">

                    <span class="info-label">
                        Time
                    </span>

                    <span class="info-value">

                        <?= e($event["start_time"]) ?>

                        -

                        <?= e($event["end_time"]) ?>

                    </span>

                </div>

            </div>


            <div class="col-6 col-lg-3">

                <div class="info-card">

                    <span class="info-label">
                        Venue
                    </span>

                    <span class="info-value">
                        <?= e($event["venue_name"]) ?>
                    </span>

                </div>

            </div>


            <div class="col-6 col-lg-3">

                <div class="info-card">

                    <span class="info-label">
                        Seats Available
                    </span>

                    <span class="info-value">

                        <?= $available_seats ?>

                        /

                        <?= (int)$event["max_capacity"] ?>

                    </span>

                </div>

            </div>

        </div>

    </div>


    <!-- CONTENT -->

    <div class="content-section">

        <div class="row g-4">


            <!-- ABOUT -->

            <div class="col-lg-7">

                <div class="content-card">

                    <h2>
                        About This Event
                    </h2>

                    <div class="description">

                        <?= e($event["description"]) ?>

                    </div>


                    <hr class="my-4">


                    <div class="row g-4">

                        <div class="col-sm-6">

                            <span class="info-label">
                                Organizing Department
                            </span>

                            <strong>
                                <?= e($event["department_name"]) ?>
                            </strong>

                        </div>


                        <div class="col-sm-6">

                            <span class="info-label">
                                Location
                            </span>

                            <strong>
                                <?= e($event["location_description"]) ?>
                            </strong>

                        </div>

                    </div>

                </div>

            </div>


            <!-- REGISTRATION -->

            <div class="col-lg-5">

                <div class="registration-card">

                    <h2>
                        Event Registration
                    </h2>

                    <p class="registration-subtitle">
                        Reserve your place for this event.
                    </p>


                    <!-- SEATS -->

                    <div class="seat-box">

                        <div>

                            <span class="info-label mb-0">
                                Remaining Seats
                            </span>

                        </div>

                        <span class="seat-number">
                            <?= $available_seats ?>
                        </span>

                    </div>


                    <?php if ($already_registered): ?>


                        <!-- REGISTERED -->

                        <div class="success-registration">

                            <strong>
                                Registration Confirmed
                            </strong>

                            <div>
                                You are already registered for this event.
                            </div>


                            <!-- CODE -->

                            <span class="registration-code">

                                <?= e($registration_code) ?>

                            </span>


                            <!-- STATUS -->

                            <div class="registration-status">

                                Status:
                                <?= e(
                                    ucfirst(
                                        $registration_status
                                    )
                                ) ?>

                            </div>


                            <?php

                            $event_timestamp = strtotime(
                                (string)$event["event_date"]
                            );

                            $today_timestamp = strtotime(
                                date("Y-m-d")
                            );

                            ?>

                            <?php if (
                                $event_timestamp !== false &&
                                $event_timestamp >= $today_timestamp &&
                                $registration_status === "confirmed"
                            ): ?>


                                <!--
                                ==================================================
                                CANCEL REGISTRATION FORM
                                ==================================================
                                -->

                                <form
                                    method="post"
                                    action="event-details.php?id=<?= $event_id ?>"
                                    onsubmit="return confirmCancelRegistration();"
                                >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= e($csrf_token) ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="action"
                                        value="cancel_registration"
                                    >

                                    <input
                                        type="hidden"
                                        name="registration_id"
                                        value="<?= $registration_id ?>"
                                    >


                                    <button
                                        type="submit"
                                        class="cancel-button"
                                    >

                                        Cancel Registration

                                    </button>

                                </form>


                                <div class="cancel-note">

                                    You can cancel your registration
                                    before the event date.

                                </div>


                            <?php else: ?>


                                <div class="cancel-note">

                                    This registration can no longer
                                    be cancelled because the event
                                    date has passed.

                                </div>


                            <?php endif; ?>

                        </div>


                    <?php elseif (!$user_logged_in): ?>


                        <!-- LOGIN -->

                        <div class="login-box">

                            <h5 class="fw-bold">
                                Login required
                            </h5>

                            <p class="text-muted small mb-3">

                                Please login with your student
                                account before registering for
                                this event.

                            </p>


                            <a
                                href="login.php"
                                class="btn btn-dark w-100"
                            >

                                Login to Register

                            </a>


                            <div class="text-center mt-3 small">

                                Don't have an account?

                                <a href="register.php">
                                    Create one
                                </a>

                            </div>

                        </div>


                    <?php elseif (!$user_is_student): ?>


                        <!-- NON STUDENT -->

                        <div class="full-event">

                            Only student accounts can register
                            for college events.

                        </div>


                    <?php elseif ($available_seats > 0): ?>


                        <!-- REGISTRATION FORM -->

                        <form
                            method="post"
                            action="event-details.php?id=<?= $event_id ?>"
                            novalidate
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($csrf_token) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="register"
                            >


                            <div class="mb-3">

                                <label class="form-label-modern">
                                    Full Name
                                </label>

                                <input
                                    type="text"
                                    name="full_name"
                                    class="form-control form-control-modern"
                                    placeholder="Enter your full name"
                                    required
                                >

                            </div>


                            <div class="mb-3">

                                <label class="form-label-modern">
                                    Email Address
                                </label>

                                <input
                                    type="email"
                                    name="email"
                                    class="form-control form-control-modern"
                                    placeholder="student@example.com"
                                    required
                                >

                            </div>


                            <div class="mb-3">

                                <label class="form-label-modern">
                                    Phone Number
                                </label>

                                <input
                                    type="text"
                                    name="phone"
                                    class="form-control form-control-modern"
                                    placeholder="+92 300 1234567"
                                    required
                                >

                            </div>


                            <div class="mb-4">

                                <label class="form-label-modern">
                                    Enrollment Number
                                </label>

                                <input
                                    type="text"
                                    name="enrollment_no"
                                    class="form-control form-control-modern"
                                    placeholder="Enter enrollment number"
                                    required
                                >

                            </div>


                            <button
                                type="submit"
                                class="register-button"
                            >

                                Confirm Registration

                            </button>

                        </form>


                    <?php elseif (
                        (int)$event["waitlist_enabled"] === 1
                    ): ?>


                        <!-- WAITLIST -->

                        <div class="full-event mb-3">

                            <strong>
                                Event is currently full.
                            </strong>

                            <div class="small mt-1">

                                You can still join the waitlist.

                            </div>

                        </div>


                        <form
                            method="post"
                            action="event-details.php?id=<?= $event_id ?>"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= e($csrf_token) ?>"
                            >

                            <input
                                type="hidden"
                                name="action"
                                value="register"
                            >

                            <input
                                type="hidden"
                                name="full_name"
                                value="Waitlist"
                            >

                            <input
                                type="hidden"
                                name="email"
                                value="<?= e(
                                    $_SESSION["user"]["email"] ?? ""
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="phone"
                                value="0000000"
                            >

                            <input
                                type="hidden"
                                name="enrollment_no"
                                value="WAITLIST"
                            >


                            <button
                                type="submit"
                                class="register-button"
                            >

                                Join Waitlist

                            </button>

                        </form>


                    <?php else: ?>


                        <!-- FULL -->

                        <div class="full-event">

                            This event is currently full and
                            registration is closed.

                        </div>


                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</div>


<script>

/*
|--------------------------------------------------------------------------
| CANCEL CONFIRMATION
|--------------------------------------------------------------------------
*/

function confirmCancelRegistration() {

    return confirm(
        "Are you sure you want to cancel your registration?\n\n" +
        "Your seat will become available for another student."
    );

}

</script>


<?php require "footer.php"; ?>