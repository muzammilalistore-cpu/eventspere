<?php

http_response_code(404);

$title = "Page Not Found";

require "header.php";
?>

<style>
.error-page {
    min-height: 68vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 60px 20px;
}

.error-box {
    max-width: 650px;
    width: 100%;
    padding: 55px 35px;
    text-align: center;
    border: 1px solid #e5e7eb;
    border-radius: 28px;
    background: #ffffff;
    box-shadow: 0 25px 70px rgba(15, 23, 42, .08);
}

.error-number {
    margin: 0;
    font-size: clamp(5rem, 15vw, 9rem);
    line-height: .9;
    font-weight: 900;
    letter-spacing: -.08em;
    background: linear-gradient(135deg, #4f46e5, #06b6d4);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

.error-box h1 {
    margin: 25px 0 12px;
    font-size: 2rem;
    font-weight: 800;
    color: #111827;
}

.error-box p {
    margin: 0 auto 28px;
    max-width: 500px;
    color: #64748b;
    line-height: 1.7;
}

.error-actions {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 12px;
}

.error-actions a {
    padding: 12px 20px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 700;
    transition: .25s ease;
}

.error-primary {
    color: #fff;
    background: #4f46e5;
}

.error-primary:hover {
    color: #fff;
    background: #3730a3;
    transform: translateY(-2px);
}

.error-secondary {
    color: #334155;
    background: #f1f5f9;
}

.error-secondary:hover {
    color: #111827;
    background: #e2e8f0;
    transform: translateY(-2px);
}

@media(max-width:576px) {
    .error-box {
        padding: 40px 22px;
    }

    .error-box h1 {
        font-size: 1.6rem;
    }

    .error-actions {
        flex-direction: column;
    }

    .error-actions a {
        width: 100%;
    }
}
</style>

<div class="error-page">

    <div class="error-box">

        <div class="error-number">404</div>

        <h1>We couldn't find that page</h1>

        <p>
            The page you're looking for may have been moved,
            removed, or the address may be incorrect.
        </p>

        <div class="error-actions">

            <a href="index.php" class="error-primary">
                Back to Home
            </a>

            <a href="events.php" class="error-secondary">
                Explore Events
            </a>

        </div>

    </div>

</div>

<?php require "footer.php"; ?>