<?php

require "db.php";

header("Content-Type: application/xml; charset=utf-8");

$base_url = "http://localhost/eventsphere";

function xml_escape($value)
{
    return htmlspecialchars(
        $value,
        ENT_XML1 | ENT_QUOTES,
        "UTF-8"
    );
}

function add_url($url, $lastmod = null, $changefreq = "weekly", $priority = "0.7")
{
    echo "<url>";
    echo "<loc>" . xml_escape($url) . "</loc>";

    if ($lastmod) {
        echo "<lastmod>" . xml_escape($lastmod) . "</lastmod>";
    }

    echo "<changefreq>" . xml_escape($changefreq) . "</changefreq>";
    echo "<priority>" . xml_escape($priority) . "</priority>";
    echo "</url>";
}

echo '<?xml version="1.0" encoding="UTF-8"?>';

echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

add_url(
    $base_url . "/index.php",
    date("Y-m-d"),
    "daily",
    "1.0"
);

add_url(
    $base_url . "/events.php",
    date("Y-m-d"),
    "daily",
    "0.9"
);

add_url(
    $base_url . "/gallery.php",
    date("Y-m-d"),
    "weekly",
    "0.8"
);

add_url(
    $base_url . "/contact-us.php",
    date("Y-m-d"),
    "monthly",
    "0.6"
);

add_url(
    $base_url . "/register.php",
    date("Y-m-d"),
    "monthly",
    "0.6"
);

add_url(
    $base_url . "/login.php",
    date("Y-m-d"),
    "monthly",
    "0.5"
);

$event_query = mysqli_query(
    $conn,
    "SELECT event_id, event_date
     FROM events
     WHERE event_status = 'published'
     AND event_date >= CURDATE()
     ORDER BY event_date ASC"
);

if ($event_query) {

    while ($event = mysqli_fetch_assoc($event_query)) {

        $event_id = (int)$event["event_id"];

        $lastmod = !empty($event["event_date"])
            ? date("Y-m-d", strtotime($event["event_date"]))
            : date("Y-m-d");

        add_url(
            $base_url . "/event-details.php?id=" . $event_id,
            $lastmod,
            "weekly",
            "0.8"
        );
    }
}

$category_query = mysqli_query(
    $conn,
    "SELECT category_id
     FROM event_categories
     ORDER BY category_id ASC"
);

if ($category_query) {

    while ($category = mysqli_fetch_assoc($category_query)) {

        $category_id = (int)$category["category_id"];

        add_url(
            $base_url . "/events.php?category=" . $category_id,
            date("Y-m-d"),
            "weekly",
            "0.6"
        );
    }
}

$department_query = mysqli_query(
    $conn,
    "SELECT department_id
     FROM departments
     WHERE status = 'active'
     ORDER BY department_id ASC"
);

if ($department_query) {

    while ($department = mysqli_fetch_assoc($department_query)) {

        $department_id = (int)$department["department_id"];

        add_url(
            $base_url . "/events.php?department=" . $department_id,
            date("Y-m-d"),
            "weekly",
            "0.6"
        );
    }
}

echo "</urlset>";