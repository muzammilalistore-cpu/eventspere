
<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

require "db.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$errors = [];
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    /* =========================
       VALIDATION
    ========================= */

    if ($email === "") {
        $errors[] = "Email address is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if ($password === "") {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 8) {
        $errors[] = "Password must contain at least 8 characters.";
    }

    if ($confirmPassword !== $password) {
        $errors[] = "Passwords do not match.";
    }

    /* =========================
       CHECK EMAIL
    ========================= */

    if (empty($errors)) {

        $checkSql = "
            SELECT user_id
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $checkStmt = mysqli_prepare($conn, $checkSql);

        if (!$checkStmt) {
            $errors[] = "Unable to check account.";
        } else {

            mysqli_stmt_bind_param(
                $checkStmt,
                "s",
                $email
            );

            mysqli_stmt_execute($checkStmt);
            mysqli_stmt_store_result($checkStmt);

            if (mysqli_stmt_num_rows($checkStmt) > 0) {
                $errors[] = "An account with this email already exists.";
            }

            mysqli_stmt_close($checkStmt);
        }
    }

    /* =========================
       CREATE ORGANIZER
    ========================= */

    if (empty($errors)) {

        $passwordHash = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $sql = "
            INSERT INTO users
            (
                email,
                password_hash,
                role,
                account_status,
                email_verified
            )
            VALUES
            (
                ?,
                ?,
                'organizer',
                'active',
                0
            )
        ";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {

            $errors[] =
                "Registration failed: " .
                mysqli_error($conn);

        } else {

            mysqli_stmt_bind_param(
                $stmt,
                "ss",
                $email,
                $passwordHash
            );

            if (mysqli_stmt_execute($stmt)) {

                $success =
                    "Organizer account created successfully.";

            } else {

                $errors[] =
                    "Unable to create organizer account: " .
                    mysqli_stmt_error($stmt);
            }

            mysqli_stmt_close($stmt);
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Organizer Registration | EventSphere</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;

            display: flex;
            align-items: center;
            justify-content: center;

            padding: 30px;

            font-family:
                Inter,
                Arial,
                sans-serif;

            background:
                radial-gradient(
                    circle at 15% 20%,
                    rgba(99,102,241,.20),
                    transparent 30%
                ),
                radial-gradient(
                    circle at 85% 80%,
                    rgba(14,165,233,.16),
                    transparent 30%
                ),
                linear-gradient(
                    135deg,
                    #f8fafc,
                    #eef2ff
                );
        }

        .register-wrapper {
            width: 100%;
            max-width: 470px;
        }

        .register-card {

            position: relative;

            padding: 38px;

            background: rgba(255,255,255,.94);

            border:
                1px solid
                rgba(255,255,255,.8);

            border-radius: 26px;

            box-shadow:
                0 30px 80px
                rgba(15,23,42,.12);

            backdrop-filter: blur(18px);
        }

        .brand {
            text-align: center;
            margin-bottom: 30px;
        }

        .brand-icon {

            width: 58px;
            height: 58px;

            margin: 0 auto 15px;

            display: flex;
            align-items: center;
            justify-content: center;

            border-radius: 17px;

            color: white;

            font-size: 24px;
            font-weight: 900;

            background:
                linear-gradient(
                    135deg,
                    #6366f1,
                    #4f46e5
                );

            box-shadow:
                0 12px 25px
                rgba(79,70,229,.25);
        }

        .brand h1 {

            margin: 0;

            color: #0f172a;

            font-size: 27px;
            font-weight: 850;
        }

        .brand p {

            margin: 8px 0 0;

            color: #64748b;

            font-size: 13px;
        }

        .alert {

            margin-bottom: 20px;

            padding: 13px 15px;

            border-radius: 12px;

            font-size: 13px;
            line-height: 1.5;
        }

        .alert-error {

            color: #991b1b;

            background: #fef2f2;

            border:
                1px solid
                #fecaca;
        }

        .alert-success {

            color: #065f46;

            background: #ecfdf5;

            border:
                1px solid
                #a7f3d0;
        }

        .form-group {
            margin-bottom: 19px;
        }

        label {

            display: block;

            margin-bottom: 8px;

            color: #334155;

            font-size: 12px;
            font-weight: 800;
        }

        input {

            width: 100%;

            height: 48px;

            padding: 0 14px;

            border:
                1px solid
                #dbe2ea;

            border-radius: 12px;

            outline: none;

            color: #0f172a;

            background: #fff;

            font-size: 13px;

            transition: .2s ease;
        }

        input:focus {

            border-color: #6366f1;

            box-shadow:
                0 0 0 4px
                rgba(99,102,241,.10);
        }

        .password-help {

            margin-top: 7px;

            color: #94a3b8;

            font-size: 11px;
        }

        .register-btn {

            width: 100%;

            height: 50px;

            margin-top: 7px;

            border: 0;

            border-radius: 12px;

            color: white;

            background:
                linear-gradient(
                    135deg,
                    #6366f1,
                    #4f46e5
                );

            font-size: 13px;
            font-weight: 850;

            cursor: pointer;

            box-shadow:
                0 12px 25px
                rgba(79,70,229,.22);

            transition: .25s ease;
        }

        .register-btn:hover {

            transform: translateY(-2px);

            box-shadow:
                0 17px 32px
                rgba(79,70,229,.28);
        }

        .bottom-link {

            margin-top: 23px;

            text-align: center;

            color: #64748b;

            font-size: 12px;
        }

        .bottom-link a {

            color: #4f46e5;

            font-weight: 800;

            text-decoration: none;
        }

        .bottom-link a:hover {
            text-decoration: underline;
        }

        .role-badge {

            display: flex;
            align-items: center;
            justify-content: center;

            margin-bottom: 24px;

            padding: 9px 12px;

            border-radius: 10px;

            color: #4338ca;

            background: #eef2ff;

            font-size: 11px;
            font-weight: 800;
        }

        @media(max-width:520px) {

            body {
                padding: 18px;
            }

            .register-card {
                padding: 28px 22px;
                border-radius: 21px;
            }

            .brand h1 {
                font-size: 24px;
            }
        }

    </style>

</head>

<body>

<div class="register-wrapper">

    <div class="register-card">

        <div class="brand">

            <div class="brand-icon">
                ES
            </div>

            <h1>
                Create Organizer Account
            </h1>

            <p>
                Join EventSphere as an event organizer
            </p>

        </div>


        <div class="role-badge">
            Organizer Account
        </div>


        <?php if (!empty($errors)): ?>

            <div class="alert alert-error">

                <?php foreach ($errors as $error): ?>

                    <div>
                        <?= h($error) ?>
                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($success): ?>

            <div class="alert alert-success">

                <?= h($success) ?>

                <br><br>

                <a href="organizer-login.php">
                    Continue to Organizer Login →
                </a>

            </div>

        <?php endif; ?>


        <?php if (!$success): ?>

        <form
            method="POST"
            autocomplete="off"
        >

            <div class="form-group">

                <label for="email">
                    Organizer Email
                </label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="organizer@example.com"
                    maxlength="150"
                    value="<?= h($_POST["email"] ?? "") ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label for="password">
                    Password
                </label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Create a strong password"
                    minlength="8"
                    required
                >

                <div class="password-help">
                    Minimum 8 characters recommended.
                </div>

            </div>


            <div class="form-group">

                <label for="confirm_password">
                    Confirm Password
                </label>

                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    placeholder="Enter password again"
                    minlength="8"
                    required
                >

            </div>


            <button
                type="submit"
                class="register-btn"
            >
                Create Organizer Account
            </button>

        </form>

        <?php endif; ?>


        <div class="bottom-link">

            Already have an organizer account?

            <a href="organizer-login.php">
                Login here
            </a>

        </div>

    </div>

</div>

</body>

</html>