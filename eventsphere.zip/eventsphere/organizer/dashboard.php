<?php
session_start();

require_once __DIR__ . '/../db.php';

/*
|--------------------------------------------------------------------------
| ORGANIZER AUTHENTICATION
|--------------------------------------------------------------------------
| Your database uses:
| users.role = 'organizer'
| users.account_status = 'active'
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$organizer_id = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| Verify Organizer
|--------------------------------------------------------------------------
*/

$user_stmt = mysqli_prepare(
    $conn,
    "
    SELECT 
        u.user_id,
        u.email,
        u.role,
        u.account_status,
        up.full_name
    FROM users u
    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id
    WHERE u.user_id = ?
      AND u.role = 'organizer'
      AND u.account_status = 'active'
    LIMIT 1
    "
);

mysqli_stmt_bind_param($user_stmt, "i", $organizer_id);
mysqli_stmt_execute($user_stmt);

$user_result = mysqli_stmt_get_result($user_stmt);
$organizer = mysqli_fetch_assoc($user_result);

mysqli_stmt_close($user_stmt);

if (!$organizer) {
    session_unset();
    session_destroy();

    header("Location: ../login.php?error=unauthorized");
    exit;
}

$organizer_name = !empty($organizer['full_name'])
    ? $organizer['full_name']
    : 'Organizer';

$organizer_email = $organizer['email'];


/*
|--------------------------------------------------------------------------
| HELPER FUNCTION
|--------------------------------------------------------------------------
*/

function getCount($conn, $sql, $organizer_id)
{
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        return 0;
    }

    mysqli_stmt_bind_param($stmt, "i", $organizer_id);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_row($result);

    mysqli_stmt_close($stmt);

    return $row ? (int)$row[0] : 0;
}


/*
|--------------------------------------------------------------------------
| EVENT STATISTICS
|--------------------------------------------------------------------------
*/

/* Total Events */
$total_events = getCount(
    $conn,
    "
    SELECT COUNT(*)
    FROM events
    WHERE organizer_id = ?
    ",
    $organizer_id
);


/* Pending Approval */
$pending_events = getCount(
    $conn,
    "
    SELECT COUNT(*)
    FROM events
    WHERE organizer_id = ?
      AND event_status = 'pending_approval'
    ",
    $organizer_id
);


/* Approved / Published Events */
$upcoming_events = getCount(
    $conn,
    "
    SELECT COUNT(*)
    FROM events
    WHERE organizer_id = ?
      AND event_status IN ('approved', 'published')
      AND event_date >= CURDATE()
    ",
    $organizer_id
);


/* Completed Events */
$completed_events = getCount(
    $conn,
    "
    SELECT COUNT(*)
    FROM events
    WHERE organizer_id = ?
      AND event_status = 'completed'
    ",
    $organizer_id
);


/*
|--------------------------------------------------------------------------
| REGISTRATION STATISTICS
|--------------------------------------------------------------------------
*/

$total_registrations = getCount(
    $conn,
    "
    SELECT COUNT(*)
    FROM event_registrations er
    INNER JOIN events e
        ON e.event_id = er.event_id
    WHERE e.organizer_id = ?
      AND er.status != 'cancelled'
    ",
    $organizer_id
);


/* Attended Participants */
$total_attendance = getCount(
    $conn,
    "
    SELECT COUNT(*)
    FROM event_registrations er
    INNER JOIN events e
        ON e.event_id = er.event_id
    WHERE e.organizer_id = ?
      AND er.status = 'attended'
    ",
    $organizer_id
);


/*
|--------------------------------------------------------------------------
| FEEDBACK / RATING
|--------------------------------------------------------------------------
*/

$rating_stmt = mysqli_prepare(
    $conn,
    "
    SELECT 
        COALESCE(AVG(ef.overall_rating), 0) AS average_rating,
        COUNT(ef.feedback_id) AS total_feedback
    FROM event_feedback ef
    INNER JOIN events e
        ON e.event_id = ef.event_id
    WHERE e.organizer_id = ?
      AND ef.status = 'visible'
    "
);

mysqli_stmt_bind_param($rating_stmt, "i", $organizer_id);
mysqli_stmt_execute($rating_stmt);

$rating_result = mysqli_stmt_get_result($rating_stmt);
$rating_data = mysqli_fetch_assoc($rating_result);

mysqli_stmt_close($rating_stmt);

$average_rating = round((float)$rating_data['average_rating'], 1);
$total_feedback = (int)$rating_data['total_feedback'];


/*
|--------------------------------------------------------------------------
| UPCOMING EVENTS
|--------------------------------------------------------------------------
*/

$upcoming_stmt = mysqli_prepare(
    $conn,
    "
    SELECT
        e.event_id,
        e.title,
        e.slug,
        e.event_date,
        e.start_time,
        e.end_time,
        e.event_status,
        e.max_capacity,
        e.featured_image,

        ec.category_name,

        v.venue_name,
        v.building_name,

        COUNT(
            CASE 
                WHEN er.status != 'cancelled'
                THEN er.registration_id
            END
        ) AS registration_count

    FROM events e

    LEFT JOIN event_categories ec
        ON ec.category_id = e.category_id

    LEFT JOIN venues v
        ON v.venue_id = e.venue_id

    LEFT JOIN event_registrations er
        ON er.event_id = e.event_id

    WHERE e.organizer_id = ?
      AND e.event_date >= CURDATE()
      AND e.event_status NOT IN ('cancelled', 'completed')

    GROUP BY
        e.event_id,
        e.title,
        e.slug,
        e.event_date,
        e.start_time,
        e.end_time,
        e.event_status,
        e.max_capacity,
        e.featured_image,
        ec.category_name,
        v.venue_name,
        v.building_name

    ORDER BY e.event_date ASC, e.start_time ASC

    LIMIT 5
    "
);

mysqli_stmt_bind_param($upcoming_stmt, "i", $organizer_id);
mysqli_stmt_execute($upcoming_stmt);

$upcoming_result = mysqli_stmt_get_result($upcoming_stmt);


/*
|--------------------------------------------------------------------------
| RECENT REGISTRATIONS
|--------------------------------------------------------------------------
*/

$registration_stmt = mysqli_prepare(
    $conn,
    "
    SELECT
        er.registration_id,
        er.registration_code,
        er.registered_at,
        er.status,

        e.title AS event_title,

        up.full_name,
        u.email

    FROM event_registrations er

    INNER JOIN events e
        ON e.event_id = er.event_id

    INNER JOIN users u
        ON u.user_id = er.student_id

    LEFT JOIN user_profiles up
        ON up.user_id = u.user_id

    WHERE e.organizer_id = ?

    ORDER BY er.registered_at DESC

    LIMIT 6
    "
);

mysqli_stmt_bind_param($registration_stmt, "i", $organizer_id);
mysqli_stmt_execute($registration_stmt);

$registration_result = mysqli_stmt_get_result($registration_stmt);


/*
|--------------------------------------------------------------------------
| RECENT FEEDBACK
|--------------------------------------------------------------------------
*/

$feedback_stmt = mysqli_prepare(
    $conn,
    "
    SELECT
        ef.feedback_id,
        ef.overall_rating,
        ef.comments,
        ef.submitted_at,
        ef.is_anonymous,

        up.full_name,
        e.title AS event_title

    FROM event_feedback ef

    INNER JOIN events e
        ON e.event_id = ef.event_id

    LEFT JOIN user_profiles up
        ON up.user_id = ef.student_id

    WHERE e.organizer_id = ?
      AND ef.status = 'visible'

    ORDER BY ef.submitted_at DESC

    LIMIT 4
    "
);

mysqli_stmt_bind_param($feedback_stmt, "i", $organizer_id);
mysqli_stmt_execute($feedback_stmt);

$feedback_result = mysqli_stmt_get_result($feedback_stmt);

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Organizer Dashboard | EventSphere</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family:
                Inter,
                -apple-system,
                BlinkMacSystemFont,
                "Segoe UI",
                sans-serif;

            background: #f5f7fb;
            color: #182230;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            font-family: inherit;
        }

        /* =========================================
           LAYOUT
        ========================================= */

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* =========================================
           SIDEBAR
        ========================================= */

        .sidebar {
            width: 260px;
            background: #111827;
            color: #fff;
            padding: 24px 16px;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            overflow-y: auto;
            z-index: 1000;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px 28px;
        }

        .brand-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(
                135deg,
                #6366f1,
                #8b5cf6
            );
            font-weight: 800;
            font-size: 18px;
        }

        .brand-text strong {
            display: block;
            font-size: 18px;
        }

        .brand-text span {
            display: block;
            color: #9ca3af;
            font-size: 11px;
            margin-top: 2px;
        }

        .nav-title {
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: .08em;
            font-size: 10px;
            font-weight: 700;
            padding: 18px 12px 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: 10px;
            color: #cbd5e1;
            font-size: 14px;
            margin-bottom: 4px;
            transition: .2s ease;
        }

        .nav-link:hover {
            background: #1f2937;
            color: #fff;
            transform: translateX(2px);
        }

        .nav-link.active {
            background: #4f46e5;
            color: #fff;
        }

        .nav-icon {
            width: 20px;
            text-align: center;
            font-size: 15px;
        }

        .logout {
            margin-top: 25px;
            border-top: 1px solid #273244;
            padding-top: 18px;
        }

        .logout .nav-link {
            color: #fca5a5;
        }

        /* =========================================
           MAIN
        ========================================= */

        .main {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }

        /* =========================================
           TOPBAR
        ========================================= */

        .topbar {
            height: 76px;
            background: #fff;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .page-title h1 {
            font-size: 21px;
            font-weight: 750;
        }

        .page-title p {
            color: #6b7280;
            font-size: 13px;
            margin-top: 3px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 11px;
        }

        .profile-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(
                135deg,
                #6366f1,
                #8b5cf6
            );
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }

        .profile-info strong {
            display: block;
            font-size: 13px;
        }

        .profile-info span {
            color: #6b7280;
            font-size: 11px;
        }

        /* =========================================
           CONTENT
        ========================================= */

        .content {
            padding: 30px;
        }

        .welcome {
            background:
                linear-gradient(
                    135deg,
                    #111827,
                    #312e81
                );

            color: #fff;
            border-radius: 18px;
            padding: 27px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 24px;
            overflow: hidden;
            position: relative;
        }

        .welcome::after {
            content: "";
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255,255,255,.06);
            position: absolute;
            right: -70px;
            top: -100px;
        }

        .welcome h2 {
            font-size: 25px;
            margin-bottom: 7px;
        }

        .welcome p {
            color: #c7d2fe;
            font-size: 14px;
        }

        .create-btn {
            position: relative;
            z-index: 2;
            background: #fff;
            color: #4338ca;
            padding: 12px 18px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            transition: .2s ease;
            white-space: nowrap;
        }

        .create-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,.18);
        }

        /* =========================================
           STAT CARDS
        ========================================= */

        .stats-grid {
            display: grid;
            grid-template-columns:
                repeat(6, minmax(0, 1fr));

            gap: 15px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: #fff;
            border: 1px solid #e8ebf0;
            border-radius: 15px;
            padding: 19px;
            min-width: 0;
            transition: .2s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(15,23,42,.07);
        }

        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 14px;
        }

        .stat-icon {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #eef2ff;
            color: #4f46e5;
            font-size: 16px;
        }

        .stat-label {
            color: #6b7280;
            font-size: 12px;
            font-weight: 600;
        }

        .stat-value {
            font-size: 25px;
            font-weight: 800;
            line-height: 1;
        }

        .stat-small {
            color: #9ca3af;
            font-size: 11px;
            margin-top: 7px;
        }

        /* =========================================
           GRID
        ========================================= */

        .two-column {
            display: grid;
            grid-template-columns: 1.7fr 1fr;
            gap: 20px;
            margin-bottom: 22px;
        }

        .panel {
            background: #fff;
            border: 1px solid #e8ebf0;
            border-radius: 16px;
            overflow: hidden;
        }

        .panel-header {
            padding: 19px 20px;
            border-bottom: 1px solid #edf0f4;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .panel-header h3 {
            font-size: 15px;
        }

        .view-all {
            color: #4f46e5;
            font-size: 12px;
            font-weight: 700;
        }

        /* =========================================
           EVENT LIST
        ========================================= */

        .event-list {
            padding: 8px 0;
        }

        .event-item {
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            border-bottom: 1px solid #f0f2f5;
        }

        .event-item:last-child {
            border-bottom: 0;
        }

        .event-date {
            width: 48px;
            height: 52px;
            border-radius: 10px;
            background: #eef2ff;
            color: #4338ca;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .event-date strong {
            font-size: 17px;
            line-height: 1;
        }

        .event-date span {
            font-size: 9px;
            text-transform: uppercase;
            margin-top: 3px;
        }

        .event-info {
            flex: 1;
            min-width: 0;
        }

        .event-info h4 {
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .event-info p {
            color: #6b7280;
            font-size: 11px;
            margin-top: 5px;
        }

        .event-meta {
            text-align: right;
            min-width: 85px;
        }

        .registration-count {
            font-size: 12px;
            font-weight: 700;
        }

        .capacity {
            color: #9ca3af;
            font-size: 10px;
            margin-top: 3px;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 8px;
            border-radius: 999px;
            font-size: 9px;
            font-weight: 700;
            text-transform: capitalize;
        }

        .badge-published,
        .badge-approved {
            background: #dcfce7;
            color: #166534;
        }

        .badge-pending_approval {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-completed {
            background: #e0e7ff;
            color: #3730a3;
        }

        /* =========================================
           REGISTRATIONS
        ========================================= */

        .registration-list {
            padding: 8px 0;
        }

        .registration-item {
            padding: 14px 20px;
            display: flex;
            align-items: center;
            gap: 11px;
            border-bottom: 1px solid #f0f2f5;
        }

        .registration-item:last-child {
            border-bottom: 0;
        }

        .student-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #475569;
            font-size: 12px;
            font-weight: 800;
            flex-shrink: 0;
        }

        .student-info {
            flex: 1;
            min-width: 0;
        }

        .student-info strong {
            display: block;
            font-size: 12px;
        }

        .student-info span {
            display: block;
            color: #94a3b8;
            font-size: 10px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-top: 2px;
        }

        .reg-status {
            font-size: 9px;
            font-weight: 700;
            padding: 4px 7px;
            border-radius: 999px;
        }

        .status-confirmed {
            color: #166534;
            background: #dcfce7;
        }

        .status-attended {
            color: #3730a3;
            background: #e0e7ff;
        }

        .status-no_show {
            color: #92400e;
            background: #fef3c7;
        }

        .status-cancelled {
            color: #991b1b;
            background: #fee2e2;
        }

        /* =========================================
           FEEDBACK
        ========================================= */

        .feedback-list {
            padding: 8px 20px 15px;
        }

        .feedback-item {
            padding: 14px 0;
            border-bottom: 1px solid #f0f2f5;
        }

        .feedback-item:last-child {
            border-bottom: 0;
        }

        .feedback-head {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        .feedback-name {
            font-size: 12px;
            font-weight: 700;
        }

        .stars {
            color: #f59e0b;
            font-size: 12px;
            letter-spacing: 1px;
        }

        .feedback-event {
            color: #6b7280;
            font-size: 10px;
            margin-top: 4px;
        }

        .feedback-comment {
            color: #475569;
            font-size: 11px;
            line-height: 1.55;
            margin-top: 7px;
        }

        /* =========================================
           QUICK ACTIONS
        ========================================= */

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            padding: 18px 20px 20px;
        }

        .quick-action {
            border: 1px solid #e8ebf0;
            border-radius: 12px;
            padding: 15px;
            transition: .2s ease;
        }

        .quick-action:hover {
            border-color: #c7d2fe;
            background: #f8faff;
            transform: translateY(-2px);
        }

        .quick-action-icon {
            width: 34px;
            height: 34px;
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #eef2ff;
            color: #4f46e5;
            margin-bottom: 9px;
        }

        .quick-action strong {
            display: block;
            font-size: 12px;
        }

        .quick-action span {
            display: block;
            color: #94a3b8;
            font-size: 10px;
            margin-top: 4px;
        }

        /* =========================================
           EMPTY STATE
        ========================================= */

        .empty {
            text-align: center;
            padding: 35px 20px;
            color: #94a3b8;
        }

        .empty-icon {
            font-size: 28px;
            margin-bottom: 8px;
        }

        .empty p {
            font-size: 12px;
        }

        /* =========================================
           RESPONSIVE
        ========================================= */

        @media (max-width: 1250px) {

            .stats-grid {
                grid-template-columns:
                    repeat(3, 1fr);
            }

        }

        @media (max-width: 1000px) {

            .sidebar {
                width: 220px;
            }

            .main {
                margin-left: 220px;
                width: calc(100% - 220px);
            }

            .two-column {
                grid-template-columns: 1fr;
            }

        }

        @media (max-width: 750px) {

            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
                width: 100%;
            }

            .dashboard {
                display: block;
            }

            .topbar {
                padding: 0 18px;
            }

            .content {
                padding: 18px;
            }

            .stats-grid {
                grid-template-columns:
                    repeat(2, 1fr);
            }

            .quick-actions {
                grid-template-columns:
                    repeat(2, 1fr);
            }

            .welcome {
                align-items: flex-start;
                flex-direction: column;
            }

        }

        @media (max-width: 480px) {

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .profile-info {
                display: none;
            }

            .event-item {
                align-items: flex-start;
            }

            .event-meta {
                display: none;
            }

        }

    </style>

</head>

<body>

<div class="dashboard">

    <!-- =========================================
         SIDEBAR
    ========================================== -->

    <aside class="sidebar">

        <div class="brand">

            <div class="brand-icon">
                ES
            </div>

            <div class="brand-text">
                <strong>EventSphere</strong>
                <span>Organizer Portal</span>
            </div>

        </div>


        <div class="nav-title">
            Main
        </div>

        <a href="dashboard.php"
           class="nav-link active">

            <span class="nav-icon">⌂</span>
            Dashboard

        </a>

        <a href="events.php"
           class="nav-link">

            <span class="nav-icon">◈</span>
            My Events

        </a>

        <a href="create-event.php"
           class="nav-link">

            <span class="nav-icon">＋</span>
            Create Event

        </a>


        <div class="nav-title">
            Event Operations
        </div>

        <a href="registrations.php"
           class="nav-link">

            <span class="nav-icon">♙</span>
            Registrations

        </a>

        <a href="attendance.php"
           class="nav-link">

            <span class="nav-icon">✓</span>
            Attendance

        </a>

        <a href="certificates.php"
           class="nav-link">

            <span class="nav-icon">▣</span>
            Certificates

        </a>


        <div class="nav-title">
            Engagement
        </div>

        <a href="gallery.php"
           class="nav-link">

            <span class="nav-icon">▧</span>
            Gallery

        </a>

        <a href="announcements.php"
           class="nav-link">

            <span class="nav-icon">◉</span>
            Announcements

        </a>

        <a href="feedback.php"
           class="nav-link">

            <span class="nav-icon">★</span>
            Feedback

        </a>


        <div class="logout">

            <a href="../logout.php"
               class="nav-link">

                <span class="nav-icon">↪</span>
                Logout

            </a>

        </div>

    </aside>


    <!-- =========================================
         MAIN
    ========================================== -->

    <main class="main">


        <!-- TOP BAR -->

        <header class="topbar">

            <div class="page-title">

                <h1>Organizer Dashboard</h1>

                <p>
                    Manage your events and participants
                </p>

            </div>


            <div class="profile">

                <div class="profile-avatar">

                    <?php
                    echo strtoupper(
                        substr($organizer_name, 0, 1)
                    );
                    ?>

                </div>

                <div class="profile-info">

                    <strong>
                        <?= htmlspecialchars($organizer_name) ?>
                    </strong>

                    <span>
                        Organizer
                    </span>

                </div>

            </div>

        </header>


        <!-- CONTENT -->

        <section class="content">


            <!-- WELCOME -->

            <div class="welcome">

                <div>

                    <h2>
                        Welcome back,
                        <?= htmlspecialchars($organizer_name) ?>!
                    </h2>

                    <p>
                        Here's what's happening with your events today.
                    </p>

                </div>

                <a href="create-event.php"
                   class="create-btn">

                    + Create New Event

                </a>

            </div>


            <!-- =========================================
                 STATISTICS
            ========================================== -->

            <div class="stats-grid">


                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Total Events
                        </span>

                        <div class="stat-icon">
                            ◈
                        </div>

                    </div>

                    <div class="stat-value">
                        <?= number_format($total_events) ?>
                    </div>

                    <div class="stat-small">
                        Events created by you
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Pending
                        </span>

                        <div class="stat-icon">
                            ◷
                        </div>

                    </div>

                    <div class="stat-value">
                        <?= number_format($pending_events) ?>
                    </div>

                    <div class="stat-small">
                        Awaiting approval
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Upcoming
                        </span>

                        <div class="stat-icon">
                            ◷
                        </div>

                    </div>

                    <div class="stat-value">
                        <?= number_format($upcoming_events) ?>
                    </div>

                    <div class="stat-small">
                        Future events
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Completed
                        </span>

                        <div class="stat-icon">
                            ✓
                        </div>

                    </div>

                    <div class="stat-value">
                        <?= number_format($completed_events) ?>
                    </div>

                    <div class="stat-small">
                        Finished events
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Registrations
                        </span>

                        <div class="stat-icon">
                            ♙
                        </div>

                    </div>

                    <div class="stat-value">
                        <?= number_format($total_registrations) ?>
                    </div>

                    <div class="stat-small">
                        Active registrations
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Rating
                        </span>

                        <div class="stat-icon">
                            ★
                        </div>

                    </div>

                    <div class="stat-value">

                        <?= number_format(
                            $average_rating,
                            1
                        ) ?>

                    </div>

                    <div class="stat-small">
                        <?= number_format($total_feedback) ?>
                        feedback responses
                    </div>

                </div>

            </div>


            <!-- =========================================
                 UPCOMING EVENTS + REGISTRATIONS
            ========================================== -->

            <div class="two-column">


                <!-- UPCOMING EVENTS -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>
                            Upcoming Events
                        </h3>

                        <a href="events.php"
                           class="view-all">

                            View all

                        </a>

                    </div>


                    <div class="event-list">

                        <?php if (mysqli_num_rows($upcoming_result) > 0): ?>

                            <?php while ($event = mysqli_fetch_assoc($upcoming_result)): ?>

                                <div class="event-item">


                                    <div class="event-date">

                                        <strong>
                                            <?= date(
                                                'd',
                                                strtotime(
                                                    $event['event_date']
                                                )
                                            ) ?>
                                        </strong>

                                        <span>
                                            <?= date(
                                                'M',
                                                strtotime(
                                                    $event['event_date']
                                                )
                                            ) ?>
                                        </span>

                                    </div>


                                    <div class="event-info">

                                        <h4>
                                            <?= htmlspecialchars(
                                                $event['title']
                                            ) ?>
                                        </h4>

                                        <p>

                                            <?= htmlspecialchars(
                                                $event['venue_name']
                                                ?? 'Venue not assigned'
                                            ) ?>

                                            <?php if (!empty($event['building_name'])): ?>

                                                ·
                                                <?= htmlspecialchars(
                                                    $event['building_name']
                                                ) ?>

                                            <?php endif; ?>

                                        </p>

                                    </div>


                                    <div class="event-meta">

                                        <span class="badge badge-<?= htmlspecialchars(
                                            $event['event_status']
                                        ) ?>">

                                            <?= str_replace(
                                                '_',
                                                ' ',
                                                htmlspecialchars(
                                                    $event['event_status']
                                                )
                                            ) ?>

                                        </span>

                                        <div class="registration-count">

                                            <?= number_format(
                                                $event['registration_count']
                                            ) ?>

                                            registered

                                        </div>

                                        <div class="capacity">

                                            of
                                            <?= number_format(
                                                $event['max_capacity']
                                            ) ?>

                                        </div>

                                    </div>

                                </div>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <div class="empty">

                                <div class="empty-icon">
                                    ◈
                                </div>

                                <p>
                                    No upcoming events found.
                                </p>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>


                <!-- RECENT REGISTRATIONS -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>
                            Recent Registrations
                        </h3>

                        <a href="registrations.php"
                           class="view-all">

                            View all

                        </a>

                    </div>


                    <div class="registration-list">

                        <?php if (mysqli_num_rows($registration_result) > 0): ?>

                            <?php while (
                                $registration =
                                mysqli_fetch_assoc(
                                    $registration_result
                                )
                            ): ?>

                                <?php

                                $student_name =
                                    !empty(
                                        $registration['full_name']
                                    )
                                    ? $registration['full_name']
                                    : $registration['email'];

                                $initial =
                                    strtoupper(
                                        substr(
                                            $student_name,
                                            0,
                                            1
                                        )
                                    );

                                ?>

                                <div class="registration-item">


                                    <div class="student-avatar">

                                        <?= htmlspecialchars(
                                            $initial
                                        ) ?>

                                    </div>


                                    <div class="student-info">

                                        <strong>
                                            <?= htmlspecialchars(
                                                $student_name
                                            ) ?>
                                        </strong>

                                        <span>

                                            <?= htmlspecialchars(
                                                $registration['event_title']
                                            ) ?>

                                        </span>

                                    </div>


                                    <span class="reg-status status-<?= htmlspecialchars(
                                        $registration['status']
                                    ) ?>">

                                        <?= str_replace(
                                            '_',
                                            ' ',
                                            htmlspecialchars(
                                                $registration['status']
                                            )
                                        ) ?>

                                    </span>

                                </div>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <div class="empty">

                                <div class="empty-icon">
                                    ♙
                                </div>

                                <p>
                                    No registrations yet.
                                </p>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </div>


            <!-- =========================================
                 ATTENDANCE + FEEDBACK
            ========================================== -->

            <div class="two-column">


                <!-- ATTENDANCE SUMMARY -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>
                            Participation Overview
                        </h3>

                        <a href="attendance.php"
                           class="view-all">

                            Attendance

                        </a>

                    </div>


                    <div style="padding:25px 20px;">

                        <div style="
                            display:grid;
                            grid-template-columns:
                                repeat(2,1fr);
                            gap:15px;
                        ">


                            <div style="
                                background:#f8fafc;
                                border-radius:12px;
                                padding:20px;
                            ">

                                <div style="
                                    color:#64748b;
                                    font-size:11px;
                                    margin-bottom:8px;
                                ">
                                    Total Registered
                                </div>

                                <div style="
                                    font-size:28px;
                                    font-weight:800;
                                ">

                                    <?= number_format(
                                        $total_registrations
                                    ) ?>

                                </div>

                            </div>


                            <div style="
                                background:#f8fafc;
                                border-radius:12px;
                                padding:20px;
                            ">

                                <div style="
                                    color:#64748b;
                                    font-size:11px;
                                    margin-bottom:8px;
                                ">
                                    Attended
                                </div>

                                <div style="
                                    font-size:28px;
                                    font-weight:800;
                                ">

                                    <?= number_format(
                                        $total_attendance
                                    ) ?>

                                </div>

                            </div>

                        </div>


                        <?php

                        $attendance_percentage = 0;

                        if ($total_registrations > 0) {

                            $attendance_percentage =
                                round(
                                    (
                                        $total_attendance /
                                        $total_registrations
                                    ) * 100
                                );
                        }

                        ?>


                        <div style="
                            margin-top:20px;
                        ">

                            <div style="
                                display:flex;
                                justify-content:space-between;
                                margin-bottom:7px;
                                font-size:11px;
                                color:#64748b;
                            ">

                                <span>
                                    Attendance Rate
                                </span>

                                <strong>
                                    <?= $attendance_percentage ?>%
                                </strong>

                            </div>


                            <div style="
                                width:100%;
                                height:8px;
                                background:#e5e7eb;
                                border-radius:20px;
                                overflow:hidden;
                            ">

                                <div style="
                                    width:<?= $attendance_percentage ?>%;
                                    height:100%;
                                    background:#4f46e5;
                                    border-radius:20px;
                                "></div>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- FEEDBACK -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>
                            Recent Feedback
                        </h3>

                        <a href="feedback.php"
                           class="view-all">

                            View all

                        </a>

                    </div>


                    <div class="feedback-list">

                        <?php if (mysqli_num_rows($feedback_result) > 0): ?>

                            <?php while (
                                $feedback =
                                mysqli_fetch_assoc(
                                    $feedback_result
                                )
                            ): ?>

                                <div class="feedback-item">

                                    <div class="feedback-head">

                                        <span class="feedback-name">

                                            <?php
                                            if (
                                                (int)$feedback['is_anonymous'] === 1
                                            ) {
                                                echo 'Anonymous Participant';
                                            } else {
                                                echo htmlspecialchars(
                                                    $feedback['full_name']
                                                    ?? 'Participant'
                                                );
                                            }
                                            ?>

                                        </span>


                                        <span class="stars">

                                            <?php

                                            $rating =
                                                (int)$feedback[
                                                    'overall_rating'
                                                ];

                                            echo str_repeat(
                                                '★',
                                                $rating
                                            );

                                            echo str_repeat(
                                                '☆',
                                                5 - $rating
                                            );

                                            ?>

                                        </span>

                                    </div>


                                    <div class="feedback-event">

                                        <?= htmlspecialchars(
                                            $feedback['event_title']
                                        ) ?>

                                    </div>


                                    <?php if (
                                        !empty(
                                            $feedback['comments']
                                        )
                                    ): ?>

                                        <div class="feedback-comment">

                                            <?= htmlspecialchars(
                                                $feedback['comments']
                                            ) ?>

                                        </div>

                                    <?php endif; ?>

                                </div>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <div class="empty">

                                <div class="empty-icon">
                                    ★
                                </div>

                                <p>
                                    No feedback available yet.
                                </p>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </div>


            <!-- =========================================
                 QUICK ACTIONS
            ========================================== -->

            <div class="panel">

                <div class="panel-header">

                    <h3>
                        Quick Actions
                    </h3>

                </div>


                <div class="quick-actions">


                    <a href="create-event.php"
                       class="quick-action">

                        <div class="quick-action-icon">
                            ＋
                        </div>

                        <strong>
                            Create Event
                        </strong>

                        <span>
                            Submit a new event
                        </span>

                    </a>


                    <a href="registrations.php"
                       class="quick-action">

                        <div class="quick-action-icon">
                            ♙
                        </div>

                        <strong>
                            Registrations
                        </strong>

                        <span>
                            Manage participants
                        </span>

                    </a>


                    <a href="attendance.php"
                       class="quick-action">

                        <div class="quick-action-icon">
                            ✓
                        </div>

                        <strong>
                            Attendance
                        </strong>

                        <span>
                            Track event attendance
                        </span>

                    </a>


                    <a href="announcements.php"
                       class="quick-action">

                        <div class="quick-action-icon">
                            ◉
                        </div>

                        <strong>
                            Announcement
                        </strong>

                        <span>
                            Notify participants
                        </span>

                    </a>

                </div>

            </div>


        </section>

    </main>

</div>


<script>

/*
|--------------------------------------------------------------------------
| Small Dashboard Animation
|--------------------------------------------------------------------------
*/

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const cards =
            document.querySelectorAll(
                ".stat-card, .panel"
            );

        cards.forEach(
            function (card, index) {

                card.style.opacity = "0";
                card.style.transform =
                    "translateY(10px)";

                setTimeout(
                    function () {

                        card.style.transition =
                            "opacity .45s ease, transform .45s ease";

                        card.style.opacity = "1";
                        card.style.transform =
                            "translateY(0)";

                    },
                    60 + (index * 45)
                );

            }
        );

    }
);

</script>

</body>
</html>

<?php

/*
|--------------------------------------------------------------------------
| CLOSE STATEMENTS
|--------------------------------------------------------------------------
*/

mysqli_stmt_close($upcoming_stmt);
mysqli_stmt_close($registration_stmt);
mysqli_stmt_close($feedback_stmt);

?>