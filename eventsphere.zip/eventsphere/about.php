<?php

$title = "About EventSphere";

require "header.php";
?>

<style>
.about-page {
    overflow: hidden;
    background: #f8fafc;
}

.about-hero {
    position: relative;
    min-height: 590px;
    display: flex;
    align-items: center;
    overflow: hidden;
    background:
        radial-gradient(circle at 15% 20%, rgba(99,102,241,.28), transparent 32%),
        radial-gradient(circle at 85% 75%, rgba(34,211,238,.18), transparent 30%),
        linear-gradient(135deg, #0f172a 0%, #1e1b4b 55%, #312e81 100%);
    color: #fff;
}

.about-hero::before {
    content: "";
    position: absolute;
    width: 500px;
    height: 500px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 50%;
    right: -170px;
    top: -180px;
    animation: rotateCircle 18s linear infinite;
}

.about-hero::after {
    content: "";
    position: absolute;
    width: 330px;
    height: 330px;
    border: 1px solid rgba(255,255,255,.07);
    border-radius: 50%;
    left: -150px;
    bottom: -160px;
    animation: rotateCircle 14s linear infinite reverse;
}

.about-container {
    position: relative;
    z-index: 2;
}

.about-content {
    max-width: 760px;
    animation: fadeUp .9s ease both;
}

.about-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    border: 1px solid rgba(255,255,255,.15);
    border-radius: 50px;
    background: rgba(255,255,255,.08);
    color: #c7d2fe;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    backdrop-filter: blur(10px);
}

.about-content h1 {
    margin: 22px 0 18px;
    font-size: clamp(42px, 6vw, 76px);
    line-height: .98;
    font-weight: 900;
    letter-spacing: -.055em;
}

.about-gradient {
    background: linear-gradient(90deg, #a5b4fc, #67e8f9);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.about-content p {
    max-width: 650px;
    margin: 0;
    color: #cbd5e1;
    font-size: 16px;
    line-height: 1.8;
}

.about-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 30px;
}

.about-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 50px;
    padding: 0 22px;
    border-radius: 13px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 800;
    transition: .3s ease;
}

.about-btn-primary {
    color: #fff;
    background: linear-gradient(135deg, #6366f1, #4f46e5);
    box-shadow: 0 15px 35px rgba(79,70,229,.3);
}

.about-btn-primary:hover {
    color: #fff;
    transform: translateY(-4px);
    box-shadow: 0 20px 45px rgba(79,70,229,.42);
}

.about-btn-secondary {
    color: #fff;
    border: 1px solid rgba(255,255,255,.16);
    background: rgba(255,255,255,.07);
    backdrop-filter: blur(10px);
}

.about-btn-secondary:hover {
    color: #fff;
    transform: translateY(-4px);
    background: rgba(255,255,255,.13);
}

.about-floating-card {
    position: absolute;
    right: 9%;
    bottom: 75px;
    width: 250px;
    padding: 22px;
    border: 1px solid rgba(255,255,255,.13);
    border-radius: 20px;
    background: rgba(255,255,255,.08);
    backdrop-filter: blur(18px);
    box-shadow: 0 25px 70px rgba(0,0,0,.2);
    animation: floatCard 4s ease-in-out infinite;
}

.about-floating-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 14px;
    border-radius: 14px;
    background: rgba(99,102,241,.22);
    font-size: 22px;
}

.about-floating-card h4 {
    margin: 0 0 6px;
    font-size: 16px;
    font-weight: 850;
}

.about-floating-card p {
    margin: 0;
    color: #cbd5e1;
    font-size: 11px;
    line-height: 1.6;
}

.about-section {
    padding: 100px 0;
}

.about-section-heading {
    max-width: 720px;
    margin: 0 auto 55px;
    text-align: center;
}

.about-eyebrow {
    display: block;
    margin-bottom: 10px;
    color: #6366f1;
    font-size: 11px;
    font-weight: 850;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.about-section-heading h2 {
    margin: 0 0 14px;
    color: #0f172a;
    font-size: clamp(30px, 4vw, 46px);
    font-weight: 900;
    letter-spacing: -.045em;
}

.about-section-heading p {
    margin: 0;
    color: #64748b;
    font-size: 14px;
    line-height: 1.8;
}

.about-story {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 55px;
    align-items: center;
}

.about-story-visual {
    position: relative;
    min-height: 420px;
    border-radius: 30px;
    overflow: hidden;
    background:
        radial-gradient(circle at 70% 20%, rgba(129,140,248,.35), transparent 28%),
        linear-gradient(145deg, #111827, #312e81);
    box-shadow: 0 25px 70px rgba(15,23,42,.12);
}

.about-orbit {
    position: absolute;
    width: 310px;
    height: 310px;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    border: 1px solid rgba(255,255,255,.15);
    border-radius: 50%;
    animation: rotateCircle 16s linear infinite;
}

.about-orbit::before,
.about-orbit::after {
    content: "";
    position: absolute;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #818cf8;
    box-shadow: 0 0 25px rgba(129,140,248,.9);
}

.about-orbit::before {
    top: 18px;
    left: 50%;
}

.about-orbit::after {
    bottom: 20px;
    right: 18px;
}

.about-center {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 135px;
    height: 135px;
    transform: translate(-50%, -50%);
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 35px;
    color: #fff;
    background: rgba(255,255,255,.09);
    border: 1px solid rgba(255,255,255,.14);
    backdrop-filter: blur(15px);
    font-size: 20px;
    font-weight: 900;
    letter-spacing: -.03em;
}

.about-story-text h3 {
    margin: 0 0 18px;
    color: #0f172a;
    font-size: 32px;
    font-weight: 900;
    letter-spacing: -.04em;
}

.about-story-text p {
    margin: 0 0 17px;
    color: #64748b;
    font-size: 14px;
    line-height: 1.9;
}

.about-features {
    background: #fff;
}

.about-feature-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.about-feature {
    position: relative;
    padding: 28px;
    border: 1px solid #e8edf3;
    border-radius: 22px;
    background: #fff;
    box-shadow: 0 10px 35px rgba(15,23,42,.035);
    transition: .35s ease;
    overflow: hidden;
}

.about-feature::before {
    content: "";
    position: absolute;
    width: 100px;
    height: 100px;
    right: -50px;
    top: -50px;
    border-radius: 50%;
    background: rgba(99,102,241,.07);
    transition: .35s ease;
}

.about-feature:hover {
    transform: translateY(-8px);
    border-color: #c7d2fe;
    box-shadow: 0 22px 50px rgba(15,23,42,.09);
}

.about-feature:hover::before {
    transform: scale(2);
}

.about-feature-icon {
    width: 54px;
    height: 54px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 20px;
    border-radius: 16px;
    color: #4f46e5;
    background: #eef2ff;
    font-size: 22px;
    transition: .35s ease;
}

.about-feature:hover .about-feature-icon {
    transform: rotate(-6deg) scale(1.08);
    background: #4f46e5;
    color: #fff;
}

.about-feature h3 {
    margin: 0 0 10px;
    color: #172033;
    font-size: 17px;
    font-weight: 850;
}

.about-feature p {
    margin: 0;
    color: #64748b;
    font-size: 12px;
    line-height: 1.8;
}

.about-categories {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
}

.about-category {
    position: relative;
    padding: 25px;
    min-height: 150px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    overflow: hidden;
    border-radius: 20px;
    color: #fff;
    background: linear-gradient(135deg, #1e293b, #312e81);
    transition: .35s ease;
}

.about-category:nth-child(2) {
    background: linear-gradient(135deg, #172554, #1d4ed8);
}

.about-category:nth-child(3) {
    background: linear-gradient(135deg, #164e63, #0e7490);
}

.about-category:nth-child(4) {
    background: linear-gradient(135deg, #422006, #b45309);
}

.about-category:nth-child(5) {
    background: linear-gradient(135deg, #3b0764, #7e22ce);
}

.about-category:nth-child(6) {
    background: linear-gradient(135deg, #134e4a, #0f766e);
}

.about-category:hover {
    transform: translateY(-7px) scale(1.015);
}

.about-category-icon {
    position: absolute;
    top: 22px;
    right: 22px;
    font-size: 29px;
    opacity: .7;
}

.about-category h3 {
    margin: 0 0 5px;
    font-size: 17px;
    font-weight: 850;
}

.about-category p {
    margin: 0;
    color: rgba(255,255,255,.72);
    font-size: 11px;
}

.about-cta {
    position: relative;
    padding: 75px 30px;
    overflow: hidden;
    border-radius: 30px;
    text-align: center;
    color: #fff;
    background:
        radial-gradient(circle at 20% 50%, rgba(99,102,241,.35), transparent 28%),
        radial-gradient(circle at 80% 50%, rgba(34,211,238,.2), transparent 28%),
        linear-gradient(135deg, #0f172a, #1e1b4b);
}

.about-cta h2 {
    margin: 0 0 14px;
    font-size: clamp(30px, 4vw, 46px);
    font-weight: 900;
    letter-spacing: -.045em;
}

.about-cta p {
    max-width: 600px;
    margin: 0 auto;
    color: #cbd5e1;
    font-size: 14px;
    line-height: 1.8;
}

.about-cta .about-buttons {
    justify-content: center;
}

@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes floatCard {
    0%, 100% {
        transform: translateY(0);
    }

    50% {
        transform: translateY(-14px);
    }
}

@keyframes rotateCircle {
    from {
        transform: rotate(0deg);
    }

    to {
        transform: rotate(360deg);
    }
}

@media (max-width: 991px) {

    .about-floating-card {
        display: none;
    }

    .about-story {
        grid-template-columns: 1fr;
    }

    .about-feature-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .about-categories {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 767px) {

    .about-hero {
        min-height: 570px;
    }

    .about-content h1 {
        font-size: 46px;
    }

    .about-content p {
        font-size: 14px;
    }

    .about-section {
        padding: 70px 0;
    }

    .about-story-visual {
        min-height: 330px;
    }

    .about-orbit {
        width: 230px;
        height: 230px;
    }

    .about-center {
        width: 105px;
        height: 105px;
        font-size: 16px;
    }

    .about-feature-grid,
    .about-categories {
        grid-template-columns: 1fr;
    }

    .about-feature {
        padding: 23px;
    }

    .about-cta {
        padding: 55px 20px;
        border-radius: 23px;
    }
}
</style>

<main class="about-page">

    <section class="about-hero">

        <div class="container about-container">

            <div class="about-content">

                <span class="about-badge">
                    ✦ College Event Experience
                </span>

                <h1>
                    Discover.
                    <span class="about-gradient">Connect.</span>
                    Experience.
                </h1>

                <p>
                    EventSphere is a student-focused college event platform
                    designed to make discovering, registering, and participating
                    in campus events simple, organized, and engaging.
                </p>

                <div class="about-buttons">

                    <a href="events.php" class="about-btn about-btn-primary">
                        Explore Events
                    </a>

                    <a href="gallery.php" class="about-btn about-btn-secondary">
                        View Gallery
                    </a>

                </div>

            </div>

        </div>

        <div class="about-floating-card">

            <div class="about-floating-icon">
                ✦
            </div>

            <h4>
                One Place for Campus Events
            </h4>

            <p>
                Discover events, manage registrations, explore media,
                share experiences, and stay connected with campus activities.
            </p>

        </div>

    </section>


    <section class="about-section">

        <div class="container">

            <div class="about-story">

                <div class="about-story-visual">

                    <div class="about-orbit"></div>

                    <div class="about-center">
                        EventSphere
                    </div>

                </div>

                <div class="about-story-text">

                    <span class="about-eyebrow">
                        About The Platform
                    </span>

                    <h3>
                        Built around the student event experience.
                    </h3>

                    <p>
                        College life is filled with activities, competitions,
                        workshops, cultural programs, sports events, and
                        celebrations. EventSphere brings these experiences
                        together in one organized digital platform.
                    </p>

                    <p>
                        Students can discover upcoming events, check event
                        details, register for available activities, manage their
                        participation, and explore memories through the media
                        gallery.
                    </p>

                    <p>
                        The platform is designed to provide a clear and
                        user-friendly experience while keeping event information
                        easy to find and manage.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <section class="about-section about-features">

        <div class="container">

            <div class="about-section-heading">

                <span class="about-eyebrow">
                    What EventSphere Offers
                </span>

                <h2>
                    Everything students need for campus events.
                </h2>

                <p>
                    From discovering an event to sharing your experience,
                    EventSphere keeps the complete student journey organized.
                </p>

            </div>

            <div class="about-feature-grid">

                <div class="about-feature">

                    <div class="about-feature-icon">
                        ◉
                    </div>

                    <h3>
                        Event Discovery
                    </h3>

                    <p>
                        Find upcoming college events and explore important
                        information including dates, categories, venues,
                        and event details.
                    </p>

                </div>

                <div class="about-feature">

                    <div class="about-feature-icon">
                        ✓
                    </div>

                    <h3>
                        Easy Registration
                    </h3>

                    <p>
                        Register for upcoming events and manage your
                        registrations from your personal student dashboard.
                    </p>

                </div>

                <div class="about-feature">

                    <div class="about-feature-icon">
                        ◷
                    </div>

                    <h3>
                        Live Availability
                    </h3>

                    <p>
                        View available event slots and receive updated
                        availability as registrations and cancellations occur.
                    </p>

                </div>

                <div class="about-feature">

                    <div class="about-feature-icon">
                        ▣
                    </div>

                    <h3>
                        Event Gallery
                    </h3>

                    <p>
                        Explore photographs and videos from college events
                        and revisit memorable campus experiences.
                    </p>

                </div>

                <div class="about-feature">

                    <div class="about-feature-icon">
                        ★
                    </div>

                    <h3>
                        Reviews & Feedback
                    </h3>

                    <p>
                        Share your event experience through ratings,
                        comments, suggestions, and component-based feedback.
                    </p>

                </div>

                <div class="about-feature">

                    <div class="about-feature-icon">
                        ♡
                    </div>

                    <h3>
                        Student Dashboard
                    </h3>

                    <p>
                        Keep registrations, activity, notifications,
                        saved media, certificates, and profile information
                        accessible in one place.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <section class="about-section">

        <div class="container">

            <div class="about-section-heading">

                <span class="about-eyebrow">
                    Campus Experiences
                </span>

                <h2>
                    Explore different types of events.
                </h2>

                <p>
                    EventSphere supports a wide range of activities that
                    contribute to an active and engaging campus environment.
                </p>

            </div>

            <div class="about-categories">

                <div class="about-category">

                    <span class="about-category-icon">♪</span>

                    <h3>
                        Cultural Events
                    </h3>

                    <p>
                        Performances, celebrations and cultural activities.
                    </p>

                </div>

                <div class="about-category">

                    <span class="about-category-icon">⌘</span>

                    <h3>
                        Technical Fests
                    </h3>

                    <p>
                        Programming, technology and innovation activities.
                    </p>

                </div>

                <div class="about-category">

                    <span class="about-category-icon">◈</span>

                    <h3>
                        Sports Meets
                    </h3>

                    <p>
                        Competitions and sporting activities.
                    </p>

                </div>

                <div class="about-category">

                    <span class="about-category-icon">✦</span>

                    <h3>
                        Annual Day
                    </h3>

                    <p>
                        Major celebrations and college functions.
                    </p>

                </div>

                <div class="about-category">

                    <span class="about-category-icon">◇</span>

                    <h3>
                        Workshops & Seminars
                    </h3>

                    <p>
                        Learning sessions and knowledge-sharing activities.
                    </p>

                </div>

                <div class="about-category">

                    <span class="about-category-icon">🏆</span>

                    <h3>
                        Competitions
                    </h3>

                    <p>
                        Intercollegiate and campus-level competitions.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <section class="about-section">

        <div class="container">

            <div class="about-cta">

                <h2>
                    Ready to explore EventSphere?
                </h2>

                <p>
                    Discover what's happening on campus, find events that
                    interest you, and become part of the experience.
                </p>

                <div class="about-buttons">

                    <a href="events.php" class="about-btn about-btn-primary">
                        Browse Events
                    </a>

                    <a href="register.php" class="about-btn about-btn-secondary">
                        Create Account
                    </a>

                </div>

            </div>

        </div>

    </section>

</main>

<?php require "footer.php"; ?>