<?php

require "db.php";
require_once "functions.php";

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$title = "Create Account | EventSphere";

$full_name = "";
$enrollment_no = "";
$email = "";
$department_id = "";
$errors = [];
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $full_name = trim($_POST["full_name"] ?? "");
    $enrollment_no = trim($_POST["enrollment_no"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $department_id = (int)($_POST["department_id"] ?? 0);
    $password = $_POST["password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";

    if ($full_name === "" || strlen($full_name) < 3) {
        $errors[] = "Please enter your full name.";
    }

    if ($enrollment_no === "") {
        $errors[] = "Please enter your enrollment number.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if ($department_id <= 0) {
        $errors[] = "Please select your department.";
    }

    if (strlen($password) < 8) {
        $errors[] = "Password must contain at least 8 characters.";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($errors)) {
        $department_check = q(
            $conn,
            "SELECT department_id
             FROM departments
             WHERE department_id = ?
             AND status = 'active'
             LIMIT 1",
            "i",
            $department_id
        );

        if (!$department_check || mysqli_num_rows($department_check) === 0) {
            $errors[] = "Selected department is not available.";
        }
    }

    if (empty($errors)) {
        $email_check = q(
            $conn,
            "SELECT user_id
             FROM users
             WHERE email = ?
             LIMIT 1",
            "s",
            $email
        );

        if ($email_check && mysqli_num_rows($email_check) > 0) {
            $errors[] = "An account with this email already exists.";
        }
    }

    if (empty($errors)) {
        $enrollment_check = q(
            $conn,
            "SELECT user_id
             FROM user_profiles
             WHERE enrollment_no = ?
             LIMIT 1",
            "s",
            $enrollment_no
        );

        if ($enrollment_check && mysqli_num_rows($enrollment_check) > 0) {
            $errors[] = "This enrollment number is already registered.";
        }
    }

    if (empty($errors)) {

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        mysqli_begin_transaction($conn);

        try {

            $user_query = mysqli_prepare(
                $conn,
                "INSERT INTO users
                (
                    email,
                    password_hash,
                    role,
                    account_status,
                    email_verified
                )
                VALUES
                (
                    ?,
                    ?,
                    'student',
                    'active',
                    1
                )"
            );

            if (!$user_query) {
                throw new Exception("Unable to create account.");
            }

            mysqli_stmt_bind_param(
                $user_query,
                "ss",
                $email,
                $password_hash
            );

            if (!mysqli_stmt_execute($user_query)) {
                throw new Exception("Unable to create account.");
            }

            $user_id = mysqli_insert_id($conn);

            mysqli_stmt_close($user_query);

            $profile_query = mysqli_prepare(
                $conn,
                "INSERT INTO user_profiles
                (
                    user_id,
                    full_name,
                    enrollment_no,
                    department_id
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?
                )"
            );

            if (!$profile_query) {
                throw new Exception("Unable to save profile.");
            }

            mysqli_stmt_bind_param(
                $profile_query,
                "issi",
                $user_id,
                $full_name,
                $enrollment_no,
                $department_id
            );

            if (!mysqli_stmt_execute($profile_query)) {
                throw new Exception("Unable to save profile.");
            }

            mysqli_stmt_close($profile_query);

            mysqli_commit($conn);

            header("Location: login.php?registered=1");
            exit;

        } catch (Throwable $error) {

            mysqli_rollback($conn);

            $errors[] = "Registration could not be completed. Please try again.";
        }
    }
}

$departments = q(
    $conn,
    "SELECT department_id, department_name
     FROM departments
     WHERE status = 'active'
     ORDER BY department_name ASC"
);

require "header.php";
?>

<style>
.register-page {
    min-height: calc(100vh - 150px);
    display: flex;
    align-items: center;
    padding: 55px 0;
}

.register-wrapper {
    position: relative;
    overflow: hidden;
    border: 1px solid #e5e7eb;
    border-radius: 28px;
    background: #fff;
    box-shadow: 0 25px 70px rgba(15,23,42,.10);
}

.register-info {
    position: relative;
    min-height: 650px;
    padding: 55px 45px;
    color: #fff;
    overflow: hidden;
    background:
        radial-gradient(circle at 85% 15%, rgba(129,140,248,.28), transparent 30%),
        radial-gradient(circle at 10% 85%, rgba(34,211,238,.15), transparent 30%),
        linear-gradient(145deg,#070b16,#111827 55%,#1e1b4b);
}

.register-info::after {
    content: "";
    position: absolute;
    width: 240px;
    height: 240px;
    right: -100px;
    bottom: -100px;
    border: 1px solid rgba(255,255,255,.10);
    border-radius: 50%;
}

.info-content {
    position: relative;
    z-index: 2;
}

.register-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 13px;
    border: 1px solid rgba(255,255,255,.13);
    border-radius: 999px;
    background: rgba(255,255,255,.06);
    color: #c7d2fe;
    font-size: .72rem;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.register-label::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #34d399;
    box-shadow: 0 0 14px #34d399;
}

.register-heading {
    margin-top: 25px;
    font-size: clamp(2.4rem,4vw,4rem);
    line-height: 1;
    font-weight: 850;
    letter-spacing: -.055em;
}

.register-heading span {
    background: linear-gradient(100deg,#a5b4fc,#67e8f9);
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

.register-description {
    max-width: 470px;
    margin-top: 20px;
    color: #cbd5e1;
    line-height: 1.75;
}

.register-benefits {
    display: grid;
    gap: 13px;
    margin-top: 35px;
}

.register-benefit {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 14px;
    border: 1px solid rgba(255,255,255,.09);
    border-radius: 14px;
    background: rgba(255,255,255,.045);
    transition: .3s ease;
}

.register-benefit:hover {
    transform: translateX(6px);
    background: rgba(255,255,255,.08);
}

.benefit-icon {
    display: grid;
    place-items: center;
    flex: 0 0 38px;
    width: 38px;
    height: 38px;
    border-radius: 11px;
    background: rgba(99,102,241,.18);
    color: #a5b4fc;
    font-size: .75rem;
    font-weight: 800;
}

.register-benefit strong {
    display: block;
    font-size: .9rem;
}

.register-benefit small {
    color: #94a3b8;
}

.register-form-area {
    position: relative;
    z-index: 2;
    padding: 55px 45px;
}

.form-heading {
    margin-bottom: 30px;
}

.form-heading h2 {
    margin: 0;
    color: #111827;
    font-size: 2rem;
    font-weight: 850;
    letter-spacing: -.04em;
}

.form-heading p {
    margin: 8px 0 0;
    color: #64748b;
    font-size: .9rem;
}

.form-label-modern {
    display: block;
    margin-bottom: 7px;
    color: #334155;
    font-size: .78rem;
    font-weight: 750;
}

.form-group {
    margin-bottom: 18px;
}

.input-modern,
.select-modern {
    width: 100%;
    min-height: 48px;
    padding: 11px 14px;
    border: 1px solid #dbe1ea;
    border-radius: 12px;
    outline: none;
    background: #f8fafc;
    color: #111827;
    font-size: .9rem;
    transition: .25s ease;
}

.input-modern:focus,
.select-modern:focus {
    border-color: #6366f1;
    background: #fff;
    box-shadow: 0 0 0 4px rgba(99,102,241,.10);
}

.password-note {
    margin-top: 6px;
    color: #94a3b8;
    font-size: .72rem;
}

.register-button {
    width: 100%;
    min-height: 51px;
    border: 0;
    border-radius: 13px;
    color: #fff;
    background: linear-gradient(135deg,#6366f1,#4f46e5);
    font-weight: 750;
    box-shadow: 0 12px 30px rgba(79,70,229,.22);
    transition: .3s ease;
}

.register-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 18px 40px rgba(79,70,229,.32);
}

.form-errors {
    margin-bottom: 22px;
    padding: 14px 17px;
    border: 1px solid #fecaca;
    border-radius: 13px;
    background: #fef2f2;
    color: #b91c1c;
    font-size: .82rem;
}

.form-errors div {
    margin-bottom: 5px;
}

.form-errors div:last-child {
    margin-bottom: 0;
}

.login-note {
    margin-top: 22px;
    text-align: center;
    color: #64748b;
    font-size: .85rem;
}

.login-note a {
    color: #4f46e5;
    font-weight: 750;
    text-decoration: none;
}

.login-note a:hover {
    color: #3730a3;
}

@media (max-width: 991px) {
    .register-info {
        min-height: auto;
        padding: 40px 30px;
    }

    .register-form-area {
        padding: 40px 30px;
    }

    .register-benefits {
        grid-template-columns: repeat(3,1fr);
    }
}

@media (max-width: 767px) {
    .register-page {
        padding: 25px 0;
    }

    .register-wrapper {
        border-radius: 20px;
    }

    .register-info,
    .register-form-area {
        padding: 35px 24px;
    }

    .register-heading {
        font-size: 2.6rem;
    }

    .register-benefits {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="register-page">
    <div class="container">

        <div class="register-wrapper">

            <div class="row g-0">

                <div class="col-lg-6">

                    <section class="register-info">

                        <div class="info-content">

                            <div class="register-label">
                                Student Registration
                            </div>

                            <h1 class="register-heading">
                                Start your
                                <span>campus journey.</span>
                            </h1>

                            <p class="register-description">
                                Create your EventSphere student account
                                and keep your college events, registrations
                                and participation history together.
                            </p>

                            <div class="register-benefits">

                                <div class="register-benefit">
                                    <div class="benefit-icon">01</div>
                                    <div>
                                        <strong>Discover Events</strong>
                                        <small>Explore activities across campus.</small>
                                    </div>
                                </div>

                                <div class="register-benefit">
                                    <div class="benefit-icon">02</div>
                                    <div>
                                        <strong>Register Easily</strong>
                                        <small>Reserve your place in upcoming events.</small>
                                    </div>
                                </div>

                                <div class="register-benefit">
                                    <div class="benefit-icon">03</div>
                                    <div>
                                        <strong>Track Participation</strong>
                                        <small>Keep your event history organized.</small>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </section>

                </div>

                <div class="col-lg-6">

                    <section class="register-form-area">

                        <div class="form-heading">
                            <h2>Create your account</h2>
                            <p>Enter your details to get started.</p>
                        </div>

                        <?php if (!empty($errors)): ?>

                            <div class="form-errors">
                                <?php foreach ($errors as $error): ?>
                                    <div><?= e($error) ?></div>
                                <?php endforeach; ?>
                            </div>

                        <?php endif; ?>

                        <form method="post" autocomplete="off">

                            <div class="form-group">
                                <label class="form-label-modern">
                                    Full Name
                                </label>

                                <input
                                    type="text"
                                    name="full_name"
                                    class="input-modern"
                                    value="<?= e($full_name) ?>"
                                    placeholder="Enter your full name"
                                    minlength="3"
                                    maxlength="100"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label class="form-label-modern">
                                    Enrollment Number
                                </label>

                                <input
                                    type="text"
                                    name="enrollment_no"
                                    class="input-modern"
                                    value="<?= e($enrollment_no) ?>"
                                    placeholder="Enter enrollment number"
                                    maxlength="50"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label class="form-label-modern">
                                    Email Address
                                </label>

                                <input
                                    type="email"
                                    name="email"
                                    class="input-modern"
                                    value="<?= e($email) ?>"
                                    placeholder="you@example.com"
                                    maxlength="150"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label class="form-label-modern">
                                    Department
                                </label>

                                <select
                                    name="department_id"
                                    class="select-modern"
                                    required
                                >
                                    <option value="">
                                        Select your department
                                    </option>

                                    <?php while ($department = mysqli_fetch_assoc($departments)): ?>

                                        <option
                                            value="<?= (int)$department["department_id"] ?>"
                                            <?= $department_id === (int)$department["department_id"] ? "selected" : "" ?>
                                        >
                                            <?= e($department["department_name"]) ?>
                                        </option>

                                    <?php endwhile; ?>

                                </select>
                            </div>

                            <div class="row">

                                <div class="col-md-6">

                                    <div class="form-group">

                                        <label class="form-label-modern">
                                            Password
                                        </label>

                                        <input
                                            type="password"
                                            name="password"
                                            class="input-modern"
                                            placeholder="Create password"
                                            minlength="8"
                                            required
                                        >

                                        <div class="password-note">
                                            Minimum 8 characters
                                        </div>

                                    </div>

                                </div>

                                <div class="col-md-6">

                                    <div class="form-group">

                                        <label class="form-label-modern">
                                            Confirm Password
                                        </label>

                                        <input
                                            type="password"
                                            name="confirm_password"
                                            class="input-modern"
                                            placeholder="Repeat password"
                                            minlength="8"
                                            required
                                        >

                                    </div>

                                </div>

                            </div>

                            <button
                                type="submit"
                                class="register-button"
                            >
                                Create Student Account
                            </button>

                        </form>

                        <div class="login-note">
                            Already have an account?
                            <a href="login.php">
                                Sign in here
                            </a>
                        </div>

                    </section>

                </div>

            </div>

        </div>

    </div>
</div>

<?php require "footer.php"; ?>