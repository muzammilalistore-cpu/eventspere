<?php

require "db.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user"]["user_id"])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION["user"];
$userId = (int) $user["user_id"];

/*
|--------------------------------------------------------------------------
| Student Only
|--------------------------------------------------------------------------
*/

if (($user["role"] ?? "") !== "student") {
    header("Location: index.php");
    exit;
}

$title = "My Certificates";

/*
|--------------------------------------------------------------------------
| Safe Output
|--------------------------------------------------------------------------
*/

function h($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        "UTF-8"
    );
}

/*
|--------------------------------------------------------------------------
| Fetch Student Certificates
|--------------------------------------------------------------------------
|
| A certificate is displayed only when:
|
| 1. It belongs to the logged-in student
| 2. Its registration belongs to the same student
| 3. The registration belongs to the same event
| 4. Attendance exists with status = present
|
|--------------------------------------------------------------------------
*/

$certificates = [];

$sql = "
    SELECT
        c.certificate_id,
        c.event_id,
        c.student_id,
        c.registration_id,
        c.certificate_number,
        c.certificate_type,
        c.certificate_url,
        c.issued_at,

        e.title AS event_title,
        e.event_date,
        e.start_time,

        er.registration_code,
        er.status AS registration_status,

        a.attendance_status,
        a.marked_at

    FROM certificates c

    INNER JOIN events e
        ON e.event_id = c.event_id

    INNER JOIN event_registrations er
        ON er.registration_id = c.registration_id
        AND er.event_id = c.event_id
        AND er.student_id = c.student_id

    INNER JOIN attendance a
        ON a.event_id = c.event_id
        AND a.student_id = c.student_id
        AND a.registration_id = c.registration_id
        AND a.attendance_status = 'present'

    WHERE c.student_id = ?

    ORDER BY c.issued_at DESC
";

$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $userId
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
        $certificates[] = $row;
    }

    mysqli_stmt_close($stmt);
}

/*
|--------------------------------------------------------------------------
| Certificate Statistics
|--------------------------------------------------------------------------
*/

$certificateCount = count($certificates);

require "header.php";

?>

<style>

/* =========================================================
   CERTIFICATE PAGE
========================================================= */

.certificate-page {
    padding: 45px 0 85px;
}

/* =========================================================
   HERO
========================================================= */

.certificate-hero {
    position: relative;
    overflow: hidden;
    padding: 42px;
    margin-bottom: 30px;
    border-radius: 26px;

    background:
        radial-gradient(
            circle at 85% 15%,
            rgba(99,102,241,.28),
            transparent 30%
        ),
        radial-gradient(
            circle at 10% 90%,
            rgba(34,211,238,.16),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #0f172a,
            #1e1b4b
        );

    color: #fff;

    box-shadow:
        0 25px 60px rgba(15,23,42,.16);
}

.certificate-hero::after {
    content: "";
    position: absolute;
    width: 260px;
    height: 260px;
    right: -90px;
    top: -100px;

    border: 1px solid rgba(255,255,255,.10);
    border-radius: 50%;

    box-shadow:
        0 0 0 35px rgba(255,255,255,.025),
        0 0 0 70px rgba(255,255,255,.018);
}

.certificate-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 8px 13px;

    border: 1px solid rgba(255,255,255,.13);
    border-radius: 999px;

    background: rgba(255,255,255,.06);

    color: #c7d2fe;

    font-size: .72rem;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.certificate-label::before {
    content: "";

    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #34d399;

    box-shadow:
        0 0 15px rgba(52,211,153,.8);
}

.certificate-hero h1 {
    position: relative;
    z-index: 2;

    margin: 18px 0 10px;

    font-size: clamp(2rem, 4vw, 3.3rem);
    line-height: 1;
    letter-spacing: -.05em;
    font-weight: 850;
}

.certificate-hero p {
    position: relative;
    z-index: 2;

    max-width: 650px;

    margin: 0;

    color: #cbd5e1;

    line-height: 1.7;
}

/* =========================================================
   SUMMARY
========================================================= */

.certificate-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 20px;

    padding: 20px 23px;

    margin-bottom: 22px;

    background: #fff;

    border: 1px solid #e9edf3;
    border-radius: 18px;

    box-shadow:
        0 8px 30px rgba(15,23,42,.045);
}

.summary-left {
    display: flex;
    align-items: center;
    gap: 14px;
}

.summary-icon {
    width: 45px;
    height: 45px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background: #eef2ff;

    color: #4f46e5;

    font-size: 19px;
}

.summary-left strong {
    display: block;

    color: #111827;

    font-size: .95rem;
}

.summary-left span {
    color: #94a3b8;

    font-size: .75rem;
}

.summary-count {
    min-width: 48px;
    height: 35px;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 0 12px;

    border-radius: 999px;

    background: #eef2ff;

    color: #4338ca;

    font-size: .8rem;
    font-weight: 850;
}

/* =========================================================
   CERTIFICATE GRID
========================================================= */

.certificate-grid {
    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(320px, 1fr)
        );

    gap: 22px;
}

/* =========================================================
   CERTIFICATE CARD
========================================================= */

.certificate-card {
    position: relative;

    overflow: hidden;

    background: #fff;

    border: 1px solid #e8ecf2;

    border-radius: 22px;

    box-shadow:
        0 10px 35px rgba(15,23,42,.055);

    transition:
        transform .3s ease,
        box-shadow .3s ease,
        border-color .3s ease;
}

.certificate-card:hover {
    transform: translateY(-6px);

    border-color: #c7d2fe;

    box-shadow:
        0 22px 55px rgba(15,23,42,.10);
}

/* =========================================================
   CARD TOP
========================================================= */

.certificate-card-top {
    position: relative;

    padding: 26px;

    background:
        linear-gradient(
            135deg,
            #f8fafc,
            #eef2ff
        );
}

.certificate-card-top::after {
    content: "";

    position: absolute;

    width: 130px;
    height: 130px;

    right: -55px;
    top: -55px;

    border-radius: 50%;

    border: 1px solid #dbeafe;
}

.certificate-mark {
    width: 52px;
    height: 52px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 18px;

    border-radius: 15px;

    background: #fff;

    color: #4f46e5;

    font-size: 23px;

    box-shadow:
        0 8px 20px rgba(79,70,229,.10);
}

.certificate-card h2 {
    margin: 0 0 7px;

    color: #111827;

    font-size: 1.18rem;
    font-weight: 800;

    line-height: 1.4;
}

.certificate-event-date {
    color: #64748b;

    font-size: .76rem;
}

/* =========================================================
   CARD BODY
========================================================= */

.certificate-card-body {
    padding: 22px 26px 25px;
}

.certificate-meta {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 13px;

    margin-bottom: 22px;
}

.meta-item {
    padding: 12px;

    border: 1px solid #edf0f4;

    border-radius: 12px;

    background: #fafbfc;
}

.meta-item span {
    display: block;

    margin-bottom: 4px;

    color: #94a3b8;

    font-size: .67rem;

    font-weight: 700;

    text-transform: uppercase;
    letter-spacing: .04em;
}

.meta-item strong {
    display: block;

    color: #1e293b;

    font-size: .78rem;

    word-break: break-word;
}

/* =========================================================
   VERIFIED
========================================================= */

.verified {
    display: flex;
    align-items: center;
    gap: 7px;

    margin-bottom: 18px;

    color: #15803d;

    font-size: .72rem;
    font-weight: 800;
}

.verified-dot {
    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #22c55e;

    box-shadow:
        0 0 10px rgba(34,197,94,.5);
}

/* =========================================================
   BUTTON
========================================================= */

.certificate-button {
    width: 100%;
    min-height: 46px;

    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            #6366f1,
            #4f46e5
        );

    color: #fff;

    text-decoration: none;

    font-size: .8rem;
    font-weight: 800;

    box-shadow:
        0 10px 25px rgba(79,70,229,.20);

    transition: .25s ease;
}

.certificate-button:hover {
    color: #fff;

    transform: translateY(-2px);

    box-shadow:
        0 15px 32px rgba(79,70,229,.30);
}

/* =========================================================
   EMPTY STATE
========================================================= */

.certificate-empty {
    padding: 65px 25px;

    text-align: center;

    background: #fff;

    border: 1px solid #e8ecf2;

    border-radius: 22px;

    box-shadow:
        0 10px 35px rgba(15,23,42,.045);
}

.empty-icon {
    width: 65px;
    height: 65px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin: 0 auto 18px;

    border-radius: 18px;

    background: #f1f5f9;

    font-size: 26px;
}

.certificate-empty h2 {
    margin: 0 0 8px;

    color: #111827;

    font-size: 1.25rem;
    font-weight: 800;
}

.certificate-empty p {
    max-width: 500px;

    margin: auto;

    color: #64748b;

    font-size: .85rem;

    line-height: 1.7;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 767px) {

    .certificate-page {
        padding: 25px 0 55px;
    }

    .certificate-hero {
        padding: 30px 23px;
        border-radius: 20px;
    }

    .certificate-hero h1 {
        font-size: 2.2rem;
    }

    .certificate-summary {
        align-items: flex-start;
    }

    .certificate-grid {
        grid-template-columns: 1fr;
    }

    .certificate-meta {
        grid-template-columns: 1fr;
    }
}

</style>


<div class="container certificate-page">

    <!-- HERO -->

    <section class="certificate-hero">

        <span class="certificate-label">
            EventSphere Student Portal
        </span>

        <h1>
            My Certificates
        </h1>

        <p>
            View and access certificates earned through
            successfully attending EventSphere events.
            Certificates are available only for verified
            attendance records.
        </p>

    </section>


    <!-- SUMMARY -->

    <div class="certificate-summary">

        <div class="summary-left">

            <div class="summary-icon">
                🎓
            </div>

            <div>

                <strong>
                    Earned Certificates
                </strong>

                <span>
                    Certificates verified against your attendance
                </span>

            </div>

        </div>

        <div class="summary-count">
            <?= $certificateCount ?>
        </div>

    </div>


    <?php if (empty($certificates)): ?>

        <!-- EMPTY -->

        <div class="certificate-empty">

            <div class="empty-icon">
                🎓
            </div>

            <h2>
                No certificates available yet
            </h2>

            <p>
                Certificates are issued only after you successfully
                attend an eligible event. Registering for an event
                alone does not qualify you for a certificate.
            </p>

        </div>

    <?php else: ?>

        <!-- CERTIFICATES -->

        <div class="certificate-grid">

            <?php foreach ($certificates as $certificate): ?>

                <?php

                $issuedDate = !empty($certificate["issued_at"])
                    ? strtotime($certificate["issued_at"])
                    : false;

                $eventDate = !empty($certificate["event_date"])
                    ? strtotime($certificate["event_date"])
                    : false;

                /*
                 * Only allow relative local certificate paths.
                 * This prevents arbitrary external URLs from
                 * being directly trusted by the page.
                 */

                $certificateUrl = trim(
                    (string)($certificate["certificate_url"] ?? "")
                );

                $safeCertificateUrl = "";

                if (
                    $certificateUrl !== "" &&
                    !preg_match(
                        '/^(https?:)?\/\//i',
                        $certificateUrl
                    )
                ) {
                    $safeCertificateUrl = $certificateUrl;
                }

                ?>

                <article class="certificate-card">

                    <div class="certificate-card-top">

                        <div class="certificate-mark">
                            🎓
                        </div>

                        <h2>
                            <?= h($certificate["event_title"]) ?>
                        </h2>

                        <?php if ($eventDate): ?>

                            <div class="certificate-event-date">

                                Event Date:
                                <?= h(date("d M Y", $eventDate)) ?>

                            </div>

                        <?php endif; ?>

                    </div>


                    <div class="certificate-card-body">

                        <div class="verified">

                            <span class="verified-dot"></span>

                            Attendance Verified

                        </div>


                        <div class="certificate-meta">

                            <div class="meta-item">

                                <span>
                                    Certificate No.
                                </span>

                                <strong>
                                    <?= h(
                                        $certificate["certificate_number"]
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Type
                                </span>

                                <strong>
                                    <?= h(
                                        ucfirst(
                                            $certificate["certificate_type"]
                                        )
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Registration
                                </span>

                                <strong>
                                    <?= h(
                                        $certificate["registration_code"]
                                    ) ?>
                                </strong>

                            </div>


                            <div class="meta-item">

                                <span>
                                    Issued
                                </span>

                                <strong>

                                    <?php if ($issuedDate): ?>

                                        <?= h(
                                            date(
                                                "d M Y",
                                                $issuedDate
                                            )
                                        ) ?>

                                    <?php else: ?>

                                        Not specified

                                    <?php endif; ?>

                                </strong>

                            </div>

                        </div>


                        <?php if ($safeCertificateUrl !== ""): ?>

                            <a
                                href="<?= h($safeCertificateUrl) ?>"
                                class="certificate-button"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                View Certificate
                                <span>↗</span>
                            </a>

                        <?php else: ?>

                            <div
                                style="
                                    padding:12px;
                                    border-radius:12px;
                                    background:#f8fafc;
                                    color:#64748b;
                                    font-size:.75rem;
                                    text-align:center;
                                "
                            >
                                Certificate file is currently unavailable.
                            </div>

                        <?php endif; ?>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>


<?php require "footer.php"; ?>