
<?php

require_once __DIR__ . "/db.php";

$title = "Events";

/*
|--------------------------------------------------------------------------
| Search
|--------------------------------------------------------------------------
*/

$search = trim($_GET["q"] ?? "");
$searchSafe = mysqli_real_escape_string($conn, $search);


/*
|--------------------------------------------------------------------------
| Events Query
|--------------------------------------------------------------------------
|
| LEFT JOIN is intentional.
| Agar category, department ya venue ka relation missing ho,
| event phir bhi events page par show hoga.
|
*/

$sql = "
    SELECT
        e.event_id,
        e.title,
        e.short_description,
        e.description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.max_capacity,
        e.event_status,

        COALESCE(c.category_name, 'General') AS category_name,
        COALESCE(d.department_name, 'All Departments') AS department_name,
        COALESCE(v.venue_name, 'Venue TBA') AS venue_name,

        COUNT(
            CASE
                WHEN r.status IN ('confirmed', 'attended')
                THEN r.registration_id
            END
        ) AS registered_count

    FROM events AS e

    LEFT JOIN event_categories AS c
        ON c.category_id = e.category_id

    LEFT JOIN departments AS d
        ON d.department_id = e.department_id

    LEFT JOIN venues AS v
        ON v.venue_id = e.venue_id

    LEFT JOIN event_registrations AS r
        ON r.event_id = e.event_id

    WHERE e.event_status = 'published'
";


/*
|--------------------------------------------------------------------------
| Search Filter
|--------------------------------------------------------------------------
*/

if ($search !== "") {

    $sql .= "
        AND (
            e.title LIKE '%$searchSafe%'
            OR e.short_description LIKE '%$searchSafe%'
            OR e.description LIKE '%$searchSafe%'
            OR c.category_name LIKE '%$searchSafe%'
            OR d.department_name LIKE '%$searchSafe%'
            OR v.venue_name LIKE '%$searchSafe%'
        )
    ";
}


/*
|--------------------------------------------------------------------------
| Group + Sorting
|--------------------------------------------------------------------------
*/

$sql .= "
    GROUP BY
        e.event_id,
        e.title,
        e.short_description,
        e.description,
        e.event_date,
        e.start_time,
        e.end_time,
        e.max_capacity,
        e.event_status,
        c.category_name,
        d.department_name,
        v.venue_name

    ORDER BY
        e.event_date ASC,
        e.start_time ASC
";


/*
|--------------------------------------------------------------------------
| Execute Query
|--------------------------------------------------------------------------
*/

$result = mysqli_query($conn, $sql);

if (!$result) {
    die(
        "Unable to load events: " .
        htmlspecialchars(mysqli_error($conn), ENT_QUOTES, "UTF-8")
    );
}


/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
|
| Use a unique function name so it does not conflict with functions.php.
|
*/

if (!function_exists("events_clean")) {

    function events_clean($value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            "UTF-8"
        );
    }
}


$totalEvents = mysqli_num_rows($result);


/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/header.php";

?>

<style>

/* =========================================================
   EVENTSPHERE - EVENTS PAGE
   ========================================================= */

.events-page {
    padding: 55px 0 80px;
}


/* ---------------------------------------------------------
   Page Header
   --------------------------------------------------------- */

.events-heading {
    margin-bottom: 38px;
}

.events-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 7px 14px;

    border-radius: 50px;

    background: rgba(13, 110, 253, 0.09);

    color: #0d6efd;

    font-size: 12px;
    font-weight: 700;

    text-transform: uppercase;
    letter-spacing: 1px;
}

.events-heading h1 {
    margin: 14px 0 10px;

    font-size: clamp(32px, 5vw, 48px);

    font-weight: 800;

    letter-spacing: -1.5px;

    color: #111827;
}

.events-heading p {
    max-width: 650px;

    margin: 0;

    color: #6b7280;

    font-size: 16px;

    line-height: 1.7;
}


/* ---------------------------------------------------------
   Search
   --------------------------------------------------------- */

.event-search {
    position: relative;

    max-width: 470px;

    margin-left: auto;
}

.event-search input {
    width: 100%;

    min-height: 54px;

    padding: 0 125px 0 20px;

    border: 1px solid #e5e7eb;

    border-radius: 14px;

    background: #ffffff;

    color: #111827;

    font-size: 14px;

    outline: none;

    box-shadow:
        0 5px 20px rgba(15, 23, 42, 0.05);

    transition: all 0.25s ease;
}

.event-search input:focus {
    border-color: #0d6efd;

    box-shadow:
        0 0 0 4px rgba(13, 110, 253, 0.10);
}

.event-search button {
    position: absolute;

    top: 6px;
    right: 6px;

    height: 42px;

    padding: 0 20px;

    border: 0;

    border-radius: 10px;

    background: #111827;

    color: #ffffff;

    font-size: 14px;

    font-weight: 600;

    cursor: pointer;

    transition: all 0.25s ease;
}

.event-search button:hover {
    background: #0d6efd;

    transform: translateY(-1px);
}


/* ---------------------------------------------------------
   Results
   --------------------------------------------------------- */

.events-results {
    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

    margin-bottom: 24px;

    padding-bottom: 16px;

    border-bottom: 1px solid #eef0f3;
}

.results-count {
    color: #6b7280;

    font-size: 14px;
}

.results-count strong {
    color: #111827;
}


/* ---------------------------------------------------------
   Event Card
   --------------------------------------------------------- */

.event-card {
    position: relative;

    height: 100%;

    padding: 0 !important;

    overflow: hidden;

    border: 1px solid #edf0f4 !important;

    border-radius: 20px !important;

    background: #ffffff;

    box-shadow:
        0 8px 30px rgba(15, 23, 42, 0.055) !important;

    transition:
        transform 0.35s ease,
        box-shadow 0.35s ease,
        border-color 0.35s ease;
}

.event-card:hover {
    transform: translateY(-8px);

    border-color:
        rgba(13, 110, 253, 0.18) !important;

    box-shadow:
        0 20px 45px rgba(15, 23, 42, 0.12) !important;
}


/* ---------------------------------------------------------
   Card Top
   --------------------------------------------------------- */

.event-card-top {
    position: relative;

    min-height: 92px;

    padding: 22px;

    background:
        linear-gradient(
            135deg,
            #f8fbff 0%,
            #eef5ff 100%
        );

    border-bottom: 1px solid #eef2f7;
}

.event-category {
    display: inline-flex;

    align-items: center;

    max-width: calc(100% - 70px);

    padding: 7px 11px;

    border-radius: 8px;

    background: #ffffff;

    color: #0d6efd;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 0.5px;

    box-shadow:
        0 4px 12px rgba(13, 110, 253, 0.08);
}


/* ---------------------------------------------------------
   Date Badge
   --------------------------------------------------------- */

.event-date-badge {
    position: absolute;

    top: 18px;
    right: 18px;

    width: 52px;

    text-align: center;

    overflow: hidden;

    border-radius: 12px;

    background: #ffffff;

    box-shadow:
        0 5px 18px rgba(15, 23, 42, 0.09);
}

.event-date-month {
    display: block;

    padding: 4px;

    background: #0d6efd;

    color: #ffffff;

    font-size: 9px;

    font-weight: 800;

    text-transform: uppercase;
}

.event-date-day {
    display: block;

    padding: 7px 0;

    color: #111827;

    font-size: 18px;

    font-weight: 800;
}


/* ---------------------------------------------------------
   Card Body
   --------------------------------------------------------- */

.event-card-body {
    padding: 24px;
}

.event-card-title {
    margin: 0 0 10px;

    color: #111827;

    font-size: 20px;

    font-weight: 750;

    line-height: 1.35;

    letter-spacing: -0.4px;
}

.event-card-description {
    min-height: 50px;

    margin-bottom: 20px;

    color: #6b7280;

    font-size: 14px;

    line-height: 1.65;
}


/* ---------------------------------------------------------
   Event Meta
   --------------------------------------------------------- */

.event-meta {
    display: flex;

    flex-direction: column;

    gap: 10px;

    margin-bottom: 22px;
}

.event-meta-item {
    display: flex;

    align-items: center;

    gap: 10px;

    color: #596273;

    font-size: 13px;

    min-width: 0;
}

.event-meta-item > span:last-child {
    overflow-wrap: anywhere;
}

.event-meta-icon {
    display: flex;

    align-items: center;

    justify-content: center;

    width: 30px;
    height: 30px;

    flex: 0 0 30px;

    border-radius: 9px;

    background: #f4f7fb;

    color: #0d6efd;

    font-size: 12px;
}


/* ---------------------------------------------------------
   Capacity
   --------------------------------------------------------- */

.capacity-box {
    margin-bottom: 20px;

    padding: 13px 14px;

    border-radius: 12px;

    background: #f8fafc;
}

.capacity-top {
    display: flex;

    justify-content: space-between;

    gap: 10px;

    margin-bottom: 7px;

    font-size: 12px;
}

.capacity-label {
    color: #6b7280;
}

.capacity-number {
    color: #111827;

    font-weight: 700;
}

.capacity-bar {
    height: 6px;

    overflow: hidden;

    border-radius: 20px;

    background: #e5e7eb;
}

.capacity-fill {
    height: 100%;

    border-radius: inherit;

    background:
        linear-gradient(
            90deg,
            #0d6efd,
            #5b9cff
        );

    transition: width 0.5s ease;
}


/* ---------------------------------------------------------
   Button
   --------------------------------------------------------- */

.event-details-btn {
    display: flex;

    align-items: center;

    justify-content: center;

    width: 100%;

    min-height: 46px;

    border-radius: 11px;

    background: #111827;

    color: #ffffff;

    text-decoration: none;

    font-size: 13px;

    font-weight: 700;

    transition: all 0.25s ease;
}

.event-details-btn:hover {
    background: #0d6efd;

    color: #ffffff;

    transform: translateY(-2px);
}


/* ---------------------------------------------------------
   Empty State
   --------------------------------------------------------- */

.empty-events {
    padding: 70px 20px;

    text-align: center;

    border: 1px dashed #dce1e8;

    border-radius: 20px;

    background: #fafbfc;
}

.empty-icon {
    display: flex;

    align-items: center;

    justify-content: center;

    width: 70px;
    height: 70px;

    margin: 0 auto 20px;

    border-radius: 50%;

    background: #eef5ff;

    color: #0d6efd;

    font-size: 25px;
}

.empty-events h3 {
    margin-bottom: 8px;

    color: #111827;

    font-size: 20px;

    font-weight: 750;
}

.empty-events p {
    margin: 0;

    color: #6b7280;

    font-size: 14px;

    line-height: 1.7;
}


/* ---------------------------------------------------------
   Responsive
   --------------------------------------------------------- */

@media (max-width: 767px) {

    .events-page {
        padding: 35px 0 55px;
    }

    .events-heading {
        margin-bottom: 25px;
    }

    .events-heading h1 {
        font-size: 34px;
    }

    .event-search {
        max-width: none;

        margin-top: 22px;
    }

    .events-results {
        margin-top: 25px;
    }

    .event-card-body {
        padding: 20px;
    }
}

</style>


<div class="container events-page">

    <!-- =====================================================
         PAGE INTRO
         ===================================================== -->

    <div class="row align-items-end events-heading">

        <div class="col-lg-7">

            <div class="events-eyebrow">
                <span>●</span>
                EventSphere
            </div>

            <h1>
                Discover Events
            </h1>

            <p>
                Find upcoming events, workshops, competitions,
                seminars and activities happening across campus.
            </p>

        </div>


        <div class="col-lg-5">

            <form
                method="GET"
                action="events.php"
                class="event-search"
            >

                <input
                    type="search"
                    name="q"
                    value="<?= events_clean($search) ?>"
                    placeholder="Search events, categories, venues..."
                    autocomplete="off"
                >

                <button type="submit">
                    Search
                </button>

            </form>

        </div>

    </div>


    <!-- =====================================================
         RESULT INFORMATION
         ===================================================== -->

    <div class="events-results">

        <div class="results-count">

            Showing

            <strong>
                <?= $totalEvents ?>
            </strong>

            <?= $totalEvents === 1 ? "event" : "events" ?>

            <?php if ($search !== ""): ?>

                for

                <strong>
                    "<?= events_clean($search) ?>"
                </strong>

            <?php endif; ?>

        </div>

    </div>


    <!-- =====================================================
         EVENTS
         ===================================================== -->

    <?php if ($totalEvents > 0): ?>

        <div class="row g-4">

            <?php while ($event = mysqli_fetch_assoc($result)): ?>

                <?php

                /*
                |--------------------------------------------------------------------------
                | Capacity
                |--------------------------------------------------------------------------
                */

                $capacity = (int)$event["max_capacity"];

                $registered = (int)$event["registered_count"];

                $remaining = max(
                    0,
                    $capacity - $registered
                );

                if ($capacity > 0) {

                    $percentage = round(
                        ($registered / $capacity) * 100
                    );

                    $percentage = min(
                        100,
                        max(0, $percentage)
                    );

                } else {

                    $percentage = 0;
                }


                /*
                |--------------------------------------------------------------------------
                | Date
                |--------------------------------------------------------------------------
                */

                $eventTimestamp = strtotime(
                    $event["event_date"]
                );

                if ($eventTimestamp === false) {
                    $eventTimestamp = time();
                }

                $month = date(
                    "M",
                    $eventTimestamp
                );

                $day = date(
                    "d",
                    $eventTimestamp
                );

                $formattedDate = date(
                    "D, d M Y",
                    $eventTimestamp
                );


                /*
                |--------------------------------------------------------------------------
                | Time
                |--------------------------------------------------------------------------
                */

                $startTimestamp = strtotime(
                    $event["start_time"]
                );

                $endTimestamp = strtotime(
                    $event["end_time"]
                );

                $formattedStartTime =
                    $startTimestamp !== false
                    ? date("g:i A", $startTimestamp)
                    : events_clean($event["start_time"]);

                $formattedEndTime =
                    $endTimestamp !== false
                    ? date("g:i A", $endTimestamp)
                    : events_clean($event["end_time"]);

                ?>

                <div class="col-xl-4 col-md-6">

                    <article class="event-card">

                        <!-- Card Header -->

                        <div class="event-card-top">

                            <span class="event-category">
                                <?= events_clean($event["category_name"]) ?>
                            </span>


                            <div class="event-date-badge">

                                <span class="event-date-month">
                                    <?= events_clean($month) ?>
                                </span>

                                <span class="event-date-day">
                                    <?= events_clean($day) ?>
                                </span>

                            </div>

                        </div>


                        <!-- Card Content -->

                        <div class="event-card-body">

                            <h2 class="event-card-title">
                                <?= events_clean($event["title"]) ?>
                            </h2>


                            <p class="event-card-description">

                                <?= events_clean(
                                    $event["short_description"]
                                ) ?>

                            </p>


                            <!-- Event Information -->

                            <div class="event-meta">

                                <div class="event-meta-item">

                                    <span class="event-meta-icon">
                                        📅
                                    </span>

                                    <span>
                                        <?= events_clean($formattedDate) ?>
                                    </span>

                                </div>


                                <div class="event-meta-item">

                                    <span class="event-meta-icon">
                                        🕐
                                    </span>

                                    <span>
                                        <?= events_clean($formattedStartTime) ?>
                                        –
                                        <?= events_clean($formattedEndTime) ?>
                                    </span>

                                </div>


                                <div class="event-meta-item">

                                    <span class="event-meta-icon">
                                        📍
                                    </span>

                                    <span>
                                        <?= events_clean($event["venue_name"]) ?>
                                    </span>

                                </div>


                                <div class="event-meta-item">

                                    <span class="event-meta-icon">
                                        🏢
                                    </span>

                                    <span>
                                        <?= events_clean($event["department_name"]) ?>
                                    </span>

                                </div>

                            </div>


                            <!-- Capacity -->

                            <div class="capacity-box">

                                <div class="capacity-top">

                                    <span class="capacity-label">
                                        Available seats
                                    </span>

                                    <span class="capacity-number">

                                        <?php if ($capacity <= 0): ?>

                                            Unlimited

                                        <?php elseif ($remaining > 0): ?>

                                            <?= $remaining ?>
                                            /
                                            <?= $capacity ?>

                                        <?php else: ?>

                                            Full

                                        <?php endif; ?>

                                    </span>

                                </div>


                                <div class="capacity-bar">

                                    <div
                                        class="capacity-fill"
                                        style="width: <?= $percentage ?>%;"
                                    ></div>

                                </div>

                            </div>


                            <!-- Details -->

                            <a
                                href="event-details.php?id=<?= (int)$event["event_id"] ?>"
                                class="event-details-btn"
                            >

                                View Event Details

                                <span class="ms-2">
                                    →
                                </span>

                            </a>

                        </div>

                    </article>

                </div>

            <?php endwhile; ?>

        </div>


    <?php else: ?>

        <!-- =================================================
             EMPTY RESULT
             ================================================= -->

        <div class="empty-events">

            <div class="empty-icon">
                🔎
            </div>

            <h3>
                No events found
            </h3>

            <p>

                <?php if ($search !== ""): ?>

                    We couldn't find any event matching
                    "<strong><?= events_clean($search) ?></strong>".

                <?php else: ?>

                    There are currently no published events available.

                <?php endif; ?>

            </p>

        </div>

    <?php endif; ?>

</div>


<?php

/*
|--------------------------------------------------------------------------
| Footer
|--------------------------------------------------------------------------
*/

require_once __DIR__ . "/footer.php";

?>
